import json, numpy as np
from engine_v2 import load_kb
exec(open("evaluate_v2.py").read().split("res = {")[0].split("core = load_kb")[0])  # imports only
tau = json.load(open("../results_part2.json"))["tau"]
out = {}
for label, keep, pc in [("yes/no only", lambda q: not (q == "part" or q.startswith("pic_")), .6),
                        ("+ plant part", lambda q: not q.startswith("pic_"), .6),
                        ("+ part + picture (farmer picks right 40%)", lambda q: True, .4),
                        ("+ part + picture (farmer picks right 60%)", lambda q: True, .6)]:
    core = load_kb("knowledge_v2.json", tau=tau, pic_correct=pc, max_q=4)
    core.qids = [q for q in core.qids if keep(q)]
    FE = .1; row = {}
    for crop in ["rice", "chilli", "groundnut", "tomato"]:
        ids = [i for i, c in enumerate(core.crops) if c == crop]; rng = np.random.default_rng(0); ok = N = 0
        for rep in range(300):
            for y in ids:
                st = core.start(crop)
                while True:
                    q, g = core.next_question(st)
                    if q is None: break
                    T = core.theta[q][y].copy(); K = len(T)
                    if K == 2: T = (T - FE) / (1 - 2 * FE)
                    elif q == "part": T = (T - FE / K) / (1 - FE)
                    T = np.clip(T, 1e-9, None); T /= T.sum(); k = rng.choice(K, p=T)
                    if rng.random() < .15: k = rng.integers(K)
                    core.answer(st, q, int(k))
                ok += core.names.index(core.result(st)["top"][0][0]) == y; N += 1
        row[crop] = round(ok / N, 3)
    out[label] = row; print(f"{label:45s}", row)
json.dump(out, open("results_ablation.json", "w"), indent=1)
