import json, numpy as np
from engine_v2 import load_kb
V = "/home/claude/agri_vision"; C = "/home/claude/data/cache"
tau = json.load(open("../results_part2.json"))["tau"]
core = load_kb("knowledge_v2.json", tau=tau); kb = core.kb
FE = 0.1
err0 = {}; k0 = {}
for q in core.qids:
    K = len(core.opts[q])
    if K == 2: err0[q] = np.array([FE, FE]); k0[q] = 2 * FE
    elif q == "part": err0[q] = FE / K; k0[q] = FE
    else: err0[q] = 0.0; k0[q] = 0.0

def simulate(core, y, crop, cos=None, err=0.15, rng=None, max_q=None, jitter=None):
    if max_q: core.max_q = max_q
    st = core.start(crop, cos)
    while True:
        q, g = core.next_question(st)
        if q is None: break
        T = core.theta[q] if jitter is None else jitter[q]
        clean = (T[y] - err0[q]) / (1 - k0[q]) if jitter is None else T[y]   # strip modelled farmer noise
        clean = np.clip(clean, 1e-9, None); clean = clean / clean.sum()
        k = rng.choice(len(clean), p=clean)
        if rng.random() < err: k = rng.integers(len(clean))                   # farmer mistake: random option
        core.answer(st, q, int(k))
    r = core.result(st); return core.names.index(r["top"][0][0]) == y, r["status"] == "ok", len(r["asked"])

res = {"tau": tau}
# A) questions only (no vision model yet) for the Indian crops, simulated farmers
for crop in ["rice", "chilli", "groundnut", "tomato"]:
    ids = [i for i, c in enumerate(core.crops) if c == crop]
    for mq in [3, 4]:
        for err in [0.15, 0.30]:
            rng = np.random.default_rng(0); ok = ans = nq = cor_ans = 0; N = 0
            for rep in range(300):
                for y in ids:
                    c, a, n = simulate(core, y, crop, err=err, rng=rng, max_q=mq); N += 1
                    ok += c; ans += a; nq += n; cor_ans += c and a
            res[f"A_questions_only/{crop}/maxq{mq}/err{int(err*100)}"] = dict(n_diseases=len(ids), top1=round(ok/N, 3), answered=round(ans/N, 3),
                acc_when_answered=round(cor_ans/max(ans, 1), 3), avg_q=round(nq/N, 2))
# robustness: real symptoms differ from table
for crop in ["rice", "chilli", "groundnut"]:
    ids = [i for i, c in enumerate(core.crops) if c == crop]; rng = np.random.default_rng(1); ok = N = 0
    for rep in range(300):
        jit = {}
        for q in core.qids:
            T = np.clip(core.theta[q] + rng.normal(0, 0.2, core.theta[q].shape), .01, None); jit[q] = T / T.sum(1, keepdims=True)
        for y in ids: c, a, n = simulate(core, y, crop, err=.15, rng=rng, max_q=4, jitter=jit); ok += c; N += 1
    res[f"A_robust_sd0.2/{crop}/maxq4/err15"] = round(ok/N, 3)
# B) tomato WITH the Part 1 vision model, real test photos
classes = json.load(open(f"{C}/classes.json")); E = np.load(f"{V}/embeddings.npz")
base = json.load(open(f"{V}/fingerprints_base.json")) + ["Tomato leaf yellow virus"]
F = np.vstack([np.load(f"{V}/fingerprints_base.npy"), np.load(f"{V}/fp_new_disease.npy")]).astype(np.float32)
vc2kb = {e["vision_class"]: core.names.index(k) for k, e in kb["diseases"].items() if e.get("vision_class")}
yte = np.load(f"{C}/test.npz")["y"]; tomato = [i for i, c in enumerate(yte) if classes[c] in vc2kb]
for err in [0.15, 0.30]:
    for use_q in [False, True]:
        rng = np.random.default_rng(0); ok = ans = nq = 0
        for i in tomato:
            s = E["Zte"][i] @ F.T; cos = np.full(len(core.names), -1.0)
            for vc, k in vc2kb.items(): cos[k] = s[base.index(vc)]
            y = vc2kb[classes[yte[i]]]
            if use_q: c, a, n = simulate(core, y, "tomato", cos=cos, err=err, rng=rng, max_q=3)
            else:
                st = core.start("tomato", cos); r = core.result(st); c = core.names.index(r["top"][0][0]) == y; a = r["status"] == "ok"; n = 0
            ok += c; ans += a; nq += n
        res[f"B_tomato_vision{'+questions' if use_q else '_only(crop known)'}/err{int(err*100)}"] = dict(
            n_photos=len(tomato), top1=round(ok/len(tomato), 3), answered=round(ans/len(tomato), 3), avg_q=round(nq/len(tomato), 2))
json.dump(res, open("results_v2.json", "w"), indent=1); print(json.dumps(res, indent=1))
