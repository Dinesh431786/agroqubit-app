"""Doctor v2: Bayesian diagnosis with yes/no AND multi-choice questions (plant part, picture match),
driven by knowledge_v2.json. Pure math in DoctorCore is mirrored exactly by the Java port."""
import json, numpy as np

KCC = "1800-180-1551"

class DoctorCore:
    """questions: list of (qid, options); theta[q] = array [n_diseases, n_options] of P(option | disease)."""
    def __init__(self, names, crops, questions, theta, q_crop=None, tau=0.12, stop_p=0.85, max_q=3, min_gain=0.05, final_min_p=0.5):
        self.names, self.crops = list(names), list(crops)
        self.qids = [q for q, _ in questions]; self.opts = {q: o for q, o in questions}
        self.theta = {q: np.asarray(theta[q], float) for q in self.qids}
        self.q_crop = q_crop or {}          # question only valid for this crop (e.g. picture grid)
        self.tau, self.stop_p, self.max_q, self.min_gain, self.final_min_p = tau, stop_p, max_q, min_gain, final_min_p

    def start(self, crop=None, cos_scores=None):
        p = np.array([1.0 if (crop is None or c == crop) else 0.0 for c in self.crops])
        if cos_scores is not None:
            s = np.asarray(cos_scores, float); m = np.max(s[p > 0])
            p = p * np.exp((s - m) / self.tau)
        return {"post": p / p.sum(), "asked": [], "answers": {}, "crop": crop}

    @staticmethod
    def H(p):
        h = 0.0
        for x in p:
            if x > 0: h -= x * np.log2(x)
        return h

    def gain(self, p, q):
        T = self.theta[q]; h0 = self.H(p); g = h0
        for k in range(T.shape[1]):
            pk = float(np.dot(p, T[:, k]))
            if pk > 1e-12: g -= pk * self.H(p * T[:, k] / pk)
        return g

    def next_question(self, st, skip=()):
        p = st["post"]
        if p.max() >= self.stop_p or len(st["asked"]) >= self.max_q: return None, 0.0
        best, bg = None, 0.0
        for q in self.qids:
            if q in st["asked"] or q in skip: continue
            if q in self.q_crop and self.q_crop[q] != st["crop"]: continue
            g = self.gain(p, q)
            if g > bg + 1e-12: best, bg = q, g
        return (best, bg) if bg >= self.min_gain else (None, bg)

    def answer(self, st, q, opt_index):     # opt_index None = "don't know"
        st["asked"].append(q); st["answers"][q] = None if opt_index is None else self.opts[q][opt_index]
        if opt_index is None: return st
        p = st["post"] * self.theta[q][:, opt_index]; st["post"] = p / p.sum(); return st

    def result(self, st, k=3):
        o = np.argsort(-st["post"], kind="stable")[:k]
        top = [(self.names[i], float(st["post"][i])) for i in o]
        return {"status": "ok" if top[0][1] >= self.final_min_p else "not_sure", "top": top, "asked": list(st["asked"])}

PARTS = ["leaf", "stem_or_sheath", "grain_or_fruit", "whole_plant_yellow_stunted"]

def load_kb(path, farmer_err=0.1, pic_correct=0.6, **kw):
    kb = json.load(open(path)); d = kb["defaults"]; names = list(kb["diseases"]); n = len(names)
    crops = [kb["diseases"][x]["crop"] for x in names]
    questions, theta, q_crop = [], {}, {}
    # 1) plant-part multi-choice
    T = np.zeros((n, len(PARTS)))
    for i, x in enumerate(names):
        part = kb["diseases"][x].get("part", {"leaf": 1.0})
        T[i] = [part.get(o, 0.0) for o in PARTS]; T[i] = T[i] / T[i].sum()
    questions.append(("part", PARTS)); theta["part"] = (1 - farmer_err) * T + farmer_err / len(PARTS)
    # 2) picture-match grid per crop: options = that crop's diseases + 'none look like mine'
    for crop in sorted(set(crops)):
        ids = [i for i, c in enumerate(crops) if c == crop]; opts = [names[i] for i in ids] + ["none"]
        T = np.full((n, len(opts)), 1.0 / len(opts))
        for r, i in enumerate(ids):
            T[i] = (1 - pic_correct) / len(opts); T[i, r] += pic_correct
        q = f"pic_{crop}"; questions.append((q, opts)); theta[q] = T; q_crop[q] = crop
    # 3) yes/no symptom + context questions
    for q, meta in kb["questions"].items():
        t = np.zeros(n)
        for i, x in enumerate(names):
            e = kb["diseases"][x]
            if e.get("healthy"):
                t[i] = d["healthy_q_if_healthy"] if q == "healthy" else (d["symptom_if_healthy"] if meta["type"] == "symptom" else d["context_if_healthy"])
            else:
                t[i] = e["p"].get(q, d["healthy_q_if_diseased"] if q == "healthy" else (d["symptom_absent"] if meta["type"] == "symptom" else d["context_base"]))
        t = farmer_err + (1 - 2 * farmer_err) * t
        questions.append((q, ["yes", "no"])); theta[q] = np.stack([t, 1 - t], 1)
    core = DoctorCore(names, crops, questions, theta, q_crop, **kw); core.kb = kb
    return core

def export_flat(core, path):
    """Flat JSON the phone loads (no Python needed): names, crops, questions, options, theta, q_crop, params."""
    json.dump({"names": core.names, "crops": core.crops, "qids": core.qids, "options": [core.opts[q] for q in core.qids],
               "theta": [core.theta[q].tolist() for q in core.qids], "q_crop": core.q_crop,
               "params": dict(tau=core.tau, stop_p=core.stop_p, max_q=core.max_q, min_gain=core.min_gain, final_min_p=core.final_min_p)},
              open(path, "w"))
