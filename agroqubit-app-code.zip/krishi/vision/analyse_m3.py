import json, sys, numpy as np, torch
sys.path.insert(0, "."); from profiles import SYM, HOLDOUT
CK = sys.argv[1]; C = "/home/claude/data/cache"; classes = json.load(open(f"{C}/classes.json"))
E = np.load(CK.replace(".pt", "_emb.npz")); ck = torch.load(CK, weights_only=False); ho = ck["ho"]
ytr, yte = np.load(f"{C}/train.npz")["y"], np.load(f"{C}/test.npz")["y"]
A = np.concatenate([E["Atr"], E["Ate"]]); y = np.concatenate([ytr, yte])
DEF = {"Potato leaf early blight": "target_rings", "Potato leaf late blight": "dark_wet_patches", "Corn rust leaf": "orange_pustules_underside", "Tomato leaf yellow virus": "leaf_curl_crinkle_stunt"}
from sklearn.metrics import roc_auc_score
for h, s in DEF.items():
    c = classes.index(h); k = SYM.index(s); pos = A[y == c, k]; neg = A[~np.isin(y, ho), k]
    print(f"{h:28s} defining '{s}': mean prob on its photos {pos.mean():.2f} vs other photos {neg.mean():.2f}  AUC {roc_auc_score(np.r_[np.ones(len(pos)), np.zeros(len(neg))], np.r_[pos, neg]):.3f}")
