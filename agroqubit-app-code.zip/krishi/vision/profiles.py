"""Symptom profiles (in the shared meaning-slot space) for the PlantDoc vision classes: P(symptom visible | disease).
Used to train the vision 'symptom head'. Engineering estimates from standard symptom descriptions (review needed)."""
SYM = ["healthy", "target_rings", "small_grey_centre", "water_soaked_yellow_halo", "dark_wet_patches", "white_powder_underside",
       "underside_olive_mold", "leaf_curl_crinkle_stunt", "mosaic_mottle", "orange_pustules_underside", "black_spots_no_halo",
       "eye_shaped_grey_centre", "round_brown_spots", "light_brown_spot_yellow_halo"]
H = {"healthy": .95}
P = {
 "Apple Scab Leaf": {"black_spots_no_halo": .8, "round_brown_spots": .2},
 "Apple leaf": H, "Apple rust leaf": {"orange_pustules_underside": .85, "light_brown_spot_yellow_halo": .2},
 "Bell_pepper leaf": H, "Bell_pepper leaf spot": {"water_soaked_yellow_halo": .8, "small_grey_centre": .3},
 "Blueberry leaf": H, "Cherry leaf": H,
 "Corn Gray leaf spot": {"eye_shaped_grey_centre": .6, "small_grey_centre": .2},
 "Corn leaf blight": {"eye_shaped_grey_centre": .8, "dark_wet_patches": .1},
 "Corn rust leaf": {"orange_pustules_underside": .9},
 "Peach leaf": H,
 "Potato leaf early blight": {"target_rings": .85, "light_brown_spot_yellow_halo": .2},
 "Potato leaf late blight": {"dark_wet_patches": .9, "white_powder_underside": .15},
 "Raspberry leaf": H, "Soyabean leaf": H,
 "Squash Powdery mildew leaf": {"white_powder_underside": .9},
 "Strawberry leaf": H,
 "Tomato Early blight leaf": {"target_rings": .85, "light_brown_spot_yellow_halo": .2},
 "Tomato Septoria leaf spot": {"small_grey_centre": .85, "round_brown_spots": .2},
 "Tomato leaf": H,
 "Tomato leaf bacterial spot": {"water_soaked_yellow_halo": .8, "small_grey_centre": .2},
 "Tomato leaf late blight": {"dark_wet_patches": .9, "white_powder_underside": .15},
 "Tomato leaf mosaic virus": {"mosaic_mottle": .85, "leaf_curl_crinkle_stunt": .25},
 "Tomato leaf yellow virus": {"leaf_curl_crinkle_stunt": .9, "mosaic_mottle": .15},
 "Tomato mold leaf": {"underside_olive_mold": .85},
 "grape leaf": H, "grape leaf black rot": {"small_grey_centre": .4, "round_brown_spots": .5, "black_spots_no_halo": .3},
}
def profile(name):
    p = P[name]; return [p.get(s, 0.92 if (s == "healthy" and p is H) else (0.03 if s == "healthy" else 0.04)) for s in SYM]
# New diseases are defined ONLY by text (sourced descriptions; ICAR/NIPHM/TNAU wording), in more than one language.
HOLDOUT = ["Potato leaf early blight", "Potato leaf late blight", "Corn rust leaf", "Tomato leaf yellow virus"]
TEXT_DEF = {
 "Potato leaf early blight": ["small black lesions mostly on the older leaves with concentric rings in a bull's eye pattern",
                              "पुरानी पत्तियों पर छोटे काले धब्बे जिनमें निशाने जैसे गोल छल्ले हैं"],
 "Potato leaf late blight": ["large dark water soaked patches on leaves spreading fast in cool wet weather",
                             "ठंडे नम मौसम में पत्तियों पर बड़े गहरे गीले धब्बे तेज़ी से फैलते हैं"],
 "Corn rust leaf": ["raised orange rust coloured pustules on the leaves that leave powder on the finger",
                    "இலைகளில் விரலில் தூள் ஒட்டும் ஆரஞ்சு துரு நிறக் கொப்புளங்கள்"],
 "Tomato leaf yellow virus": ["severe stunting of the plants with downward rolling and crinkling of the leaves, leathery and brittle",
                              "ಗಿಡ ತುಂಬಾ ಕುಂಠಿತ, ಎಲೆಗಳು ಕೆಳಗೆ ಸುರುಳಿಯಾಗಿ ಮುದುರಿ ದಪ್ಪ ಮತ್ತು ಸುಲಭವಾಗಿ ಮುರಿಯುತ್ತವೆ"],
}
