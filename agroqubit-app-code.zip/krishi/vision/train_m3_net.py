import sys, torch, torch.nn as nn, torch.nn.functional as F
sys.path.insert(0, "/home/claude/agri_vision"); sys.path.insert(0, "/home/claude/krishi/vision")
from model import Embedder
from profiles import SYM
W = "/home/claude/weights/mnv3.pth"
class Net(nn.Module):
    def __init__(s):
        super().__init__(); s.emb = Embedder(W); s.sym = nn.Linear(256, len(SYM))
    def forward(s, x):
        h = s.emb.proj(s.emb.backbone((x - s.emb.mean) / s.emb.std)); z = F.normalize(h, dim=-1)
        return h, z, s.sym(z)
