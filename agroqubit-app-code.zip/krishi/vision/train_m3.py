"""Vision encoder v2: fingerprint (CosFace) + symptom head (into the shared meaning slots) + optional SIGReg (LeJEPA).
4 diseases are held out completely (no photos in training) to test add-from-text and add-from-photos."""
import json, time, math, sys, numpy as np, torch, torch.nn as nn, torch.nn.functional as F
sys.path.insert(0, "/home/claude/agri_vision"); sys.path.insert(0, "."); from model import Embedder, CosineHead
from profiles import SYM, profile, HOLDOUT
LAM = float(sys.argv[1]); SEED = int(sys.argv[2]); EPOCHS = int(sys.argv[3]) if len(sys.argv) > 3 else 15
torch.manual_seed(SEED); np.random.seed(SEED); torch.set_num_threads(2)
C = "/home/claude/data/cache"; W = "/home/claude/weights/mnv3.pth"; OUT = f"/home/claude/krishi/vision/m3_sig{LAM}_s{SEED}.pt"
classes = json.load(open(f"{C}/classes.json")); ho = [classes.index(h) for h in HOLDOUT]
tr = np.load(f"{C}/train.npz"); X, y = tr["X"], tr["y"]
rng = np.random.default_rng(0); val = []
for c in range(len(classes)):
    if c in ho: continue
    idx = rng.permutation(np.where(y == c)[0]); val += idx[: max(2, len(idx) // 10)].tolist()
val = np.array(sorted(val)); mask = np.ones(len(y), bool); mask[val] = False; mask[np.isin(y, ho)] = False; tri = np.where(mask)[0]
known = [c for c in range(len(classes)) if c not in ho]; remap = {c: i for i, c in enumerate(known)}
A = torch.tensor([profile(classes[c]) for c in known], dtype=torch.float32)        # symptom targets per known class

def sigreg(h, M=64, T=17):
    """LeJEPA SIGReg: push embeddings toward an isotropic Gaussian via Epps-Pulley tests on random 1-D projections."""
    d = torch.randn(h.shape[1], M, device=h.device); d = d / d.norm(dim=0, keepdim=True)
    p = h @ d; t = torch.linspace(-4, 4, T)
    ang = p[:, :, None] * t; cr, ci = torch.cos(ang).mean(0), torch.sin(ang).mean(0)
    w = torch.exp(-t ** 2 / 2); return (((cr - torch.exp(-t ** 2 / 2)) ** 2 + ci ** 2) * w).mean() * h.shape[0]

def batch(idx, aug):
    x = torch.from_numpy(X[idx]).permute(0, 3, 1, 2).float()
    if not aug: return x[:, :, 16:240, 16:240].contiguous()
    out = torch.empty(len(idx), 3, 224, 224)
    for i in range(len(idx)):
        s = max(120, int(256 * math.sqrt(np.random.uniform(0.45, 1.0)))); t, l = np.random.randint(0, 257 - s, 2)
        im = F.interpolate(x[i:i+1, :, t:t+s, l:l+s], size=224, mode="bilinear", align_corners=False)[0]
        if np.random.rand() < .5: im = im.flip(2)
        if np.random.rand() < .5: im = im.flip(1)
        im = torch.rot90(im, np.random.randint(4), (1, 2))
        im = (im - im.mean()) * np.random.uniform(.75, 1.25) + im.mean() * np.random.uniform(.75, 1.25)
        out[i] = (im * torch.tensor(np.random.uniform(.9, 1.1, 3), dtype=torch.float32).view(3, 1, 1)).clamp(0, 255)
    return out

class Net(nn.Module):
    def __init__(s):
        super().__init__(); s.emb = Embedder(W); s.sym = nn.Linear(256, len(SYM))
    def forward(s, x):
        h = s.emb.proj(s.emb.backbone((x - s.emb.mean) / s.emb.std)); z = F.normalize(h, dim=-1)
        return h, z, s.sym(z)
net = Net().to(memory_format=torch.channels_last); head = CosineHead(len(known))
opt = torch.optim.AdamW([{"params": net.emb.backbone.parameters(), "lr": 4e-4},
                         {"params": list(net.emb.proj.parameters()) + list(net.sym.parameters()) + list(head.parameters()), "lr": 2e-3}], weight_decay=0.02)
BS = 32; steps = EPOCHS * math.ceil(len(tri) / BS); st = 0; base = [g["lr"] for g in opt.param_groups]; t0 = time.time()
for ep in range(EPOCHS):
    net.train(); perm = np.random.permutation(tri); tl = ts = 0
    for i in range(0, len(perm), BS):
        idx = perm[i:i+BS]; yb = torch.tensor([remap[c] for c in y[idx]])
        h, z, s = net(batch(idx, True).to(memory_format=torch.channels_last))
        loss = F.cross_entropy(head(z, yb), yb, label_smoothing=0.1) + 0.5 * F.binary_cross_entropy_with_logits(s, A[yb])
        if LAM > 0: sr = sigreg(h); loss = loss + LAM * sr; ts += sr.item()
        cos = 0.5 * (1 + math.cos(math.pi * st / steps)); warm = min(1, (st + 1) / 30)
        for g, b in zip(opt.param_groups, base): g["lr"] = b * warm * cos
        opt.zero_grad(); loss.backward(); opt.step(); st += 1; tl += loss.item()
    print(f"ep {ep+1} loss {tl/math.ceil(len(perm)/BS):.3f} sigreg {ts/math.ceil(len(perm)/BS):.3f} {time.time()-t0:.0f}s", flush=True)
torch.save({"net": net.state_dict(), "head": head.state_dict(), "known": known, "val": val, "tri": tri, "ho": ho}, OUT)
