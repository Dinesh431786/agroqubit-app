"""M3 evaluation: (1) known-disease accuracy, (2) add a NEW disease from a TEXT description only (zero photos) through the
shared meaning space, (3) from 10 photos, (4) text + 10 photos. Generalised setting: new diseases compete with all known ones.
The 'unseen' bias is calibrated using SEEN validation photos only (no peeking at new-disease photos)."""
import json, sys, numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "/home/claude/agri_vision"); sys.path.insert(0, "/home/claude/krishi/vision"); sys.path.insert(0, "/home/claude/krishi/text")
from train_m3_net import Net
from profiles import SYM, profile, HOLDOUT, TEXT_DEF
from textenc import TextEncoder, pack, pack_windows, mil_logits
torch.set_num_threads(2); CK = sys.argv[1]; C = "/home/claude/data/cache"; K = "/home/claude/krishi"
ck = torch.load(CK, weights_only=False); net = Net(); net.load_state_dict(ck["net"]); net.eval()
classes = json.load(open(f"{C}/classes.json")); known, ho, val, tri = ck["known"], ck["ho"], ck["val"], ck["tri"]
tr, te = np.load(f"{C}/train.npz"), np.load(f"{C}/test.npz")
@torch.no_grad()
def emb(X):
    Z, A = [], []
    for i in range(0, len(X), 64):
        x = torch.from_numpy(X[i:i+64]).permute(0, 3, 1, 2).float()[:, :, 16:240, 16:240]
        _, z1, s1 = net(x); _, z2, s2 = net(x.flip(3)); Z.append(F.normalize(z1 + z2, dim=-1)); A.append(torch.sigmoid((s1 + s2) / 2))
    return torch.cat(Z).numpy(), torch.cat(A).numpy()
import os
cache = CK.replace(".pt", "_emb.npz")
if os.path.exists(cache): E = np.load(cache); Ztr, Atr, Zte, Ate = E["Ztr"], E["Atr"], E["Zte"], E["Ate"]
else:
    Ztr, Atr = emb(tr["X"]); Zte, Ate = emb(te["X"]); np.savez(cache, Ztr=Ztr, Atr=Atr, Zte=Zte, Ate=Ate)
ytr, yte = tr["y"], te["y"]
n = lambda v: v / np.linalg.norm(v, axis=-1, keepdims=True)
FP = {c: n(Ztr[tri][ytr[tri] == c].mean(0)) for c in known}
R = {}
mk = ~np.isin(yte, ho); Mk = np.stack([FP[c] for c in known]); pred = np.array(known)[(Zte[mk] @ Mk.T).argmax(1)]
R["known_test_top1"] = round(float((pred == yte[mk]).mean()), 4)
R["known_test_top3"] = round(float((np.array(known)[np.argsort(-(Zte[mk] @ Mk.T), 1)[:, :3]] == yte[mk][:, None]).any(1).mean()), 4)
# ---- symptom profiles of NEW diseases from TEXT (multilingual) via the text encoder ----
SL = list(json.load(open(f"{K}/slots.json"))); idx = [SL.index(s) for s in SYM]
def text_probs(texts):
    out = []
    for name, mil in [("A", False), ("D", True)]:
        c2 = torch.load(f"{K}/text/enc_{name}_0.pt"); m = TextEncoder(len(SL)); m.load_state_dict(c2["state"]); m.eval()
        with torch.no_grad():
            if mil: i, o, w, h = pack_windows(texts); out.append(torch.sigmoid(mil_logits(m, i, o, w, len(texts))).numpy())
            else: i, o = pack(texts); out.append(torch.sigmoid(m.slot_logits(m.embed(i, o))).numpy())
    return (out[0] + out[1]) / 2
TP = {}
for h in HOLDOUT:
    p = text_probs(TEXT_DEF[h]).max(0)[idx]                 # union of what the descriptions say
    TP[h] = np.clip(np.where(p > 0.5, 0.85, 0.04), 0.03, 0.95); TP[h][SYM.index("healthy")] = 0.03
R["text_profiles_detected"] = {h: [SYM[k] for k in np.where(TP[h] > .5)[0]] for h in HOLDOUT}
def LL(A, th): th = np.clip(th, .02, .98); return (A * np.log(th) + (1 - A) * np.log(1 - th)).sum(-1)
# ---- evaluation sets: all photos of new diseases (never trained on); seen photos = seen test set ----
new_imgs = {c: (np.concatenate([Ztr[ytr == c], Zte[yte == c]]), np.concatenate([Atr[ytr == c], Ate[yte == c]])) for c in ho}
TAU = 0.12
def gzsl(new_score_fn, tag, shots=None, seed=0):
    rng = np.random.default_rng(seed); used = {}
    if shots:
        for c in ho: used[c] = rng.choice(len(new_imgs[c][0]), shots, replace=False)
    def scores(Z, A):
        S_known = (Z @ Mk.T) / TAU
        S_new = np.stack([new_score_fn(c, Z, A, used.get(c)) for c in ho], 1); return S_known, S_new
    # calibrate bias on SEEN validation photos: allow at most 5% of them to be grabbed by new classes
    Sk, Sn = scores(Ztr[val], Atr[val]); margin = Sk.max(1) - Sn.max(1); bias = float(np.quantile(margin, 0.05))
    Sk, Sn = scores(Zte[mk], Ate[mk]); allS = np.concatenate([Sk, Sn + bias], 1); lab = np.array(known + ho)
    seen_acc = float((lab[allS.argmax(1)] == yte[mk]).mean())
    hit = tot = 0; hit_new_only = 0
    for c in ho:
        Z, A = new_imgs[c]; keep = np.setdiff1d(np.arange(len(Z)), used.get(c, []))
        Sk, Sn = scores(Z[keep], A[keep]); allS = np.concatenate([Sk, Sn + bias], 1)
        hit += (lab[allS.argmax(1)] == c).sum(); hit_new_only += (np.array(ho)[Sn.argmax(1)] == c).sum(); tot += len(keep)
    u = hit / tot; H = 2 * seen_acc * u / max(seen_acc + u, 1e-9)
    R[tag] = dict(seen_acc=round(seen_acc, 4), new_acc=round(float(u), 4), harmonic=round(float(H), 4), new_only_4way=round(float(hit_new_only / tot), 4))
fp_new = lambda c, Z, A, u: (Z @ n(new_imgs[c][0][u].mean(0))) / TAU
gzsl(lambda c, Z, A, u: LL(A, TP[classes[c]]), "new_from_TEXT_only")
gzsl(lambda c, Z, A, u: LL(A, np.array(profile(classes[c]))), "new_from_expert_profile_only")
for s in [5, 10]:
    gzsl(fp_new, f"new_from_{s}_PHOTOS", shots=s)
    gzsl(lambda c, Z, A, u: fp_new(c, Z, A, u) + 0.5 * LL(A, TP[classes[c]]), f"new_from_TEXT+{s}_PHOTOS", shots=s)
print(json.dumps(R, indent=1)); json.dump(R, open(CK.replace(".pt", "_eval.json"), "w"), indent=1)
