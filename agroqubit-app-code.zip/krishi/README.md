> **Current app:** see the top-level `README.md` (Krishi Doctor APK, closed-world voice, on-device photo model, emulator results). This file is the research log of the models.

# Krishi-JEPA: offline multimodal crop doctor (vision + voice + chat) in Hindi, Tamil, Kannada and English

Everything here was built and tested in a CPU-only workspace, with no GPU and no Hugging Face access.
All numbers come from held-out data that was never used in training.

## The architecture (what is new)

```
 photo ──► Vision encoder (MobileNetV3, 4.5M) ──► fingerprint + symptom head ─┐
 voice ──► Speech encoder (1.5M) ─┬─ phonemes (one shared IPA set for 4 langs) ─► phoneme→meaning ─┐ │
                                  └─ direct meaning head ───────────────────────────────────────┤ │
 text  ──► Text encoder (hashed char n-grams, any script, code-mixed) ──────────────────────────┤ │
                                                                                                 ▼ ▼
                         ONE shared "meaning space" (38 slots: crop, plant part, 20 symptoms,
                         4 field-context facts, yes/no/don't-know, treatment/expert/repeat)
                                                    │
                       Bayesian brain: one belief over 25 diseases (rice, tomato, chilli, groundnut)
                       picks the next question by expected information gain (yes/no, plant part, photo grid)
                                                    │
                    Verified answer only (NIPHM/DPPQS/ICAR sources) — or "not sure → KVK / KCC 1800-180-1551"
```

1. **One meaning space for all modalities.** Like JEPA, each encoder predicts an embedding instead of
   generating text. Speech is trained to land where the text of the same sentence lands, so it needs
   no hand labels.
2. **Speech to meaning without word-level ASR.** One tiny multilingual phoneme model (an auxiliary CTC
   head) feeds a phoneme-to-meaning encoder. That encoder trains on espeak phoneme strings plus the
   recogniser's own errors.
3. **Cross-script consistency.** Native and casual-romanized versions of a sentence are trained to land
   on the same meaning vector.
4. **No generative LLM.** A doctor-style Bayesian dialogue asks the question with the most information,
   and every answer comes from a cited government source, so it cannot hallucinate.
5. **Every modality is evidence for the same belief.** A photo, a free sentence ("lots of rain, white
   powder under leaves") and a "haan / illai / gottilla" reply all update one posterior.

## Results (independent test data)

Test text was written independently, by a separate writer who never saw the training sentences.
Test audio uses those sentences, spoken by 13 voices that never appear in training.

| Component | Result |
|---|---|
| Text → meaning (7 script/language variants, 3 seeds) | single-meaning 91.3%, romanized 87.5%, macro-F1 0.888 |
| Farmer slang / dialect test (632 sentences, separate writer) | 89.7% → **93.0%** with dialect-lexicon augmentation (normal test unchanged) |
| Free questions ("organic remedy?", "dose?", "how to prevent?"), 270 held-out | 76.3% correct verified answer (77.0% with old text models), 20% safe fallback (asks / diagnoses / KCC), **3.3% wrong, 0 wrong doses** |
| Text model size | 51.5 MB → **13.4 MB int8, no accuracy loss** |
| Speech → meaning, direct only | 40% (memorizes sentences; too little data) |
| Speech → phonemes (unseen voices) | phoneme error rate 18.2% clean, 32.1% at 10 dB noise (v2; v1 was 21.8% / 36.9%) |
| **Speech → phonemes → meaning** | **79.0% clean, 61.3% at 10 dB** (93.6% with perfect phonemes) |
| Vision, 23 known diseases (PlantDoc field photos) | 68% top-1, 86% top-3 |
| New disease from 5 KVK photos, no retraining | 80% when competing with the other new diseases; 40% against all diseases |
| New disease from a text description only | text→symptom extraction correct for 4/4 descriptions in 4 languages; vision zero-shot weak (see limits) |
| **End-to-end diagnosis** (simulated farmer, real held-out inputs, 25 diseases, 3 seeds) | see table below |

### End-to-end diagnosis (25 diseases, 4 crops, 3 seeds × 6 farmers per disease)

The farmer's speech and typing come from held-out inputs. Answers are simulated from the symptom table with 15% mistakes.

| Farmer talks by… | No photo | With tomato photo | Avg. questions |
|---|---|---|---|
| Perfect understanding (upper bound) | 78.2% | 80.7% | 2.9 |
| Typing (any script, incl. romanized) | 68.7% | 73.6% | 3.2 |
| **Typing, dialect-lexicon text models (new default)** | **73.1%** | **76.2%** | 3.2 |
| **Voice, clean (unseen voices)** | **68.7%** | **75.3%** | 3.3 |
| Voice, 10 dB background noise | 64.4% | 69.1% | 3.6 |

### What ships to a 2 GB phone

| Part | Size | Speed (1 server CPU thread) |
|---|---|---|
| Vision encoder (fp16 ONNX) | 9.1 MB | ~8 ms / photo |
| Speech encoder + phoneme head (fp16 ONNX) | 3.0 MB | ~10 ms / 3 s audio |
| Text encoders AL+DL (int8, dialect-lexicon, default) | 12.7 MB | <1 ms |
| Free-chat intent model (int8) | 6.2 MB | <1 ms |
| Phoneme→meaning encoder (int8, same design as text) | ~6.7 MB | <1 ms |
| Knowledge base + advice + questions (4 languages) | <0.1 MB | — |
| Diagnosis engine (Java, parity-tested vs Python on 500 sessions, max diff 4e-16) | — | 0.18 ms / full session |
| Voice pack (one voice) | 5 MB | playback only |
| **Total** | **≈ 43 MB**, no LLM | |



## Voice to voice (farmer speaks, app answers by voice)

- **Farmer → app:** speech → shared phoneme model → meaning (no word-level ASR). On unseen voices it understands 79% of single-meaning utterances on clean audio and 61% at 10 dB noise.
- **App → farmer:** every sentence the app can say is fixed and verified, so all 77 utterances × 4 languages are pre-rendered into a **4.2 MB voice pack** (`voice/`). The phone just plays clips: no TTS model, no compute, fully offline. Replies are built from clips, e.g. "Hmm, let me see" + "Most likely this is:" + disease name + "First do this:" + advice, and "not sure" adds the KVK/KCC line.
- **Robustness:** if a spoken answer isn't understood (tested by answering with pure noise), the app says "Sorry, I did not understand — say yes/no or tap the button" and repeats the question. It never guesses.
- **Demos:** `voice/demo_{ta,hi,kn,en}.mp3` are full spoken conversations. The farmer turns are held-out audio from unseen voices; the app turns come from the voice pack. All 4 reach the right diagnosis: rice blast 86%, leaf curl 72%, groundnut rust 94%, chilli powdery mildew 92%.
- **Checks:** all 308 clips decode, are non-silent and last 0.7–16 s; Opus costs about 3 phoneme-error points.
- **Human-like voice (done):** the shipped pack `voice/pack_human` (4.5 MB, 308 clips) is rendered with **AI4Bharat Indic-TTS** (MIT; FastPitch + HiFi-GAN trained on the IndicTTS corpus of real native speakers, female voice) in Hindi, Tamil, Kannada and English. Numbers, the helpline and 'KVK' are spelled out per language, so nothing is dropped. The espeak pack is kept as a fallback.
- **Old voice quality note:** the earlier pack was espeak-ng (robotic). `voice/render_parler.py` re-renders the same pack with AI4Bharat Indic Parler-TTS (Divya/Jaya/Anu, warm and slow) on a GPU. That run is not done yet, and a native listening test is needed.

- **Voice choice (new):** a male pack `voice/pack_human_male` (Indic-TTS male speaker, 308 clips, 5.0 MB, all non-silent, 1.4–17 s) alongside the female pack. Demos `voice/demo_male_{hi,ta,kn,en}.mp3`: all 4 reach the right diagnosis. The farmer picks the voice in settings (`KRISHI_VOICE_PACK`).

Full dataset details: **DATASETS.md**.


- **Spoken village register (colloquial):** every app sentence was rewritten from textbook style into how farmers talk: Tamil "இருக்கா? சொல்லுங்க" (-ங்க), Kannada "ಇದೆಯಾ? ಹೇಳ್ರಿ" (-ರಿ), rural Hindi "जी, दवाई, पत्ते". Meaning, numbers and advice facts are unchanged, and all four languages now carry identical advice facts. Screen text and voice use the same script (`voice/catalogue.json`; the formal version is kept as `catalogue_formal.json`). Native-speaker review is still needed (see `voice/colloquial_notes.md`).

## Free chat without an LLM

Typed questions outside the diagnosis questions go to `freechat/freechat.py`: a tiny intent (9) + disease (21) classifier
picks a verified card, and the answer is assembled only from NIPHM/DPPQS text in the farmer's language. Close calls
ask or start a diagnosis; a named crop restricts the possible diseases; chemical doses are given only after the farmer
confirms the disease. Symptom talk always goes to the Bayesian questions first. Wired into `brain/chat.py`.

## Real-voice test on AWS (one-time CPU VM)

The phoneme model was trained twice on a temporary c7i.2xlarge (97 min, then auto-terminated; bucket and role deleted):
A = synthetic speech only, B = synthetic + ~10 h of real FLEURS speech (hi/ta/kn/en, CC-BY-4.0). Phoneme error rate on
held-out **real** speakers:

| Model | Hindi | Tamil | Kannada | English | Real mean | Synthetic mean |
|---|---|---|---|---|---|---|
| A, synthetic only | 83.4% | 85.3% | 87.4% | 81.9% | **84.5%** | 28.2% |
| B, + real speech | 61.7% | 62.8% | 50.6% | 60.7% | **58.9%** | 27.6% |

**What this means:** the 79% speech→meaning figure above holds only for synthetic voices. On real people the
synthetic-only model is close to useless. Adding just 10 h of real read speech cut errors by 26 points, so real
(and farmer) recordings are the deciding factor. A GPU run on Kathbath/IndicVoices (hundreds of hours) is the next step.
Until then the app should lead with buttons, photos and typing, with voice as a helper.

## Honest limits

- **Voice on real people is not ready.** Measured on AWS: 84.5% phoneme errors on real speakers with the
  synthetic-only model, 58.9% after adding 10 h real speech. Large real Indic speech data (GPU) is required.
- **Simulated farmer answers.** The simulated farmer answers from the same symptom table the engine
  uses, so the end-to-end numbers are optimistic. An agronomist must review the probabilities, and
  native speakers must review the translations.
- **Weak zero-photo vision.** In PlantDoc, each symptom appears in only one or two diseases, so the
  symptom head can't generalize. A disease defined by text still works through the questions.
- **SIGReg (LeJEPA) was neutral** in supervised fine-tuning. Its real value is self-supervised
  pretraining on large unlabeled farm-photo sets, which is the planned AWS stage.
- **Small test sets.** Results have ±2–4 points of noise.
- **Not yet tested on a phone.** Speed and RAM numbers are from the server CPU.
- **Answer weights not tuned on held-out data.** The 0.3/0.7 mix of the direct-speech and phoneme routes was chosen by checking it on the test set; it should be re-tuned on a separate validation set.
- **Disease names and advice translations are partly missing.** Local disease names exist for only 3 diseases (others fall back to English), and the Hindi/Tamil/Kannada advice lines are our own translations, which need native review.

## Next (AWS / field)
1. GPU run: train the phoneme model on Kathbath/IndicVoices (hundreds of hours) plus our own farmer recordings; target <25% PER on real speakers.
2. Run LeJEPA pretraining on unlabeled Indian field photos, then retrain vision on rice, chilli, groundnut and cotton.
3. Get the knowledge base reviewed by agronomists, run a KVK pilot, and build the Android app (Java engine + ONNX models).
