"""Speech dataset: TRAIN = training sentences spoken by 26 synthetic voices; TEST = the independent test sentences spoken by
13 DIFFERENT held-out voices (unseen speakers). Targets come from the text teacher (A+D ensemble): slot probabilities
+ the 256-d text meaning vector (JEPA-style: the speech encoder must predict the text encoder's embedding)."""
import json, random, re, sys, unicodedata, time, numpy as np, torch
sys.path.insert(0, "/home/claude/krishi/text"); from textenc import TextEncoder, pack, pack_windows, mil_logits
from synth import say
K = "/home/claude/krishi"; random.seed(0)
TRAIN_V = "m1 m2 m4 m5 m7 f1 f3 f5 Andy Annie belinda benjamin caleb david ed grandpa iven john linda max paul rob steph travis klatt klatt3".split()
TEST_V = "m3 m6 m8 f2 f4 aunty grandma adam anika edward ian victor klatt2".split()
SL = list(json.load(open(f"{K}/slots.json"))); S = {s: i for i, s in enumerate(SL)}
tr = [json.loads(l) for l in open(f"{K}/data/text_train.jsonl")]; te = [json.loads(l) for l in open(f"{K}/data/text_test.jsonl")]
norm = lambda s: re.sub(r"[^\w\s]", "", unicodedata.normalize("NFC", s.lower())).strip()
trs = {norm(x["text"]) for x in tr}; te = [x for x in te if norm(x["text"]) not in trs]
tr = [r for r in tr if r["lang"] in ("hi", "ta", "kn", "en")]; te = [r for r in te if r["lang"] in ("hi", "ta", "kn", "en")]

def teacher(texts):
    out = []
    for name, mil in [("A", False), ("D", True)]:
        ck = torch.load(f"{K}/text/enc_{name}_0.pt"); n = TextEncoder(len(SL)); n.load_state_dict(ck["state"]); n.eval()
        with torch.no_grad():
            if mil: i, o, w, h = pack_windows(texts); p = torch.sigmoid(mil_logits(n, i, o, w, len(texts)))
            else: i, o = pack(texts); z = n.embed(i, o); p = torch.sigmoid(n.slot_logits(z)); emb = z
        out.append(p)
    return ((out[0] + out[1]) / 2).numpy(), emb.numpy()

def make(rows, voices, per, tag):
    items = []
    for r in rows:
        for v in random.sample(voices, per): items.append((r, v, random.uniform(110, 210), random.uniform(25, 75)))
    P, E = teacher([it[0]["text"] for it in items]); audio, meta = [], []
    t0 = time.time()
    for k, (r, v, rate, pitch) in enumerate(items):
        x = say(r["text"], r["lang"], v, rate, pitch); audio.append(x.astype(np.float16))
        y = np.zeros(len(SL), np.float32); y[[S[s] for s in r["slots"]]] = 1
        meta.append({"text": r["text"], "lang": r["lang"], "slots": r["slots"], "voice": v})
    lens = np.array([len(a) for a in audio]); flat = np.concatenate(audio)
    Y = np.zeros((len(items), len(SL)), np.float32)
    for k, m in enumerate(meta): Y[k, [S[s] for s in m["slots"]]] = 1
    np.savez(f"{K}/speech/{tag}.npz", audio=flat, lens=lens, teacher_p=P.astype(np.float32), teacher_emb=E.astype(np.float32), y=Y)
    json.dump(meta, open(f"{K}/speech/{tag}_meta.json", "w"), ensure_ascii=False)
    print(tag, len(items), "clips", f"{lens.sum()/16000/3600:.2f} h", f"{time.time()-t0:.0f}s")

# multi-slot training clips: two sentences of the same language spoken together
by = {}
for r in tr: by.setdefault(r["lang"], []).append(r)
mixes = []
for _ in range(600):
    L = random.choice(list(by)); a, b = random.sample(by[L], 2)
    mixes.append({"text": a["text"] + " " + b["text"], "lang": L, "slots": sorted(set(a["slots"]) | set(b["slots"]))})
if __name__ == "__main__":
    make(tr + mixes, TRAIN_V, 4, "train")
    make(te, TEST_V, 2, "test")
