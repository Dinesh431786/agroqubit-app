import sys, numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, ".")
src = open("train_speech.py").read().split("opt = torch.optim")[0]; exec(src)
idx = np.argsort(D["lens"])[2000:2064]
opt = torch.optim.AdamW(net.parameters(), lr=2e-3)
mel, M = batch(idx, False)
for it in range(60):
    z = net(mel, M); lb = F.binary_cross_entropy_with_logits(net.slot_logits(z), TP[idx]); lc = (1 - (z * TE[idx]).sum(-1)).mean()
    opt.zero_grad(); (lb + lc).backward(); opt.step()
    if it % 10 == 0: print(it, round(lb.item(), 3), round(lc.item(), 3), "acc", (net.slot_logits(z).argmax(1) == TP[idx].argmax(1)).float().mean().item(), flush=True)
print("teacher BCE floor:", float(F.binary_cross_entropy(TP[idx], TP[idx])))
print("mel", mel.mean().item(), mel.std().item(), tuple(mel.shape))
