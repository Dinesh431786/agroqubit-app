import json, sys, numpy as np, torch
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/krishi/brain")
K = "/home/claude/krishi"; SL = list(json.load(open(f"{K}/slots.json"))); S = {s: i for i, s in enumerate(SL)}
meta = json.load(open(f"{K}/speech/test_meta.json")); Y = np.zeros((len(meta), len(SL)), bool)
for i, m in enumerate(meta): Y[i, [S[s] for s in m["slots"]]] = True
single = [i for i, m in enumerate(meta) if len(m["slots"]) == 1]
sys.argv = ["x", "speech:clean", "1", f"{K}/speech/speech_enc_0.pt"]
src = open(f"{K}/brain/e2e.py").read(); exec(src.split("# utterance pool")[0])
R = {}
for cond, key in [("clean", "clean"), ("pink@10", "pink10")]:
    Pd = speech_probs(cond); Pp = np.load(f"{K}/speech/test_p2m_{key}.npy")
    for name, P in [("direct", Pd), ("phoneme_route", Pp), ("fused_0.3d+0.7p", 0.3 * Pd + 0.7 * Pp)]:
        R[f"{cond}/{name}"] = round(float(np.mean([P[i].argmax() == Y[i].argmax() for i in single])), 3)
print(json.dumps(R, indent=1))
