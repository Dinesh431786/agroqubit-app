import json, sys, time, math, random, numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "."); from speechenc import SpeechEncoder, logmel, HOP
torch.set_num_threads(2); seed = int(sys.argv[1]) if len(sys.argv) > 1 else 0; torch.manual_seed(seed); np.random.seed(seed); random.seed(seed)
K = "/home/claude/krishi"; EP = int(sys.argv[2]) if len(sys.argv) > 2 else 14
D = dict(np.load(f"{K}/speech/train.npz")); off = np.concatenate([[0], np.cumsum(D["lens"])])
TP, TE = torch.tensor(D["teacher_p"]), torch.tensor(D["teacher_emb"])
protos = torch.load(f"{K}/text/enc_A_0.pt")["state"]["slots"]
PH = json.load(open(f"{K}/speech/train_phon.json")); VOC = {c: i + 1 for i, c in enumerate(PH["vocab"])}
TGT = [torch.tensor([VOC[c] for c in p]) for p in PH["phon"]]
net = SpeechEncoder(protos, n_phon=len(VOC)); print("params", sum(p.numel() for p in net.parameters()) / 1e6, "M")
MAXN = 16000 * 7

def noise(n, kind):
    w = np.random.randn(n).astype(np.float32)
    if kind == "white": return w
    f = np.fft.rfft(w); fr = np.arange(len(f)) + 1
    f = f / (fr ** (0.5 if kind == "pink" else 1.0)); x = np.fft.irfft(f, n).astype(np.float32)   # pink / brown (wind-like)
    return x / (x.std() + 1e-8)
def augment(x):
    x = x * np.random.uniform(0.3, 1.5)
    if np.random.rand() < .6:
        snr = np.random.uniform(5, 30); nz = noise(len(x), np.random.choice(["white", "pink", "brown"]))
        x = x + nz * (np.sqrt((x ** 2).mean()) / 10 ** (snr / 20))
    return x
def batch(idx, aug):
    xs = [D["audio"][off[i]:off[i+1]].astype(np.float32)[:MAXN] for i in idx]
    if aug: xs = [augment(x) for x in xs]
    n = max(len(x) for x in xs); X = np.zeros((len(xs), n), np.float32); M = np.zeros((len(xs), n // HOP + 1), bool)
    for k, x in enumerate(xs): X[k, :len(x)] = x; M[k, :len(x) // HOP + 1] = True
    mel = logmel(torch.tensor(X))
    if aug:   # SpecAugment + telephone band-limit
        for k in range(len(xs)):
            f0 = np.random.randint(0, 56); mel[k, f0:f0 + np.random.randint(0, 9)] = mel[k].min()
            t0 = np.random.randint(0, max(1, mel.shape[2] - 30)); mel[k, :, t0:t0 + np.random.randint(0, 25)] = mel[k].min()
            if np.random.rand() < .25: mel[k, :4] = mel[k].min(); mel[k, 44:] = mel[k].min()
    return mel, torch.tensor(M[:, :mel.shape[2]])

opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
N = len(D["lens"]); order = np.argsort(D["lens"]); BS = 32
batches = [order[i:i+BS] for i in range(0, N, BS)]; steps = EP * len(batches); st = 0; t0 = time.time()
for ep in range(EP):
    net.train(); random.shuffle(batches); tot = 0
    for b in batches:
        mel, M = batch(b, True); z, h = net(mel, M, return_frames=True)
        loss = F.binary_cross_entropy_with_logits(net.slot_logits(z), TP[b]) + (1 - (z * TE[b]).sum(-1)).mean()   # text-teacher only, no labels
        lp = net.ctc(h).log_softmax(1).permute(2, 0, 1)                                                        # (T, B, V)
        il = torch.clamp((M.sum(1) + 1) // 2, max=lp.shape[0]); tg = [TGT[i] for i in b]
        loss = loss + 0.3 * F.ctc_loss(lp, torch.cat(tg), il, torch.tensor([len(x) for x in tg]), zero_infinity=True)
        lr = 2e-3 * min(1, (st + 1) / 100) * 0.5 * (1 + math.cos(math.pi * st / steps))
        for g in opt.param_groups: g["lr"] = lr
        opt.zero_grad(); loss.backward(); opt.step(); st += 1; tot += loss.item()
    print(f"ep {ep+1}/{EP} loss {tot/len(batches):.3f} {time.time()-t0:.0f}s", flush=True)
torch.save({"state": net.state_dict()}, f"{K}/speech/speech_enc_{seed}.pt")
