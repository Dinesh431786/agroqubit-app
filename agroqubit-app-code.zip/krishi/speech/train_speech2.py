"""Fine-tune the speech encoder with ~40% more audio for the phoneme (CTC) head; meaning losses only on clips with targets."""
import json, sys, time, math, random, numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "."); from speechenc import SpeechEncoder, logmel, HOP
torch.set_num_threads(2); torch.manual_seed(1); np.random.seed(1); random.seed(1); K = "/home/claude/krishi"; EP = int(sys.argv[1]) if len(sys.argv) > 1 else 6
A = dict(np.load(f"{K}/speech/train.npz")); B = dict(np.load(f"{K}/speech/train2.npz"))
PA = json.load(open(f"{K}/speech/train_phon.json")); PB = json.load(open(f"{K}/speech/train2_phon.json"))
VOC = {c: i + 1 for i, c in enumerate(PA["vocab"])}
audio = np.concatenate([A["audio"], B["audio"]]); lens = np.concatenate([A["lens"], B["lens"]]); off = np.concatenate([[0], np.cumsum(lens)])
phon = PA["phon"] + PB["phon"]; TGT = [torch.tensor([VOC[c] for c in p if c in VOC]) for p in phon]
nA = len(A["lens"]); TP = torch.tensor(A["teacher_p"]); TE = torch.tensor(A["teacher_emb"])
protos = torch.load(f"{K}/text/enc_A_0.pt")["state"]["slots"]
net = SpeechEncoder(protos, n_phon=len(VOC)); net.load_state_dict(torch.load(f"{K}/speech/speech_enc_0.pt")["state"])
def noise(n, kind):
    w = np.random.randn(n).astype(np.float32)
    if kind == "white": return w
    f = np.fft.rfft(w); fr = np.arange(len(f)) + 1; x = np.fft.irfft(f / fr ** (0.5 if kind == "pink" else 1.0), n).astype(np.float32); return x / (x.std() + 1e-8)
def augment(x):
    x = x * np.random.uniform(0.3, 1.5)
    if np.random.rand() < .7: x = x + noise(len(x), np.random.choice(["white", "pink", "brown"])) * (np.sqrt((x ** 2).mean()) / 10 ** (np.random.uniform(3, 30) / 20))
    return x
def batch(idx):
    xs = [augment(audio[off[i]:off[i+1]].astype(np.float32)[:16000 * 7]) for i in idx]
    n = max(len(x) for x in xs); X = np.zeros((len(xs), n), np.float32); M = np.zeros((len(xs), n // HOP + 1), bool)
    for k, x in enumerate(xs): X[k, :len(x)] = x; M[k, :len(x) // HOP + 1] = True
    mel = logmel(torch.tensor(X))
    for k in range(len(xs)):
        f0 = np.random.randint(0, 56); mel[k, f0:f0 + np.random.randint(0, 9)] = mel[k].min()
        t0 = np.random.randint(0, max(1, mel.shape[2] - 30)); mel[k, :, t0:t0 + np.random.randint(0, 25)] = mel[k].min()
        if np.random.rand() < .25: mel[k, :4] = mel[k].min(); mel[k, 44:] = mel[k].min()
    return mel, torch.tensor(M[:, :mel.shape[2]])
opt = torch.optim.AdamW(net.parameters(), lr=1e-3, weight_decay=1e-3)
order = np.argsort(lens); batches = [order[i:i+32] for i in range(0, len(lens), 32)]; steps = EP * len(batches); st = 0; t0 = time.time()
for ep in range(EP):
    net.train(); random.shuffle(batches); tot = 0
    for b in batches:
        mel, M = batch(b); z, h = net(mel, M, return_frames=True)
        lp = net.ctc(h).log_softmax(1).permute(2, 0, 1); il = torch.clamp((M.sum(1) + 1) // 2, max=lp.shape[0]); tg = [TGT[i] for i in b]
        loss = F.ctc_loss(lp, torch.cat(tg), il, torch.tensor([len(x) for x in tg]), zero_infinity=True)
        mA = torch.tensor([i < nA for i in b])
        if mA.any():
            ia = torch.tensor([i for i in b if i < nA]); za = z[mA]
            loss = loss + F.binary_cross_entropy_with_logits(net.slot_logits(za), TP[ia]) + (1 - (za * TE[ia]).sum(-1)).mean()
        for g in opt.param_groups: g["lr"] = 1e-3 * 0.5 * (1 + math.cos(math.pi * st / steps))
        opt.zero_grad(); loss.backward(); opt.step(); st += 1; tot += loss.item()
    print(f"ep {ep+1}/{EP} loss {tot/len(batches):.3f} {time.time()-t0:.0f}s", flush=True); torch.save({"state": net.state_dict()}, f"{K}/speech/speech_enc_v2.pt")
torch.save({"state": net.state_dict()}, f"{K}/speech/speech_enc_v2.pt")
