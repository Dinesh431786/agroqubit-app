"""Greedy CTC phoneme decoding of clips (train or test) with optional noise; also phoneme error rate vs espeak G2P."""
import json, sys, re, numpy as np, torch
sys.path.insert(0, "."); from speechenc import SpeechEncoder, logmel, HOP
from synth import phonemes
torch.set_num_threads(1); K = "/home/claude/krishi"
def load(ck=f"{K}/speech/speech_enc_0.pt"):
    protos = torch.load(f"{K}/text/enc_A_0.pt")["state"]["slots"]; sd = torch.load(ck)["state"]
    net = SpeechEncoder(protos, n_phon=sd["ctc.weight"].shape[0] - 1); net.load_state_dict(sd); net.eval(); return net
VOCAB = json.load(open(f"{K}/speech/train_phon.json"))["vocab"]
def noisy(x, cond, rng):
    if cond == "clean": return x
    kind, snr = cond.split("@"); w = rng.standard_normal(len(x)).astype(np.float32)
    if kind != "white":
        f = np.fft.rfft(w); fr = np.arange(len(f)) + 1; w = np.fft.irfft(f / fr ** (0.5 if kind == "pink" else 1.0), len(x)).astype(np.float32); w /= w.std() + 1e-8
    return x + w * np.sqrt((x ** 2).mean()) / 10 ** (float(snr) / 20)
def decode(net, audio, lens, cond="clean", seed=0):
    off = np.concatenate([[0], np.cumsum(lens)]); rng = np.random.default_rng(seed); out = []
    for i0 in range(0, len(lens), 32):
        xs = [noisy(audio[off[i]:off[i+1]].astype(np.float32), cond, rng) for i in range(i0, min(i0 + 32, len(lens)))]
        n = max(len(x) for x in xs); X = np.zeros((len(xs), n), np.float32); M = np.zeros((len(xs), n // HOP + 1), bool)
        for k, x in enumerate(xs): X[k, :len(x)] = x; M[k, :len(x) // HOP + 1] = True
        with torch.no_grad():
            mel = logmel(torch.tensor(X)); Mt = torch.tensor(M[:, :mel.shape[2]]); z, h = net(mel, Mt, return_frames=True)
            lp = net.ctc(h).argmax(1).numpy()
        for k in range(len(xs)):
            T = int((Mt[k].sum() + 1) // 2); seq = lp[k, :T]; s = []; prev = 0
            for t in seq:
                if t != prev and t != 0: s.append(VOCAB[t - 1])
                prev = t
            out.append("".join(s))
    return out
def per(hyp, ref):
    import difflib
    d = np.zeros((len(ref) + 1, len(hyp) + 1), int); d[:, 0] = range(len(ref) + 1); d[0, :] = range(len(hyp) + 1)
    for i in range(1, len(ref) + 1):
        for j in range(1, len(hyp) + 1): d[i, j] = min(d[i-1, j] + 1, d[i, j-1] + 1, d[i-1, j-1] + (ref[i-1] != hyp[j-1]))
    return d[-1, -1] / max(len(ref), 1)
if __name__ == "__main__":
    CKP = sys.argv[1] if len(sys.argv) > 1 else f"{K}/speech/speech_enc_0.pt"; TAG = sys.argv[2] if len(sys.argv) > 2 else ""
    net = load(CKP); D = dict(np.load(f"{K}/speech/test.npz")); meta = json.load(open(f"{K}/speech/test_meta.json"))
    refs = [re.sub(r"[ˈˌ]", "", phonemes(m["text"], m["lang"])) for m in meta]
    res = {}
    for cond in ["clean", "pink@10"]:
        hyp = decode(net, D["audio"], D["lens"], cond); res[cond] = round(float(np.mean([per(h, r) for h, r in zip(hyp[:300], refs[:300])])), 3)
        json.dump(hyp, open(f"{K}/speech/test_decoded{TAG}_{cond.replace('@','')}.json", "w"), ensure_ascii=False)
        print(cond, "PER", res[cond], "| e.g.", refs[0], "->", hyp[0], flush=True)
    json.dump(refs, open(f"{K}/speech/test_phon_refs.json", "w"), ensure_ascii=False)
