import json, sys, numpy as np, torch
sys.path.insert(0, "."); from speechenc import SpeechEncoder, logmel, HOP
torch.set_num_threads(2); K = "/home/claude/krishi"; ck = sys.argv[1]
SL = list(json.load(open(f"{K}/slots.json"))); S = {s: i for i, s in enumerate(SL)}
D = dict(np.load(f"{K}/speech/test.npz")); off = np.concatenate([[0], np.cumsum(D["lens"])]); meta = json.load(open(f"{K}/speech/test_meta.json"))
protos = torch.load(f"{K}/text/enc_A_0.pt")["state"]["slots"]; thr = (torch.load(f"{K}/text/enc_A_0.pt")["threshold"] + torch.load(f"{K}/text/enc_D_0.pt")["threshold"]) / 2
sd = torch.load(ck)["state"]; net = SpeechEncoder(protos, n_phon=sd["ctc.weight"].shape[0] - 1 if "ctc.weight" in sd else 0); net.load_state_dict(sd); net.eval()
Y = D["y"] > 0; rng = np.random.default_rng(123)
def noise(n, kind):
    w = rng.standard_normal(n).astype(np.float32)
    if kind == "white": return w
    f = np.fft.rfft(w); fr = np.arange(len(f)) + 1; x = np.fft.irfft(f / (fr ** (0.5 if kind == "pink" else 1.0)), n).astype(np.float32); return x / (x.std() + 1e-8)
def run(cond):
    P = []
    for i0 in range(0, len(meta), 32):
        xs = []
        for i in range(i0, min(i0 + 32, len(meta))):
            x = D["audio"][off[i]:off[i+1]].astype(np.float32)
            if cond != "clean":
                kind, snr = cond.split("@"); x = x + noise(len(x), kind) * (np.sqrt((x ** 2).mean()) / 10 ** (float(snr) / 20))
            xs.append(x)
        n = max(len(x) for x in xs); X = np.zeros((len(xs), n), np.float32); M = np.zeros((len(xs), n // HOP + 1), bool)
        for k, x in enumerate(xs): X[k, :len(x)] = x; M[k, :len(x) // HOP + 1] = True
        with torch.no_grad(): mel = logmel(torch.tensor(X)); P.append(torch.sigmoid(net.slot_logits(net(mel, torch.tensor(M[:, :mel.shape[2]])))).numpy())
    return np.concatenate(P)
def score(P, thr):
    pred = P >= thr
    for i in range(len(pred)):
        if not pred[i].any(): pred[i, P[i].argmax()] = True
    single = [i for i, m in enumerate(meta) if len(m["slots"]) == 1]; multi = [i for i, m in enumerate(meta) if len(m["slots"]) > 1]
    tp = (pred & Y).sum(0); fp = (pred & ~Y).sum(0); fn = (~pred & Y).sum(0)
    by = {L: round(float(np.mean([P[i].argmax() == Y[i].argmax() for i in single if meta[i]["lang"] == L])), 3) for L in ["en", "hi", "ta", "kn"]}
    return dict(single_top1=round(float(np.mean([P[i].argmax() == Y[i].argmax() for i in single])), 3), exact=round(float((pred == Y).all(1).mean()), 3),
                multi_exact=round(float((pred[multi] == Y[multi]).all(1).mean()), 3), macro_f1=round(float((2*tp/np.maximum(2*tp+fp+fn, 1)).mean()), 3), by_lang=by)
R = {"text_teacher_on_transcripts(upper bound)": score(D["teacher_p"], thr)}
for cond in ["clean", "pink@20", "pink@10", "brown@5", "white@5"]: R[cond] = score(run(cond), thr); print(cond, R[cond], flush=True)
print("teacher", R["text_teacher_on_transcripts(upper bound)"])
json.dump(R, open(ck.replace(".pt", "_eval.json"), "w"), indent=1)
