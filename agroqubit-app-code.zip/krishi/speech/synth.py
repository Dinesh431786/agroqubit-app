"""Offline speech synthesis with espeak-ng (bundled via espeakng_loader) for hi / ta / kn / en, with voice variants,
rate and pitch control. Returns float32 mono audio at 16 kHz."""
import ctypes, os, numpy as np, espeakng_loader
from scipy.signal import resample_poly

LIB = ctypes.cdll.LoadLibrary(espeakng_loader.get_library_path())
DATA = espeakng_loader.get_data_path()
_buf = []
CB = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.POINTER(ctypes.c_short), ctypes.c_int, ctypes.c_void_p)
@CB
def _cb(wav, n, events):
    if n > 0: _buf.append(np.ctypeslib.as_array(wav, shape=(n,)).copy())
    return 0
SR = LIB.espeak_Initialize(1, 500, DATA.encode(), 0)       # AUDIO_OUTPUT_RETRIEVAL
LIB.espeak_SetSynthCallback(_cb)
VARIANTS = sorted(os.listdir(os.path.join(DATA, "voices", "!v")))
VOICE = {"hi": "hi", "ta": "ta", "kn": "kn", "en": "en-us"}

def say(text, lang, variant=None, rate=150, pitch=50, prange=50):
    _buf.clear()
    name = VOICE[lang] + (f"+{variant}" if variant else "")
    LIB.espeak_SetVoiceByName(name.encode())
    LIB.espeak_SetParameter(1, int(rate), 0); LIB.espeak_SetParameter(3, int(pitch), 0); LIB.espeak_SetParameter(4, int(prange), 0)
    b = text.encode("utf-8") + b"\0"
    LIB.espeak_Synth(ctypes.c_char_p(b), len(b), 0, 1, 0, 1, None, None); LIB.espeak_Synchronize()
    if not _buf: return np.zeros(1600, np.float32)
    x = np.concatenate(_buf).astype(np.float32) / 32768.0
    return resample_poly(x, 16000, SR).astype(np.float32) if SR != 16000 else x

if __name__ == "__main__":
    import soundfile as sf
    print("espeak sample rate", SR, "variants", len(VARIANTS), VARIANTS[:12])
    for t, l in [("पत्तों के नीचे सफेद पाउडर है", "hi"), ("இலைக்கு அடியில வெள்ளை பொடி இருக்கு", "ta"), ("ಎಲೆಯ ಕೆಳಗೆ ಬಿಳಿ ಪುಡಿ ಇದೆ", "kn"), ("white powder under the leaves", "en")]:
        x = say(t, l, "m3"); sf.write(f"sample_{l}.wav", x, 16000); print(l, f"{len(x)/16000:.2f}s", "rms", float(np.sqrt((x**2).mean())))

LIB.espeak_TextToPhonemes.restype = ctypes.c_char_p
LIB.espeak_TextToPhonemes.argtypes = [ctypes.POINTER(ctypes.c_char_p), ctypes.c_int, ctypes.c_int]
def phonemes(text, lang):
    """IPA phoneme string from espeak-ng (same G2P that produced the audio)."""
    LIB.espeak_SetVoiceByName(VOICE[lang].encode())
    buf = ctypes.c_char_p(text.encode("utf-8")); out = []
    p = ctypes.pointer(buf)
    while p.contents.value:
        r = LIB.espeak_TextToPhonemes(p, 1, 0x02)   # UTF-8 text, IPA output
        if r: out.append(r.decode("utf-8", "ignore"))
        else: break
    return " ".join(out)
