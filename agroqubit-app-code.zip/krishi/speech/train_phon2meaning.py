"""Phoneme -> meaning encoder. Input: IPA phoneme string (no word boundaries, as emitted by the CTC head).
Trained on (a) espeak G2P of the training sentences, (b) the CTC model's REAL decodes of the training audio (clean + noisy),
(c) random edits. Labels come from the text data (no audio labelling needed)."""
import json, sys, re, random, zlib, numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/krishi/text")
from textenc import TextEncoder, NB
from decode import load, decode, VOCAB
CKP = sys.argv[1] if len(sys.argv) > 1 else f"/home/claude/krishi/speech/speech_enc_0.pt"; TAG = sys.argv[2] if len(sys.argv) > 2 else ""
torch.set_num_threads(2); random.seed(0); torch.manual_seed(0); K = "/home/claude/krishi"
SL = list(json.load(open(f"{K}/slots.json"))); S = {s: i for i, s in enumerate(SL)}
def feats(s, nmin=2, nmax=5):
    s = "#" + re.sub(r"[\sˈˌ]", "", s) + "#"; ids = []
    for n in range(nmin, nmax + 1):
        for i in range(len(s) - n + 1): ids.append(zlib.crc32(("P" + s[i:i+n]).encode()) % NB)
    return ids or [0]
def pk(strs):
    ids, off = [], []
    for s in strs: off.append(len(ids)); ids += feats(s)
    return torch.tensor(ids), torch.tensor(off)
meta = json.load(open(f"{K}/speech/train_meta.json")); PH = json.load(open(f"{K}/speech/train_phon.json"))["phon"]
D = dict(np.load(f"{K}/speech/train.npz"))
import os
if not os.path.exists(f"{K}/speech/train_decoded{TAG}.json"):
    net = load(CKP); dec_clean = decode(net, D["audio"], D["lens"], "clean"); dec_noisy = decode(net, D["audio"], D["lens"], "pink@12", seed=1)
    json.dump([dec_clean, dec_noisy], open(f"{K}/speech/train_decoded{TAG}.json", "w"), ensure_ascii=False)
dec_clean, dec_noisy = json.load(open(f"{K}/speech/train_decoded{TAG}.json"))
data = []
for m, g2p, dc, dn in zip(meta, PH, dec_clean, dec_noisy):
    for s in (g2p, dc, dn): data.append((s, m["slots"]))
def edit(s):
    c = list(s)
    for _ in range(int(len(c) * random.uniform(0, .2))):
        if not c: break
        k = random.randrange(len(c)); r = random.random()
        if r < .4: del c[k]
        elif r < .8: c[k] = random.choice(VOCAB)
        else: c.insert(k, random.choice(VOCAB))
    return "".join(c)
net = TextEncoder(len(SL)); opt = torch.optim.AdamW(net.parameters(), lr=3e-3, weight_decay=1e-4); EP = 12
for ep in range(EP):
    random.shuffle(data); tot = 0
    for i in range(0, len(data), 128):
        b = data[i:i+128]; ids, off = pk([edit(s) if random.random() < .5 else s for s, _ in b])
        y = torch.zeros(len(b), len(SL))
        for j, (_, sl) in enumerate(b): y[j, [S[x] for x in sl]] = 1
        loss = F.binary_cross_entropy_with_logits(net.slot_logits(net.embed(ids, off)), y); opt.zero_grad(); loss.backward(); opt.step(); tot += loss.item()
    for g in opt.param_groups: g["lr"] = 3e-3 * 0.5 * (1 + np.cos(np.pi * (ep + 1) / EP))
    print("ep", ep + 1, round(tot / (len(data) / 128), 4), flush=True)
torch.save({"state": net.state_dict()}, f"{K}/speech/phon2meaning{TAG}.pt")
# ---- evaluate on the independent test clips (unseen sentences, unseen voices) ----
tmeta = json.load(open(f"{K}/speech/test_meta.json")); Y = np.zeros((len(tmeta), len(SL)), bool)
for i, m in enumerate(tmeta): Y[i, [S[s] for s in m["slots"]]] = True
single = [i for i, m in enumerate(tmeta) if len(m["slots"]) == 1]
def score(P, thr=0.45):
    pred = P >= thr
    for i in range(len(pred)):
        if not pred[i].any(): pred[i, P[i].argmax()] = True
    tp = (pred & Y).sum(0); fp = (pred & ~Y).sum(0); fn = (~pred & Y).sum(0)
    return dict(single_top1=round(float(np.mean([P[i].argmax() == Y[i].argmax() for i in single])), 3), exact=round(float((pred == Y).all(1).mean()), 3),
                macro_f1=round(float((2*tp/np.maximum(2*tp+fp+fn, 1)).mean()), 3),
                by_lang={L: round(float(np.mean([P[i].argmax() == Y[i].argmax() for i in single if tmeta[i]["lang"] == L])), 3) for L in ["en", "hi", "ta", "kn"]})
R = {}
with torch.no_grad():
    refs = json.load(open(f"{K}/speech/test_phon_refs.json")); i, o = pk(refs); R["perfect_phonemes(upper bound)"] = score(torch.sigmoid(net.slot_logits(net.embed(i, o))).numpy())
    for cond in ["clean", "pink10"]:
        hyp = json.load(open(f"{K}/speech/test_decoded{TAG}_{cond}.json")); i, o = pk(hyp); P = torch.sigmoid(net.slot_logits(net.embed(i, o))).numpy()
        np.save(f"{K}/speech/test_p2m{TAG}_{cond}.npy", P); R[f"speech_{cond}"] = score(P)
print(json.dumps(R, indent=1)); json.dump(R, open(f"{K}/speech/results_phon2meaning{TAG}.json", "w"), indent=1)
