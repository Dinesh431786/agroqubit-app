"""Extra speech for the phoneme recogniser: training sentences re-voiced with new random voice settings, plus word-shuffled
training sentences (new phoneme sequences, meaning not used). Only TRAIN text and TRAIN voices are used (no test leakage)."""
import json, random, re, unicodedata, numpy as np, time
from synth import say, phonemes
from build_data import TRAIN_V
K = "/home/claude/krishi"; random.seed(7)
tr = [json.loads(l) for l in open(f"{K}/data/text_train.jsonl")]; tr = [r for r in tr if r["lang"] in ("hi", "ta", "kn", "en")]
items = []
for r in tr:
    for _ in range(2): items.append((r["text"], r["lang"], True, r["slots"]))
    for _ in range(2):
        w = r["text"].split(); random.shuffle(w); items.append((" ".join(w), r["lang"], False, []))
audio, lens, phon, has_meaning, texts = [], [], [], [], []; t0 = time.time()
for text, lang, hm, sl in items:
    x = say(text, lang, random.choice(TRAIN_V), random.uniform(100, 220), random.uniform(20, 80)); audio.append(x.astype(np.float16)); lens.append(len(x))
    phon.append(re.sub(r"[ˈˌ]", "", phonemes(text, lang))); has_meaning.append(hm); texts.append(text)
np.savez(f"{K}/speech/train2.npz", audio=np.concatenate(audio), lens=np.array(lens), has_meaning=np.array(has_meaning))
json.dump({"phon": phon, "texts": texts}, open(f"{K}/speech/train2_phon.json", "w"), ensure_ascii=False)
print(len(items), "clips", f"{sum(lens)/16000/3600:.2f} h", f"{time.time()-t0:.0f}s")
