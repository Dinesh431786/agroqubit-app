# Offline Whisper speech recogniser (Krishi Doctor)

This is the fallback voice input for when the phone's built-in Android recogniser has no offline model for the
farmer's language. It uses the Whisper-tiny architecture (39M parameters) with one checkpoint per language (hi, ta, kn,
en). Inference is plain Java on the phone, with no ML runtime and no native code. It targets 2 GB phones on Android 7+.

| File | What it is |
|---|---|
| `speech/whisper/export_whisper.py` | HF `WhisperForConditionalGeneration` to `whisper_<lang>.bin` (KRW1) + `whisper_<lang>.json` |
| `speech/whisper/select_finetune.py` | GPU-VM pipeline: FLEURS, candidate evaluation and licences, SHORT-mode fine-tune, export, checks, report |
| `speech/whisper/whisper_common.py` | Shared helpers: exact log-mel, SHORT-mode encoder with masks, phone-identical greedy decoding, normaliser, WER/CER, synthetic tokenizer |
| `speech/whisper/fleurs_data.py` | FLEURS download without the `datasets` script, extra manifests, synthetic offline data |
| `speech/whisper/align_crops.py` | Cross-attention DTW word timings and 2–15 s training crops cut at pauses |
| `android/src/in/krishi/doctor/Whisper.java` | Recogniser: log-mel, encoder, KV-cached greedy decoder, detokeniser (no android.*) |
| `android/src/in/krishi/doctor/WhisperMath.java` | Register-blocked int8 kernels, bit-identical to `Nn.linear` / `Nn.attention` / `Nn.conv1d` |
| `android/app/src/in/krishi/doctor/Listen.java` | AudioRecord at 16 kHz, energy endpointing, Whisper on a worker thread, callbacks |
| `android/test/whisper/` | Python reference, Java parity / kernel / Listen / speed tests, CLI, android.* test doubles, `run_tests.sh` |

## Model files

**`whisper_<lang>.bin`** (KRW1, `android/tools/krw.py`). Tensors use HF parameter names without the `model.` prefix
(`encoder.layers.0.fc1.weight`, `decoder.embed_tokens.weight`, ...).

- **int8 rows** (one fp32 scale per output row): every linear weight (q/k/v/out, fc1, fc2) and the token embedding.
- **fp16**: the conv stem and both positional tables.
- **fp32**: layer norms and biases.
- `proj_out.weight` is stored only if it is not tied to the embedding.

The file is 39.5 MB with the full vocabulary, or about 19.5 MB with a restricted one (see below).

**`whisper_<lang>.json`** (`format: krishi-whisper-1`) holds:

- `dims`
- `tokens`: sot, lang, transcribe, translate, notimestamps, eot, no_speech, startofprev
- `prompt` (the forced decoder prefix) and `sot_index`
- `suppress_tokens` and `begin_suppress_tokens`, from the model's own generation config
- `max_new_tokens` (96)
- `audio`: sr 16000, n_fft 400, hop 160, 3000 frames, `short_pad_frames`
- `mel_filters`: [80][201] slaney filters from `WhisperFeatureExtractor`, base64 f32 big-endian
- `vocab`: token id to raw bytes through the GPT-2 byte decoder, stored as one base64 blob plus base64 uint16 lengths.
  Ids at or above eot, and `nontext_ids`, are never text.
- optional `vocab_ids` (restricted vocabulary)
- `info`: source, licence, token statistics

## Phone runtime (`Whisper.java`)

```java
Whisper w = Whisper.fromRes(name -> getAssets().open(name), "ta");   // or Whisper.load(binFile, jsonFile)
Whisper.Result r = w.transcribe(pcm16kFloat, n, false);              // false = SHORT mode (the phone), true = 30 s window
r.text; r.avgLogProb; r.noSpeechProb; r.compressionRatio; r.confidence(); r.unreliable(); r.noSpeech();
```

**Log-mel.** This is exactly `WhisperFeatureExtractor`:

- periodic Hann 400, hop 160, centred STFT with reflect padding (a 400-point mixed-radix FFT, two frames per complex FFT)
- power spectrum, then 80 mel filters
- `log10(max(x, 1e-10))`, then `max(x, max - 8)`, then `(x + 4) / 4`

The maximum is taken over the frames of the 30 s zero-padded window, so SHORT-mode frames are identical to FULL-mode
frames.

**FULL mode** pads to 3000 frames (1500 encoder positions) and matches HF.

**SHORT mode** is what the phone uses. It keeps `ceil(n / 160)` frames (plus `short_pad_frames`), rounded up to even,
so the encoder cost grows with the audio length. Whisper only ever saw 30 s windows, which is why our checkpoints are
fine-tuned in SHORT mode.

**Encoder.** conv k3 + GELU, then conv k3 stride 2 + GELU, then positions, then 4 pre-LN blocks (k has no bias), then
ln_post.

**Decoder.**

- token embedding plus learned positions
- 4 blocks: causal self-attention with a preallocated KV cache, cross-attention with K/V computed once per utterance,
  then FFN
- final LN; logits are `h · E^T`

**Greedy decoding.**

- forced prefix `[sot, lang, transcribe, notimestamps]` (or the model's own forced ids)
- `suppress_tokens` at every step, plus `begin_suppress_tokens` at the first step
- stops at eot or after 96 new tokens
- text is the bytes of the ids below eot, decoded as UTF-8 (errors become U+FFFD), then trimmed

**Confidence values.**

- `avgLogProb` is OpenAI's average log-probability over the generated tokens, including eot.
- `noSpeechProb` is P(no_speech) from the raw logits at the sot position.
- `compressionRatio` above 2.4 means a repetition loop.
- `confidence()` is `exp(avgLogProb) * (1 - noSpeechProb)`.

**Kernels.** All matmuls keep the weights in int8. `WhisperMath.linear` blocks 4 output rows by 4 time steps, so there
are 16 independent accumulators. It expands each int8 4-row block to floats once per 32-step tile. The per-output
summation order is unchanged, so its results are bit-identical to `Nn.linear`, but it runs 5–6x faster: the JIT may not
reorder float sums, so a single-accumulator loop is bound by add latency. The conv stem runs as im2col plus the same
kernel. Set `Whisper.nnKernels = true` to use the shared `Nn` kernels instead. Threads come from `Nn`'s pool
(min(4, cores)).

**Restricted vocabulary** (optional, json `vocab_ids`). Only the tokens of the language's training text, plus the 256
single-byte tokens (any text stays spellable) and the specials, keep embedding/output rows. The file goes from
39.5 MB to about 20 MB, the decoder is about 3x faster per token, and RAM drops by about 18 MB. `select_finetune.py`
keeps the restricted variant only if test CER (int8, SHORT) does not rise by more than 0.3 points.

**Memory.** Weights take about 37 MB (full vocabulary) or about 18 MB (restricted). SHORT-mode activations for 12 s
take about 10 MB. FULL mode adds about 18 MB of cross K/V. Instances are not thread-safe; the public methods are
synchronized.

## Voice input (`Listen.java`, Android)

- **Recording.** AudioRecord, mono 16-bit at 16 kHz from the `VOICE_RECOGNITION` source. If that fails it falls back
  to `MIC`, then to 48 or 44.1 kHz with a polyphase windowed-sinc resampler.
- **Endpointing.** It works on 30 ms frames. The noise floor starts as the minimum of the first 150 ms; it then follows
  quieter frames and creeps up by about 3 dB/s on non-speech frames.
  - Speech starts after 3 frames above floor + 10 dB (and above -55 dBFS); 300 ms of pre-roll is kept.
  - Recording stops after 0.8 s of silence (`silenceMs`), after 12 s of speech (`maxSpeechMs`), on `stop()`, or
    after 8 s with no speech (`noSpeechTimeoutMs`). `cancel()` drops the recording.
  - Trailing silence is trimmed to 0.3 s. Quiet input (peak below -12 dBFS) is raised to about -6 dBFS, by at most
    +20 dB.
- **Recognition.** Whisper (SHORT mode) runs on a worker thread. The model is loaded there on first use (`preload()`
  to start early) and only one language is kept in memory. Callbacks run on the main thread: `onReady`, `onSpeech`,
  `onLevel`, `onThinking`, `onResult(text, confidence, result)`, `onNothing(no_speech|too_short|cancelled)`,
  `onError`.
- **Lifecycle.** The caller must already hold RECORD_AUDIO. Call `release()` in `onDestroy`.

Integration sketch for MainActivity (not edited here):

```java
Whisper.Opener res = name -> getAssets().open(name);      // same lambda the app already gives Krishi
listen = new Listen(res, new Listen.Callback() {
  public void onReady() { setListening(true); }      public void onSpeech() { }
  public void onLevel(float v) { }                   public void onThinking() { showWait(); }
  public void onResult(String t, double c, Whisper.Result r) { setListening(false);
      if (c < 0.45 || r.unreliable()) askToRepeat(); else userSaid(t); }   // tune 0.45 on farmer audio
  public void onNothing(String why) { setListening(false); }
  public void onError(Exception e) { setListening(false); speakIntent(); }
});
// mic tap when the on-device Android recogniser lacks the language and Listen.hasModel(res, lang):
listen.setLanguage(lang); listen.start();      // second tap: listen.stop();   onDestroy: listen.release();
```

## Tests (local, CPU only): `android/test/whisper/run_tests.sh [WORK_DIR]`

The tests use a random-init Whisper-tiny (d_model 384, 4+4 layers, 6 heads, vocab 51865, 1500/448 positions) with a
synthetic BPE vocabulary in openai/whisper-tiny's id layout. Weights are perturbed so that attention is not uniform.

The HF reference runs on the **exported** (dequantised) weights, so the comparison isolates the implementation. On
random weights, int8 quantisation alone moves the encoder output by up to 0.095 and the logits by up to 0.21 (2 of the
3 greedy runs stay identical); real checkpoints are measured on the VM.

The suppress lists include the unsuppressed first-step winners, so suppression must work.

Results (sandbox, 2 shared vCPUs):

| Check | Result |
|---|---|
| log-mel vs `WhisperFeatureExtractor` (6 signals incl. silence, 0.7 s, 31 s) | max abs diff 6.0e-5 |
| encoder, FULL and SHORT, HF mel / Java mel | max abs diff 8.3e-6 / 8.9e-6 (limit 1e-3) |
| first-step logits after the forced prefix | max abs diff 1.6e-5 |
| greedy 20 steps with suppression (8 full-vocab + 3 restricted-vocab) | 11/11 identical |
| `transcribe()` (stop at eot, 96 tokens): ids, text, avg log-prob, no-speech | 9/9 identical (avg log-prob within 1.2e-6) |
| manual greedy loop vs `model.generate()` (FULL) | 3/3 identical |
| `WhisperMath` vs `Nn` (linear int8/f32 with tails, attention incl. causal + cache offset, conv k3 s1/s2, GELU) | 42/42 bit-identical |
| `Listen` on the JVM (fake AudioRecord, virtual clock) | stop 0.8 s after speech (4.32 s, expected 4.30), 8.0 s timeout, 12 s cap, manual stop, cancel, too-short blip, 48 kHz fallback, resampler error 0.001, every AudioRecord released |

Speed for **5 s of audio** on the sandbox Xeon (2.8 GHz), with load average around 3 from other jobs. Only 2 vCPUs
exist, so "4 threads" really means 2 contended cores, and the decoder cannot gain from them here:

| Mode, threads | log-mel | encoder | decoder per token, full / restricted vocab | total for 30 tokens, full / restricted |
|---|---|---|---|---|
| SHORT, 1 thread | 8 ms | 1.03 s | 14.6 / 4.7 ms | 1.62 / 1.27 s |
| SHORT, "4" threads | 9 ms | 0.70 s | 15.4 / 7.3 ms | 1.26 / 1.17 s |
| FULL, 1 thread | 48 ms | 11.0 s | 23.5 ms | 12.4 s |
| FULL, "4" threads | 26 ms | 7.2 s | 19.7 ms | 8.5 s |

- **Nn kernels.** With the shared `Nn` kernels instead (2 threads), SHORT takes 6.7 s for the encoder and 95 ms per
  token. `WhisperMath` is 5–6x faster.
- **12 s clip, 96 tokens, 2 threads.** 3.9 s with the full vocabulary (encoder 2.1 s), 2.9 s restricted.
- **Heap.** The 12 s transcription still succeeds with the JVM heap capped at 64 MB (`-Xmx64m`).
- **Phone estimate.** A 4-core Cortex-A53 phone should be about 2–3x slower than one sandbox core in total. Measure with
  `WhisperBench` / `WhisperCli` on a device.

## GPU VM pipeline (`select_finetune.py`)

```bash
# setup (Ubuntu + NVIDIA driver, one L4 24 GB)
python3 -m venv ~/wsp && . ~/wsp/bin/activate
pip install torch --index-url https://download.pytorch.org/whl/cu124          # any CUDA build that matches the driver
pip install "transformers==4.57.6" huggingface_hub hf_transfer soundfile scipy pandas pyarrow editdistance
sudo apt-get install -y openjdk-17-jdk-headless                               # optional: Java check stage
export HF_HUB_ENABLE_HF_TRANSFER=1
# run from the repo root; re-run the same command after any interruption (every stage resumes)
python speech/whisper/select_finetune.py --work /data/wsp --langs hi,ta,kn,en \
    --vocab-text data/text_train.jsonl --vocab-text data/free_questions_train.jsonl --vocab-text voice/catalogue.json \
    2>&1 | tee -a /data/wsp.log
# results: /data/wsp/export/whisper_{hi,ta,kn,en}.{bin,json} -> android assets; /data/wsp/report.json
```

### Stages

Each stage is cached under `--work`; select stages with `--stages`.

1. **`data`**: FLEURS (`google/fleurs`, CC-BY-4.0) `hi_in` / `ta_in` / `kn_in` / `en_us` train, dev and test.
   - Downloads `data/<cfg>/<split>.tsv` and `audio/<split>.tar.gz` with `huggingface_hub`, since `datasets` 4 can't run
     the loading script.
   - Falls back to parquet (`main` or `refs/convert/parquet`), then to `datasets<4`.
   - Extra training data: `--extra-manifest file.jsonl` (`{"audio", "text", "lang"}`) or
     `--extra-hf "repo|config|split|audio_col|text_col|lang"`. Examples: farmer recordings, Svarah (Indian English),
     Kathbath, IndicVoices; check their licences first.
2. **`eval`**: for every candidate:
   - **Licence check.** Is it on the Hub, and what licence does its card declare? Non-commercial (`*-nc-*`) models are
     skipped without download. Unknown or `other` licences are scored but not selected unless
     `--allow-unknown-licence`.
   - **Prompt probe.** On 40 dev clips it tries the standard prefix, the model's own forced ids, and a bare
     `[sot, notimestamps]`. The standard prefix stays unless another is better by 2 CER points.
   - **Scoring.** WER and CER on dev (FULL) and test (FULL and SHORT), each also on clips of 12 s or less. It also
     records the share of hypotheses longer than 96 tokens.

   Candidates:
   - hi: collabora/whisper-tiny-hindi, ARTPARK-IISc/whisper-tiny-vaani-hindi, openai/whisper-tiny
   - ta: tamilnlpSLIIT/whisper-tiny-ta-v3, BadBoy17G/whisper-tiny-tamil, openai/whisper-tiny
   - kn: vasista22/whisper-kannada-tiny, openai/whisper-tiny
   - en: openai/whisper-tiny with `<|en|>`

   Override the list with `--candidates-json`.
3. **`finetune`**: starts from the eligible candidate with the lowest dev CER (FULL window), otherwise from
   openai/whisper-tiny (MIT).
   - Trains in **SHORT mode**: padded mel frames are zero (the same as conv padding), and padded positions are masked in
     encoder self-attention and in decoder cross-attention, which HF's decoder lacks and is injected here.
   - Examples are 50% random **2–15 s crops** and 50% whole utterances (up to 30 s).
   - **Crop alignment.** Crops start and end only at word boundaries that fall in a pause. Word times come from
     teacher-forced cross-attention DTW over the alignment heads (OpenAI's `word_timestamps` recipe).
   - **Alignment check.** An utterance is used for crops only if its DTW path score beats a frame-shuffled baseline by
     at least 0.5 standard units. Random attention reaches about 0.2; a clean alignment about 3.8.
   - **Augmentation.** Gain ±6 dB, noise at 10–30 dB SNR (p 0.3), and light SpecAugment.
   - **Optimiser.** AdamW at 3e-5 with 200 warmup steps and linear decay, bf16 autocast, batch 32, at most 4000 steps.
   - **Selection.** Dev CER (SHORT) is checked every 250 steps; the best checkpoint is kept, with early stopping after 4
     evaluations without gain. Then test WER/CER (FULL and SHORT).
4. **`export`**: writes `export_whisper.py` files for the full and the restricted vocabulary. The restricted vocabulary
   comes from FLEURS train/dev plus the app's farm-domain sentences passed with `--vocab-text`. Both are re-scored on test
   in SHORT mode with the exported int8/fp16 weights and the phone's 96-token limit. It warns if more than 5% of ≤12 s
   references need more than 96 tokens; Tamil and Kannada are long in Whisper's BPE, so use `--phone-max-tokens`.
5. **`javacheck`** (if a JDK is present): runs `Whisper.java` on 20 test clips and reports token agreement with the
   Python int8 run.
6. **`report`**: writes `report.json` with every number, the licences, the chosen prompts, training curves, sizes,
   timings, and the GPU-hour estimate.

**Text normalisation** (WER/CER, `whisper_common.normalize_text`):

1. Unicode NFC (also decomposes the nukta letters U+0958–095F canonically).
2. Remove zero-width space, joiner and non-joiner, word joiner, BOM and soft hyphen.
3. Drop `<...>` and `[...]` tags.
4. Map Indic digits to ASCII.
5. Lowercase.
6. Turn every Unicode punctuation (P\*) or symbol (S\*) character into a space; this covers the danda U+0964/0965.
7. Collapse whitespace.

Whisper's `BasicTextNormalizer` is not used, because it deletes combining marks (Indic vowel signs). CER counts code
points, keeping single spaces.

**Estimated L4 time** for 4 languages with the defaults:

| Step | Time |
|---|---|
| Data download and preparation (network, no GPU) | 0.3–0.5 h |
| Candidate evaluation (9 model–language pairs) | about 0.3 h |
| Alignment | about 0.1 h |
| Fine-tuning (up to 4000 steps per language, early stopping) | about 1.5–2 h |
| Final test, export and int8 re-scoring | about 0.3 h |
| **Total** | **about 2.5–3.5 h** |

Peak GPU memory stays under 10 GB. Stage timings are in `report.json` (`timings_s`, `gpu_hours_measured`). Disk use is
about 6 GB of audio, plus about 0.6 GB of checkpoints per language (`last.pt` is deleted when a language finishes).

Offline dry run of the whole pipeline, with random models (one non-commercial, one missing, one with its own forced
ids) and synthetic audio, on CPU:

```bash
python speech/whisper/select_finetune.py --work /tmp/wsp_test --offline-test --langs hi,ta,kn,en
```

Standalone export:

```bash
python speech/whisper/export_whisper.py --model work/ft/hi/best --lang hi --out export/ [--keep-text hi_train.txt]
```
