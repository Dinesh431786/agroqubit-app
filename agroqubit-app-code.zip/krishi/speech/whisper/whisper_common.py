"""Shared helpers for the offline Whisper-tiny recogniser (export, tests, evaluation, fine-tuning).

Everything here mirrors what the phone does (android/src/in/krishi/doctor/Whisper.java):
  * log-mel identical to WhisperFeatureExtractor (torch path), batched, on any device;
  * SHORT mode: only the real audio frames (ceil(n/160), rounded up to even) go into the encoder; batches of
    different lengths are exact because padded mel frames are zero (= conv zero padding) and padded encoder
    positions are masked out of encoder self-attention and decoder cross-attention;
  * greedy decoding with Whisper's suppress_tokens / begin_suppress_tokens, avg log-prob and no-speech prob;
  * text normalisation + WER/CER;
  * a synthetic Whisper tokenizer (same id layout as openai/whisper-tiny) for offline tests.
"""
import base64, json, math, os, re, struct, unicodedata
import numpy as np
import torch
import torch.nn.functional as F

SR, N_FFT, HOP, N_SAMPLES, N_FRAMES = 16000, 400, 160, 480000, 3000
FLEURS = {"hi": "hi_in", "ta": "ta_in", "kn": "kn_in", "en": "en_us"}
LANG_NAMES = {"hi": "hindi", "ta": "tamil", "kn": "kannada", "en": "english"}


# ----------------------------------------------------------------------------------------------- frames / log-mel
def short_frames(n_samples, pad_frames=0):
    """Mel frames used in SHORT mode: frames whose centre lies inside the audio, plus pad_frames, rounded up to even."""
    f = -(-int(n_samples) // HOP) + int(pad_frames)
    f += f % 2
    return int(max(2, min(N_FRAMES, f)))


def mel_filters_np():
    from transformers import WhisperFeatureExtractor
    return np.asarray(WhisperFeatureExtractor(feature_size=80).mel_filters, np.float32)  # [201, 80]


class LogMel:
    """Exactly WhisperFeatureExtractor._torch_extract_fbank_features, for a [B, L] batch on any device.
    With L >= n_max + 400 the frames t < L//160 and the per-item max equal those of the 30 s padded input."""

    def __init__(self, mel_filters=None, device="cpu"):
        fb = mel_filters_np() if mel_filters is None else np.asarray(mel_filters, np.float32)
        self.fb = torch.tensor(fb, dtype=torch.float32, device=device)  # [201, 80]
        self.win = torch.hann_window(N_FFT, device=device)
        self.device = device

    def __call__(self, wave):
        st = torch.stft(wave, N_FFT, HOP, window=self.win, return_complex=True)
        mag = st[..., :-1].abs() ** 2
        log = torch.clamp(self.fb.T @ mag, min=1e-10).log10()
        mx = log.amax(dim=(1, 2), keepdim=True)
        return (torch.maximum(log, mx - 8.0) + 4.0) / 4.0


def batch_features(waves, logmel, mode="short", pad_frames=0):
    """waves: list of 1-D float arrays (16 kHz). Returns (feats [B, 80, F] with zeros after each item's frames,
    frames LongTensor [B]). mode 'full' = 30 s window (3000 frames, exact HF features)."""
    dev = logmel.device
    waves = [np.asarray(w, np.float32)[:N_SAMPLES] for w in waves]
    B = len(waves)
    if mode == "full":
        L = N_SAMPLES
        frames = [N_FRAMES] * B
    else:
        frames = [short_frames(len(w), pad_frames) for w in waves]
        L = min(N_SAMPLES, max(max(len(w) for w in waves) + 2 * N_FFT, max(frames) * HOP + N_FFT))
    W = torch.zeros(B, L, dtype=torch.float32)
    for i, w in enumerate(waves):
        W[i, : len(w)] = torch.from_numpy(w)
    feats = logmel(W.to(dev))
    if mode == "full":
        return feats[:, :, :N_FRAMES].contiguous(), torch.tensor(frames, device=dev)
    Fm = max(frames)
    feats = feats[:, :, :Fm].clone()
    for i, f in enumerate(frames):
        feats[i, :, f:] = 0.0
    return feats, torch.tensor(frames, device=dev)


# ----------------------------------------------------------------------------------------------- short-mode model
def _key_mask(model, keymask, dtype):
    """[B, T] bool (True = real position) -> mask for HF attention: bool for sdpa, additive for eager."""
    if keymask is None:
        return None
    impl = getattr(model.config, "_attn_implementation", "eager")
    if impl == "sdpa":
        return keymask[:, None, None, :]
    m = torch.zeros(keymask.shape, dtype=dtype, device=keymask.device)
    m.masked_fill_(~keymask, torch.finfo(dtype).min)
    return m[:, None, None, :]


def enable_cross_mask(model):
    """HF's WhisperDecoder never passes an encoder attention mask to its layers; inject one (model._xmask['mask'])."""
    if getattr(model, "_xmask", None) is not None:
        return model._xmask
    holder = {"mask": None}
    for layer in model.model.decoder.layers:
        orig = layer.forward

        def fwd(*a, _orig=orig, **kw):
            if holder["mask"] is not None and kw.get("encoder_attention_mask") is None:
                kw["encoder_attention_mask"] = holder["mask"]
            return _orig(*a, **kw)

        layer.forward = fwd
    model._xmask = holder
    return holder


def encode(model, feats, frames=None):
    """Whisper encoder for full (3000 frames) or SHORT (variable, masked) input.
    feats [B, 80, F] (F even, zeros after each item's frames). Returns (hidden [B, F/2, d], keymask [B, F/2] or None)."""
    enc = model.model.encoder
    x = F.gelu(enc.conv1(feats))
    x = F.gelu(enc.conv2(x)).permute(0, 2, 1)
    T = x.shape[1]
    if T > enc.embed_positions.weight.shape[0]:
        raise ValueError(f"{T} encoder positions > {enc.embed_positions.weight.shape[0]}")
    x = x + enc.embed_positions.weight[:T].to(x.dtype)
    x = F.dropout(x, p=enc.dropout, training=enc.training)
    keymask = None
    if frames is not None:
        km = torch.arange(T, device=x.device)[None, :] < (frames // 2)[:, None]
        if not bool(km.all()):
            keymask = km
    m = _key_mask(model, keymask, x.dtype)
    for layer in enc.layers:
        x = layer(x, m, layer_head_mask=None)[0]
    return enc.layer_norm(x), keymask


def set_cross_mask(model, keymask, dtype=torch.float32):
    enable_cross_mask(model)["mask"] = _key_mask(model, keymask, dtype)


@torch.no_grad()
def greedy(model, enc, keymask, prompt, suppress=(), begin_suppress=(), eot=50257, no_speech=None, max_new=96,
           stop_at_eot=True, sot_index=0, allowed=None):
    """Batched greedy decoding exactly as the phone does it. allowed: optional bool [V] (restricted vocabulary: other
    ids get -inf before everything else, as in a pruned export). Returns dict(ids=list[list[int]] (without eot),
    raw=list[list[int]] (all generated incl. eot), avg_logprob, no_speech_prob, first_logits [B, V])."""
    B, dev = enc.shape[0], enc.device
    set_cross_mask(model, keymask, enc.dtype)
    dec = model.model.decoder
    ids = torch.tensor([list(prompt)] * B, device=dev)
    out = dec(input_ids=ids, encoder_hidden_states=enc, use_cache=True)
    cache = out.past_key_values
    h = out.last_hidden_state
    lg2 = model.proj_out(h[:, [sot_index, -1]]).float()
    V = lg2.shape[-1]
    if allowed is not None:
        allowed = allowed.to(dev)
        lg2 = lg2.masked_fill(~allowed, float("-inf"))
    nsp = lg2[:, 0].softmax(-1)[:, no_speech] if no_speech is not None and 0 <= no_speech < V else torch.zeros(B, device=dev)
    logits = lg2[:, 1]
    first = logits.clone()
    sup = torch.zeros(V, dtype=torch.bool, device=dev)
    sup[[t for t in suppress if 0 <= t < V]] = True
    bsup = torch.zeros(V, dtype=torch.bool, device=dev)
    bsup[[t for t in begin_suppress if 0 <= t < V]] = True
    done = torch.zeros(B, dtype=torch.bool, device=dev)
    slp = torch.zeros(B, dtype=torch.float64, device=dev)
    nlp = torch.zeros(B, dtype=torch.float64, device=dev)
    toks = []
    for step in range(max_new):
        logits = logits.masked_fill(sup, float("-inf"))
        if step == 0:
            logits = logits.masked_fill(bsup, float("-inf"))
        nxt = logits.argmax(-1)
        lp = torch.log_softmax(logits, -1).gather(1, nxt[:, None])[:, 0].double()
        live = ~done if stop_at_eot else torch.ones_like(done)
        slp += torch.where(live, lp, torch.zeros_like(lp))
        nlp += live.double()
        if stop_at_eot:
            nxt = torch.where(done, torch.full_like(nxt, eot), nxt)
        toks.append(nxt)
        done |= nxt == eot
        if stop_at_eot and bool(done.all()):
            break
        if step == max_new - 1:
            break
        out = dec(input_ids=nxt[:, None], encoder_hidden_states=enc, past_key_values=cache, use_cache=True)
        cache = out.past_key_values
        logits = model.proj_out(out.last_hidden_state[:, -1]).float()
        if allowed is not None:
            logits = logits.masked_fill(~allowed, float("-inf"))
    set_cross_mask(model, None)
    raw = torch.stack(toks, 1).tolist() if toks else [[] for _ in range(B)]
    ids = []
    for r in raw:
        if stop_at_eot and eot in r:
            r = r[: r.index(eot)]
        ids.append(r)
    return {"ids": ids, "raw": raw, "avg_logprob": (slp / nlp.clamp(min=1)).tolist(), "no_speech_prob": nsp.tolist(),
            "first_logits": first}


# ----------------------------------------------------------------------------------------------- tokens / prompt
def special_ids(gen, tok, lang):
    """Special token ids for a model (generation_config first, tokenizer as fallback)."""
    def tid(s):
        try:
            i = tok.convert_tokens_to_ids(s)
        except Exception:
            i = None
        return i if isinstance(i, int) and i >= 0 else None

    lang_to_id = dict(getattr(gen, "lang_to_id", None) or {})
    task_to_id = dict(getattr(gen, "task_to_id", None) or {})
    d = {
        "sot": getattr(gen, "decoder_start_token_id", None) or tid("<|startoftranscript|>"),
        "eot": tid("<|endoftext|>") if tid("<|endoftext|>") is not None else getattr(gen, "eos_token_id", None),
        "lang": lang_to_id.get(f"<|{lang}|>") or tid(f"<|{lang}|>"),
        "transcribe": task_to_id.get("transcribe") or tid("<|transcribe|>"),
        "translate": task_to_id.get("translate") or tid("<|translate|>"),
        "notimestamps": getattr(gen, "no_timestamps_token_id", None) or tid("<|notimestamps|>"),
        "no_speech": tid("<|nospeech|>") if tid("<|nospeech|>") not in (None, tid("<|endoftext|>")) else tid("<|nocaptions|>"),
        "startofprev": getattr(gen, "prev_sot_token_id", None) or tid("<|startofprev|>"),
    }
    if isinstance(d["eot"], (list, tuple)):
        d["eot"] = d["eot"][0]
    for k in ("no_speech", "startofprev", "translate"):
        if d[k] == d["eot"]:
            d[k] = None
    return d


def decoder_prompt(gen, tok, lang, variant="hf"):
    """Forced decoder prefix.
    'hf'     = what model.generate(language=lang, task='transcribe') uses: [sot, lang, transcribe, notimestamps]
    'forced' = the model's own forced_decoder_ids (None -> language token), + notimestamps
    'bare'   = [sot, notimestamps] (models fine-tuned without language/task tokens)"""
    s = special_ids(gen, tok, lang)
    if variant == "bare":
        p = [s["sot"]]
    elif variant == "forced":
        forced = getattr(gen, "forced_decoder_ids", None)
        if not forced:
            return None
        p = [s["sot"]]
        for pos, t in sorted((int(a), b) for a, b in forced):
            if pos != len(p):
                return None
            p.append(s["lang"] if t is None else int(t))
    else:
        p = [s["sot"], s["lang"], s["transcribe"]]
    if s["notimestamps"] is not None and p[-1] != s["notimestamps"]:
        p.append(s["notimestamps"])
    if any(t is None for t in p):
        return None
    return [int(t) for t in p]


def vocab_bytes(tok, n_vocab):
    """Raw bytes of every token id (GPT-2 byte decoder for BPE tokens, UTF-8 of the name for added/special tokens)
    and the set of ids that are special/added (never part of the text)."""
    from transformers.models.whisper.tokenization_whisper import bytes_to_unicode
    dec = getattr(tok, "byte_decoder", None) or {v: k for k, v in bytes_to_unicode().items()}
    added = set(getattr(tok, "added_tokens_decoder", {}).keys()) | set(tok.all_special_ids)
    out, special = [], set()
    for i in range(n_vocab):
        try:
            t = tok.convert_ids_to_tokens(i)
        except Exception:
            t = None
        if t is None:
            out.append(b"")
            special.add(i)
            continue
        if i in added:
            out.append(t.encode("utf-8"))
            special.add(i)
            continue
        try:
            out.append(bytes(dec[c] for c in t))
        except KeyError:
            out.append(t.encode("utf-8"))
    return out, special


def keep_ids(tok, texts, specials, n_vocab):
    """Restricted vocabulary for one language: every token of the given texts (whole sentences and each word with
    and without a leading space), all 256 single-byte tokens (any UTF-8 text stays spellable) and the specials."""
    from transformers.models.whisper.tokenization_whisper import bytes_to_unicode
    be = bytes_to_unicode()
    keep = {int(t) for t in specials if t is not None and t >= 0}
    for b in range(256):
        i = tok.convert_tokens_to_ids(be[b])
        if isinstance(i, int) and 0 <= i < n_vocab:
            keep.add(i)
    seen = set()
    for t in texts:
        t = (t or "").strip()
        if not t:
            continue
        keep.update(tok(t, add_special_tokens=False).input_ids)
        for w in t.split():
            if w not in seen:
                seen.add(w)
                keep.update(tok(w, add_special_tokens=False).input_ids)
                keep.update(tok(" " + w, add_special_tokens=False).input_ids)
    return sorted(i for i in keep if 0 <= i < n_vocab)


def detok(ids, vb, eot):
    """Phone detokenisation: drop ids >= eot, concatenate raw bytes, decode UTF-8 (errors -> U+FFFD), strip."""
    b = b"".join(vb[i] for i in ids if 0 <= i < eot)
    return b.decode("utf-8", errors="replace").strip()


def b64(b):
    return base64.b64encode(bytes(b)).decode("ascii")


# ----------------------------------------------------------------------------------------------- synthetic tokenizer
SYN_WORDS = [" the", " and", " leaf", " rice", " spots", " yellow", " water", " पत्ते", " पीले", " धान", " खेत", " में",
             " हैं", " दवाई", " பயிர்", " இலை", " மஞ்சள்", " தண்ணீர்", " ರೈತ", " ಎಲೆ", " ಹಳದಿ", " ನೀರು", " ಬೆಳೆ", "ing",
             " 10", " kg", ".", ",", "?", " ।"]


def build_synthetic_tokenizer(out_dir, seed=0):
    """A WhisperTokenizer with the same id layout as openai/whisper-tiny (50257 byte-level BPE tokens, then
    <|endoftext|> 50257, <|startoftranscript|> 50258, 99 languages, task/control tokens, <|notimestamps|> 50363,
    1501 timestamps) but a made-up BPE vocabulary (incl. tokens that split UTF-8 characters). Offline tests only."""
    from transformers import WhisperTokenizer
    from transformers.models.whisper.tokenization_whisper import bytes_to_unicode, LANGUAGES
    os.makedirs(out_dir, exist_ok=True)
    be = bytes_to_unicode()
    vocab, merges = {}, []
    for b in sorted(be):
        vocab[be[b]] = len(vocab)
    for w in SYN_WORDS:
        sym = [be[b] for b in w.encode("utf-8")]
        while len(sym) > 1:
            m = sym[0] + sym[1]
            if m not in vocab:
                vocab[m] = len(vocab)
                merges.append(f"{sym[0]} {sym[1]}")
            sym = [m] + sym[2:]
    rng = np.random.default_rng(seed)
    chars = [be[b] for b in range(256)]
    while len(vocab) < 50257:
        t = "".join(chars[i] for i in rng.integers(0, 256, size=int(rng.integers(2, 6))))
        if t not in vocab:
            vocab[t] = len(vocab)
    vocab["<|endoftext|>"] = 50257
    vf, mf = os.path.join(out_dir, "vocab.json"), os.path.join(out_dir, "merges.txt")
    with open(vf, "w", encoding="utf-8") as f:
        json.dump(vocab, f, ensure_ascii=False)
    with open(mf, "w", encoding="utf-8") as f:
        f.write("#version: 0.2\n" + "\n".join(merges) + "\n")
    tok = WhisperTokenizer(vf, mf, errors="replace", pad_token="<|endoftext|>")
    langs = [f"<|{c}|>" for c in list(LANGUAGES)[:99]]
    specials = ["<|endoftext|>", "<|startoftranscript|>"] + langs + ["<|translate|>", "<|transcribe|>", "<|startoflm|>",
                                                                     "<|startofprev|>", "<|nocaptions|>", "<|notimestamps|>"]
    tok.add_special_tokens({"additional_special_tokens": specials})
    tok.add_tokens(["<|%.2f|>" % (i * 0.02) for i in range(1501)])
    assert len(tok) == 51865 and tok.convert_tokens_to_ids("<|notimestamps|>") == 50363, len(tok)
    tok.save_pretrained(out_dir)
    return tok


def synthetic_generation_config(tok):
    from transformers import GenerationConfig
    from transformers.models.whisper.tokenization_whisper import LANGUAGES
    g = GenerationConfig()
    g.decoder_start_token_id = 50258
    g.bos_token_id = g.eos_token_id = g.pad_token_id = 50257
    g.lang_to_id = {f"<|{c}|>": tok.convert_tokens_to_ids(f"<|{c}|>") for c in list(LANGUAGES)[:99]}
    g.task_to_id = {"transcribe": 50359, "translate": 50358}
    g.no_timestamps_token_id = 50363
    g.prev_sot_token_id = 50361
    g.is_multilingual = True
    g.forced_decoder_ids = [[1, None], [2, 50359]]
    g.begin_suppress_tokens = [220, 50257]
    # same non-speech list as openai/whisper-tiny's generation_config
    g.suppress_tokens = [1, 2, 7, 8, 9, 10, 14, 25, 26, 27, 28, 29, 31, 58, 59, 60, 61, 62, 63, 90, 91, 92, 93, 359, 503,
                         522, 542, 873, 893, 902, 918, 922, 931, 1350, 1853, 1982, 2460, 2627, 3246, 3253, 3268, 3536,
                         3846, 3961, 4183, 4667, 6585, 6647, 7273, 9061, 9383, 10428, 10929, 11938, 12033, 12331, 12562,
                         13793, 14157, 14635, 15265, 15618, 16553, 16604, 18362, 18956, 20075, 21675, 22520, 26130,
                         26161, 26435, 28279, 29464, 31650, 32302, 32470, 36865, 42863, 47425, 49870, 50254, 50258,
                         50358, 50359, 50360, 50361, 50362]
    g.max_length = 448
    g.return_timestamps = False
    g.alignment_heads = [[2, 2], [3, 0], [3, 2], [3, 3], [3, 4], [3, 5]]
    return g


def tiny_config(**kw):
    from transformers import WhisperConfig
    c = dict(vocab_size=51865, num_mel_bins=80, d_model=384, encoder_layers=4, decoder_layers=4,
             encoder_attention_heads=6, decoder_attention_heads=6, encoder_ffn_dim=1536, decoder_ffn_dim=1536,
             max_source_positions=1500, max_target_positions=448, decoder_start_token_id=50258, eos_token_id=50257,
             bos_token_id=50257, pad_token_id=50257, activation_function="gelu", scale_embedding=False)
    c.update(kw)
    return WhisperConfig(**c)


def is_tiny(cfg):
    return (cfg.d_model, cfg.encoder_layers, cfg.decoder_layers, cfg.encoder_attention_heads, cfg.num_mel_bins) == (384, 4, 4, 6, 80)


# ----------------------------------------------------------------------------------------------- text normalisation
_ZW = dict.fromkeys(map(ord, "​‌‍⁠﻿­"), None)
_DIGITS = {}
for _base in (0x0966, 0x0BE6, 0x0CE6, 0x09E6, 0x0A66, 0x0AE6, 0x0B66, 0x0C66, 0x0D66):  # Indic digit blocks -> 0-9
    for _k in range(10):
        _DIGITS[_base + _k] = ord("0") + _k
_BRACKETS = re.compile(r"[<\[][^>\]]*[>\]]")


def normalize_text(s):
    """WER/CER normaliser (script-safe; Whisper's BasicTextNormalizer is NOT used because it deletes Indic vowel
    signs, category M). Steps: NFC (also decomposes nukta letters U+0958-095F the canonical way); drop zero-width
    chars and soft hyphen; remove <...>/[...] tags; Indic digits -> ASCII; lowercase; every Unicode punctuation (P*)
    or symbol (S*) char -> space (danda U+0964/0965 are P*); collapse whitespace."""
    s = unicodedata.normalize("NFC", s or "").translate(_ZW)
    s = _BRACKETS.sub(" ", s).translate(_DIGITS).lower()
    s = "".join(" " if unicodedata.category(c)[0] in "PS" else c for c in s)
    return " ".join(s.split())


def edit_distance(a, b):
    try:
        import editdistance
        return editdistance.eval(a, b)
    except ImportError:
        pass
    if len(a) < len(b):
        a, b = b, a
    prev = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        cur = [i] + [0] * len(b)
        for j, y in enumerate(b, 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x != y))
        prev = cur
    return prev[-1]


def wer_cer(refs, hyps):
    """Corpus WER/CER (total edits / total reference length) on normalize_text() output; CER counts code points
    with single spaces between words (like jiwer.cer)."""
    we = wn = ce = cn = 0
    for r, h in zip(refs, hyps):
        r, h = normalize_text(r), normalize_text(h)
        rw, hw = r.split(), h.split()
        we += edit_distance(rw, hw)
        wn += len(rw)
        ce += edit_distance(list(r), list(h))
        cn += len(r)
    return {"wer": we / max(1, wn), "cer": ce / max(1, cn), "n": len(refs), "ref_words": wn, "ref_chars": cn}
