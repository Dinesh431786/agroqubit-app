#!/usr/bin/env python3
"""Export a transformers WhisperForConditionalGeneration (Whisper-tiny dims) for the phone:

  whisper_<lang>.bin   KRW1 (android/tools/krw.py): int8 rows for every linear weight and the token embedding,
                       fp16 conv stem + positional embeddings, fp32 layer norms and biases. HF parameter names
                       without the leading "model." (e.g. encoder.layers.0.fc1.weight). proj_out.weight only if it
                       is not tied to decoder.embed_tokens.weight.
  whisper_<lang>.json  dims, special token ids, forced decoder prompt, suppress / begin_suppress tokens, mel filters
                       [80][201] (base64 f32 big-endian), STFT params, vocab (token id -> raw bytes: base64 blob +
                       base64 uint16 big-endian lengths; ids >= eot and "nontext_ids" are never text).

VM (real checkpoints; tokenizer + generation_config from the hub, falling back to openai/whisper-tiny's):
  python speech/whisper/export_whisper.py --model openai/whisper-tiny --lang hi --out export/
  python speech/whisper/export_whisper.py --model work/ft/hi/best --lang hi --out export/
Offline test (random weights, synthetic vocab):
  python speech/whisper/export_whisper.py --random-tiny --lang hi --out /tmp/w
"""
import argparse, json, os, struct, sys, time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "..", "android", "tools"))
from krw import write_krw1, read_krw1, q8, f16, f32  # noqa: E402
import whisper_common as wc  # noqa: E402

FORMAT = "krishi-whisper-1"


def _kind(name, shape):
    if name.endswith("embed_positions.weight") or ".conv" in name and name.endswith(".weight"):
        return "f16"
    if len(shape) == 2 and (name.endswith("_proj.weight") or name.endswith("fc1.weight") or name.endswith("fc2.weight")
                            or name.endswith("embed_tokens.weight") or name == "proj_out.weight"):
        return "q8"
    return "f32"


def export_weights(model, path, keep=None):
    """Writes the KRW1 file. keep: sorted token ids of a restricted vocabulary (only those rows of the token embedding
    / output projection are written, in that order). Returns {name: kind}."""
    sd = model.state_dict()
    emb = sd["model.decoder.embed_tokens.weight"]
    tensors, kinds = {}, {}
    for k, v in sd.items():
        if k == "proj_out.weight":
            if v.data_ptr() == emb.data_ptr() or torch.equal(v, emb):
                continue
            name = k
        elif k.startswith("model."):
            name = k[len("model."):]
        else:
            continue
        a = v.detach().float().cpu().numpy()
        if keep is not None and name in ("decoder.embed_tokens.weight", "proj_out.weight"):
            a = a[np.asarray(keep, np.int64)]
        kind = _kind(name, a.shape)
        tensors[name] = {"q8": q8, "f16": f16, "f32": f32}[kind](a)
        kinds[name] = kind
    write_krw1(path, tensors)
    return kinds


def load_exported_into(model, bin_path, keep=None):
    """Loads the (dequantised) exported weights back into an HF model: the exact weights the phone uses. For a
    restricted-vocabulary export pass its keep ids: those rows are replaced, the others keep their old values and must
    be masked out when decoding (greedy(allowed=...))."""
    w = read_krw1(bin_path)
    sd = model.state_dict()
    new = {}
    for k in sd:
        name = k[len("model."):] if k.startswith("model.") else k
        if name in w:
            if keep is not None and name in ("decoder.embed_tokens.weight", "proj_out.weight"):
                t = sd[k].detach().clone().float()
                t[torch.as_tensor(keep)] = torch.from_numpy(w[name].copy())
                new[k] = t
            else:
                new[k] = torch.from_numpy(w[name].reshape(sd[k].shape).copy())
    if "proj_out.weight" not in w:
        new["proj_out.weight"] = new["model.decoder.embed_tokens.weight"]
    missing = [k for k in sd if k not in new]
    if missing:
        raise RuntimeError(f"weights missing in {bin_path}: {missing[:5]}")
    model.load_state_dict(new, strict=True)
    return model


def export_meta(model, tok, gen, lang, path, prompt=None, info=None, max_new_tokens=96, short_pad_frames=0, keep=None):
    cfg = model.config
    if getattr(cfg, "scale_embedding", False):
        raise ValueError("scale_embedding=True is not supported by Whisper.java")
    if cfg.activation_function not in ("gelu",):
        raise ValueError(f"activation {cfg.activation_function} not supported (Whisper.java uses exact GELU)")
    V = cfg.vocab_size
    sp = wc.special_ids(gen, tok, lang)
    if prompt is None:
        prompt = wc.decoder_prompt(gen, tok, lang, "hf")
    if not prompt:
        raise ValueError("could not build the decoder prompt")
    vb, special = wc.vocab_bytes(tok, V)
    eot = sp["eot"]
    lens = [len(b) for b in vb]
    if max(lens) > 65535:
        raise ValueError("token longer than 65535 bytes")
    mel = wc.mel_filters_np().T  # [80, 201]
    sup = [int(t) for t in (getattr(gen, "suppress_tokens", None) or []) if 0 <= int(t) < V]
    bsup = [int(t) for t in (getattr(gen, "begin_suppress_tokens", None) or []) if 0 <= int(t) < V]
    tied = model.proj_out.weight.data_ptr() == model.model.decoder.embed_tokens.weight.data_ptr() or \
        torch.equal(model.proj_out.weight, model.model.decoder.embed_tokens.weight)
    meta = {
        "format": FORMAT,
        "lang": lang,
        "dims": {"n_mels": cfg.num_mel_bins, "d_model": cfg.d_model, "enc_layers": cfg.encoder_layers,
                 "dec_layers": cfg.decoder_layers, "enc_heads": cfg.encoder_attention_heads,
                 "dec_heads": cfg.decoder_attention_heads, "enc_ffn": cfg.encoder_ffn_dim, "dec_ffn": cfg.decoder_ffn_dim,
                 "vocab": V, "n_audio_ctx": cfg.max_source_positions, "n_text_ctx": cfg.max_target_positions},
        "layer_norm_eps": 1e-5,
        "activation": "gelu",
        "tokens": {k: (int(v) if v is not None else -1) for k, v in sp.items()},
        "prompt": [int(t) for t in prompt],
        "sot_index": int(prompt.index(sp["sot"])) if sp["sot"] in prompt else 0,
        "suppress_tokens": sup,
        "begin_suppress_tokens": bsup,
        "max_new_tokens": int(max_new_tokens),
        "tied_output": bool(tied),
        "audio": {"sr": wc.SR, "n_fft": wc.N_FFT, "hop": wc.HOP, "n_mels": cfg.num_mel_bins, "chunk_samples": wc.N_SAMPLES,
                  "n_frames": wc.N_FRAMES, "window": "hann_periodic", "center": "reflect", "log": "log10",
                  "dynamic_range": 8.0, "short_pad_frames": int(short_pad_frames)},
        "mel_filters": {"shape": list(mel.shape), "dtype": "f32be", "b64": wc.b64(np.asarray(mel, ">f4").tobytes())},
        "vocab": {"n": V, "text_below": int(eot), "nontext_ids": sorted(i for i in special if i < eot),
                  "lens_b64": wc.b64(np.asarray(lens, ">u2").tobytes()), "bytes_b64": wc.b64(b"".join(vb))},
        "quant": {"linear": "int8 rows", "embed_tokens": "int8 rows", "conv": "f16", "positions": "f16",
                  "norms_biases": "f32"},
        "info": dict(info or {}),
    }
    if keep is not None:
        need = [t for t in list(prompt) + [sp["eot"], sp["no_speech"]] if t is not None and t >= 0]
        miss = [t for t in need if t not in set(keep)]
        if miss:
            raise ValueError(f"restricted vocabulary lacks special tokens {miss}")
        meta["vocab_ids"] = {"n": len(keep), "b64": wc.b64(np.asarray(keep, ">i4").tobytes())}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=True, separators=(",", ":"))
    return meta


def export(model, tok, gen, lang, out_dir, name=None, prompt=None, info=None, max_new_tokens=96, short_pad_frames=0, keep=None):
    os.makedirs(out_dir, exist_ok=True)
    name = name or f"whisper_{lang}"
    bp, jp = os.path.join(out_dir, name + ".bin"), os.path.join(out_dir, name + ".json")
    model = model.float().cpu().eval()
    kinds = export_weights(model, bp, keep)
    info = dict(info or {})
    info.setdefault("exported", time.strftime("%Y-%m-%d %H:%M:%S"))
    info["tensors"] = len(kinds)
    if keep is not None:
        info["vocab_kept"] = len(keep)
    export_meta(model, tok, gen, lang, jp, prompt=prompt, info=info, max_new_tokens=max_new_tokens,
                short_pad_frames=short_pad_frames, keep=keep)
    return bp, jp


def load_model(model_id, tokenizer_id=None, attn="sdpa", fallback="openai/whisper-tiny"):
    """Model + slow tokenizer + generation_config, with fallbacks for fine-tuned repos that lack them."""
    from transformers import WhisperForConditionalGeneration, WhisperTokenizer, GenerationConfig
    model = WhisperForConditionalGeneration.from_pretrained(model_id, attn_implementation=attn).float()
    tok = None
    for src in [tokenizer_id, model_id] + ([fallback] if fallback and fallback != model_id else []):
        if not src:
            continue
        try:
            tok = WhisperTokenizer.from_pretrained(src)
            break
        except Exception as e:  # noqa: BLE001
            print(f"[export] tokenizer from {src} failed: {type(e).__name__}: {e}", file=sys.stderr)
    if tok is None:
        raise RuntimeError("no tokenizer")
    own = fb = None
    try:
        own = GenerationConfig.from_pretrained(model_id)
    except Exception as e:  # noqa: BLE001
        print(f"[export] {model_id} has no generation_config.json ({type(e).__name__}); using the model config + {fallback}", file=sys.stderr)
    try:
        fb = GenerationConfig.from_pretrained(fallback) if fallback else None
    except Exception as e:  # noqa: BLE001
        print(f"[export] generation_config from {fallback} failed: {type(e).__name__}", file=sys.stderr)
    gen = merge_generation_config(model, own, fb)
    return model, tok, gen


def merge_generation_config(model, own, fallback):
    """The model's own generation config wins (its forced ids / suppress lists are what it was trained and published
    with); missing Whisper fields (lang_to_id, task_to_id, no_timestamps_token_id, alignment_heads, ...) come from the
    legacy model config, then from the base model's generation config."""
    import copy
    g = copy.deepcopy(own if own is not None else (fallback if fallback is not None else model.generation_config))
    for attr in ("forced_decoder_ids", "suppress_tokens", "begin_suppress_tokens"):
        if getattr(g, attr, None) is None and getattr(model.config, attr, None) is not None:
            setattr(g, attr, getattr(model.config, attr))
    if fallback is not None:
        for attr in ("lang_to_id", "task_to_id", "no_timestamps_token_id", "decoder_start_token_id", "prev_sot_token_id",
                     "alignment_heads", "is_multilingual", "suppress_tokens", "begin_suppress_tokens"):
            if getattr(g, attr, None) is None and getattr(fallback, attr, None) is not None:
                setattr(g, attr, copy.deepcopy(getattr(fallback, attr)))
    return g


def random_tiny(seed=0, tok_dir=None):
    """Random-init Whisper-tiny with a synthetic vocab (offline tests)."""
    from transformers import WhisperForConditionalGeneration
    torch.manual_seed(seed)
    tok_dir = tok_dir or os.path.join("/tmp", "krishi_whisper_syntok")
    tok = wc.build_synthetic_tokenizer(tok_dir, seed=seed)
    model = WhisperForConditionalGeneration(wc.tiny_config()).eval()
    gen = wc.synthetic_generation_config(tok)
    model.generation_config = gen
    return model, tok, gen


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", help="hub id or local dir of a WhisperForConditionalGeneration")
    ap.add_argument("--tokenizer", help="tokenizer source if the model repo has none (default: model, then openai/whisper-tiny)")
    ap.add_argument("--random-tiny", action="store_true", help="random weights + synthetic vocab (offline test)")
    ap.add_argument("--lang", required=True, help="hi | ta | kn | en (any Whisper language code)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--name", help="file stem (default whisper_<lang>)")
    ap.add_argument("--prompt", help="override the forced prompt, JSON list of ids")
    ap.add_argument("--prompt-variant", default="hf", choices=["hf", "forced", "bare"])
    ap.add_argument("--max-new-tokens", type=int, default=96)
    ap.add_argument("--short-pad-frames", type=int, default=0)
    ap.add_argument("--info", help="JSON file merged into meta['info'] (licence, metrics, ...)")
    ap.add_argument("--allow-non-tiny", action="store_true")
    ap.add_argument("--keep-text", action="append", default=[],
                    help="restrict the vocabulary to tokens of these UTF-8 text files (one sentence per line) + bytes + specials")
    a = ap.parse_args()
    if a.random_tiny:
        model, tok, gen = random_tiny()
        src = "random-init (synthetic vocab)"
    else:
        if not a.model:
            ap.error("--model or --random-tiny")
        model, tok, gen = load_model(a.model, a.tokenizer)
        src = a.model
    if not wc.is_tiny(model.config) and not a.allow_non_tiny:
        sys.exit(f"{src} is not Whisper-tiny dims ({model.config.d_model}, {model.config.encoder_layers} layers); use --allow-non-tiny")
    prompt = json.loads(a.prompt) if a.prompt else wc.decoder_prompt(gen, tok, a.lang, a.prompt_variant)
    info = {"source": src}
    if a.info:
        with open(a.info, encoding="utf-8") as f:
            info.update(json.load(f))
    keep = None
    if a.keep_text:
        texts = []
        for fn in a.keep_text:
            with open(fn, encoding="utf-8") as f:
                texts += [l.strip() for l in f if l.strip()]
        sp = wc.special_ids(gen, tok, a.lang)
        keep = wc.keep_ids(tok, texts, list(prompt) + [sp["eot"], sp["no_speech"]], model.config.vocab_size)
    t0 = time.time()
    bp, jp = export(model, tok, gen, a.lang, a.out, a.name, prompt, info, a.max_new_tokens, a.short_pad_frames, keep)
    print(json.dumps({"bin": bp, "bin_mb": round(os.path.getsize(bp) / 1e6, 2), "json": jp,
                      "json_kb": round(os.path.getsize(jp) / 1e3, 1), "prompt": prompt, "seconds": round(time.time() - t0, 1)}))


if __name__ == "__main__":
    main()
