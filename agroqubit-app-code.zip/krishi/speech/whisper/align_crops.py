"""Word timings from Whisper cross-attention and random 2-15 s training crops cut at pauses between words.

FLEURS utterances are 5-30 s read sentences; the phone sees 2-12 s questions in SHORT mode. To train on shorter
pieces without wrong labels we need to know where each word is: like OpenAI's word_timestamps, the reference
tokens are teacher-forced through the starting checkpoint (30 s window, eager attention), the cross-attention of the
alignment heads is renormalised over the audio frames, standardised over tokens, median-filtered (width 7), averaged
and aligned with DTW. A crop may only start/end at a word boundary whose +-0.2 s neighbourhood has a pause (frame
energy below floor + 25% of the speech range); the cut is placed at the quietest frame. Utterances whose alignment
looks degenerate are only used whole.
"""
import numpy as np
import torch

TOKENS_PER_SECOND = 50  # encoder positions per second


def dtw(x):
    """OpenAI's dtw_cpu (same tie-breaking), vectorised over anti-diagonals. x: cost [N, M] -> (text_idx, time_idx)."""
    N, M = x.shape
    cost = np.full((N + 1, M + 1), np.inf)
    cost[0, 0] = 0
    trace = np.full((N + 1, M + 1), -1, np.int8)
    for d in range(2, N + M + 1):
        i = np.arange(max(1, d - M), min(N, d - 1) + 1)
        if len(i) == 0:
            continue
        j = d - i
        c0, c1, c2 = cost[i - 1, j - 1], cost[i - 1, j], cost[i, j - 1]
        t = np.where((c0 < c1) & (c0 < c2), 0, np.where((c1 < c0) & (c1 < c2), 1, 2))
        cost[i, j] = x[i - 1, j - 1] + np.where(t == 0, c0, np.where(t == 1, c1, c2))
        trace[i, j] = t
    trace[0, :] = 2
    trace[:, 0] = 1
    i, j, path = N, M, []
    while i > 0 or j > 0:
        path.append((i - 1, j - 1))
        t = trace[i, j]
        if t == 0:
            i, j = i - 1, j - 1
        elif t == 1:
            i -= 1
        else:
            j -= 1
    p = np.array(path[::-1]).T
    return p[0], p[1]


def median_filter(x, width=7):
    """Median over the last axis with reflect padding (OpenAI's median_filter)."""
    if x.shape[-1] <= width // 2:
        return x
    pad, shape = width // 2, x.shape
    y = torch.nn.functional.pad(x.reshape(1, -1, shape[-1]), (pad, pad), mode="reflect")   # reflect needs 2-D/3-D input
    return y.unfold(-1, width, 1).median(-1).values.reshape(shape)


def word_spans(tokens, vb):
    """Token index ranges [(a, b)] of words: a word starts at a complete-UTF-8 unit whose bytes start with a space."""
    units, cur = [], []
    for k, t in enumerate(tokens):
        cur.append(k)
        try:
            b"".join(vb[tokens[i]] for i in cur).decode("utf-8")
            units.append(cur)
            cur = []
        except UnicodeDecodeError:
            pass
    if cur:
        units.append(cur)
    words = []
    for u in units:
        first = vb[tokens[u[0]]]
        if not words or first.startswith(b" "):
            words.append([u[0], u[-1] + 1])
        else:
            words[-1][1] = u[-1] + 1
    return [tuple(w) for w in words]


def alignment_heads(model):
    h = getattr(model.generation_config, "alignment_heads", None)
    if h:
        return [tuple(int(v) for v in x) for x in h]
    L, H = model.config.decoder_layers, model.config.decoder_attention_heads
    return [(l, k) for l in range(L // 2, L) for k in range(H)]


@torch.no_grad()
def attention_matrices(model, feats, n_frames, token_lists, prompt, eot, heads=None):
    """Teacher-forced cross-attention of the alignment heads (OpenAI's word_timestamps recipe), one [n+1, frames/2]
    matrix per item (rows: text tokens + eot; renormalised over the audio frames, standardised over tokens, median
    filtered, averaged over heads). feats [B, 80, 3000] (full window), n_frames [B] real mel frames."""
    heads = heads or alignment_heads(model)
    P = len(prompt)
    seqs = [list(prompt) + list(t) + [eot] for t in token_lists]
    L = max(len(s) for s in seqs)
    dec = torch.full((len(seqs), L), eot, dtype=torch.long, device=feats.device)
    for b, s in enumerate(seqs):
        dec[b, : len(s)] = torch.tensor(s, device=feats.device)
    out = model(input_features=feats, decoder_input_ids=dec, output_attentions=True, return_dict=True)
    cross = out.cross_attentions
    mats = []
    for b, toks in enumerate(token_lists):
        n, nf = len(toks), max(2, int(n_frames[b]) // 2)
        if n == 0:
            mats.append(None)
            continue
        w = torch.stack([cross[l][b, h, P - 1: P + n, :nf] for l, h in heads]).float()  # [heads, n+1, nf]
        w = w / w.sum(-1, keepdim=True).clamp(min=1e-12)
        std, mean = torch.std_mean(w, dim=-2, keepdim=True, unbiased=False)
        w = (w - mean) / std.clamp(min=1e-12)
        mats.append(median_filter(w, 7).mean(0).cpu().numpy().astype(np.float64))
    return mats


def dtw_align(m, seed=0):
    """-> (start time in s of each row = text token / eot, path score, frame-shuffled path score) or None.
    The scores are the mean standardised attention along the DTW path: a real alignment beats the same matrix with
    its frames shuffled by a wide margin, flat/random attention does not."""
    if m is None:
        return None
    ti, tj = dtw(-m)
    jumps = np.pad(np.diff(ti), (1, 0), constant_values=1).astype(bool)
    jt = tj[jumps] / TOKENS_PER_SECOND
    ms = m[:, np.random.default_rng(seed).permutation(m.shape[1])]
    si, sj = dtw(-ms)
    return (jt, float(m[ti, tj].mean()), float(ms[si, sj].mean())) if len(jt) == m.shape[0] else None


def token_times(model, feats, n_frames, token_lists, prompt, eot, heads=None):
    """attention_matrices + dtw_align, in this process."""
    return [dtw_align(m) for m in attention_matrices(model, feats, n_frames, token_lists, prompt, eot, heads)]


def frame_db(x, hop=160, win=400):
    if len(x) < win:
        return np.array([10 * np.log10(np.mean(x ** 2) + 1e-10)])
    n = 1 + (len(x) - win) // hop
    idx = np.arange(win)[None] + hop * np.arange(n)[:, None]
    return 10 * np.log10((x[idx] ** 2).mean(1) + 1e-10)


def plan_cuts(x, tokens, aligned, vb, sr=16000, search=0.2, margin=0.5):
    """aligned = token_times() item. -> dict(ok, score, base, words=[[tok_a, tok_b]], cuts=[[boundary_index, sample]])."""
    words = word_spans(tokens, vb)
    if aligned is None or len(words) == 0:
        return {"ok": False, "words": [list(w) for w in words], "cuts": []}
    times, score, base = aligned
    dur = len(x) / sr
    starts = [float(times[a]) for a, _ in words] + [float(times[len(tokens)])]
    wl = np.diff(starts)
    ok = bool(np.all(wl >= 0) and starts[-1] <= dur + 0.5 and np.median(wl) > 0.04 and np.median(wl) < 2.5
              and (starts[-1] - starts[0]) > 0.3 * dur and score - base > margin)
    e = frame_db(x)
    floor, speech = np.percentile(e, 10), np.percentile(e, 90)
    thr = floor + 0.25 * max(speech - floor, 1e-3)
    cuts = [[0, 0]]
    for k in range(1, len(words)):
        c = int(round(starts[k] * 100))
        a, b = max(0, c - int(search * 100)), min(len(e), c + int(search * 100) + 1)
        if b <= a:
            continue
        j = a + int(np.argmin(e[a:b]))
        if e[j] < thr:
            s = min(len(x), j * 160 + 200)  # centre of the quietest 25 ms frame
            if s > cuts[-1][1]:
                cuts.append([k, s])
    cuts.append([len(words), len(x)])
    return {"ok": ok, "score": round(score, 3), "base": round(base, 3), "words": [list(w) for w in words], "cuts": cuts}


def sample_crop(info, n_samples, rng, min_s=2.0, max_s=15.0, sr=16000):
    """Random crop between two cuttable word boundaries, duration in [min_s, max_s] (closest to a random target).
    -> (start_sample, end_sample, word_a, word_b) or None."""
    if not info or not info.get("ok") or len(info["cuts"]) < 2:
        return None
    cuts = info["cuts"]
    target = rng.uniform(min_s, max_s)
    order = rng.permutation(len(cuts) - 1)
    for si in order[:8]:
        bs, ss = cuts[si]
        best = None
        for be, se in cuts[si + 1:]:
            d = (se - ss) / sr
            if d > max_s:
                break
            if d >= min_s and (best is None or abs(d - target) < abs(best[2] - target)):
                best = (be, se, d)
        if best is not None:
            return ss, best[1], bs, best[0]
    return None
