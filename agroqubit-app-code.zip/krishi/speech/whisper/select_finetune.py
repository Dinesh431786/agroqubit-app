#!/usr/bin/env python3
"""Pick, fine-tune and export one Whisper-tiny per language for the phone (GPU VM; --offline-test runs anywhere).

Stages (every result is cached under --work, so re-running the same command resumes where it stopped):
  data      FLEURS (google/fleurs, CC-BY-4.0) hi_in / ta_in / kn_in / en_us train+dev+test, plus optional extra
            training sets (--extra-manifest JSONL, --extra-hf repo|config|split|audio_col|text_col|lang)
  eval      every candidate checkpoint: does it exist? licence from its hub card (non-commercial -> skipped, unknown ->
            evaluated but not eligible unless --allow-unknown-licence); prompt probe (its own forced ids vs
            [sot, lang, transcribe, notimestamps] vs bare) on dev; WER/CER on dev (full 30 s window) and test (full
            window and SHORT mode = only the real audio frames, exactly like the phone)
  finetune  best eligible candidate per language (lowest dev CER, full window) fine-tuned in SHORT mode on random
            2-15 s crops cut at word pauses (cross-attention DTW) plus whole utterances; AMP (bf16); dev CER (SHORT)
            every --eval-every steps, best checkpoint kept, early stopping; then test WER/CER
  export    whisper_<lang>.bin/.json via export_whisper.py into --export-dir; the int8/fp16 weights are loaded back and
            re-scored on test in SHORT mode with the phone's token limit
  javacheck optional: android Whisper.java (needs javac/java) on test clips vs the Python int8 run (token agreement)
  report    <work>/report.json with every number, stage timings and a GPU-hour estimate

Text normalisation for WER/CER: whisper_common.normalize_text (NFC, zero-width chars removed, Indic digits -> ASCII,
lowercase, Unicode punctuation/symbols -> space, whitespace collapsed); CER over code points incl. single spaces.

Example (VM):  python speech/whisper/select_finetune.py --work /data/wsp --langs hi,ta,kn,en
Offline test:  python speech/whisper/select_finetune.py --work /tmp/wsp_test --offline-test
"""
import argparse, json, math, os, queue, random, re, shutil, subprocess, sys, threading, time, traceback

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, HERE)
import whisper_common as wc  # noqa: E402
import export_whisper as ex  # noqa: E402
import fleurs_data as fd  # noqa: E402
import align_crops as ac  # noqa: E402

CANDIDATES = {
    "hi": ["collabora/whisper-tiny-hindi", "ARTPARK-IISc/whisper-tiny-vaani-hindi", "openai/whisper-tiny"],
    "ta": ["tamilnlpSLIIT/whisper-tiny-ta-v3", "BadBoy17G/whisper-tiny-tamil", "openai/whisper-tiny"],
    "kn": ["vasista22/whisper-kannada-tiny", "openai/whisper-tiny"],
    "en": ["openai/whisper-tiny"],
}
FALLBACK = "openai/whisper-tiny"
PERMISSIVE = {"mit", "apache-2.0", "bsd", "bsd-2-clause", "bsd-3-clause", "cc0-1.0", "cc-by-4.0", "cc-by-3.0", "cc-by-2.0",
              "cc-by-sa-4.0", "cc-by-sa-3.0", "unlicense", "isc", "mpl-2.0", "bsl-1.0", "afl-3.0", "artistic-2.0", "zlib",
              "pddl", "odc-by", "cdla-permissive-2.0", "ecl-2.0", "wtfpl", "postgresql", "ncsa", "ms-pl", "openrail++"}
NORMALIZATION = ("whisper_common.normalize_text: Unicode NFC (nukta letters U+0958-095F decompose canonically); remove "
                 "zero-width space/joiner/non-joiner, word joiner, BOM, soft hyphen; drop <...>/[...] tags; Devanagari/"
                 "Tamil/Kannada/other Indic digits -> ASCII 0-9; lowercase; every Unicode punctuation (P*) or symbol (S*) "
                 "character -> space (includes danda U+0964/U+0965); collapse whitespace. Whisper's BasicTextNormalizer "
                 "is NOT used: it deletes combining marks (Indic vowel signs). WER = word edits / reference words; CER = "
                 "code-point edits / reference code points (single spaces kept), both summed over the whole set.")

LOG = None


def log(msg):
    line = time.strftime("[%Y-%m-%d %H:%M:%S] ") + str(msg)
    print(line, flush=True)
    if LOG:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")


def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def load_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def slug(repo):
    return re.sub(r"[^A-Za-z0-9_.-]+", "__", repo)


# ----------------------------------------------------------------------------------------------- hub access
class Hub:
    """Model existence / licence / loading. Real: Hugging Face Hub. Offline: a local registry of random models."""

    def __init__(self, offline_dir=None):
        self.offline = offline_dir
        self.registry = load_json(os.path.join(offline_dir, "registry.json"), {}) if offline_dir else {}

    def info(self, repo):
        if self.offline:
            r = self.registry.get(repo)
            return {"exists": False, "error": "RepositoryNotFoundError (offline registry)"} if r is None else dict(r, exists=True)
        try:
            from huggingface_hub import HfApi
            mi = HfApi().model_info(repo)
        except Exception as e:  # noqa: BLE001
            name = type(e).__name__
            return {"exists": False, "error": f"{name}: {str(e)[:300]}", "unreachable": name not in ("RepositoryNotFoundError", "GatedRepoError")}
        lic = None
        cd = getattr(mi, "card_data", None) or getattr(mi, "cardData", None)
        if cd is not None:
            lic = cd.get("license") if isinstance(cd, dict) else getattr(cd, "license", None)
        if not lic:
            lic = next((t.split(":", 1)[1] for t in (mi.tags or []) if t.startswith("license:")), None)
        if isinstance(lic, (list, tuple)):
            lic = ",".join(map(str, lic))
        return {"exists": True, "licence": lic, "sha": getattr(mi, "sha", None), "gated": getattr(mi, "gated", False),
                "downloads": getattr(mi, "downloads", None), "last_modified": str(getattr(mi, "last_modified", "") or "")}

    def path(self, repo):
        return self.registry[repo]["path"] if self.offline else repo


def licence_class(lic):
    if not lic:
        return "unknown"
    parts = [p.strip().lower() for p in str(lic).split(",")]
    for l in parts:
        toks = re.split(r"[-_ ]", l)
        if "nc" in toks or "noncommercial" in l or "non-commercial" in l or "research-only" in l or "academic" in l:
            return "non_commercial"
    return "ok" if all(l in PERMISSIVE for l in parts) else "unknown"


FALLBACK_SOURCE = FALLBACK   # where the base tokenizer / generation config come from (a local path offline)


def load(hub, repo, device, attn="sdpa"):
    model, tok, gen = ex.load_model(hub.path(repo), attn=attn, fallback=FALLBACK_SOURCE)
    model = model.float().to(device).eval()
    wc.enable_cross_mask(model)
    return model, tok, gen


# ----------------------------------------------------------------------------------------------- evaluation
class Ctx:
    """Per-model decoding context: prompt, suppression, token bytes."""

    def __init__(self, model, tok, gen, lang, prompt):
        self.model, self.tok, self.gen, self.lang, self.prompt = model, tok, gen, lang, prompt
        self.sp = wc.special_ids(gen, tok, lang)
        V = model.config.vocab_size
        self.sup = [int(t) for t in (getattr(gen, "suppress_tokens", None) or []) if 0 <= int(t) < V]
        self.bsup = [int(t) for t in (getattr(gen, "begin_suppress_tokens", None) or []) if 0 <= int(t) < V]
        self.vb, _ = wc.vocab_bytes(tok, V)
        self.sot_index = prompt.index(self.sp["sot"]) if self.sp["sot"] in prompt else 0


@torch.no_grad()
def transcribe(ctx, logmel, waves, mode, max_new, batch, pad_frames=0):
    """-> list of (text, ids, avg_logprob, no_speech) in input order; batches sorted by length."""
    order = sorted(range(len(waves)), key=lambda i: len(waves[i]))
    out = [None] * len(waves)
    for k in range(0, len(order), batch):
        idx = order[k: k + batch]
        feats, frames = wc.batch_features([waves[i] for i in idx], logmel, mode, pad_frames)
        enc, km = wc.encode(ctx.model, feats, frames if mode == "short" else None)
        g = wc.greedy(ctx.model, enc, km, ctx.prompt, ctx.sup, ctx.bsup, ctx.sp["eot"], ctx.sp["no_speech"], max_new=max_new,
                      sot_index=ctx.sot_index)
        for j, i in enumerate(idx):
            out[i] = (wc.detok(g["ids"][j], ctx.vb, ctx.sp["eot"]), g["ids"][j], g["avg_logprob"][j], g["no_speech_prob"][j])
    return out


def score(rows, res, phone_max=96, samples=5):
    refs, hyps = [r["text"] for r in rows], [h[0] for h in res]
    m = wc.wer_cer(refs, hyps)
    le = [i for i, r in enumerate(rows) if r["n"] <= 12 * wc.SR]
    m12 = wc.wer_cer([refs[i] for i in le], [hyps[i] for i in le]) if le else None
    return {"wer": round(m["wer"], 4), "cer": round(m["cer"], 4), "n": m["n"],
            "le12s": {"wer": round(m12["wer"], 4), "cer": round(m12["cer"], 4), "n": m12["n"]} if m12 else None,
            "over_phone_max_tokens": round(float(np.mean([len(h[1]) > phone_max for h in res])), 4),
            "mean_avg_logprob": round(float(np.mean([h[2] for h in res])), 4),
            "samples": [{"ref": refs[i], "hyp": hyps[i]} for i in range(min(samples, len(rows)))]}


def eval_set(ctx, logmel, audio, rows, mode, a):
    t0 = time.time()
    waves = [fd.wave_of(audio, r) for r in rows]
    res = transcribe(ctx, logmel, waves, mode, a.eval_max_new, a.eval_batch, a.short_pad_frames)
    m = score(rows, res, a.phone_max_tokens)
    m["seconds"] = round(time.time() - t0, 1)
    m["mode"] = mode
    return m, res


def subset(rows, limit, seed=0):
    if not limit or len(rows) <= limit:
        return rows
    idx = sorted(random.Random(seed).sample(range(len(rows)), limit))
    return [rows[i] for i in idx]


def eval_candidate(hub, lang, repo, a, logmel):
    path = os.path.join(a.work, "eval", lang, slug(repo) + ".json")
    old = load_json(path)
    if old and old.get("status") in ("ok", "missing", "skipped_non_commercial", "skipped_not_tiny"):
        return old
    t0 = time.time()
    r = {"repo": repo, "lang": lang}
    info = hub.info(repo)
    r["hub"] = info
    if not info.get("exists"):
        r["status"] = "unreachable" if info.get("unreachable") else "missing"
        log(f"[eval] {lang} {repo}: {r['status']} ({info.get('error')})")
        if r["status"] == "missing":
            save_json(path, r)
        return r
    r["licence"] = info.get("licence")
    r["licence_class"] = licence_class(info.get("licence"))
    if r["licence_class"] == "non_commercial":
        r["status"] = "skipped_non_commercial"
        log(f"[eval] {lang} {repo}: licence {r['licence']} is non-commercial -> skipped")
        save_json(path, r)
        return r
    try:
        model, tok, gen = load(hub, repo, a.device)
    except Exception as e:  # noqa: BLE001
        r["status"] = "load_error"
        r["error"] = f"{type(e).__name__}: {str(e)[:500]}"
        log(f"[eval] {lang} {repo}: load failed: {r['error']}")
        save_json(path, r)
        return r
    cfg = model.config
    r["dims"] = {"d_model": cfg.d_model, "enc_layers": cfg.encoder_layers, "dec_layers": cfg.decoder_layers,
                 "heads": cfg.encoder_attention_heads, "vocab": cfg.vocab_size, "params_m": round(sum(p.numel() for p in model.parameters()) / 1e6, 1)}
    r["tiny"] = wc.is_tiny(cfg)
    if not r["tiny"] and not a.allow_non_tiny:
        r["status"] = "skipped_not_tiny"
        save_json(path, r)
        return r
    r["generation_config"] = {"forced_decoder_ids": getattr(gen, "forced_decoder_ids", None), "language": getattr(gen, "language", None),
                              "task": getattr(gen, "task", None), "suppress_tokens": len(getattr(gen, "suppress_tokens", None) or []),
                              "begin_suppress_tokens": getattr(gen, "begin_suppress_tokens", None)}
    dev_a, dev_rows = fd.load_split(a.work, lang, "dev")
    test_a, test_rows = fd.load_split(a.work, lang, "test")
    dev_rows, test_rows = subset(dev_rows, a.eval_limit), subset(test_rows, a.eval_limit)
    # prompt probe: the model's own forced ids may differ from the standard prefix
    variants = {}
    for v in ("hf", "forced", "bare"):
        p = wc.decoder_prompt(gen, tok, lang, v)
        if p and p not in variants.values():
            variants[v] = p
    probe = {}
    if len(variants) > 1:
        rows = dev_rows[: a.probe_n]
        for v, p in variants.items():
            m, _ = eval_set(Ctx(model, tok, gen, lang, p), logmel, dev_a, rows, "full", a)
            probe[v] = {"prompt": p, "cer": m["cer"], "wer": m["wer"]}
        # keep the standard prefix unless another one is clearly better (2 CER points) on the probe set
        best = "hf" if "hf" in probe else next(iter(probe))
        for v in probe:
            if probe[v]["cer"] < probe[best]["cer"] - 0.02:
                best = v
    else:
        best = next(iter(variants))
    r["prompt_probe"] = probe
    r["prompt_variant"] = best
    r["prompt"] = variants[best]
    ctx = Ctx(model, tok, gen, lang, r["prompt"])
    r["metrics"] = {}
    r["metrics"]["dev_full"], _ = eval_set(ctx, logmel, dev_a, dev_rows, "full", a)
    r["metrics"]["test_full"], _ = eval_set(ctx, logmel, test_a, test_rows, "full", a)
    r["metrics"]["test_short"], _ = eval_set(ctx, logmel, test_a, test_rows, "short", a)
    r["status"] = "ok"
    r["eligible"] = r["licence_class"] == "ok" or a.allow_unknown_licence
    r["seconds"] = round(time.time() - t0, 1)
    m = r["metrics"]
    log(f"[eval] {lang} {repo} ({r['licence']}, prompt {best}): dev CER {m['dev_full']['cer']:.3f} | test full WER/CER "
        f"{m['test_full']['wer']:.3f}/{m['test_full']['cer']:.3f} | test SHORT {m['test_short']['wer']:.3f}/{m['test_short']['cer']:.3f}"
        f" ({r['seconds']:.0f} s)")
    save_json(path, r)
    del model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return r


def select(a, lang):
    """Best eligible candidate by dev CER (full window); None -> fall back to openai/whisper-tiny."""
    rs = [load_json(os.path.join(a.work, "eval", lang, slug(c) + ".json")) for c in a.candidates[lang]]
    ok = [r for r in rs if r and r.get("status") == "ok" and (r.get("licence_class") == "ok" or a.allow_unknown_licence)
          and (r.get("tiny") or a.allow_non_tiny)]
    if not ok:
        return None
    return min(ok, key=lambda r: (r["metrics"]["dev_full"]["cer"], r["metrics"]["test_short"]["cer"]))


# ----------------------------------------------------------------------------------------------- fine-tuning
def train_sets(a, lang):
    sets = []
    for name in ["train"] + sorted(f[:-5] for f in os.listdir(os.path.join(a.work, "data", lang)) if f.startswith("extra_") and f.endswith(".done")):
        au, rows = fd.load_split(a.work, lang, name)
        if rows:
            sets.append((name, au, rows))
    return sets


def align_set(a, lang, name, audio, rows, ctx, hub, start_repo, log_every=200):
    """Cross-attention word alignment of a training set (cached)."""
    path = os.path.join(a.work, "ft", lang, f"align_{name}.json")
    old = load_json(path)
    if old and old.get("n") == len(rows) and old.get("start") == start_repo:
        return old["items"]
    t0 = time.time()
    model, tok, gen = load(hub, start_repo, a.device, attn="eager")
    heads = ac.alignment_heads(model)
    logmel = wc.LogMel(device=a.device)
    items = [None] * len(rows)
    order = [i for i in sorted(range(len(rows)), key=lambda i: rows[i]["n"]) if rows[i]["n"] <= wc.N_SAMPLES]
    bs = max(1, a.align_batch)
    pool = None
    if a.dtw_workers > 1:
        try:
            import multiprocessing
            from concurrent.futures import ProcessPoolExecutor
            pool = ProcessPoolExecutor(max_workers=a.dtw_workers, mp_context=multiprocessing.get_context("fork"))
        except Exception as e:  # noqa: BLE001
            log(f"[align] no process pool ({e}); DTW runs in this process")
    try:
        for k in range(0, len(order), bs):
            idx = order[k: k + bs]
            waves = [fd.wave_of(audio, rows[i]) for i in idx]
            toks = [tok(rows[i]["text"], add_special_tokens=False).input_ids[: a.max_label] for i in idx]
            try:
                feats, _ = wc.batch_features(waves, logmel, "full")
                mats = ac.attention_matrices(model, feats, [wc.short_frames(len(w)) for w in waves], toks, ctx.prompt, ctx.sp["eot"], heads)
                times = list(pool.map(ac.dtw_align, mats)) if pool else [ac.dtw_align(m) for m in mats]
            except Exception as e:  # noqa: BLE001
                log(f"[align] batch failed: {type(e).__name__}: {e}")
                times = [None] * len(idx)
            for j, i in enumerate(idx):
                info = ac.plan_cuts(waves[j], toks[j], times[j], ctx.vb, margin=a.align_margin)
                info["tokens"] = toks[j]
                items[i] = info
            if (k // bs) % max(1, log_every // bs) == 0:
                log(f"[align] {lang}/{name}: {k + len(idx)}/{len(order)}")
    finally:
        if pool:
            pool.shutdown()
    ok = sum(1 for it in items if it and it["ok"])
    gaps = [it["score"] - it["base"] for it in items if it and "score" in it]
    q = np.percentile(gaps, [10, 50, 90]).round(2).tolist() if gaps else None
    log(f"[align] {lang}/{name}: {ok}/{len(rows)} utterances usable for crops; path score - shuffled score p10/p50/p90 {q} "
        f"(margin {a.align_margin}) ({time.time() - t0:.0f} s)")
    save_json(path, {"n": len(rows), "start": start_repo, "ok": ok, "score_gap_p10_p50_p90": q, "items": items})
    del model
    return items


class Batches:
    """Endless stream of training batches: random crops / whole utterances, length-bucketed, augmented on the CPU."""

    def __init__(self, a, sets, aligns, tok, ctx, seed):
        self.a, self.sets, self.aligns, self.tok, self.ctx = a, sets, aligns, tok, ctx
        self.rng = np.random.default_rng(seed)
        self.q = queue.Queue(maxsize=8)
        self.stop = False
        self.stats = {"crops": 0, "whole": 0, "skipped": 0}
        self.t = threading.Thread(target=self._run, daemon=True)
        self.t.start()

    def _plan(self):
        a, items = self.a, []
        for si, (_, au, rows) in enumerate(self.sets):
            al = self.aligns[si]
            for i, r in enumerate(rows):
                n = r["n"]
                crop = None
                if al is not None and al[i] is not None and self.rng.random() < a.crop_prob:
                    crop = ac.sample_crop(al[i], n, self.rng, a.min_sec, a.max_sec)
                if crop is None and n > a.max_full_sec * wc.SR and al is not None and al[i] is not None:
                    crop = ac.sample_crop(al[i], n, self.rng, a.min_sec, a.max_full_sec)
                if crop is not None:
                    s, e, wa, wb = crop
                    words = al[i]["words"]
                    toks = al[i]["tokens"][words[wa][0]: words[wb - 1][1]]
                    text = wc.detok(toks, self.ctx.vb, self.ctx.sp["eot"])
                    if text:
                        items.append((si, i, s, e, text))
                        self.stats["crops"] += 1
                        continue
                if n > a.max_full_sec * wc.SR or n < 0.3 * wc.SR:
                    self.stats["skipped"] += 1
                    continue
                items.append((si, i, 0, n, r["text"]))
                self.stats["whole"] += 1
        order = self.rng.permutation(len(items))
        items = [items[k] for k in order]
        B, out = self.a.batch, []
        for k in range(0, len(items), 50 * B):
            chunk = sorted(items[k: k + 50 * B], key=lambda it: it[3] - it[2])
            out += [chunk[j: j + B] for j in range(0, len(chunk), B)]
        return [out[k] for k in self.rng.permutation(len(out))]

    def _augment(self, x):
        a, rng = self.a, self.rng
        if a.gain_db > 0:
            x = x * float(10 ** (rng.uniform(-a.gain_db, a.gain_db) / 20))
        if rng.random() < a.noise_prob:
            rms = float(np.sqrt(np.mean(x ** 2)) + 1e-6)
            snr = rng.uniform(10, 30)
            x = x + rng.standard_normal(len(x)).astype(np.float32) * rms / (10 ** (snr / 20))
        return np.clip(x, -1, 1).astype(np.float32)

    def _make(self, batch):
        P, eot = self.ctx.prompt, self.ctx.sp["eot"]
        waves, toks = [], []
        for si, i, s, e, text in batch:
            au, rows = self.sets[si][1], self.sets[si][2]
            waves.append(self._augment(fd.wave_of(au, rows[i], s, e)))
            toks.append(self.tok(text, add_special_tokens=False).input_ids[: self.a.max_label])
        L = max(len(t) for t in toks) + len(P)
        dec = torch.full((len(batch), L), eot, dtype=torch.long)
        lab = torch.full((len(batch), L), -100, dtype=torch.long)
        for b, t in enumerate(toks):
            seq = list(P) + t + [eot]
            dec[b, : len(seq) - 1] = torch.tensor(seq[:-1])
            lab[b, len(P) - 1: len(seq) - 1] = torch.tensor(seq[len(P):])
        return waves, dec, lab

    def _run(self):
        while not self.stop:
            for b in self._plan():
                if self.stop:
                    return
                try:
                    item = self._make(b)
                except Exception as e:  # noqa: BLE001
                    log(f"[train] batch build failed: {e}")
                    continue
                while not self.stop:
                    try:
                        self.q.put(item, timeout=1)
                        break
                    except queue.Full:
                        pass

    def next(self):
        while True:
            try:
                return self.q.get(timeout=5)
            except queue.Empty:
                if not self.t.is_alive():
                    raise RuntimeError("batch thread died")

    def close(self):
        self.stop = True


def spec_augment(feats, frames, rng, n_freq=2, f_max=12, n_time=2, t_frac=0.05):
    for b in range(feats.shape[0]):
        f = int(frames[b])
        mean = feats[b, :, :f].mean()
        for _ in range(n_freq):
            w = int(rng.integers(0, f_max + 1))
            s = int(rng.integers(0, max(1, 80 - w)))
            feats[b, s: s + w, :f] = mean
        for _ in range(n_time):
            w = int(rng.integers(0, max(1, int(t_frac * f)) + 1))
            s = int(rng.integers(0, max(1, f - w)))
            feats[b, :, s: s + w] = mean
    return feats


def finetune(hub, lang, a):
    d = os.path.join(a.work, "ft", lang)
    res_path = os.path.join(d, "results.json")
    old = load_json(res_path)
    if old and old.get("done"):
        log(f"[ft] {lang}: done before (best step {old.get('best_step')}, dev CER {old.get('best_dev_cer')})")
        return old
    sel = select(a, lang)
    start = sel["repo"] if sel else FALLBACK
    t0 = time.time()
    model, tok, gen = load(hub, start, a.device)
    prompt = sel["prompt"] if sel else wc.decoder_prompt(gen, tok, lang, "hf")
    ctx = Ctx(model, tok, gen, lang, prompt)
    log(f"[ft] {lang}: start from {start} (prompt {prompt}), {sum(p.numel() for p in model.parameters()) / 1e6:.1f}M params")
    sets = train_sets(a, lang)
    if not sets:
        raise RuntimeError(f"no training data for {lang}")
    hours = sum(r["n"] for _, _, rows in sets for r in rows) / wc.SR / 3600
    aligns = [align_set(a, lang, name, au, rows, ctx, hub, start) if a.crop_prob > 0 else None for name, au, rows in sets]
    dev_a, dev_rows = fd.load_split(a.work, lang, "dev")
    dev_rows = subset(dev_rows, a.dev_limit)
    logmel = wc.LogMel(device=a.device)
    model.train()
    model.config.use_cache = False
    V = model.config.vocab_size
    for n, p in model.named_parameters():
        if "encoder.embed_positions" in n:      # fixed sinusoids (frozen in Whisper); the decoder's learned positions train
            p.requires_grad_(False)
    decay = [p for n, p in model.named_parameters() if p.requires_grad and p.ndim >= 2]
    no_decay = [p for n, p in model.named_parameters() if p.requires_grad and p.ndim < 2]
    opt = torch.optim.AdamW([{"params": decay, "weight_decay": a.weight_decay}, {"params": no_decay, "weight_decay": 0.0}],
                            lr=a.lr, betas=(0.9, 0.98), eps=1e-6)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: min(1.0, (s + 1) / max(1, a.warmup)) * max(0.05, 1 - s / max(1, a.max_steps)))
    st = {"step": 0, "best_dev_cer": None, "best_step": None, "curve": [], "bad_evals": 0}
    last = os.path.join(d, "last.pt")
    if os.path.exists(last):
        ck = torch.load(last, map_location=a.device, weights_only=False)
        model.load_state_dict(ck["model"])
        opt.load_state_dict(ck["opt"])
        sched.load_state_dict(ck["sched"])
        st = ck["state"]
        log(f"[ft] {lang}: resumed at step {st['step']} (best dev CER {st['best_dev_cer']})")
    use_amp = a.device.startswith("cuda") and not a.no_amp
    amp_dtype = torch.bfloat16 if (use_amp and torch.cuda.is_bf16_supported()) else torch.float16
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp and amp_dtype == torch.float16)
    rng = np.random.default_rng(a.seed + st["step"])
    data = Batches(a, sets, aligns, tok, ctx, a.seed + st["step"])
    tl, tn, t_last = 0.0, 0, time.time()
    try:
        while st["step"] < a.max_steps:
            waves, dec, lab = data.next()
            feats, frames = wc.batch_features(waves, logmel, "short", a.short_pad_frames)
            if a.specaug:
                feats = spec_augment(feats, frames, rng)
            dec, lab = dec.to(a.device), lab.to(a.device)
            with torch.autocast("cuda" if a.device.startswith("cuda") else "cpu", dtype=amp_dtype, enabled=use_amp):
                enc, km = wc.encode(model, feats, frames)
                wc.set_cross_mask(model, km, enc.dtype)
                h = model.model.decoder(input_ids=dec, encoder_hidden_states=enc, use_cache=False).last_hidden_state
                sel_m = lab != -100
                logits = model.proj_out(h[sel_m])
            loss = F.cross_entropy(logits.float(), lab[sel_m])
            wc.set_cross_mask(model, None)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(opt)
            scaler.update()
            sched.step()
            st["step"] += 1
            tl += loss.item()
            tn += 1
            if st["step"] % a.log_every == 0:
                log(f"[ft] {lang} step {st['step']}/{a.max_steps} loss {tl / tn:.4f} lr {sched.get_last_lr()[0]:.2e} "
                    f"({(time.time() - t_last) / tn:.3f} s/step)")
                tl, tn, t_last = 0.0, 0, time.time()
            if st["step"] % a.eval_every == 0 or st["step"] >= a.max_steps:
                model.eval()
                m, _ = eval_set(ctx, logmel, dev_a, dev_rows, "short", a)
                model.train()
                st["curve"].append({"step": st["step"], "dev_short_cer": m["cer"], "dev_short_wer": m["wer"]})
                improved = st["best_dev_cer"] is None or m["cer"] < st["best_dev_cer"]
                if improved:
                    st.update(best_dev_cer=m["cer"], best_step=st["step"], bad_evals=0)
                    bd = os.path.join(d, "best")
                    model.save_pretrained(bd)
                    tok.save_pretrained(bd)
                    gen.save_pretrained(bd)
                    save_json(os.path.join(bd, "krishi_prompt.json"), {"prompt": prompt, "start": start, "step": st["step"]})
                else:
                    st["bad_evals"] += 1
                note = "(best)" if improved else "(best %.4f @ %d)" % (st["best_dev_cer"], st["best_step"])
                log(f"[ft] {lang} step {st['step']}: dev SHORT CER {m['cer']:.4f} WER {m['wer']:.4f} {note}")
                torch.save({"model": model.state_dict(), "opt": opt.state_dict(), "sched": sched.state_dict(), "state": st}, last + ".tmp")
                os.replace(last + ".tmp", last)
                if st["bad_evals"] >= a.patience:
                    log(f"[ft] {lang}: early stop at step {st['step']}")
                    break
    finally:
        data.close()
    del model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    # test the best checkpoint
    best_dir = os.path.join(d, "best")
    model, tok, gen = load(hub_local(), best_dir, a.device)
    ctx = Ctx(model, tok, gen, lang, prompt)
    test_a, test_rows = fd.load_split(a.work, lang, "test")
    test_rows = subset(test_rows, a.eval_limit)
    res = {"lang": lang, "start": start, "prompt": prompt, "train_hours": round(hours, 2), "train_sets": [s[0] for s in sets],
           "best_step": st["best_step"], "best_dev_cer": st["best_dev_cer"], "steps": st["step"], "curve": st["curve"],
           "batch_stats": data.stats, "hparams": {k: getattr(a, k) for k in ("lr", "batch", "max_steps", "warmup", "eval_every", "patience",
                                                                             "crop_prob", "min_sec", "max_sec", "specaug", "noise_prob", "gain_db")}}
    res["test_full"], _ = eval_set(ctx, logmel, test_a, test_rows, "full", a)
    res["test_short"], _ = eval_set(ctx, logmel, test_a, test_rows, "short", a)
    res["seconds"] = round(time.time() - t0, 1)
    res["done"] = True
    save_json(res_path, res)
    if os.path.exists(last) and not a.keep_last:
        os.remove(last)   # optimizer state (~0.45 GB) is only needed to resume an unfinished run
    log(f"[ft] {lang}: best step {st['best_step']} dev CER {st['best_dev_cer']} | test full {res['test_full']['wer']:.3f}/"
        f"{res['test_full']['cer']:.3f} | test SHORT {res['test_short']['wer']:.3f}/{res['test_short']['cer']:.3f} ({res['seconds']:.0f} s)")
    del model
    return res


class _LocalHub:
    def path(self, repo):
        return repo


def hub_local():
    return _LocalHub()


# ----------------------------------------------------------------------------------------------- export + checks
def source_for(a, lang, hub):
    ft = load_json(os.path.join(a.work, "ft", lang, "results.json"))
    if ft and ft.get("done"):
        return os.path.join(a.work, "ft", lang, "best"), hub_local(), ft["prompt"], "fine-tuned from " + ft["start"]
    sel = select(a, lang)
    if sel:
        return sel["repo"], hub, sel["prompt"], "candidate (not fine-tuned)"
    return FALLBACK, hub, None, "fallback (not fine-tuned)"


def token_stats(tok, rows):
    rates, counts = [], []
    for r in rows:
        n = len(tok(r["text"], add_special_tokens=False).input_ids)
        counts.append(n)
        rates.append(n / max(0.5, r["n"] / wc.SR))
    rates = np.array(rates)
    return {"tokens_per_second_p50": round(float(np.percentile(rates, 50)), 2), "tokens_per_second_p95": round(float(np.percentile(rates, 95)), 2),
            "tokens_per_second_p99": round(float(np.percentile(rates, 99)), 2), "tokens_for_12s_p99": int(math.ceil(np.percentile(rates, 99) * 12)),
            "ref_over_96_tokens_le12s": round(float(np.mean([c > 96 for c, r in zip(counts, rows) if r["n"] <= 12 * wc.SR] or [0])), 4)}


def vocab_texts(a, lang):
    """Training-side texts that define a restricted vocabulary (never the test set)."""
    texts = []
    for name in ["train", "dev"] + [s[0] for s in train_sets(a, lang) if s[0].startswith("extra_")]:
        texts += [r["text"] for r in fd.load_split(a.work, lang, name)[1]]
    for fn in a.vocab_text:
        texts += read_texts(fn, lang)
    return texts


def read_texts(fn, lang):
    """Sentences of one language from a text file: .jsonl rows {"text", "lang"} (other languages / romanised variants
    such as hi-Latn skipped), .json {id: {lang: text}} (e.g. voice/catalogue.json), or plain UTF-8 lines."""
    out = []
    try:
        with open(fn, encoding="utf-8") as f:
            if fn.endswith(".jsonl"):
                for line in f:
                    try:
                        r = json.loads(line)
                    except ValueError:
                        continue
                    if isinstance(r, dict) and isinstance(r.get("text"), str) and r.get("lang", lang) == lang:
                        out.append(r["text"])
            elif fn.endswith(".json"):
                def walk(o):
                    if isinstance(o, dict):
                        if isinstance(o.get(lang), str):
                            out.append(o[lang])
                        for v in o.values():
                            if isinstance(v, (dict, list)):
                                walk(v)
                    elif isinstance(o, list):
                        for v in o:
                            walk(v)
                walk(json.load(f))
            else:
                out = [l.strip() for l in f if l.strip()]
    except (OSError, ValueError) as e:
        log(f"[export] --vocab-text {fn}: {e}")
    return out


def source_stamp(src):
    """Identity of the weights being exported (a re-done fine-tune invalidates a cached export)."""
    for f in ("model.safetensors", "pytorch_model.bin"):
        p = os.path.join(src, f)
        if os.path.exists(p):
            return f"{src}@{os.path.getmtime(p):.0f}"
    return src


def export_lang(hub, lang, a):
    out = os.path.join(a.work, "export_results", lang + ".json")
    old = load_json(out)
    src, h, prompt, how = source_for(a, lang, hub)
    if old and old.get("done") and os.path.exists(old.get("bin", "")) and old.get("stamp") == source_stamp(src):
        return old
    t0 = time.time()
    model, tok, gen = load(h, src, "cpu")
    if prompt is None:
        prompt = wc.decoder_prompt(gen, tok, lang, "hf")
    test_a, test_rows = fd.load_split(a.work, lang, "test")
    test_rows = subset(test_rows, a.eval_limit)
    ts = token_stats(tok, test_rows)
    if ts["ref_over_96_tokens_le12s"] > 0.05 and a.phone_max_tokens <= 96:
        log(f"[export] {lang}: WARNING {ts['ref_over_96_tokens_le12s'] * 100:.0f}% of <=12 s test references need >96 tokens "
            f"(p99 for 12 s: {ts['tokens_for_12s_p99']}); re-export with --phone-max-tokens {min(440, ts['tokens_for_12s_p99'])} "
            f"or edit max_new_tokens in whisper_{lang}.json")
    ev = load_json(os.path.join(a.work, "eval", lang, slug(src) + ".json")) or {}
    if not ev and how.startswith("fine-tuned"):
        ft = load_json(os.path.join(a.work, "ft", lang, "results.json")) or {}
        ev = load_json(os.path.join(a.work, "eval", lang, slug(ft.get("start", "")) + ".json")) or {}
    info = {"source": src, "how": how, "licence": ev.get("licence"), "base_model": ev.get("repo"),
            "train_data": "FLEURS (CC-BY-4.0)", "token_stats": ts}
    sp = wc.special_ids(gen, tok, lang)
    V = model.config.vocab_size
    stage = os.path.join(a.work, "export_stage", lang)
    variants = {"full": None}
    if a.prune_vocab != "off":
        variants["restricted"] = wc.keep_ids(tok, vocab_texts(a, lang), list(prompt) + [sp["eot"], sp["no_speech"]], V)
    logmel = wc.LogMel(device=a.device)
    pa = argparse.Namespace(**vars(a))
    pa.eval_max_new = a.phone_max_tokens
    m32, r32 = eval_set(Ctx(model.to(a.device).eval(), tok, gen, lang, prompt), logmel, test_a, test_rows, "short", pa)
    model = model.cpu()
    res = {"lang": lang, "source": src, "stamp": source_stamp(src), "how": how, "prompt": prompt, "token_stats": ts, "phone_max_tokens": a.phone_max_tokens,
           "test_short_fp32_phone_tokens": m32, "variants": {}}
    ids = {}
    for vname, keep in variants.items():
        bp, jp = ex.export(model, tok, gen, lang, stage, name=f"whisper_{lang}_{vname}", prompt=prompt, info=dict(info, vocab=vname),
                           max_new_tokens=a.phone_max_tokens, short_pad_frames=a.short_pad_frames, keep=keep)
        q, _, _ = load(h, src, "cpu")
        ex.load_exported_into(q, bp, keep)
        q = q.to(a.device).eval()
        wc.enable_cross_mask(q)
        ctx = Ctx(q, tok, gen, lang, prompt)
        allowed = None
        if keep is not None:
            allowed = torch.zeros(V, dtype=torch.bool)
            allowed[keep] = True
        m8, r8 = eval_set_allowed(ctx, logmel, test_a, test_rows, pa, allowed)
        res["variants"][vname] = {"bin": bp, "json": jp, "bin_mb": round(os.path.getsize(bp) / 1e6, 2),
                                  "json_kb": round(os.path.getsize(jp) / 1e3, 1), "vocab_rows": len(keep) if keep else V,
                                  "test_short_int8_phone_tokens": m8,
                                  "same_tokens_as_fp32": round(float(np.mean([x[1] == y[1] for x, y in zip(r32, r8)])), 4)}
        ids[vname] = r8
        log(f"[export] {lang}/{vname}: {res['variants'][vname]['bin_mb']} MB, {res['variants'][vname]['vocab_rows']} vocab rows | test SHORT "
            f"int8 WER/CER {m8['wer']:.3f}/{m8['cer']:.3f} (fp32 {m32['wer']:.3f}/{m32['cer']:.3f})")
        del q
    chosen = "full"
    if "restricted" in res["variants"]:
        cf = res["variants"]["full"]["test_short_int8_phone_tokens"]["cer"]
        cr = res["variants"]["restricted"]["test_short_int8_phone_tokens"]["cer"]
        if a.prune_vocab == "on" or cr <= cf + a.prune_tolerance:
            chosen = "restricted"
    res["chosen"] = chosen
    os.makedirs(a.export_dir, exist_ok=True)
    bp, jp = os.path.join(a.export_dir, f"whisper_{lang}.bin"), os.path.join(a.export_dir, f"whisper_{lang}.json")
    shutil.copyfile(res["variants"][chosen]["bin"], bp)
    shutil.copyfile(res["variants"][chosen]["json"], jp)
    res.update(bin=bp, json=jp, bin_mb=res["variants"][chosen]["bin_mb"], json_kb=res["variants"][chosen]["json_kb"],
               test_short_int8_phone_tokens=res["variants"][chosen]["test_short_int8_phone_tokens"],
               int8_same_tokens=res["variants"][chosen]["same_tokens_as_fp32"])
    res["seconds"] = round(time.time() - t0, 1)
    res["done"] = True
    save_json(out, res)
    save_json(os.path.join(a.work, "export_results", lang + "_int8_ids.json"),
              {"variant": chosen, "rows": [r["id"] for r in test_rows], "ids": [x[1] for x in ids[chosen]], "text": [x[0] for x in ids[chosen]]})
    log(f"[export] {lang}: -> {bp} ({chosen} vocabulary, {res['bin_mb']} MB)")
    return res


def eval_set_allowed(ctx, logmel, audio, rows, a, allowed):
    """eval_set with an optional restricted vocabulary (phone semantics: other ids are never produced)."""
    if allowed is None:
        return eval_set(ctx, logmel, audio, rows, "short", a)
    t0 = time.time()
    waves = [fd.wave_of(audio, r) for r in rows]
    order = sorted(range(len(waves)), key=lambda i: len(waves[i]))
    res = [None] * len(waves)
    with torch.no_grad():
        for k in range(0, len(order), a.eval_batch):
            idx = order[k: k + a.eval_batch]
            feats, frames = wc.batch_features([waves[i] for i in idx], logmel, "short", a.short_pad_frames)
            enc, km = wc.encode(ctx.model, feats, frames)
            g = wc.greedy(ctx.model, enc, km, ctx.prompt, ctx.sup, ctx.bsup, ctx.sp["eot"], ctx.sp["no_speech"], max_new=a.eval_max_new,
                          sot_index=ctx.sot_index, allowed=allowed)
            for j, i in enumerate(idx):
                res[i] = (wc.detok(g["ids"][j], ctx.vb, ctx.sp["eot"]), g["ids"][j], g["avg_logprob"][j], g["no_speech_prob"][j])
    m = score(rows, res, a.phone_max_tokens)
    m["seconds"] = round(time.time() - t0, 1)
    m["mode"] = "short"
    return m, res


def javacheck(lang, a):
    out = os.path.join(a.work, "export_results", lang + "_java.json")
    if not (shutil.which("javac") and shutil.which("java")):
        log("[java] javac/java not found, skipped (apt-get install -y openjdk-17-jdk-headless)")
        return {"skipped": "no JDK"}
    exp = load_json(os.path.join(a.work, "export_results", lang + ".json"))
    ref = load_json(os.path.join(a.work, "export_results", lang + "_int8_ids.json"))
    if not exp or not ref:
        return {"skipped": "no export"}
    cls = os.path.join(a.work, "java", "classes")
    os.makedirs(cls, exist_ok=True)
    core = os.path.join(ROOT, "android", "src", "in", "krishi", "doctor")
    src = [os.path.join(core, f) for f in ("Whisper.java", "WhisperMath.java", "Nn.java", "Krw.java", "Json.java")]
    src.append(os.path.join(ROOT, "android", "test", "whisper", "WhisperCli.java"))
    p = subprocess.run(["javac", "-nowarn", "-encoding", "UTF-8", "--release", "8", "-d", cls] + src, capture_output=True, text=True)
    if p.returncode != 0:
        log(f"[java] javac failed: {p.stderr[-2000:]}")
        return {"error": "javac", "stderr": p.stderr[-2000:]}
    test_a, test_rows = fd.load_split(a.work, lang, "test")
    by_id = {r["id"]: r for r in test_rows}
    clips = []
    cd = os.path.join(a.work, "java", "clips", lang)
    os.makedirs(cd, exist_ok=True)
    for rid, ids in zip(ref["rows"], ref["ids"]):
        r = by_id.get(rid)
        if r is None or r["n"] > 12 * wc.SR:
            continue
        f = os.path.join(cd, f"{len(clips):04d}.f32")
        fd.wave_of(test_a, r).astype("<f4").tofile(f)
        clips.append((f, ids))
        if len(clips) >= a.java_clips:
            break
    t0 = time.time()
    p = subprocess.run(["java", "-Xmx1g", "-cp", cls, "WhisperCli", exp["bin"], exp["json"], "--max-new", str(a.phone_max_tokens)]
                       + [c[0] for c in clips], capture_output=True, text=True)
    lines = [json.loads(l) for l in p.stdout.splitlines() if l.startswith("{")]
    same = sum(1 for l, c in zip(lines, clips) if l.get("tokens") == c[1])
    res = {"clips": len(clips), "decoded": len(lines), "same_tokens": same, "agreement": round(same / max(1, len(clips)), 4),
           "java_seconds": round(time.time() - t0, 1), "mean_ms_per_clip": round(float(np.mean([l.get("ms", 0) for l in lines] or [0])), 1)}
    if p.returncode != 0:
        res["stderr"] = p.stderr[-2000:]
    save_json(out, res)
    log(f"[java] {lang}: {same}/{len(clips)} clips give identical tokens in Java (int8 Python reference)")
    return res


def report(a, timings):
    rep = {"created": time.strftime("%Y-%m-%d %H:%M:%S"), "normalization": NORMALIZATION, "langs": a.langs,
           "host": {"torch": torch.__version__, "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None},
           "candidates": {}, "selected": {}, "finetune": {}, "export": {}, "java": {}, "data": {}, "timings_s": timings}
    try:
        import transformers
        rep["host"]["transformers"] = transformers.__version__
    except ImportError:
        pass
    for lang in a.langs:
        dd = os.path.join(a.work, "data", lang)
        if os.path.isdir(dd):
            rep["data"][lang] = {f[:-5]: load_json(os.path.join(dd, f)) for f in sorted(os.listdir(dd)) if f.endswith(".done")}
        rep["candidates"][lang] = [load_json(os.path.join(a.work, "eval", lang, slug(c) + ".json")) or {"repo": c, "status": "not evaluated"}
                                   for c in a.candidates[lang]]
        sel = select(a, lang)
        rep["selected"][lang] = sel["repo"] if sel else FALLBACK + " (fallback)"
        rep["finetune"][lang] = load_json(os.path.join(a.work, "ft", lang, "results.json"))
        rep["export"][lang] = load_json(os.path.join(a.work, "export_results", lang + ".json"))
        rep["java"][lang] = load_json(os.path.join(a.work, "export_results", lang + "_java.json"))
    gpu_stages = sum(v for k, v in timings.items() if k.split(":")[0] in ("eval", "finetune", "export"))
    rep["gpu_hours_measured"] = round(gpu_stages / 3600, 2)
    rep["gpu_hours_estimate_note"] = ("Planning estimate for one L4 (4 languages, defaults): data download/prep 0.3-0.5 h (network "
                                      "bound, no GPU), candidate eval ~0.3 h, alignment ~0.1 h, fine-tuning ~1.5-2 h (<= 4000 steps x 4 "
                                      "langs, early stopping), final test + export + int8 re-scoring ~0.3 h: ~2.5-3.5 h total (worst case "
                                      "~4 h without early stopping), peak GPU memory < 10 GB.")
    save_json(os.path.join(a.work, "report.json"), rep)
    log("=" * 100)
    log(f"{'lang':4} {'selected start':42} {'licence':12} {'test CER full/SHORT before':28} {'after FT (SHORT)':18} {'int8 SHORT':12} MB (vocab)")
    for lang in a.langs:
        sel = select(a, lang)
        before = f"{sel['metrics']['test_full']['cer']:.3f}/{sel['metrics']['test_short']['cer']:.3f}" if sel else "-"
        ft = rep["finetune"][lang] or {}
        after = f"{ft['test_short']['cer']:.3f}" if ft.get("test_short") else "-"
        e = rep["export"][lang] or {}
        q = f"{e['test_short_int8_phone_tokens']['cer']:.3f}" if e.get("test_short_int8_phone_tokens") else "-"
        log(f"{lang:4} {rep['selected'][lang][:42]:42} {str(sel.get('licence') if sel else '-')[:12]:12} {before:28} {after:18} {q:12} "
            f"{e.get('bin_mb', '-')} ({e.get('chosen', '-')})")
    log(f"report: {os.path.join(a.work, 'report.json')}")
    return rep


# ----------------------------------------------------------------------------------------------- offline test setup
def setup_offline(a):
    """Random-init 'candidates' (one non-commercial, one missing) and synthetic data: tests every code path offline."""
    from transformers import WhisperForConditionalGeneration
    od = os.path.join(a.work, "offline_models")
    reg_path = os.path.join(od, "registry.json")
    if not os.path.exists(reg_path):
        tok = wc.build_synthetic_tokenizer(os.path.join(od, "tok"))
        gen = wc.synthetic_generation_config(tok)
        reg = {}
        specs = [("orgA/whisper-tiny-good", "apache-2.0", 1, None), ("orgB/whisper-tiny-nc", "cc-by-nc-4.0", 2, None),
                 ("orgD/whisper-tiny-bare", None, 3, [[1, 50363]]), ("openai/whisper-tiny", "mit", 4, None)]
        for name, lic, seed, forced in specs:
            torch.manual_seed(seed)
            m = WhisperForConditionalGeneration(wc.tiny_config())
            g = wc.synthetic_generation_config(tok)
            if forced is not None:
                g.forced_decoder_ids = forced
            m.generation_config = g
            p = os.path.join(od, slug(name))
            m.save_pretrained(p)
            tok.save_pretrained(p)
            g.save_pretrained(p)
            reg[name] = {"path": p, "licence": lic, "sha": "offline"}
        save_json(reg_path, reg)
    for lang in a.langs:
        fd.make_synthetic(a.work, lang, sizes=(("train", 24), ("dev", 6), ("test", 6)))
    a.candidates = {lang: ["orgA/whisper-tiny-good", "orgB/whisper-tiny-nc", "orgC/whisper-tiny-missing", "orgD/whisper-tiny-bare",
                           "openai/whisper-tiny"] for lang in a.langs}
    return Hub(od)


# ----------------------------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--work", required=True)
    ap.add_argument("--langs", default="hi,ta,kn,en")
    ap.add_argument("--stages", default="data,eval,finetune,export,javacheck,report")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--export-dir")
    ap.add_argument("--candidates-json", help="override the candidate list: {lang: [repo, ...]}")
    ap.add_argument("--allow-unknown-licence", action="store_true", help="unknown/other licences may be selected")
    ap.add_argument("--allow-non-tiny", action="store_true")
    ap.add_argument("--eval-max-new", type=int, default=320,
                    help="token limit when scoring (Tamil/Kannada FLEURS sentences are long in Whisper's BPE); the phone uses --phone-max-tokens")
    ap.add_argument("--eval-batch", type=int, default=32)
    ap.add_argument("--eval-limit", type=int, default=0, help="score only N random utterances per split (0 = all)")
    ap.add_argument("--probe-n", type=int, default=40, help="dev utterances for the prompt probe")
    ap.add_argument("--phone-max-tokens", type=int, default=96)
    ap.add_argument("--short-pad-frames", type=int, default=0)
    ap.add_argument("--prune-vocab", choices=["auto", "on", "off"], default="auto",
                    help="restricted vocabulary (tokens of the language's train/dev text + bytes + specials): ~20 MB smaller, "
                         "~2-3x faster decoding; 'auto' keeps it only if test CER (int8, SHORT) rises by <= --prune-tolerance")
    ap.add_argument("--prune-tolerance", type=float, default=0.003)
    ap.add_argument("--vocab-text", action="append", default=[],
                    help="extra text for the restricted vocabulary: .jsonl {text, lang}, .json {id: {lang: text}} or plain lines "
                         "(e.g. data/text_train.jsonl, data/free_questions_train.jsonl, voice/catalogue.json)")
    # fine-tuning
    ap.add_argument("--max-steps", type=int, default=4000)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--lr", type=float, default=3e-5)
    ap.add_argument("--warmup", type=int, default=200)
    ap.add_argument("--weight-decay", type=float, default=0.01)
    ap.add_argument("--eval-every", type=int, default=250)
    ap.add_argument("--patience", type=int, default=4)
    ap.add_argument("--dev-limit", type=int, default=0)
    ap.add_argument("--crop-prob", type=float, default=0.5, help="share of examples that are 2-15 s crops (0 = whole utterances only)")
    ap.add_argument("--min-sec", type=float, default=2.0)
    ap.add_argument("--max-sec", type=float, default=15.0)
    ap.add_argument("--max-full-sec", type=float, default=30.0)
    ap.add_argument("--max-label", type=int, default=440)
    ap.add_argument("--align-batch", type=int, default=16)
    ap.add_argument("--dtw-workers", type=int, default=min(8, os.cpu_count() or 1), help="processes for the alignment DTW")
    ap.add_argument("--align-margin", type=float, default=0.5,
                    help="a crop alignment is used only if its DTW path score beats the frame-shuffled score by this much")
    ap.add_argument("--no-specaug", dest="specaug", action="store_false")
    ap.add_argument("--noise-prob", type=float, default=0.3)
    ap.add_argument("--gain-db", type=float, default=6.0)
    ap.add_argument("--no-amp", action="store_true")
    ap.add_argument("--keep-last", action="store_true", help="keep ft/<lang>/last.pt (optimizer state) after a language is done")
    ap.add_argument("--log-every", type=int, default=50)
    ap.add_argument("--seed", type=int, default=0)
    # data
    ap.add_argument("--extra-manifest", action="append", default=[])
    ap.add_argument("--extra-hf", action="append", default=[])
    ap.add_argument("--extra-max-hours", type=float, default=50.0)
    ap.add_argument("--fleurs-limit", type=int, default=0, help="max utterances per FLEURS split (debug)")
    ap.add_argument("--java-clips", type=int, default=20)
    ap.add_argument("--offline-test", action="store_true", help="random models + synthetic data, tiny settings, CPU")
    a = ap.parse_args()
    a.langs = [l.strip() for l in a.langs.split(",") if l.strip()]
    a.export_dir = a.export_dir or os.path.join(a.work, "export")
    a.candidates = {l: list(CANDIDATES.get(l, [FALLBACK])) for l in a.langs}
    if a.candidates_json:
        a.candidates.update(load_json(a.candidates_json))
    os.makedirs(os.path.join(a.work, "logs"), exist_ok=True)
    global LOG
    LOG = os.path.join(a.work, "logs", "select_finetune.log")
    if a.offline_test:
        torch.set_num_threads(2)
        a.device = "cpu"
        for k, v in dict(eval_max_new=10, eval_batch=4, probe_n=3, max_steps=6, batch=4, eval_every=3, warmup=2, log_every=2,
                         align_batch=4, java_clips=3, phone_max_tokens=10, patience=2, align_margin=-1e9).items():
            setattr(a, k, v)
    torch.manual_seed(a.seed)
    random.seed(a.seed)
    log(f"select_finetune: langs {a.langs}, stages {a.stages}, device {a.device}, work {a.work}")
    hub = setup_offline(a) if a.offline_test else Hub()
    global FALLBACK_SOURCE
    FALLBACK_SOURCE = hub.path(FALLBACK)
    stages = [s.strip() for s in a.stages.split(",")]
    timings = load_json(os.path.join(a.work, "timings.json"), {})
    failures = []

    def timed(key, fn):
        t0 = time.time()
        try:
            return fn()
        except Exception as e:  # noqa: BLE001
            failures.append(f"{key}: {type(e).__name__}: {e}")
            log(f"ERROR in {key}: {type(e).__name__}: {e}\n{traceback.format_exc()}")
            return None
        finally:
            timings[key] = round(timings.get(key, 0) + time.time() - t0, 1)
            save_json(os.path.join(a.work, "timings.json"), timings)

    if "data" in stages and not a.offline_test:
        for lang in a.langs:
            timed(f"data:{lang}", lambda: fd.prepare_fleurs(a.work, lang, limit=a.fleurs_limit or None, log=log))
        for m in a.extra_manifest:
            timed(f"data:manifest:{os.path.basename(m)}", lambda: fd.prepare_manifest(a.work, m, log=log))
        for s in a.extra_hf:
            timed(f"data:hf:{s.split('|')[0]}", lambda: fd.prepare_hf_extra(a.work, s, a.extra_max_hours, log=log))
    if "eval" in stages:
        logmel = wc.LogMel(device=a.device)
        for lang in a.langs:
            for repo in a.candidates[lang]:
                timed(f"eval:{lang}:{repo}", lambda: eval_candidate(hub, lang, repo, a, logmel))
    if "finetune" in stages:
        for lang in a.langs:
            timed(f"finetune:{lang}", lambda: finetune(hub, lang, a))
    if "export" in stages:
        for lang in a.langs:
            timed(f"export:{lang}", lambda: export_lang(hub, lang, a))
    if "javacheck" in stages:
        for lang in a.langs:
            timed(f"javacheck:{lang}", lambda: javacheck(lang, a))
    if "report" in stages:
        report(a, timings)
    if failures:
        log("FAILURES:\n  " + "\n  ".join(failures))
        sys.exit(1)


if __name__ == "__main__":
    main()
