"""Speech data for the Whisper selection / fine-tune (runs on the GPU VM; the synthetic part runs anywhere).

FLEURS (google/fleurs, CC-BY-4.0; configs hi_in, ta_in, kn_in, en_us) is fetched without the `datasets` loading
script (unsupported by datasets>=4): data/<cfg>/<split>.tsv + data/<cfg>/audio/<split>.tar.gz through
huggingface_hub; if the repo layout differs, parquet files (main or refs/convert/parquet) are read instead, and as
a last resort datasets.load_dataset(..., trust_remote_code=True) (needs datasets<4).

Prepared layout, per language:  <work>/data/<lang>/<split>.i16  (int16 PCM, 16 kHz, utterances concatenated)
                                 <work>/data/<lang>/<split>.jsonl (id, offset, n, text = raw transcription, ref_norm, src)
                                 <work>/data/<lang>/<split>.done
Extra training data: JSONL manifests {"audio": path, "text": str, "lang": "hi", "split": "train"} (any soundfile
format/rate), or Hugging Face datasets "repo|config|split|audio_col|text_col|lang".
"""
import io, json, os, re, tarfile, time, zlib

import numpy as np

import whisper_common as wc

FLEURS_REPO = "google/fleurs"
SR = 16000


def _log(msg):
    print(time.strftime("[%H:%M:%S] ") + msg, flush=True)


def resample(x, sr, to=SR):
    if sr == to:
        return x
    try:
        from scipy.signal import resample_poly
        from math import gcd
        g = gcd(int(sr), int(to))
        return resample_poly(x, to // g, sr // g).astype(np.float32)
    except ImportError:
        n = int(round(len(x) * to / sr))
        return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)


def decode_audio(data_or_path):
    import soundfile as sf
    src = io.BytesIO(data_or_path) if isinstance(data_or_path, (bytes, bytearray)) else data_or_path
    x, sr = sf.read(src, dtype="float32", always_2d=False)
    if x.ndim > 1:
        x = x.mean(1)
    return resample(np.asarray(x, np.float32), sr)


class SplitWriter:
    """Appends utterances to <dir>/<name>.i16 + rows, finished by close() (writes .jsonl and .done)."""

    def __init__(self, out_dir, name):
        os.makedirs(out_dir, exist_ok=True)
        self.dir, self.name = out_dir, name
        self.f = open(os.path.join(out_dir, name + ".i16.part"), "wb")
        self.rows, self.off = [], 0

    def add(self, wav, row):
        a = np.clip(np.asarray(wav, np.float32), -1, 1)
        a = np.round(a * 32767).astype("<i2")
        self.f.write(a.tobytes())
        row = dict(row, offset=self.off, n=int(len(a)))
        self.off += len(a)
        self.rows.append(row)

    def abort(self):
        """Drops everything written so far (a failed download attempt)."""
        self.f.close()
        try:
            os.remove(os.path.join(self.dir, self.name + ".i16.part"))
        except OSError:
            pass

    def close(self):
        self.f.close()
        os.replace(os.path.join(self.dir, self.name + ".i16.part"), os.path.join(self.dir, self.name + ".i16"))
        with open(os.path.join(self.dir, self.name + ".jsonl"), "w", encoding="utf-8") as f:
            for r in self.rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        with open(os.path.join(self.dir, self.name + ".done"), "w") as f:
            f.write(json.dumps({"n": len(self.rows), "hours": self.off / SR / 3600}))
        return len(self.rows)


def load_split(work, lang, name):
    """-> (int16 memmap, rows) for a prepared split, or (None, []) if missing."""
    d = os.path.join(work, "data", lang)
    if not os.path.exists(os.path.join(d, name + ".done")):
        return None, []
    audio = np.memmap(os.path.join(d, name + ".i16"), dtype="<i2", mode="r")
    with open(os.path.join(d, name + ".jsonl"), encoding="utf-8") as f:
        rows = [json.loads(l) for l in f if l.strip()]
    return audio, rows


def wave_of(audio, row, a=0, b=None):
    """float32 samples [a, b) of an utterance."""
    n = row["n"]
    b = n if b is None else min(b, n)
    return audio[row["offset"] + a: row["offset"] + b].astype(np.float32) / 32767.0


# ----------------------------------------------------------------------------------------------- FLEURS
def parse_fleurs_tsv(path):
    """FLEURS tsv: id, file_name, raw_transcription, transcription, (phonemes), num_samples, gender."""
    meta = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            c = line.rstrip("\n").split("\t")
            if len(c) < 4 or not c[1].endswith(".wav"):
                continue
            meta[c[1]] = {"id": c[0], "file": c[1], "text": c[2].strip(), "ref_norm": c[3].strip()}
    return meta


def _fleurs_tar(tsv, tgz, writer, limit=None):
    meta = parse_fleurs_tsv(tsv)
    n = 0
    with tarfile.open(tgz, "r:*") as tf:
        for m in tf:
            if not m.isfile():
                continue
            base = os.path.basename(m.name)
            if base not in meta:
                continue
            wav = decode_audio(tf.extractfile(m).read())
            writer.add(wav, dict(meta[base], src="fleurs"))
            n += 1
            if limit and n >= limit:
                break
    return n


def _split_aliases(split):
    return {"dev": ["dev", "validation"], "validation": ["validation", "dev"]}.get(split, [split])


def _fleurs_parquet(files, writer, repo, revision, limit=None):
    import pandas as pd
    from huggingface_hub import hf_hub_download
    n = 0
    for fn in sorted(files):
        p = hf_hub_download(repo, fn, repo_type="dataset", revision=revision)
        df = pd.read_parquet(p)
        for _, r in df.iterrows():
            au = r["audio"]
            data = au.get("bytes") if isinstance(au, dict) else None
            if data is None:
                continue
            text = r.get("raw_transcription") or r.get("transcription") or ""
            writer.add(decode_audio(data), {"id": str(r.get("id", n)), "file": str(au.get("path", "")), "text": str(text).strip(),
                                            "ref_norm": str(r.get("transcription", "")).strip(), "src": "fleurs"})
            n += 1
            if limit and n >= limit:
                return n
    return n


def prepare_fleurs(work, lang, splits=("train", "dev", "test"), limit=None, log=_log):
    """Downloads + prepares FLEURS for one language (skips splits already done). Returns {split: n}."""
    from huggingface_hub import HfApi, hf_hub_download
    cfg = wc.FLEURS[lang]
    out_dir = os.path.join(work, "data", lang)
    done = {}
    for split in splits:
        if os.path.exists(os.path.join(out_dir, split + ".done")):
            done[split] = len(load_split(work, lang, split)[1])
            continue
        t0 = time.time()
        n, err, w = 0, [], None

        def attempt(fn, label):
            nonlocal n, w
            w = SplitWriter(out_dir, split)
            try:
                n = fn(w)
            except Exception as e:  # noqa: BLE001
                err.append(f"{label}: {type(e).__name__}: {str(e)[:200]}")
                n = 0
            if n == 0:
                w.abort()
                w = None
            return n > 0

        for alias in _split_aliases(split):
            def tar_fn(wr, alias=alias):
                tsv = hf_hub_download(FLEURS_REPO, f"data/{cfg}/{alias}.tsv", repo_type="dataset")
                tgz = hf_hub_download(FLEURS_REPO, f"data/{cfg}/audio/{alias}.tar.gz", repo_type="dataset")
                return _fleurs_tar(tsv, tgz, wr, limit)
            if attempt(tar_fn, f"tar/{alias}"):
                break
        if n == 0:
            for rev in ("main", "refs/convert/parquet"):
                try:
                    files = HfApi().list_repo_files(FLEURS_REPO, repo_type="dataset", revision=rev)
                except Exception as e:  # noqa: BLE001
                    err.append(f"list@{rev}: {type(e).__name__}: {str(e)[:200]}")
                    continue
                pq = [f for f in files if f.endswith(".parquet") and re.search(rf"(^|/){cfg}/", f)
                      and any(re.search(rf"(^|/|-){a}([-/.]|$)", f.split(cfg, 1)[1]) for a in _split_aliases(split))]
                if not pq:
                    err.append(f"parquet@{rev}: no files")
                    continue
                if attempt(lambda wr, pq=pq, rev=rev: _fleurs_parquet(pq, wr, FLEURS_REPO, rev, limit), f"parquet@{rev}"):
                    break
        if n == 0:
            def ds_fn(wr):
                import datasets
                ds = datasets.load_dataset(FLEURS_REPO, cfg, split="validation" if split == "dev" else split, trust_remote_code=True)
                k = 0
                for r in ds:
                    au = r["audio"]
                    wav = resample(np.asarray(au["array"], np.float32), au["sampling_rate"])
                    wr.add(wav, {"id": str(r["id"]), "file": os.path.basename(au.get("path") or ""), "text": r["raw_transcription"].strip(),
                                 "ref_norm": r["transcription"].strip(), "src": "fleurs"})
                    k += 1
                    if limit and k >= limit:
                        break
                return k
            attempt(ds_fn, "datasets")
        if n == 0:
            raise RuntimeError(f"FLEURS {cfg}/{split}: could not download ({'; '.join(err)})")
        w.close()
        done[split] = n
        log(f"FLEURS {cfg}/{split}: {n} utterances, {w.off / SR / 3600:.2f} h in {time.time() - t0:.0f} s")
    return done


# ----------------------------------------------------------------------------------------------- extra data
def prepare_manifest(work, path, name=None, log=_log):
    """JSONL manifest -> data/<lang>/extra_<name>.* (rows grouped by lang; split field ignored unless 'train')."""
    name = name or re.sub(r"\W+", "_", os.path.splitext(os.path.basename(path))[0])
    by_lang = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                r = json.loads(line)
                if r.get("split", "train") == "train":
                    by_lang.setdefault(r["lang"], []).append(r)
    out = {}
    for lang, rows in by_lang.items():
        split = f"extra_{name}"
        if os.path.exists(os.path.join(work, "data", lang, split + ".done")):
            out[lang] = split
            continue
        w = SplitWriter(os.path.join(work, "data", lang), split)
        bad = 0
        for i, r in enumerate(rows):
            try:
                w.add(decode_audio(r["audio"]), {"id": str(r.get("id", i)), "text": r["text"].strip(), "src": name})
            except Exception as e:  # noqa: BLE001
                bad += 1
                if bad <= 5:
                    log(f"manifest {path}: skip {r.get('audio')}: {e}")
        w.close()
        log(f"extra {name}/{lang}: {len(w.rows)} utterances ({bad} unreadable), {w.off / SR / 3600:.2f} h")
        out[lang] = split
    return out


def prepare_hf_extra(work, spec, max_hours=50.0, log=_log):
    """spec 'repo|config|split|audio_col|text_col|lang' (config may be empty). Needs `datasets`."""
    repo, config, split, acol, tcol, lang = (spec.split("|") + [""] * 6)[:6]
    name = "extra_" + re.sub(r"\W+", "_", f"{repo}_{config}_{split}")
    if os.path.exists(os.path.join(work, "data", lang, name + ".done")):
        return lang, name
    import datasets
    ds = datasets.load_dataset(repo, config or None, split=split, streaming=True)
    w = SplitWriter(os.path.join(work, "data", lang), name)
    for i, r in enumerate(ds):
        au = r[acol]
        wav = decode_audio(au["bytes"]) if au.get("bytes") else resample(np.asarray(au["array"], np.float32), au["sampling_rate"])
        w.add(wav, {"id": str(i), "text": str(r[tcol]).strip(), "src": repo})
        if w.off / SR / 3600 >= max_hours:
            break
    w.close()
    log(f"extra {repo}: {len(w.rows)} utterances, {w.off / SR / 3600:.2f} h")
    return lang, name


# ----------------------------------------------------------------------------------------------- offline test data
SYN_TEXT = {
    "hi": ["पत्ते", "पीले", "धान", "खेत", "में", "हैं", "दवाई", "पानी", "दाग"],
    "ta": ["பயிர்", "இலை", "மஞ்சள்", "தண்ணீர்", "நோய்", "புள்ளி"],
    "kn": ["ರೈತ", "ಎಲೆ", "ಹಳದಿ", "ನೀರು", "ಬೆಳೆ", "ರೋಗ"],
    "en": ["the", "leaf", "rice", "spots", "yellow", "water", "and"],
}


def make_synthetic(work, lang, sizes=(("train", 40), ("dev", 10), ("test", 10)), seed=0):
    """Tone/noise 'speech' with random texts in the same prepared format (offline pipeline tests only)."""
    rng = np.random.default_rng(seed + zlib.crc32(lang.encode()) % 1000)
    words = SYN_TEXT.get(lang, SYN_TEXT["en"])
    for split, n in sizes:
        if os.path.exists(os.path.join(work, "data", lang, split + ".done")):
            continue
        w = SplitWriter(os.path.join(work, "data", lang), split)
        for i in range(n):
            k = int(rng.integers(2, 9))
            ws = [words[j] for j in rng.integers(0, len(words), size=k)]
            dur = float(rng.uniform(1.5, 14.0))
            t = np.arange(int(dur * SR)) / SR
            x = np.zeros_like(t)
            seg = dur / k
            for j, word in enumerate(ws):
                f0 = 150 + 40 * (zlib.crc32(word.encode()) % 10)
                m = (t >= j * seg + 0.05) & (t < (j + 1) * seg - 0.08)
                x[m] += 0.3 * np.sin(2 * np.pi * f0 * t[m]) * (1 + 0.3 * np.sin(2 * np.pi * 4 * t[m]))
            x += 0.005 * rng.standard_normal(len(t))
            w.add(x.astype(np.float32), {"id": f"{split}{i}", "text": " ".join(ws) + ("." if lang == "en" else " ।" if lang == "hi" else ""),
                                         "ref_norm": " ".join(ws), "src": "synthetic"})
        w.close()
