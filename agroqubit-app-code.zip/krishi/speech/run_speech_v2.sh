set -e
cd /home/claude/krishi/speech
python3 train_speech2.py 6 > train_speech2.log 2>&1
python3 decode.py /home/claude/krishi/speech/speech_enc_v2.pt _v2 > decode_v2.log 2>&1
python3 train_phon2meaning.py /home/claude/krishi/speech/speech_enc_v2.pt _v2 > p2m_v2.log 2>&1
echo DONE >> p2m_v2.log
