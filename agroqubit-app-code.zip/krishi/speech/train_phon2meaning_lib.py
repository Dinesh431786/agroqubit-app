import re, zlib, torch
import sys; sys.path.insert(0, '/home/claude/krishi/text')
from textenc import NB
def feats(s, nmin=2, nmax=5):
    s = "#" + re.sub(r"[\sˈˌ]", "", s) + "#"; ids = []
    for n in range(nmin, nmax + 1):
        for i in range(len(s) - n + 1): ids.append(zlib.crc32(("P" + s[i:i+n]).encode()) % NB)
    return ids or [0]
def pk(strs):
    ids, off = [], []
    for s in strs: off.append(len(ids)); ids += feats(s)
    return torch.tensor(ids), torch.tensor(off)
