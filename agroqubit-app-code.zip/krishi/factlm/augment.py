"""Training-time augmentation for FactLM questions.

- casual romanization of hi/ta/kn (indic_transliteration ITRANS + casual rules: no diacritics, schwa deletion, common spellings),
  whole sentence (script 'roman') or some words only (script 'mixed')
- English code-mixing (native farm words -> English: medicine, spray, leaf, disease, ...)
- dialect / slang variants from data/dialect_lexicon.json (independent lexicon, never sees the test set)
- disease-name swap for seed rows: a known name of the asked disease is replaced by the name of another disease of the
  same crop and y is recomputed with the seed oracle (so every disease gets every intent)
- typos (deletion, duplication, swap, vowel play), word drop, filler words
- context sampling / dropout: rows with meta get a fresh ctx and y from the oracle; other rows only get label-preserving
  ctx changes (drop ctx.crop when a target is set, add the crop of single-crop answers)
"""
import json
import os
import random
import re
import unicodedata

import facts_lib as FL

HERE = os.path.dirname(os.path.abspath(__file__))
try:
    from indic_transliteration.sanscript import transliterate
except Exception:  # pragma: no cover - optional on the VM; romanization is then skipped
    transliterate = None

SCRIPT = {"hi": "devanagari", "ta": "tamil", "kn": "kannada"}


def _strip(s):
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


_HI_WORDS = {"men": ["me", "mein", "mai", "men"], "hain": ["hai", "hain", "he"], "hai": ["hai", "hai", "he"], "nahiin": ["nahi", "nahin"],
             "nahin": ["nahi", "nahin"], "naheen": ["nahi", "nahin"], "kyaa": ["kya", "kya", "kia"], "kyon": ["kyu", "kyon", "kyun"], "par": ["par", "pe"],
             "evan": ["evam"], "aur": ["aur", "or"], "yah": ["ye", "yah"], "vah": ["wo", "vo", "vah"]}


def casual(text, lang, rng=random):
    """Native hi/ta/kn -> casual Latin spelling as farmers type it ('पत्तों पर सफेद' -> 'patton par safed')."""
    if lang == "ta":
        return tamil_casual(text, rng)
    if transliterate is None or lang not in SCRIPT:
        return text
    t = transliterate(text, SCRIPT[lang], "itrans")
    t = t.replace("~N", "n").replace("~n", "n").replace(".N", "n").replace(".n", "n").replace("M", "n").replace("H", "h")
    t = t.replace("RRi", "ri").replace("R^i", "ru" if lang == "kn" else "ri").replace(".h", "").replace("^", "")
    t = t.replace(".a", "a").replace("{}", "").replace(".D", "d").replace(".Dh", "dh")
    t = t.replace("A", "aa").replace("I", "ee" if rng.random() < .5 else "ii").replace("U", "oo" if rng.random() < .6 else "uu")
    t = _strip(t).lower()
    t = t.replace("chh", "chh" if rng.random() < .5 else "ch").replace("sh", "sh" if rng.random() < .6 else "s")
    t = t.replace("ph", "f" if rng.random() < .7 else "ph").replace("w", "v" if rng.random() < .5 else "w")
    out = []
    for w in t.split():
        if lang == "hi" and len(w) > 2 and w.endswith("a") and not w.endswith("aa") and rng.random() < .85:
            w = w[:-1]  # schwa deletion
        if lang == "hi" and w in _HI_WORDS:
            out.append(rng.choice(_HI_WORDS[w]))
            continue
        if lang == "kn" and w.startswith("e") and rng.random() < .3:
            w = "y" + w
        if rng.random() < .5:
            w = w.replace("aa", "a")
        if rng.random() < .5:
            w = w.replace("ii", "i").replace("ee", "i")
        if rng.random() < .5:
            w = w.replace("uu", "u").replace("oo", "u")
        out.append(w)
    return " ".join(out)


# ------------------------------------------------------------------ casual Tamil romanization (k/g, ch/s, th/dh by position)
_TA_C = {"க": "k", "ங": "ng", "ச": "ch", "ஜ": "j", "ஞ": "nj", "ட": "t", "ண": "n", "த": "th", "ந": "n", "ன": "n", "ப": "p",
         "ம": "m", "ய": "y", "ர": "r", "ற": "r", "ல": "l", "ள": "l", "ழ": "zh", "வ": "v", "ஶ": "sh", "ஷ": "sh", "ஸ": "s", "ஹ": "h"}
_TA_V = {"அ": "a", "ஆ": "aa", "இ": "i", "ஈ": "ee", "உ": "u", "ஊ": "oo", "எ": "e", "ஏ": "e", "ஐ": "ai", "ஒ": "o", "ஓ": "o", "ஔ": "au"}
_TA_S = {"ா": "aa", "ி": "i", "ீ": "ee", "ு": "u", "ூ": "oo", "ெ": "e", "ே": "e", "ை": "ai", "ொ": "o", "ோ": "o", "ௌ": "au", "்": ""}


def _ta_word(w, rng):
    units = []  # [consonant or None, vowel string or None, raw char]
    for ch in w:
        if ch in _TA_C:
            units.append([ch, "a", ch])
        elif ch in _TA_S and units and units[-1][0] is not None and units[-1][1] == "a":
            units[-1][1] = _TA_S[ch]
        elif ch in _TA_V:
            units.append([None, _TA_V[ch], ch])
        elif ch == "ௗ":
            continue
        else:
            units.append([None, None, ch])
    out = []
    for i, (c, v, raw) in enumerate(units):
        if c is None:
            if v is None:
                out.append("f" if raw == "ஃ" else raw)
            else:
                out.append(("y" + v) if i == 0 and v == "e" and rng.random() < .3 else v)
            continue
        prev = units[i - 1] if i > 0 else None
        pc = prev[0] if prev and prev[1] == "" else None          # previous consonant without vowel (virama)
        nxt = units[i + 1] if i + 1 < len(units) else None
        inter = prev is not None and prev[1] not in ("", None)   # after a vowel
        s = _TA_C[c]
        gem1 = v == "" and nxt is not None and nxt[0] == c        # first half of a doubled consonant (க்க, த்த, ட்ட, ப்ப, ச்ச)
        if gem1 or pc == c:
            s = {"க": "k", "ச": "c" if gem1 else "ch", "ட": "t", "த": "t" if gem1 else "th", "ப": "p", "ற": "t" if gem1 else "r"}.get(c, s)
        elif c == "க":
            s = "g" if pc == "ங" or (inter and rng.random() < .7) else "k"
        elif c == "ச":
            s = "j" if pc == "ஞ" else "ch" if pc == "ச" else ("s" if rng.random() < .5 else "ch") if (i == 0 or inter) else "ch"
        elif c == "ட":
            s = "d" if pc == "ண" or (inter and rng.random() < .7) or (i == 0 and rng.random() < .3) else "t"
        elif c == "த":
            s = "dh" if (pc in ("ந", "ன") and rng.random() < .7) or (inter and rng.random() < .6) else ("t" if pc == "த" else "th")
        elif c == "ப":
            s = "b" if pc == "ம" or (inter and rng.random() < .15) else "p"
        elif c == "ழ":
            s = "zh" if rng.random() < .6 else "l"
        elif c == "ங" or (c == "ஞ" and nxt and nxt[0] == "ச"):
            s = "n"
        elif c == "ய" and v == "" and i == len(units) - 1 and prev and prev[1]:
            s = "i" if rng.random() < .7 else "y"                 # நோய் -> noi, காய் -> kai
        if v == "aa" and rng.random() < .4:
            v = "a"
        elif v == "ee" and rng.random() < .5:
            v = "i"
        elif v == "oo" and rng.random() < .5:
            v = "u"
        elif v == "e" and raw and c is None and rng.random() < .2:
            v = "ae"
        out.append(s + v)
    t = "".join(out).replace("tth", "tth" if rng.random() < .5 else "th")
    return t.replace("aai", "ai" if rng.random() < .6 else "aai")


def tamil_casual(text, rng=random):
    return " ".join(_ta_word(w, rng) for w in text.split())


def _is_native(w):
    return any(ord(c) > 0x2FF and unicodedata.category(c)[0] in "LM" for c in w)


def partial_roman(text, lang, rng):
    ws = text.split()
    k = [i for i, w in enumerate(ws) if _is_native(w)]
    if len(k) < 2:
        return text
    for i in rng.sample(k, max(1, int(len(k) * rng.uniform(0.2, 0.6)))):
        ws[i] = casual(ws[i], lang, rng)
    return " ".join(ws)


# native (and common romanized) farm words -> English, for code-mixing; a word matches if it starts with the stem and the
# rest is a short suffix (agglutinative case endings), and the whole word is replaced by the English word.
CODEMIX = {
    "hi": {"दवाई": "medicine", "दवा": "medicine", "छिड़काव": "spray", "रोग": "disease", "बीमारी": "disease", "पत्त": "leaves",
           "पौध": "plant", "खेत": "field", "फसल": "crop", "बीज": "seed", "पानी": "water", "कीड़": "insect", "खाद": "fertilizer",
           "इलाज": "treatment", "उपाय": "solution", "मात्रा": "dose", "एकड़": "acre", "लीटर": "litre", "धान": "paddy",
           "टमाटर": "tomato", "मिर्च": "chilli", "मूंगफली": "groundnut", "जैविक": "organic", "धब्ब": "spots", "सफ़ेद": "white",
           "सफेद": "white", "पील": "yellow", "भूर": "brown", "नंबर": "number", "अधिकारी": "officer", "बचाव": "prevention",
           "dawai": "medicine", "dawa": "medicine", "rog": "disease", "bimari": "disease", "patte": "leaves", "patti": "leaf",
           "ilaj": "treatment", "upay": "solution", "khet": "field", "fasal": "crop", "dhan": "paddy", "tamatar": "tomato",
           "mirch": "chilli", "mirchi": "chilli", "mungfali": "groundnut", "moongfali": "groundnut", "dhabbe": "spots"},
    "ta": {"மருந்து": "medicine", "நோய்": "disease", "இலை": "leaf", "செடி": "plant", "வயல்": "field", "பயிர்": "crop",
           "விதை": "seed", "தண்ணி": "water", "தண்ணீர்": "water", "பூச்சி": "pest", "உரம்": "fertilizer", "ஏக்கர்": "acre",
           "லிட்டர்": "litre", "நெல்": "paddy", "தக்காளி": "tomato", "மிளகாய்": "chilli", "கடலை": "groundnut", "புள்ளி": "spot",
           "மஞ்சள்": "yellow", "வெள்ளை": "white", "கருப்பு": "black", "அளவு": "dose", "தெளி": "spray",
           "marundhu": "medicine", "marunthu": "medicine", "noi": "disease", "ilai": "leaf", "chedi": "plant", "vayal": "field",
           "nel": "paddy", "thakkali": "tomato", "milagai": "chilli", "kadalai": "groundnut", "pulli": "spot"},
    "kn": {"ಔಷಧಿ": "medicine", "ಔಷಧ": "medicine", "ರೋಗ": "disease", "ಎಲೆ": "leaf", "ಗಿಡ": "plant", "ಹೊಲ": "field", "ಬೆಳೆ": "crop",
           "ಬೀಜ": "seed", "ನೀರು": "water", "ಕೀಟ": "pest", "ಗೊಬ್ಬರ": "fertilizer", "ಎಕರೆ": "acre", "ಲೀಟರ್": "litre",
           "ಭತ್ತ": "paddy", "ಟೊಮೆಟೊ": "tomato", "ಮೆಣಸಿನಕಾಯಿ": "chilli", "ಶೇಂಗಾ": "groundnut", "ಚುಕ್ಕೆ": "spot", "ಹಳದಿ": "yellow",
           "ಬಿಳಿ": "white", "ಕಪ್ಪು": "black", "ಪ್ರಮಾಣ": "dose", "ಸಿಂಪಡ": "spray",
           "aushadhi": "medicine", "oushadhi": "medicine", "roga": "disease", "ele": "leaf", "gida": "plant", "bhatta": "paddy",
           "menasinakayi": "chilli", "shenga": "groundnut", "chukke": "spot"},
}
FILLERS = {"hi": ["जी", "भाई", "भैया", "साहब", "sir", "ji", "bhai", "please"], "ta": ["சார்", "அண்ணா", "ங்க", "sir", "anna", "pls"],
           "kn": ["ಸಾರ್", "ಅಣ್ಣ", "ರೀ", "sir", "anna", "pls"], "en": ["sir", "pls", "please", "bro", "madam", "urgent"]}


def code_mix(text, lang, rng, p=0.5):
    lex = CODEMIX.get(lang)
    if not lex:
        return text
    out, hit = [], False
    for w in text.split():
        lw = w.lower()
        rep = None
        for stem, en in lex.items():
            if lw.startswith(stem) and len(lw) - len(stem) <= 4 and rng.random() < p:
                rep = en
                break
        out.append(rep if rep else w)
        hit |= rep is not None
    return " ".join(out)


_VOWEL_PLAY = [("aa", "a"), ("ee", "i"), ("oo", "u"), ("ai", "e"), ("au", "o"), ("ya", "ia"), ("w", "v"), ("v", "w"), ("z", "j"),
               ("ph", "f"), ("th", "t"), ("dh", "d"), ("sh", "s"), ("kh", "k"), ("q", "k")]


def typo(text, rng, n=None):
    ws = text.split()
    if not ws:
        return text
    for _ in range(n if n is not None else rng.choice([0, 1, 1, 2, 3])):
        i = rng.randrange(len(ws))
        c = list(ws[i])
        if len(c) < 3:
            continue
        op, k = rng.random(), rng.randrange(len(c))
        if op < .3:
            del c[k]
        elif op < .5:
            c.insert(k, c[k])
        elif op < .7 and k + 1 < len(c):
            c[k], c[k + 1] = c[k + 1], c[k]
        else:
            w = "".join(c)
            for a, b in rng.sample(_VOWEL_PLAY, len(_VOWEL_PLAY)):
                if a in w:
                    w = w.replace(a, b, 1)
                    break
            c = list(w)
        ws[i] = "".join(c)
    if len(ws) > 4 and rng.random() < .15:
        del ws[rng.randrange(len(ws))]
    return " ".join(ws)


class Augmenter:
    def __init__(self, facts, app_crops, root=FL.ROOT, holdout=(), p=None, seed_relabel_facts=None):
        """facts: all facts (item vocabulary); seed_relabel_facts: the facts the seed oracle may use (None = all facts)."""
        self.app = app_crops
        self.bt = FL.by_target(seed_relabel_facts if seed_relabel_facts is not None else facts)
        self.crop_of_fact = {f["id"]: f["crop"] for f in facts}
        self.target_of = {f["id"]: f["target"] for f in facts}
        self.holdout = set(holdout)
        self.p = dict(roman=0.25, mixed=0.1, codemix=0.15, dialect=0.3, swap=0.35, typo=0.5, filler=0.15, ctx=0.6, empty_ctx=0.35,
                      word_drop=0.08)
        self.p.update(p or {})
        lex_path = os.path.join(root, "data", "dialect_lexicon.json")
        self.pairs = {}
        if os.path.exists(lex_path):
            lex = json.load(open(lex_path, encoding="utf-8"))
            self.pairs = {L: [(s, v) for c in d.values() for s in c["standard"] for v in c["variants"] if s and v and s != v]
                          for L, d in lex.items()}
        names_path = os.path.join(HERE, "assets", "disease_names.json")
        self.names = json.load(open(names_path, encoding="utf-8")) if os.path.exists(names_path) else {}
        # unique, specific names usable as replacements
        allv = [(d, L, v) for d, m in self.names.items() for L, vs in m.items() for v in vs]
        self.repl = {}
        for d, L, v in allv:
            clash = any(v != v2 and (v in v2 or v2 in v) and d2 != d for d2, L2, v2 in allv if L2 == L)
            if not clash and (len(v.split()) >= 2 or len(v) >= 6):
                self.repl.setdefault((d, L), []).append(v)

    # ---------------------------------------------------------------- context
    def oracle(self, meta, ctx):
        return FL.oracle(meta["intent"], meta.get("target"), ctx, self.bt, self.app)

    def sample_ctx(self, meta, rng):
        intent, D, qcrop = meta["intent"], meta.get("target"), meta.get("crop")
        qcrop = qcrop or (self.app.get(D) if D else None)
        targets = [t for t in self.bt if t not in self.holdout]
        r = rng.random()
        if r < self.p["empty_ctx"]:
            return {"crop": None, "target": None}
        if r < self.p["empty_ctx"] + 0.15:
            return {"crop": qcrop or rng.choice(["rice", "tomato", "chilli", "groundnut"]), "target": None}
        if r < self.p["empty_ctx"] + (0.3 if intent == "dose" else 0.35) and D and D in self.bt:
            return {"crop": self.app.get(D), "target": D}
        if r < 0.95:   # some other confirmed disease (of the asked crop if known): dose -> <CONFIRM> (hard negatives)
            cands = [t for t in targets if not qcrop or self.app.get(t) == qcrop] or targets
            t = rng.choice(cands)
            return {"crop": self.app.get(t), "target": t}
        # rare: app crop conflicts with the asked disease -> <WHICH_CROP>
        crops = [c for c in ["rice", "tomato", "chilli", "groundnut"] if c != qcrop]
        return {"crop": rng.choice(crops), "target": None}

    def safe_ctx(self, row, rng):
        """Label-preserving ctx changes for rows without meta."""
        ctx, y = dict(row["ctx"]), row["y"]
        if ctx.get("target") and ctx.get("crop") and rng.random() < 0.3:
            ctx["crop"] = None
        facts = [x for x in y if x not in FL.STOP]
        crops = {self.crop_of_fact.get(x) for x in facts}
        if not ctx.get("crop") and facts and len(crops) == 1 and None not in crops and "general" not in crops \
                and FL.WHICH_CROP not in y and rng.random() < 0.3:
            ctx["crop"] = crops.pop()
        return ctx

    # ---------------------------------------------------------------- text
    def swap_disease(self, text, meta, lang, rng):
        D = meta.get("target")
        if not D or D not in self.names or lang not in self.names[D]:
            return None
        low = text.lower()
        found = [v for v in sorted(self.names[D][lang], key=len, reverse=True) if v.lower() in low]
        if not found:
            return None
        crop = self.app.get(D)
        cands = [d for d in self.names if d != D and self.app.get(d) == crop and d not in self.holdout and (d, lang) in self.repl]
        if not cands:
            return None
        D2 = rng.choice(cands)
        v = found[0]
        i = low.index(v.lower())
        return text[:i] + rng.choice(self.repl[(D2, lang)]) + text[i + len(v):], D2

    def dialect(self, text, lang, rng):
        """Swap standard words for dialect/slang variants (matches must start at a word boundary)."""
        pairs = self.pairs.get(lang, [])
        for s, v in rng.sample(pairs, min(len(pairs), 80)):
            i = text.find(s)
            if i >= 0 and (i == 0 or text[i - 1] == " ") and rng.random() < .5:
                text = text[:i] + v + text[i + len(s):]
        return text

    @staticmethod
    def intent_label(meta):
        i = (meta or {}).get("intent")
        return FL.INTENTS.index(i) if i in FL.INTENTS else -100

    def target_label(self, row, meta, ctx, y):
        """Label for the target head: the disease/pest the TEXT names ('<none>' if none), independent of ctx; '' = ignore."""
        if meta and meta.get("intent"):
            return meta.get("target") or "<none>"
        ts = {self.target_of.get(x) for x in y if x not in FL.STOP}
        if len(ts) == 1 and None not in ts:
            t = ts.pop()
            return t if t != ctx.get("target") else ""      # answer about the confirmed target: named or not, unknown
        if y[0] in (FL.NOT_SURE, FL.WHICH_CROP):
            return "<none>"
        return ""

    def __call__(self, row, rng, augment=True):
        """row -> dict(q, lang, script, ctx, y, tlabel). Never changes the meaning except through the oracle."""
        text, lang, script = row["q"], row["lang"], row["script"]
        meta = row.get("meta")
        ctx, y = dict(row["ctx"]), list(row["y"])
        if not augment:
            return {"q": text, "lang": lang, "script": script, "ctx": ctx, "y": y, "tlabel": self.target_label(row, meta, ctx, y),
                    "intent": self.intent_label(meta)}
        p = self.p
        if meta and meta.get("intent"):
            meta = dict(meta)
            if script == "native" and rng.random() < p["swap"]:
                s = self.swap_disease(text, meta, lang, rng)
                if s:
                    text, meta["target"] = s
            if rng.random() < p["ctx"]:
                ctx = self.sample_ctx(meta, rng)
            y = self.oracle(meta, ctx)
        elif rng.random() < p["ctx"]:
            ctx = self.safe_ctx(row, rng)
        tlabel = self.target_label(row, meta, ctx, y)
        if rng.random() < p["dialect"]:
            text = self.dialect(text, lang, rng)
        if lang in SCRIPT and script == "native":
            r = rng.random()
            if r < p["roman"]:
                text, script = casual(text, lang, rng), "roman"
            elif r < p["roman"] + p["mixed"]:
                text, script = partial_roman(text, lang, rng), "mixed"
        if rng.random() < p["codemix"]:
            t2 = code_mix(text, lang, rng)
            if t2 != text:
                text, script = t2, ("mixed" if lang != "en" else script)
        if rng.random() < p["typo"]:
            text = typo(text, rng)
        ws = text.split()
        if len(ws) >= 4 and p["word_drop"] > 0:                  # word dropout (keeps at least 3 words)
            keep = [w for w in ws if rng.random() >= p["word_drop"]]
            text = " ".join(keep) if len(keep) >= 3 else text
        if rng.random() < p["filler"]:
            f = rng.choice(FILLERS.get(lang, FILLERS["en"]))
            text = (f + " " + text) if rng.random() < .5 else (text + " " + f)
        return {"q": text, "lang": lang, "script": script, "ctx": ctx, "y": y, "tlabel": tlabel, "intent": self.intent_label(meta)}


def slot_aug(text, lang, rng, p_roman=0.3, p_typo=0.5):
    """Augmentation for slot-head rows (text + slots, no ctx)."""
    L = lang.split("-")[0]
    if L in SCRIPT and "-" not in lang and rng.random() < p_roman:
        text = casual(text, L, rng)
    if rng.random() < p_typo:
        text = typo(text, rng)
    return text
