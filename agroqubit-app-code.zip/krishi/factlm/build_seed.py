"""Build the seed tables for FactLM from the app's verified knowledge base.

Writes
  facts/seed_facts.jsonl            75 facts from brain/advice.json + brain/advice_i18n.json (text copied exactly)
  factlm/data/seed_train.jsonl      data/free_questions_train.jsonl -> questions (+ ctx variants), src "seed"
  factlm/data/seed_test.jsonl       data/free_questions_test.jsonl  -> questions, ctx empty (as the old free chat was tested)
  factlm/data/seed_test_ctx.jsonl   ctx variants of the held-out test questions (confirmed disease, known crop)
  factlm/assets/app_diseases.json   app disease id -> crop (android/doctor_kb.json)
  factlm/assets/disease_names.json  disease names per language (knowledge base + voice catalogue), for augmentation

y is what freechat/freechat.py answers when it understands the question perfectly (facts_lib.oracle).
Run from anywhere: python3 factlm/build_seed.py
"""
import json
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import facts_lib as FL

ROOT = FL.ROOT
KB_OUTSIDE = "/home/claude/agri_reason/v2/knowledge_v2.json"   # names only; output is saved in factlm/assets
CROP_WORDS = {  # crop words (and possessive forms) that start a disease name
    "en": {"rice": ["rice"], "tomato": ["tomato"], "chilli": ["chilli"], "groundnut": ["groundnut"]},
    "hi": {"rice": ["धान का", "धान"], "tomato": ["टमाटर का", "टमाटर के पत्तों का", "टमाटर"], "chilli": ["मिर्च का", "मिर्च के पत्तों का", "मिर्च"],
           "groundnut": ["मूंगफली का", "मूंगफली"]},
    "ta": {"rice": ["நெல்"], "tomato": ["தக்காளி"], "chilli": ["மிளகாய்"], "groundnut": ["நிலக்கடலை"]},
    "kn": {"rice": ["ಭತ್ತದ"], "tomato": ["ಟೊಮೆಟೊ"], "chilli": ["ಮೆಣಸಿನಕಾಯಿ", "ಮೆಣಸಿನ"], "groundnut": ["ಶೇಂಗಾ"]},
}


def parse_source(s):
    """'title — url' -> (doc, url)."""
    if " — " in s:
        doc, url = s.rsplit(" — ", 1)
    else:
        m = re.search(r"https?://\S+", s)
        doc, url = (s[:m.start()].strip(" —-"), m.group(0)) if m else (s, None)
    return doc.strip(), (url.strip() if url else None)


def build_facts():
    adv = json.load(open(os.path.join(ROOT, "brain/advice.json"), encoding="utf-8"))["advice"]
    i18 = json.load(open(os.path.join(ROOT, "brain/advice_i18n.json"), encoding="utf-8"))
    facts = []
    for d, a in adv.items():
        crop = d.split("_")[0]
        doc, url = parse_source(a["source"])
        order = 0

        def add(cat, n, text, kind, req):
            nonlocal order
            facts.append({"id": f"{crop}.{d}.{cat}.{n}", "crop": crop, "topic": "disease", "target": d, "kind": kind,
                          "requires_confirmed": req, "text": {L: text[L] for L in FL.LANGS},
                          "source": {"doc": doc, "url": url, "page": None, "quote": text["en"]},
                          "order": order, "review": "seed"})
            order += 1

        add("first", 1, a["first"], "first", False)
        # canonical order: first, biological, cultural, chemical (the order freechat used for organic answers)
        for cat, key, kind, req in [("biological", "biological", "action", False), ("cultural", "cultural", "action", False),
                                    ("chemical", "chemical_examples", "dose", True)]:
            en = a[key]
            for L in ["hi", "ta", "kn"]:
                assert len(i18[d][key][L]) == len(en), (d, key, L)
            for k, t in enumerate(en):
                add(cat, k + 1, {"en": t, **{L: i18[d][key][L][k] for L in ["hi", "ta", "kn"]}}, kind, req)
    for f in facts:
        err = FL.fact_errors(f)
        assert not err, (f["id"], err)
    return facts


def app_diseases():
    kb = json.load(open(os.path.join(ROOT, "android/doctor_kb.json"), encoding="utf-8"))
    return dict(zip(kb["names"], kb["crops"]))


def disease_names(app):
    """Name variants per disease and language: KB names + voice catalogue names, split at '(' / ', यानी' etc."""
    cat = json.load(open(os.path.join(ROOT, "voice/catalogue.json"), encoding="utf-8"))
    kbn = {}
    if os.path.exists(KB_OUTSIDE):
        kb = json.load(open(KB_OUTSIDE, encoding="utf-8"))
        kbn = {d: e.get("names", {}) for d, e in kb["diseases"].items()}
    old = os.path.join(FL.HERE, "assets", "disease_names.json")
    if not kbn and os.path.exists(old):           # rebuilding without the KB: keep the saved table
        return json.load(open(old, encoding="utf-8"))
    out = {}
    for d in app:
        if d.endswith("_healthy"):
            continue
        out[d] = {}
        for L in FL.LANGS:
            raw = [kbn.get(d, {}).get(L, ""), cat.get(f"name_{d}", {}).get(L, "")]
            parts = []
            for r in raw:
                for p in re.split(r"[(),]|यानी|அதாவது|ಅಂದ್ರೆ|also called|—", r):
                    p = p.strip(" .")
                    if len(p) >= 3:
                        parts.append(p)
            if L == "en":
                parts = [p.lower() for p in parts]
            # short forms without the crop word ("நிலக்கடலை துரு நோய்" -> "துரு நோய்"), as farmers usually say them
            for cw in CROP_WORDS[L][app[d]]:
                parts += [p[len(cw):].strip() for p in parts if p.startswith(cw + " ") and len(p[len(cw):].strip()) >= 4]
            seen = []
            for p in parts:
                if p not in seen and not p.startswith(("your ", "का ", "के ", "की ")):
                    seen.append(p)
            out[d][L] = seen
    return out


def to_question(r, ctx, y, src):
    lang = r["lang"].split("-")[0]
    return {"q": r["text"], "lang": lang, "script": FL.detect_script(r["text"], lang), "ctx": ctx, "y": y, "src": src,
            "meta": {"intent": r["intent"], "target": r.get("disease"), "crop": r.get("crop")}}


def variants(r, bt, app, rng, base=True):
    """Base question (empty ctx) + ctx variants where the ctx changes or tests the answer."""
    intent, D, crop = r["intent"], r.get("disease"), r.get("crop")
    qcrop = crop or (app.get(D) if D else None)
    out = []

    def add(ctx):
        y = FL.oracle(intent, D, ctx, bt, app)
        out.append(to_question(r, ctx, y, "seed"))

    if base:
        add({"crop": None, "target": None})
    if qcrop:                                                     # crop known to the app (same answer)
        add({"crop": qcrop, "target": None})
    if intent in FL.SC_INTENTS:
        if D and bt.get(D):
            add({"crop": app.get(D), "target": D})                # disease confirmed (dose -> chemical facts)
            if intent == "dose":                                  # another disease of the same crop is confirmed -> confirm first
                others = [t for t in bt if t != D and app.get(t) == app.get(D)]
                if others:
                    add({"crop": app.get(D), "target": rng.choice(others)})
        elif not D:                                               # follow-up question about the confirmed disease
            cands = [t for t in bt if not qcrop or app.get(t) == qcrop]
            if cands:
                t = rng.choice(cands)
                add({"crop": app.get(t), "target": t})
    return out


def main():
    rng = random.Random(0)
    facts = build_facts()
    FL.write_jsonl(os.path.join(ROOT, "facts/seed_facts.jsonl"), facts)
    app = app_diseases()
    json.dump(app, open(os.path.join(FL.HERE, "assets/app_diseases.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    names = disease_names(app)
    json.dump(names, open(os.path.join(FL.HERE, "assets/disease_names.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    bt = FL.by_target(facts)
    items = FL.Items(facts, targets=list(app))
    tr = FL.read_jsonl(os.path.join(ROOT, "data/free_questions_train.jsonl"))
    te = FL.read_jsonl(os.path.join(ROOT, "data/free_questions_test.jsonl"))
    q_tr = [q for r in tr for q in variants(r, bt, app, rng)]
    q_te = [to_question(r, {"crop": None, "target": None}, FL.oracle(r["intent"], r.get("disease"), {}, bt, app), "seed") for r in te]
    q_te_ctx = [q for r in te for q in variants(r, bt, app, rng, base=False)]
    for rows in (q_tr, q_te, q_te_ctx):
        for q in rows:
            err = FL.question_errors(q, items)
            assert not err, (q, err)
    FL.write_jsonl(os.path.join(FL.HERE, "data/seed_train.jsonl"), q_tr)
    FL.write_jsonl(os.path.join(FL.HERE, "data/seed_test.jsonl"), q_te)
    FL.write_jsonl(os.path.join(FL.HERE, "data/seed_test_ctx.jsonl"), q_te_ctx)
    from collections import Counter
    first = lambda rows: Counter(q["y"][0] if q["y"][0] in FL.STOP else "fact" for q in rows)
    print(f"facts: {len(facts)} ({Counter(f['kind'] for f in facts)})")
    print(f"seed_train: {len(q_tr)} rows from {len(tr)} questions; first item {dict(first(q_tr))}")
    print(f"seed_test: {len(q_te)} rows; first item {dict(first(q_te))}")
    print(f"seed_test_ctx: {len(q_te_ctx)} rows; first item {dict(first(q_te_ctx))}")
    print(f"scripts train {dict(Counter(q['script'] for q in q_tr))}, test {dict(Counter(q['script'] for q in q_te))}")


if __name__ == "__main__":
    main()
