"""Train FactLM on facts + questions (GPU with bf16 AMP, or CPU). Resumable; keeps the best checkpoint on a validation split.

Local smoke run on the seed data (CPU, ~8 min):
  python3 factlm/train.py --out factlm/runs/seed --threads 2 --max-minutes 8 --test factlm/data/seed_test.jsonl
GPU run (facts from the fact pipeline + teacher questions):
  python3 factlm/train.py --facts 'facts/*.jsonl' --questions factlm/data/seed_train.jsonl --questions 'facts/questions*.jsonl' \
      --out factlm/runs/full --batch 256 --epochs 40 --workers 6 --resume
Outputs in --out: best.pt, last.pt (resume), train.log (JSON lines), args.json, val_metrics.json, test_metrics.json.
"""
import argparse
import json
import math
import os
import random
import sys
import time
import traceback

import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import facts_lib as FL  # noqa: E402
import metrics as M  # noqa: E402
from augment import Augmenter, slot_aug  # noqa: E402
from model import DEFAULT_CFG, FactLM, save_checkpoint  # noqa: E402
from text_features import Featurizer, normalise  # noqa: E402

ROOT = FL.ROOT


def parse(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--facts", action="append", help="fact file or glob, repeatable (default facts/seed_facts.jsonl)")
    ap.add_argument("--questions", action="append", help="question file or glob, repeatable (default factlm/data/seed_train.jsonl)")
    ap.add_argument("--test", action="append", default=[], help="question files evaluated with the best checkpoint at the end")
    ap.add_argument("--slots-train", default=os.path.join(ROOT, "data", "text_train.jsonl"))
    ap.add_argument("--out", default=os.path.join(HERE, "runs", "seed"))
    ap.add_argument("--device", default="auto")
    ap.add_argument("--amp", choices=["auto", "on", "off"], default="auto", help="bf16 autocast (auto = on for CUDA)")
    ap.add_argument("--resume", action="store_true", help="continue from <out>/last.pt if it exists")
    ap.add_argument("--init", default="", help="start from this checkpoint's weights (e.g. a seed model), items matched by id")
    ap.add_argument("--epochs", type=float, default=40)
    ap.add_argument("--max-steps", type=int, default=0)
    ap.add_argument("--max-minutes", type=float, default=0, help="stop (and save) after this wall time")
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--slot-batch", type=int, default=32)
    ap.add_argument("--fact-neg", type=int, default=32, help="random extra facts per batch for the contrastive loss")
    ap.add_argument("--aux-every", type=int, default=1, help="compute the slot/contrastive/align losses every N steps (CPU: 2)")
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--bag-lr", type=float, default=3e-3)
    ap.add_argument("--wd", type=float, default=0.01)
    ap.add_argument("--warmup", type=int, default=150)
    ap.add_argument("--val-frac", type=float, default=0.1)
    ap.add_argument("--eval-every", type=int, default=250)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--workers", type=int, default=0, help="DataLoader workers for augmentation + hashing (GPU runs)")
    ap.add_argument("--threads", type=int, default=0, help="torch CPU threads (0 = default)")
    ap.add_argument("--holdout-targets", default="", help="comma list: their facts are left out of training (zero-shot test)")
    ap.add_argument("--holdout-facts", default="", help="JSON {'ids': [...]} or list of fact ids left out of training "
                    "(e.g. facts/questions/holdout_facts.json); --test rows that need them are scored zero-shot")
    ap.add_argument("--seed-relabel", choices=["keep", "oracle"], default="keep",
                    help="keep: seed rows answer with seed facts only; oracle: recompute seed y from all facts")
    ap.add_argument("--w-slot", type=float, default=0.5)
    ap.add_argument("--slot-pos-weight", type=float, default=3.0, help="BCE weight of positive slots (1-2 of 38 are on)")
    ap.add_argument("--w-target", type=float, default=0.3)
    ap.add_argument("--w-intent", type=float, default=0.5, help="auxiliary intent head (rows with meta.intent)")
    ap.add_argument("--w-con", type=float, default=0.2)
    ap.add_argument("--w-align", type=float, default=0.5)
    ap.add_argument("--tau", type=float, default=0.1)
    ap.add_argument("--smoothing", type=float, default=0.05)
    ap.add_argument("--no-aug", action="store_true")
    ap.add_argument("--no-dose-gate", action="store_true", help="disable the target-head dose gate at inference")
    for k, v in DEFAULT_CFG.items():
        if k not in ("max_steps", "n_slots", "dose_gate"):
            ap.add_argument("--" + k.replace("_", "-"), type=type(v), default=v)
    return ap.parse_args(argv)


class Log:
    def __init__(self, path):
        self.f = open(path, "a", encoding="utf-8")

    def __call__(self, msg=None, **kw):
        if msg:
            print(msg, flush=True)
        if kw:
            kw["time"] = time.strftime("%Y-%m-%d %H:%M:%S")
            self.f.write(json.dumps(kw, ensure_ascii=False) + "\n")
            self.f.flush()


# ------------------------------------------------------------------------------------------- data
class Stream:
    """Endless augmented training batches as plain Python lists (picklable, so it can run in DataLoader workers)."""

    def __init__(self, rows, srows, slot_names, aug, items, facts, args, augment=True):
        self.rows, self.srows, self.aug, self.args, self.augment = rows, srows, aug, args, augment
        self.items_index, self.ctx_targets = items.index, items.ctx_targets
        self.si = {s: i for i, s in enumerate(slot_names)}
        self.feat = Featurizer(args.nb, args.max_words)
        self.facts = [f for f in facts if f["id"] in items.index]
        self.fact_idx = [items.index[f["id"]] for f in self.facts]
        self.fact_pos = {f["id"]: k for k, f in enumerate(self.facts)}
        self.n_slots = len(slot_names)

    def tindex(self, t):
        if t == "":
            return -100
        if t == "<none>" or t is None:
            return 0
        return self.ctx_targets.index(t) if t in self.ctx_targets else 1

    def make(self, chunk, schunk, rng):
        a = self.args
        qs = [self.aug(r, rng, augment=self.augment) for r in chunk]
        b = {"feats": [self.feat(q["q"]) for q in qs], "crops": [q["ctx"].get("crop") for q in qs],
             "targets": [q["ctx"].get("target") for q in qs], "tl": [self.tindex(q["tlabel"]) for q in qs],
             "intent": [q["intent"] for q in qs]}
        S = FL.MAX_STEPS
        b["y"] = [[self.items_index[x] for x in q["y"][:S]] + [-1] * (S - len(q["y"][:S])) for q in qs]
        # slot rows
        b["slot_feats"] = [self.feat(slot_aug(r["text"], r["lang"], rng) if self.augment else r["text"]) for r in schunk]
        sy = [[0.0] * self.n_slots for _ in schunk]
        for k, r in enumerate(schunk):
            for s in r["slots"]:
                sy[k][self.si[s]] = 1.0
        b["slot_y"] = sy
        # fact texts for the contrastive / align losses: gold facts of the batch + random facts, one random language each
        gold = []
        for q in qs:
            for x in q["y"]:
                if x in self.fact_pos and x not in gold:
                    gold.append(x)
        pool = [k for k in range(len(self.facts))]
        neg = rng.sample(pool, min(a.fact_neg, len(pool))) if pool else []
        fk = [self.fact_pos[x] for x in gold] + [k for k in neg if self.facts[k]["id"] not in gold]
        b["fact_idx"] = [self.fact_idx[k] for k in fk]
        b["fact_feats"] = [self.feat(self.facts[k]["text"][rng.choice(FL.LANGS)]) for k in fk]
        ids = [self.facts[k]["id"] for k in fk]
        b["fact_pos"] = [[x in q["y"] for x in ids] for q in qs]
        return b

    def batches(self, rng):
        a = self.args
        while True:
            order = list(range(len(self.rows)))
            rng.shuffle(order)
            sorder = list(range(len(self.srows)))
            rng.shuffle(sorder)
            sp = 0
            for k in range(0, len(order) - a.batch + 1 if len(order) >= a.batch else 1, a.batch):
                chunk = [self.rows[i] for i in order[k:k + a.batch]]
                if sp + a.slot_batch > len(sorder):
                    rng.shuffle(sorder)
                    sp = 0
                schunk = [self.srows[i] for i in sorder[sp:sp + a.slot_batch]]
                sp += a.slot_batch
                yield self.make(chunk, schunk, rng)


class StreamDS(torch.utils.data.IterableDataset):
    def __init__(self, stream, seed):
        super().__init__()
        self.stream, self.seed = stream, seed

    def __iter__(self):
        wi = torch.utils.data.get_worker_info()
        rng = random.Random(self.seed * 7919 + (wi.id if wi else 0))
        return self.stream.batches(rng)


def multi_pos_nce(sim, pos):
    m = pos.any(1)
    if not bool(m.any()):
        return sim.sum() * 0
    lse_all = torch.logsumexp(sim, 1)
    lse_pos = torch.logsumexp(sim.masked_fill(~pos, -1e4), 1)
    return (lse_all - lse_pos)[m].mean()


def losses(model, b, device, args, aux=True):
    T = lambda x, dt=torch.long: torch.tensor(x, dtype=dt, device=device)
    bt = model.make_batch(feats=b["feats"], crops=b["crops"], targets=b["targets"])
    mem, valid = model.encode(bt)
    base = model.base_allowed(bt["crop"], bt["target"])
    l_seq, acc = model.seq_loss(mem, valid, base, T(b["y"]), args.smoothing)
    z = model.pool(mem, valid)
    tl = T(b["tl"])
    l_tgt = F.cross_entropy(model.target_head(z).float(), tl, ignore_index=-100) if bool((tl >= 0).any()) else z.sum() * 0
    il = T(b["intent"])
    l_int = F.cross_entropy(model.intent_head(z).float(), il, ignore_index=-100) if bool((il >= 0).any()) else z.sum() * 0
    out = {"seq": l_seq, "target": l_tgt, "intent": l_int, "seq_acc": acc}
    if aux:
        sb = model.make_batch(feats=b["slot_feats"])
        smem, svalid = model.encode(sb)
        pw = torch.full((model.cfg["n_slots"],), args.slot_pos_weight, device=device)
        out["slot"] = F.binary_cross_entropy_with_logits(model.slot_head(model.pool(smem, svalid)).float(), T(b["slot_y"], torch.float), pos_weight=pw)
    else:
        out["slot"] = l_seq * 0
    if aux and b["fact_idx"] and (args.w_con > 0 or args.w_align > 0):
        fb = model.make_batch(feats=b["fact_feats"])
        fmem, fvalid = model.encode(fb)
        fz = model.pool(fmem, fvalid)
        qv = F.normalize(model.q_proj(z).float(), dim=-1)
        fv = F.normalize(model.f_proj(fz).float(), dim=-1)
        sim = qv @ fv.t() / args.tau
        pos = T(b["fact_pos"], torch.bool)
        out["con"] = 0.5 * (multi_pos_nce(sim, pos) + multi_pos_nce(sim.t(), pos.t()))
        E = model.items_E[T(b["fact_idx"])].float()
        A = model.align(fz).float()
        out["align"] = F.mse_loss(A, E.detach()) + 0.1 * F.mse_loss(E, A.detach())
    else:
        out["con"] = out["align"] = l_seq * 0
    k = args.aux_every if aux else 0     # aux losses computed every N steps carry N times the weight
    out["loss"] = out["seq"] + args.w_target * out["target"] + args.w_intent * out["intent"] + \
        k * (args.w_slot * out["slot"] + args.w_con * out["con"] + args.w_align * out["align"])
    return out


# ------------------------------------------------------------------------------------------- evaluation helpers
@torch.no_grad()
def slot_eval(model, srows, slot_names, batch=256):
    model.eval()
    si = {s: i for i, s in enumerate(slot_names)}
    P, Y = [], torch.zeros(len(srows), len(slot_names))
    for k, r in enumerate(srows):
        for s in r["slots"]:
            Y[k, si[s]] = 1
    for i in range(0, len(srows), batch):
        s, _ = model.heads(model.make_batch([r["text"] for r in srows[i:i + batch]]))
        P.append(s.cpu())
    probs = torch.cat(P) if P else torch.zeros(0, len(slot_names))
    best_t = max([x / 20 for x in range(4, 17)], key=lambda t: M.slot_metrics(probs, Y, t)["exact_set"]) if len(srows) else 0.5
    m = M.slot_metrics(probs, Y, best_t)
    m["threshold"] = best_t
    return m


def evaluate(model, rows, facts, slot_rows=None, slot_names=None):
    preds = M.predict(model, rows)
    m = M.summarize(rows, preds, facts)
    if slot_rows:
        m["slots"] = slot_eval(model, slot_rows, slot_names)
    return m, preds


def touches(r, holdout, target_of):
    m = r.get("meta") or {}
    return m.get("target") in holdout or r["ctx"].get("target") in holdout or \
        any(target_of.get(x) in holdout for x in r["y"])


def main(argv=None):
    args = parse(argv)
    os.makedirs(args.out, exist_ok=True)
    log = Log(os.path.join(args.out, "train.log"))
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    if args.threads:
        torch.set_num_threads(args.threads)
    device = torch.device(("cuda" if torch.cuda.is_available() else "cpu") if args.device == "auto" else args.device)
    amp = (args.amp == "on") or (args.amp == "auto" and device.type == "cuda")
    if amp and device.type == "cuda" and not torch.cuda.is_bf16_supported():
        log("bf16 not supported on this GPU: AMP off")
        amp = False
    args.facts = args.facts or [os.path.join(ROOT, "facts", "seed_facts.jsonl")]
    args.questions = args.questions or [os.path.join(HERE, "data", "seed_train.jsonl")]
    json.dump(vars(args), open(os.path.join(args.out, "args.json"), "w"), indent=1)
    log(f"device {device}, amp {amp}, out {args.out}")

    # ---------------- facts, items, questions
    facts = FL.load_facts(args.facts, strict=False, log=log)
    app = json.load(open(os.path.join(HERE, "assets", "app_diseases.json"), encoding="utf-8"))
    holdout = {t for t in args.holdout_targets.split(",") if t}
    hold_ids = set()
    if args.holdout_facts:
        hj = json.load(open(args.holdout_facts, encoding="utf-8"))
        hold_ids = set(hj["ids"] if isinstance(hj, dict) else hj)
    train_facts = [f for f in facts if f["target"] not in holdout and f["id"] not in hold_ids]
    if hold_ids:
        log(f"holdout facts: {len(hold_ids & {f['id'] for f in facts})} of {len(hold_ids)} listed ids are in the fact table")
    items = FL.Items(train_facts, targets=list(app))
    meta = items.meta_json()
    meta["app_crops"] = app
    oracle_facts = [f for f in train_facts if f["review"] == "seed"] if args.seed_relabel == "keep" else train_facts
    aug = Augmenter(train_facts, app, holdout=holdout, seed_relabel_facts=oracle_facts)
    if args.no_aug:
        aug.p.update({k: 0.0 for k in aug.p})
    target_of = {f["id"]: f["target"] for f in facts}
    rows = FL.load_questions(args.questions, log=log)
    n0 = len(rows)
    rows = [r for r in rows if not touches(r, holdout, target_of) and not any(x in hold_ids for x in r["y"])]
    if args.seed_relabel == "oracle":
        for r in rows:
            if (r.get("meta") or {}).get("intent"):
                r["y"] = aug.oracle(r["meta"], r["ctx"])
    errs = [FL.question_errors(r, items) for r in rows]
    bad = [r for r, e in zip(rows, errs) if e]
    rows = [r for r, e in zip(rows, errs) if not e]
    log(f"facts {len(facts)} (training items {items.n}: {len(FL.CONTROLS)} controls + {len(train_facts)} facts), "
        f"questions {n0} -> {len(rows)} (holdout {n0 - len(rows) - len(bad)}, invalid {len(bad)})")
    for r in bad[:5]:
        log(f"  invalid: {r['q'][:60]!r} {FL.question_errors(r, items)[:1]}")
    groups = sorted({normalise(r["q"]) for r in rows})
    grng = random.Random(args.seed)
    grng.shuffle(groups)
    val_g = set(groups[:int(len(groups) * args.val_frac)])
    tr_rows = [r for r in rows if normalise(r["q"]) not in val_g]
    va_rows = [r for r in rows if normalise(r["q"]) in val_g]
    FL.write_jsonl(os.path.join(args.out, "val_questions.jsonl"), [{k: v for k, v in r.items() if k != "_file"} for r in va_rows])
    slot_names = list(json.load(open(os.path.join(ROOT, "slots.json"), encoding="utf-8")))
    srows = FL.read_jsonl(args.slots_train)
    random.Random(args.seed).shuffle(srows)
    nsv = len(srows) // 10
    s_va, s_tr = srows[:nsv], srows[nsv:]
    log(f"train {len(tr_rows)} / val {len(va_rows)} question rows ({len(val_g)} val groups); slots train {len(s_tr)} / val {len(s_va)}")

    # ---------------- model
    cfg = {k: getattr(args, k) for k in DEFAULT_CFG if k not in ("max_steps", "n_slots", "dose_gate")}
    cfg["n_slots"] = len(slot_names)
    cfg["dose_gate"] = not args.no_dose_gate
    model = FactLM(cfg, meta, slot_names).to(device)
    model.init_items_from_text(items.fact)
    if args.init:
        from model import load_checkpoint
        src, _ = load_checkpoint(args.init, device)
        sd, own = src.state_dict(), model.state_dict()
        n_copied = 0
        for k, v in sd.items():
            if k in own and own[k].shape == v.shape and not k.startswith(("items_", "ctx_target", "target_head")):
                own[k] = v
                n_copied += 1
        si = {x: i for i, x in enumerate(src.meta["ids"])}
        for i, x in enumerate(model.meta["ids"]):
            if x in si:
                own["items_E"][i] = sd["items_E"][si[x]]
                own["items_b"][i] = sd["items_b"][si[x]]
        model.load_state_dict(own)
        log(f"init from {args.init}: {n_copied} tensors, {sum(x in si for x in model.meta['ids'])} item rows")
    nparam = sum(p.numel() for p in model.parameters())
    nbag = model.bag.weight.numel()
    log(f"params {nparam / 1e6:.2f}M (bag {nbag / 1e6:.2f}M, rest {(nparam - nbag) / 1e6:.2f}M); int8 size ~{(nparam + 4 * model.cfg['nb']) / 1e6:.1f} MB")

    no_wd = lambda n: n.endswith(".bias") or ".ln" in n or "_ln" in n or n in ("pos.weight", "step.weight", "bos", "items_b") or n.startswith("ctx_")
    groups_p = [{"params": [model.bag.weight], "lr": args.bag_lr, "weight_decay": 0.0},
                {"params": [p for n, p in model.named_parameters() if n != "bag.weight" and no_wd(n)], "weight_decay": 0.0},
                {"params": [p for n, p in model.named_parameters() if n != "bag.weight" and not no_wd(n)], "weight_decay": args.wd}]
    opt = torch.optim.AdamW(groups_p, lr=args.lr, betas=(0.9, 0.98))
    base_lrs = [g["lr"] for g in opt.param_groups]
    steps_per_epoch = max(1, len(tr_rows) // args.batch)
    total = args.max_steps or int(math.ceil(args.epochs * steps_per_epoch))

    def lr_at(step):
        if step < args.warmup:
            return (step + 1) / args.warmup
        p = min(1.0, (step - args.warmup) / max(1, total - args.warmup))
        return 0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * p))

    step, best, t_start = 0, -1e9, time.time()
    last_path, best_path = os.path.join(args.out, "last.pt"), os.path.join(args.out, "best.pt")
    if args.resume and os.path.exists(last_path):
        ck = torch.load(last_path, map_location=device, weights_only=False)
        if ck["meta"]["ids"] != model.meta["ids"]:
            raise SystemExit("resume: the item list changed (different facts?) - start a new --out or use --init")
        model.load_state_dict(ck["state"])
        opt.load_state_dict(ck["opt"])
        step, best = ck["step"], ck["best"]
        log(f"resumed from step {step} (best {best:.4f})")
    log(f"{total} steps ({steps_per_epoch}/epoch), batch {args.batch}")

    stream = Stream(tr_rows, s_tr, slot_names, aug, items, train_facts, args, augment=not args.no_aug)
    if args.workers > 0:
        dl = torch.utils.data.DataLoader(StreamDS(stream, args.seed + step), batch_size=None, num_workers=args.workers,
                                         prefetch_factor=4, persistent_workers=True)
        it = iter(dl)
    else:
        it = stream.batches(random.Random(args.seed + step))

    def save_last():
        save_checkpoint(last_path, model, {"opt": opt.state_dict(), "step": step, "best": best, "args": vars(args)})

    def do_eval():
        nonlocal best
        m, _ = evaluate(model, va_rows, train_facts, s_va, slot_names)
        score = M.selection_score(m)
        a = m["all"]
        log(f"[eval step {step}] val first {a['first']:.3f} exact {a['exact']:.3f} F1 {a['F1']:.3f} wrong_target {a['wrong_target']:.3f} "
            f"WRONG_DOSE {a['WRONG_DOSE']:.3f} control {a['control_acc']} | slots {m['slots']} | score {score:.4f}"
            + (" *best*" if score > best else ""), kind="eval", step=step, val=a, slots=m["slots"], score=score)
        if score > best:
            best = score
            save_checkpoint(best_path, model, {"step": step, "best": best, "val": m, "args": vars(args)})
            json.dump(m, open(os.path.join(args.out, "val_metrics.json"), "w"), indent=1, ensure_ascii=False)
        save_last()
        model.train()

    model.train()
    agg, t_log = {}, time.time()
    try:
        while step < total:
            if args.max_minutes and (time.time() - t_start) / 60 > args.max_minutes:
                log(f"time limit reached at step {step}")
                break
            b = next(it)
            for g, lr0 in zip(opt.param_groups, base_lrs):
                g["lr"] = lr0 * lr_at(step)
            with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp):
                L = losses(model, b, device, args, aux=(step % args.aux_every == 0))
            opt.zero_grad(set_to_none=True)
            L["loss"].backward()
            gn = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            if not torch.isfinite(gn):
                log(f"non-finite gradient at step {step}, batch skipped")
                opt.zero_grad(set_to_none=True)
            else:
                opt.step()
            step += 1
            for k, v in L.items():
                agg[k] = agg.get(k, 0.0) + float(v.detach())
            agg["n"] = agg.get("n", 0) + 1
            if step % 50 == 0:
                n = agg.pop("n")
                msg = " ".join(f"{k} {v / n:.3f}" for k, v in agg.items())
                el = time.time() - t_start
                log(f"step {step}/{total} {msg} | {50 / (time.time() - t_log):.1f} it/s, {el / 60:.1f} min",
                    kind="train", step=step, **{k: v / n for k, v in agg.items()})
                agg, t_log = {}, time.time()
            if step % args.eval_every == 0:
                do_eval()
    except KeyboardInterrupt:
        log("interrupted: saving last.pt")
        save_last()
        raise
    except Exception:
        log("error:\n" + traceback.format_exc())
        save_last()
        raise
    if step % args.eval_every != 0 or not os.path.exists(best_path):
        do_eval()
    save_last()
    log(f"training done: {step} steps in {(time.time() - t_start) / 60:.1f} min, best val score {best:.4f}")

    # ---------------- final: best checkpoint on the test files (rows needing held-out facts are scored zero-shot)
    from model import load_checkpoint
    model, _ = load_checkpoint(best_path, device)
    train_items = FL.Items(train_facts, targets=list(app))
    zs_model = None
    for path in args.test:
        trows = FL.load_questions(path, log=log)
        name = os.path.splitext(os.path.basename(path))[0]
        tr_ok = [r for r in trows if not FL.question_errors(r, train_items)]
        need = {x for r in trows for x in r["y"] if x not in train_items.index and x in target_of}
        runs = [(name, model, tr_ok, train_facts)]
        if need:
            if zs_model is None:
                import copy
                zs_model = copy.deepcopy(model)
                zs_model.add_items([f for f in facts if f["id"] not in train_items.index])
            all_items = FL.Items(facts, targets=list(app))
            zs_rows = [r for r in trows if any(x in need for x in r["y"]) and not FL.question_errors(r, all_items)]
            runs.append((name + "_zeroshot", zs_model, zs_rows, facts))
        for nm, mdl, rr, ff in runs:
            if not rr:
                continue
            m, preds = evaluate(mdl, rr, ff)
            json.dump(m, open(os.path.join(args.out, f"test_{nm}.json"), "w"), indent=1, ensure_ascii=False)
            a = m["all"]
            log(f"[test {nm}] n {a['n']} first {a['first']:.3f} exact {a['exact']:.3f} F1 {a['F1']:.3f} wrong_target {a['wrong_target']:.3f} "
                f"WRONG_DOSE {a['WRONG_DOSE']:.3f} control {a['control_acc']} freechat-style {m.get('freechat_style')}",
                kind="test", file=path, metrics=m)


if __name__ == "__main__":
    main()
