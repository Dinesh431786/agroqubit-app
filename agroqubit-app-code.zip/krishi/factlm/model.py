"""FactLM: the fact-token model. A farmer question in any wording -> a short sequence of VERIFIED fact ids + control tokens.

  words --(hashed char 2-4-grams + word id, mean EmbeddingBag)--> word vectors
  [CTX_CROP, CTX_TARGET, w1..w40] + learned positions --> 4-layer pre-LN transformer encoder (4 heads, FFN 4d, GELU) --> LN
      +--> mean-pool --> slot head (38 sigmoids), target head (which disease the question is about)
      +--> 2-layer pre-LN transformer decoder: input = E_items[previous item] (BOS at step 0) + step embedding,
           causal self-attention over emitted items, cross-attention to the encoder, LN --> logits = h . E_items^T + b
  Greedy decoding under the constraints of facts/SCHEMA.md section 4 (identical in FactLM.java).
  Auxiliary heads (training only): q_proj/f_proj (question <-> fact-text contrastive), align (fact text -> E_items row),
  so a new fact can be added later by encoding its text (zero-shot).
"""
import math
import os
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import facts_lib as FL
from text_features import Featurizer

DEFAULT_CFG = dict(d=160, heads=4, ffn=640, enc_layers=4, dec_layers=2, nb=1 << 16, max_words=40, max_steps=FL.MAX_STEPS,
                   n_slots=38, dropout=0.1, dose_gate=True, min_first_prob=0.3, text_crop_min=0.5)


class MHA(nn.Module):
    def __init__(self, d, heads, p):
        super().__init__()
        self.h, self.p = heads, p
        self.q, self.k, self.v, self.o = (nn.Linear(d, d) for _ in range(4))

    def forward(self, x, kv, attn_mask=None):
        """attn_mask: bool [B or 1, 1, Tq, Tk], True = attend."""
        B, Tq, d = x.shape
        Tk, dh = kv.shape[1], d // self.h
        q = self.q(x).view(B, Tq, self.h, dh).transpose(1, 2)
        k = self.k(kv).view(B, Tk, self.h, dh).transpose(1, 2)
        v = self.v(kv).view(B, Tk, self.h, dh).transpose(1, 2)
        y = F.scaled_dot_product_attention(q, k, v, attn_mask=attn_mask)   # no dropout on attention probabilities
        return self.o(y.transpose(1, 2).reshape(B, Tq, d))


class FFN(nn.Module):
    def __init__(self, d, ffn, p):
        super().__init__()
        self.fc1, self.fc2, self.drop = nn.Linear(d, ffn), nn.Linear(ffn, d), nn.Dropout(p)

    def forward(self, x):
        return self.fc2(self.drop(F.gelu(self.fc1(x))))


class EncLayer(nn.Module):
    def __init__(self, d, heads, ffn, p):
        super().__init__()
        self.ln1, self.att, self.ln2, self.ffn, self.drop = nn.LayerNorm(d), MHA(d, heads, p), nn.LayerNorm(d), FFN(d, ffn, p), nn.Dropout(p)

    def forward(self, x, mask):
        h = self.ln1(x)
        x = x + self.drop(self.att(h, h, mask))
        return x + self.drop(self.ffn(self.ln2(x)))


class DecLayer(nn.Module):
    def __init__(self, d, heads, ffn, p):
        super().__init__()
        self.ln1, self.self_att = nn.LayerNorm(d), MHA(d, heads, p)
        self.ln2, self.cross = nn.LayerNorm(d), MHA(d, heads, p)
        self.ln3, self.ffn, self.drop = nn.LayerNorm(d), FFN(d, ffn, p), nn.Dropout(p)

    def forward(self, x, mem, self_mask, mem_mask):
        h = self.ln1(x)
        x = x + self.drop(self.self_att(h, h, self_mask))
        x = x + self.drop(self.cross(self.ln2(x), mem, mem_mask))
        return x + self.drop(self.ffn(self.ln3(x)))


class FactLM(nn.Module):
    def __init__(self, cfg, items_meta, slot_names):
        """cfg: DEFAULT_CFG-like dict. items_meta: facts_lib.Items.meta_json() (ids, crop, target, kind, requires_confirmed,
        ctx_crops, ctx_targets). slot_names: list of 38 slot names."""
        super().__init__()
        self.cfg = dict(DEFAULT_CFG, **cfg)
        c = self.cfg
        d, p = c["d"], c["dropout"]
        self.meta, self.slot_names = items_meta, list(slot_names)
        self.n_items = len(items_meta["ids"])
        self.bag = nn.EmbeddingBag(c["nb"], d, mode="mean")
        self.pos = nn.Embedding(2 + c["max_words"], d)
        self.ctx_crop = nn.Embedding(len(items_meta["ctx_crops"]), d)
        self.ctx_target = nn.Embedding(len(items_meta["ctx_targets"]), d)
        self.emb_drop = nn.Dropout(p)
        self.enc = nn.ModuleList([EncLayer(d, c["heads"], c["ffn"], p) for _ in range(c["enc_layers"])])
        self.enc_ln = nn.LayerNorm(d)
        self.slot_head = nn.Linear(d, c["n_slots"])
        self.target_head = nn.Linear(d, len(items_meta["ctx_targets"]))
        self.bos = nn.Parameter(torch.zeros(d))
        self.step = nn.Embedding(c["max_steps"], d)
        self.dec = nn.ModuleList([DecLayer(d, c["heads"], c["ffn"], p) for _ in range(c["dec_layers"])])
        self.dec_ln = nn.LayerNorm(d)
        self.items_E = nn.Parameter(torch.randn(self.n_items, d) / math.sqrt(d))
        self.items_b = nn.Parameter(torch.zeros(self.n_items))
        self.q_proj, self.f_proj, self.align = nn.Linear(d, d), nn.Linear(d, d), nn.Linear(d, d)
        self.intent_head = nn.Linear(d, len(FL.INTENTS))   # training-only auxiliary head (seed rows carry meta.intent)
        self.feat = Featurizer(c["nb"], c["max_words"])
        nn.init.normal_(self.bag.weight, 0, 0.3)
        nn.init.normal_(self.pos.weight, 0, 0.02)
        nn.init.normal_(self.step.weight, 0, 0.02)
        nn.init.normal_(self.ctx_crop.weight, 0, 0.1)
        nn.init.normal_(self.ctx_target.weight, 0, 0.1)
        nn.init.normal_(self.bos, 0, 0.1)
        self._rebuild_masks()

    # ------------------------------------------------------------------ constraint tensors
    def _rebuild_masks(self):
        m, dev = self.meta, self.items_b.device
        n = len(m["ids"])
        self.n_items = n
        buf = lambda name, t: self.register_buffer(name, t.to(dev), persistent=False)
        buf("ctrl_mask", torch.tensor([x in FL.STOP for x in m["ids"]]))
        buf("req", torch.tensor([bool(x) for x in m["requires_confirmed"]]))
        crops = m["ctx_crops"]
        # item_crop_ok[c, i]: item i allowed when ctx crop index c (0 = none, 1 = other)
        ok = torch.ones(len(crops), n, dtype=torch.bool)
        for ci, cname in enumerate(crops):
            if ci == 0:
                continue
            for i in range(n):
                ic = m["crop"][i]
                if ic is not None and ic != "general" and ic != cname:
                    ok[ci, i] = False
        buf("crop_ok", ok)
        tg = m["ctx_targets"]
        tok = torch.ones(len(tg), n, dtype=torch.bool)
        for ti in range(len(tg)):
            for i in range(n):
                t = m["target"][i]   # requires_confirmed needs fact.target == ctx.target (a target-less one: no ctx target)
                if m["requires_confirmed"][i] and not ((t is None and ti == 0) or (t is not None and ti >= 2 and t == tg[ti])):
                    tok[ti, i] = False
        buf("target_ok", tok)
        # target head: targets of another crop than ctx crop are masked too
        tcrop = [None, None] + [self._target_crop(t) for t in tg[2:]]
        tm = torch.ones(len(crops), len(tg), dtype=torch.bool)
        for ci, cname in enumerate(crops):
            if ci == 0:
                continue
            for ti in range(2, len(tg)):
                if tcrop[ti] not in (None, "general", cname):
                    tm[ci, ti] = False
        buf("target_crop_ok", tm)
        self.meta["target_crop"] = tcrop

    def _target_crop(self, t):
        for i, x in enumerate(self.meta["target"]):
            if x == t:
                return self.meta["crop"][i]
        return self.meta.get("app_crops", {}).get(t, t.split("_")[0] if t else None)

    def base_allowed(self, crop_idx, target_idx):
        """[B, n_items] items allowed by the context (crop + confirmed-target rules)."""
        return self.crop_ok[crop_idx] & self.target_ok[target_idx]

    def target_logits(self, z, crop_idx):
        """Target head (which disease/pest the question names) with targets of another crop than the ctx crop masked."""
        return self.target_head(z).float().masked_fill(~self.target_crop_ok[crop_idx], float("-inf"))

    def text_crop(self, z, crop_idx):
        """ctx crop index to MASK with: the app's crop, else the crop the text names (slot head crop_* >= text_crop_min)."""
        thr = float(self.cfg.get("text_crop_min", 0.0) or 0.0)
        if thr <= 0:
            return crop_idx
        names = self.meta["ctx_crops"]
        cs = [(k, names.index(s[5:])) for k, s in enumerate(self.slot_names) if s.startswith("crop_") and s[5:] in names]
        if not cs:
            return crop_idx
        lg = self.slot_head(z).float()[:, [k for k, _ in cs]]
        best, arg = lg.max(-1)                                  # argmax over logits (sigmoids saturate), as FactLM.java
        idx = torch.tensor([c for _, c in cs], device=z.device)[arg]
        return torch.where((crop_idx == 0) & (torch.sigmoid(best) >= thr), idx, crop_idx)

    def lex_named(self, text):
        """Targets whose local / English name appears as whole words in the (normalised) text. name_lexicon comes from
        factlm.json (export.py): unambiguous names only, so a match is a plain fact about what the farmer said."""
        lex = self.meta.get("name_lexicon") or {}
        if not lex: return set()
        from text_features import normalise
        t = " " + normalise(text) + " "
        return {tg for tg, names in lex.items() if any((" " + n + " ") in t for n in names)}

    def gated_allowed(self, mem, valid, crop_idx, target_idx, lexgate=None):
        """base_allowed with (a) the crop the text names when the app gives none (text_crop_min > 0) and (b) the dose gate:
        if the target head's top target is a real target other than the confirmed ctx target, every requires_confirmed
        fact is masked (the farmer named another disease -> no doses)."""
        z = self.pool(mem, valid)
        base = self.base_allowed(self.text_crop(z, crop_idx), target_idx)
        if self.cfg.get("dose_gate", True):
            top = self.target_logits(z, crop_idx).argmax(-1)
            gate = (top >= 2) & (top != target_idx)
            base = base & ~(gate[:, None] & self.req[None, :])
        if lexgate is not None:          # deterministic second guard: the words name only other diseases -> no doses
            base = base & ~(lexgate[:, None] & self.req[None, :])
        return base

    # ------------------------------------------------------------------ batching
    def make_batch(self, texts=None, feats=None, crops=None, targets=None):
        """texts (or pre-computed per-word id lists) + ctx names -> tensors for encode()."""
        if feats is None:
            feats = [self.feat(t) for t in texts]
        B = len(feats)
        crops = crops or [None] * B
        targets = targets or [None] * B
        ids, offs, wb, wp = [], [], [], []
        for b, ws in enumerate(feats):
            for k, w in enumerate(ws):
                offs.append(len(ids))
                ids.extend(w)
                wb.append(b)
                wp.append(2 + k)
        lens = [2 + len(ws) for ws in feats]
        dev = self.items_b.device
        T = lambda x: torch.tensor(x, dtype=torch.long, device=dev)
        lexgate = [False] * B
        if texts is not None and self.meta.get("name_lexicon"):
            for b in range(B):
                if targets[b] and self.target_index(targets[b]) >= 2:
                    named = self.lex_named(texts[b]); lexgate[b] = bool(named) and targets[b] not in named
        return {"ids": T(ids if ids else [0]), "offs": T(offs), "wb": T(wb), "wp": T(wp), "lens": T(lens),
                "crop": T([self.crop_index(c) for c in crops]), "target": T([self.target_index(t) for t in targets]),
                "lexgate": torch.tensor(lexgate, dtype=torch.bool, device=dev)}

    def crop_index(self, c):
        L = self.meta["ctx_crops"]
        return 0 if not c else (L.index(c) if c in L else 1)

    def target_index(self, t):
        L = self.meta["ctx_targets"]
        return 0 if not t else (L.index(t) if t in L else 1)

    # ------------------------------------------------------------------ encoder
    def encode(self, bt):
        """-> mem [B, T, d] (final LN applied), valid [B, T] bool."""
        lens = bt["lens"]
        B, T, d = lens.shape[0], int(lens.max()), self.cfg["d"]
        x = torch.zeros(B, T, d, device=lens.device, dtype=self.bag.weight.dtype)
        if bt["offs"].numel():
            wv = self.bag(bt["ids"], bt["offs"])
            x = x.index_put((bt["wb"], bt["wp"]), wv.to(x.dtype))
        ctx = torch.stack([self.ctx_crop(bt["crop"]), self.ctx_target(bt["target"])], 1)
        x = torch.cat([ctx.to(x.dtype), x[:, 2:]], 1)
        x = self.emb_drop(x + self.pos.weight[:T][None])
        pos = torch.arange(T, device=lens.device)
        valid = pos[None] < lens[:, None]
        # word positions do not attend to the 2 context tokens (so word states, and the heads pooled from them, read only the
        # text); the context tokens attend to everything. Padded query rows keep the plain key mask (never all-False).
        word_q = (pos[None] >= 2) & valid                                       # [B, T]
        mask = valid[:, None, None, :] & ~(word_q[:, None, :, None] & (pos < 2)[None, None, None, :])
        for L in self.enc:
            x = L(x, mask)
        return self.enc_ln(x), valid

    @staticmethod
    def pool(mem, valid):
        """Mean over the WORD positions (context tokens excluded); zeros for an empty text."""
        v = valid.clone()
        v[:, :2] = False
        v = v.to(mem.dtype)[..., None]
        return (mem * v).sum(1) / v.sum(1).clamp(min=1)

    # ------------------------------------------------------------------ decoder
    def decode(self, mem, valid, prev):
        """prev: [B, S] item ids fed at steps 1..S-1 (column 0 ignored: BOS). -> hidden [B, S, d]."""
        B, S = prev.shape
        x = self.items_E[prev.clamp(min=0)]
        x = torch.cat([self.bos.expand(B, 1, -1).to(x.dtype), x[:, 1:]], 1) + self.step.weight[:S][None]
        x = self.emb_drop(x)
        causal = torch.ones(S, S, dtype=torch.bool, device=mem.device).tril()[None, None]
        mm = valid[:, None, None, :]
        for L in self.dec:
            x = L(x, mem, causal, mm)
        return self.dec_ln(x)

    def item_logits(self, h):
        return h @ self.items_E.t() + self.items_b

    # ------------------------------------------------------------------ training losses
    def step_allowed(self, base, y):
        """Allowed items at each teacher-forced step: base [B, n] & not emitted before & no <END> at step 0. y: [B, S] (-1 pad)."""
        B, S = y.shape
        oh = torch.zeros(B, S, self.n_items, dtype=torch.bool, device=y.device)
        yy = y.clamp(min=0)
        oh.scatter_(2, yy[..., None], (y >= 0)[..., None])
        before = torch.cumsum(oh.to(torch.int16), 1) - oh.to(torch.int16)  # emitted strictly before step t
        allowed = base[:, None, :] & (before == 0)
        allowed[:, 0, 0] = False
        return allowed

    def seq_loss(self, mem, valid, base, y, smoothing=0.0):
        """Teacher-forced cross-entropy over masked item logits. y: [B, S] item ids, -1 = padding."""
        prev = torch.cat([torch.zeros_like(y[:, :1]), y[:, :-1]], 1)
        h = self.decode(mem, valid, prev)
        logits = self.item_logits(h).float()
        allowed = self.step_allowed(base, y)
        logits = logits.masked_fill(~allowed, -1e4)
        logp = torch.log_softmax(logits, -1)
        valid_t = y >= 0
        nll = -logp.gather(2, y.clamp(min=0)[..., None])[..., 0]
        smooth = -(logp * allowed).sum(-1) / allowed.sum(-1).clamp(min=1)   # label smoothing over the ALLOWED items only
        per = (1 - smoothing) * nll + smoothing * smooth
        loss = (per * valid_t).sum() / valid_t.sum().clamp(min=1)
        with torch.no_grad():
            ok = (logits.argmax(-1) == y) | ~valid_t
        return loss, ok.all(1).float().mean()

    # ------------------------------------------------------------------ inference
    @torch.no_grad()
    def generate(self, bt, max_steps=None, return_logits=False):
        """Greedy constrained decoding. -> list of (items, probs[, raw_logits per step]) per example."""
        max_steps = max_steps or self.cfg["max_steps"]
        mem, valid = self.encode(bt)
        B = mem.shape[0]
        base = self.gated_allowed(mem, valid, bt["crop"], bt["target"], bt.get("lexgate"))
        emitted = torch.zeros(B, self.n_items, dtype=torch.bool, device=mem.device)
        prev = torch.zeros(B, 1, dtype=torch.long, device=mem.device)
        done = torch.zeros(B, dtype=torch.bool, device=mem.device)
        out = [[[], [], []] for _ in range(B)]
        for t in range(max_steps):
            h = self.decode(mem, valid, prev)[:, -1]
            raw = self.item_logits(h).float()
            allowed = base & ~emitted
            if t == 0:
                allowed[:, self.meta["ids"].index(FL.END)] = False
            lm = raw.masked_fill(~allowed, float("-inf"))
            sm = torch.softmax(lm, -1)
            pick = lm.argmax(-1)
            tau = float(self.cfg.get("min_first_prob", 0.0) or 0.0)
            if t == 0 and tau > 0:   # unsure first fact -> <ASK> (diagnose first) instead of guessing
                low = ~self.ctrl_mask[pick] & (sm.gather(1, pick[:, None])[:, 0] < tau)
                pick = torch.where(low, torch.full_like(pick, self.meta["ids"].index(FL.ASK)), pick)
            prob = sm.gather(1, pick[:, None])[:, 0]
            for b in range(B):
                if not done[b]:
                    out[b][0].append(int(pick[b]))
                    out[b][1].append(float(prob[b]))
                    if return_logits:
                        out[b][2].append(raw[b].cpu())
            emitted[torch.arange(B, device=pick.device), pick] = True
            done |= self.ctrl_mask[pick]
            prev = torch.cat([prev, pick[:, None]], 1)
            if bool(done.all()):
                break
        ids = self.meta["ids"]
        res = []
        for it, pr, lg in out:
            r = {"items": [ids[i] for i in it], "item_idx": it, "scores": pr}
            if return_logits:
                r["logits"] = torch.stack(lg).numpy() if lg else None
            res.append(r)
        return res

    @torch.no_grad()
    def heads(self, bt):
        """Slot probabilities and target-head distribution (targets of another crop than ctx crop masked)."""
        mem, valid = self.encode(bt)
        z = self.pool(mem, valid)
        slots = torch.sigmoid(self.slot_head(z).float())
        return slots, torch.softmax(self.target_logits(z, bt["crop"]), -1)

    @torch.no_grad()
    def beam(self, text, crop=None, target=None, k=2, max_steps=None):
        """Beam search with the same constraints (evaluation only; the phone uses greedy)."""
        max_steps = max_steps or self.cfg["max_steps"]
        bt = self.make_batch([text], crops=[crop], targets=[target])
        mem, valid = self.encode(bt)
        base = self.gated_allowed(mem, valid, bt["crop"], bt["target"])[0]
        beams, final = [(0.0, [])], []
        for t in range(max_steps):
            cand = []
            for lp, seq in beams:
                prev = torch.tensor([[0] + seq], device=mem.device)
                raw = self.item_logits(self.decode(mem, valid, prev)[:, -1]).float()[0]
                allowed = base.clone()
                if seq:
                    allowed[torch.tensor(seq, device=mem.device)] = False
                if t == 0:
                    allowed[0] = False
                logp = torch.log_softmax(raw.masked_fill(~allowed, float("-inf")), -1)
                top = torch.topk(logp, min(k, int(allowed.sum())))
                for v, i in zip(top.values.tolist(), top.indices.tolist()):
                    cand.append((lp + v, seq + [i]))
            cand.sort(key=lambda x: -x[0])
            beams = []
            for lp, seq in cand[:k]:
                (final if bool(self.ctrl_mask[seq[-1]]) or len(seq) == max_steps else beams).append((lp, seq))
            if not beams:
                break
        final = final or beams
        lp, seq = max(final, key=lambda x: x[0])
        return {"items": [self.meta["ids"][i] for i in seq], "item_idx": seq, "logprob": lp}

    # ------------------------------------------------------------------ fact text (contrastive / zero-shot)
    def encode_texts(self, texts):
        bt = self.make_batch(texts)
        mem, valid = self.encode(bt)
        return self.pool(mem, valid)

    @torch.no_grad()
    def fact_embedding(self, fact):
        """E_items row for a fact from its text (mean over languages of the pooled encoding, through the align head)."""
        z = self.encode_texts([fact["text"][L] for L in FL.LANGS]).mean(0)
        return self.align(z)

    @torch.no_grad()
    def init_items_from_text(self, facts_by_id):
        """E_items initialised from the encoder-pooled fact text averaged over languages (unit rows); controls random."""
        was = self.training
        self.eval()
        for i, x in enumerate(self.meta["ids"]):
            f = facts_by_id.get(x)
            if f is None:
                continue
            z = self.encode_texts([f["text"][L] for L in FL.LANGS]).mean(0)
            z = z - z.mean()
            self.items_E.data[i] = z / (z.norm() + 1e-6)
        ctrl = self.items_E.data[: len(FL.CONTROLS)]
        self.items_E.data[: len(FL.CONTROLS)] = ctrl / (ctrl.norm(dim=1, keepdim=True) + 1e-6)
        self.train(was)

    @torch.no_grad()
    def add_items(self, facts):
        """Append facts zero-shot: E row = align(encoded text), bias = mean bias of existing facts of the same kind."""
        if not facts:
            return
        rows, bias = [], []
        kinds = self.meta["kind"]
        for f in facts:
            rows.append(self.fact_embedding(f))
            same = [i for i, k in enumerate(kinds) if k == f["kind"]]
            bias.append(float(self.items_b[same].mean()) if same else float(self.items_b[len(FL.CONTROLS):].mean()))
        self.items_E = nn.Parameter(torch.cat([self.items_E.data, torch.stack(rows)], 0))
        self.items_b = nn.Parameter(torch.cat([self.items_b.data, torch.tensor(bias, device=self.items_b.device)], 0))
        m = self.meta
        for f in facts:
            m["ids"].append(f["id"]); m["crop"].append(f["crop"]); m["target"].append(f["target"])
            m["kind"].append(f["kind"]); m["requires_confirmed"].append(bool(f["requires_confirmed"]))
            if f["target"] and f["target"] not in m["ctx_targets"]:
                m["ctx_targets"].append(f["target"])
        if len(m["ctx_targets"]) > self.ctx_target.num_embeddings:     # new targets: '<other>' embedding, untrained head row
            extra = len(m["ctx_targets"]) - self.ctx_target.num_embeddings
            w = self.ctx_target.weight.data
            self.ctx_target = nn.Embedding.from_pretrained(torch.cat([w, w[1:2].repeat(extra, 1)], 0), freeze=False)
            tw, tb = self.target_head.weight.data, self.target_head.bias.data
            self.target_head = nn.Linear(tw.shape[1], len(m["ctx_targets"])).to(tw.device)
            self.target_head.weight.data = torch.cat([tw, torch.zeros(extra, tw.shape[1], device=tw.device)], 0)
            self.target_head.bias.data = torch.cat([tb, torch.full((extra,), -1e4, device=tw.device)], 0)
        self._rebuild_masks()


# ---------------------------------------------------------------------------------------------- checkpoints
def save_checkpoint(path, model, extra=None):
    ck = {"cfg": model.cfg, "meta": model.meta, "slots": model.slot_names, "state": model.state_dict()}
    ck.update(extra or {})
    tmp = path + ".tmp"
    torch.save(ck, tmp)
    os.replace(tmp, path)


AUX_ONLY = ("intent_head.", "q_proj.", "f_proj.", "align.")   # training-only heads (not exported)


def load_checkpoint(path, device="cpu"):
    ck = torch.load(path, map_location=device, weights_only=False)
    m = FactLM(ck["cfg"], ck["meta"], ck["slots"])     # cfg keys missing in older checkpoints take DEFAULT_CFG values
    missing, unexpected = m.load_state_dict(ck["state"], strict=False)
    bad = [k for k in missing + unexpected if not k.startswith(AUX_ONLY)]
    if bad:
        raise RuntimeError(f"checkpoint {path} does not match the model: {bad[:5]}")
    return m.to(device).eval(), ck
