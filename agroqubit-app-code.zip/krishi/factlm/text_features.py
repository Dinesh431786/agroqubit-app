"""Per-word hashed features for FactLM, identical to TextModel.features() in Java (and text/textenc.py) but per word.

normalise(): lower-case, NFC, punctuation -> space, collapse whitespace (same regexes as TextModel.java).
Word w -> ids = [crc32("W"+w) % NB] + [crc32(g) % NB for each char 2..4-gram g of "<"+w+">"] (code points, UTF-8 CRC32).
Long inputs keep the first HEAD and the last TAIL words (max_words = HEAD + TAIL = 40).
"""
import re
import unicodedata
import zlib

_PUNCT = re.compile(r"[।॥.,!?;:\"'()\-–—/]+")
_WS = re.compile(r"\s+")


def normalise(s):
    s = unicodedata.normalize("NFC", s.lower())
    s = _PUNCT.sub(" ", s)
    return _WS.sub(" ", s).strip()


def words(s):
    n = normalise(s)
    return n.split(" ") if n else []


def truncate(ws, max_words=40):
    """First max_words//2 and last max_words - max_words//2 words of a long input (the question is often at the end)."""
    if len(ws) <= max_words:
        return ws
    head = max_words // 2
    return ws[:head] + ws[len(ws) - (max_words - head):]


def h(s, nb):
    return zlib.crc32(s.encode("utf-8")) % nb


def word_ids(w, nb, nmin=2, nmax=4):
    ids = [h("W" + w, nb)]
    t = "<" + w + ">"
    for n in range(nmin, nmax + 1):
        for i in range(len(t) - n + 1):
            ids.append(h(t[i:i + n], nb))
    return ids


class Featurizer:
    """text -> list of per-word id lists (cached per word)."""

    def __init__(self, nb, max_words=40, cache_size=500_000):
        self.nb, self.max_words, self.cache, self.cache_size = nb, max_words, {}, cache_size

    def word(self, w):
        v = self.cache.get(w)
        if v is None:
            v = word_ids(w, self.nb)
            if len(self.cache) < self.cache_size:
                self.cache[w] = v
        return v

    def __call__(self, text):
        return [self.word(w) for w in truncate(words(text), self.max_words)]
