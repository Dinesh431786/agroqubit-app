"""Evaluate FactLM on any questions.jsonl: first-item accuracy, set P/R/F1, exact set, wrong-crop / wrong-target rate,
WRONG DOSE rate, control-token accuracy, by language and script, plus the free-chat style judgement when rows carry meta.

  python3 factlm/eval.py --ckpt factlm/runs/seed/best.pt --questions factlm/data/seed_test.jsonl
  python3 factlm/eval.py --json factlm/export/factlm.json --bin factlm/export/factlm.bin --questions ...   # int8 export
  python3 factlm/eval.py --ckpt best.pt --questions ... --baseline factlm/results/freechat_preds_seed_test.json   # vs old free chat
  python3 factlm/eval.py --ckpt holdout.pt --facts facts/seed_facts.jsonl --zeroshot --questions ...           # add missing facts zero-shot
"""
import argparse
import json
import os
import sys

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import facts_lib as FL  # noqa: E402
import metrics as M  # noqa: E402
from model import load_checkpoint  # noqa: E402


def fmt(a):
    if not a:
        return "-"
    c = "  -  " if a.get("control_acc") is None else f"{a['control_acc']:.3f}"
    return (f"n {a['n']:4d} | first {a['first']:.3f} exact {a['exact']:.3f} P {a['P']:.3f} R {a['R']:.3f} F1 {a['F1']:.3f} | "
            f"wrong crop {a['wrong_crop']:.3f} target {a['wrong_target']:.3f} DOSE {a['WRONG_DOSE']:.3f} | control {c}")


def report(name, m):
    print(f"== {name}")
    print("  all         " + fmt(m["all"]))
    for key in ("by_lang", "by_script"):
        for k, a in m.get(key, {}).items():
            print(f"  {key[3:]:6s} {k:6s} " + fmt(a))
    print("  first-item type (gold -> predicted):", json.dumps(m["first_type_confusion"]))
    if "freechat_style" in m:
        print("  free-chat style:", json.dumps(m["freechat_style"]))


@torch.no_grad()
def retrieval(model, rows, facts):
    """Question -> fact text retrieval with the contrastive heads (no decoder): is the gold first fact the nearest fact text?
    Facts are encoded from their text in all 4 languages (mean of unit vectors), so unseen facts work the same way."""
    import torch.nn.functional as F
    rows = [r for r in rows if r["y"][0] not in FL.STOP]
    if not rows:
        return {}
    fv = []
    for f in facts:
        z = model.encode_texts([f["text"][L] for L in FL.LANGS])
        fv.append(F.normalize(F.normalize(model.f_proj(z), dim=-1).mean(0), dim=-1))
    fv = torch.stack(fv)
    ids = [f["id"] for f in facts]
    top1 = top5 = 0
    for i in range(0, len(rows), 128):
        ch = rows[i:i + 128]
        bt = model.make_batch([r["q"] for r in ch], crops=[r["ctx"].get("crop") for r in ch], targets=[r["ctx"].get("target") for r in ch])
        mem, valid = model.encode(bt)
        qv = F.normalize(model.q_proj(model.pool(mem, valid)), dim=-1)
        rank = (qv @ fv.t()).argsort(-1, descending=True)[:, :5]
        for r, rk in zip(ch, rank.tolist()):
            g = r["y"][0]
            top1 += ids[rk[0]] == g
            top5 += g in [ids[k] for k in rk]
    n = len(rows)
    out = {"n": n, "top1": round(top1 / n, 4), "top5": round(top5 / n, 4)}
    print(f"  retrieval (gold first fact among {len(facts)} fact texts): top-1 {out['top1']:.3f} top-5 {out['top5']:.3f} (n {n})")
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ckpt")
    ap.add_argument("--json")
    ap.add_argument("--bin")
    ap.add_argument("--questions", action="append", required=True)
    ap.add_argument("--facts", action="append", help="fact tables (default facts/*.jsonl)")
    ap.add_argument("--zeroshot", action="store_true", help="append facts missing from the model via the align head first")
    ap.add_argument("--only-targets", default="", help="comma list: evaluate only rows about these targets (zero-shot report)")
    ap.add_argument("--beam", type=int, default=0)
    ap.add_argument("--retrieval", action="store_true", help="also report question -> fact-text retrieval (contrastive heads)")
    ap.add_argument("--baseline", help="predictions of another system on the SAME single questions file (compare_freechat.py)")
    ap.add_argument("--out", help="write all metrics (and predictions) to this JSON file")
    ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("--min-first-prob", type=float, help="override the confidence fallback (0 = off)")
    ap.add_argument("--text-crop-min", type=float, help="override the text-crop mask threshold (0 = off)")
    a = ap.parse_args()
    if a.threads:
        torch.set_num_threads(a.threads)
    if a.ckpt:
        model, _ = load_checkpoint(a.ckpt)
    else:
        from export import load_exported
        model, _ = load_exported(a.json, a.bin)
    for k in ("min_first_prob", "text_crop_min"):
        v = getattr(a, k)
        if v is not None:
            model.cfg[k] = v
    print("decoding rules:", {k: model.cfg.get(k) for k in ("dose_gate", "min_first_prob", "text_crop_min")})
    facts = FL.load_facts(a.facts or [os.path.join(FL.ROOT, "facts", "*.jsonl")], strict=False, log=lambda m: None)
    if a.zeroshot:
        known = set(model.meta["ids"])
        new = [f for f in facts if f["id"] not in known]
        model.add_items(new)
        print(f"zero-shot: appended {len(new)} facts ({sorted({f['target'] for f in new})})")
    items = FL.Items([f for f in facts if f["id"] in set(model.meta["ids"])])
    only = {t for t in a.only_targets.split(",") if t}
    results = {}
    for path in a.questions:
        rows = FL.load_questions(path)
        bad = [r for r in rows if FL.question_errors(r, items)]
        rows = [r for r in rows if not FL.question_errors(r, items)]
        if bad:
            print(f"{path}: {len(bad)} rows skipped (facts unknown to this model / invalid)")
        if only:
            tg = {f["id"]: f["target"] for f in facts}
            rows = [r for r in rows if (r.get("meta") or {}).get("target") in only or any(tg.get(x) in only for x in r["y"])]
        if a.retrieval:
            results.setdefault("retrieval", {})[os.path.basename(path)] = retrieval(model, rows, facts)
        preds = M.predict(model, rows, beam=a.beam)
        m = M.summarize(rows, preds, facts)
        name = os.path.basename(path)
        report(name + (f" (beam {a.beam})" if a.beam else ""), m)
        results[name] = {"metrics": m, "predictions": [{"q": r["q"], "ctx": r["ctx"], "y": r["y"], "pred": p["items"],
                                                         "scores": [round(s, 3) for s in p.get("scores", [])],
                                                         "target_pred": p.get("target_pred")} for r, p in zip(rows, preds)]}
        if a.baseline:
            base = json.load(open(a.baseline, encoding="utf-8"))
            bp = base["predictions"]
            if len(bp) == len(rows) and all(b["q"] == r["q"] for b, r in zip(bp, rows)):
                bm = M.summarize(rows, [{"items": b["items"], "target_pred": b.get("target_pred")} for b in bp], facts)
                report(f"{name}: baseline {base.get('name', a.baseline)}", bm)
                results[name]["baseline"] = bm
            else:
                print("baseline predictions do not match these rows; skipped")
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
        json.dump(results, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
