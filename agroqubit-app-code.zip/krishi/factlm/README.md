# FactLM: the fact-token model

FactLM reads any farmer question (Hindi, Tamil, Kannada or English; native script, casual romanization, code-mixed,
typos) and **generates the answer as a short sequence of verified fact ids** plus control tokens. Its output vocabulary
holds only facts from `facts/*.jsonl`, each with a government source and an English quote. It can combine facts in new
ways for unseen questions, but it can never output unverified text. It runs in pure Java on a 2 GB phone.

```
question ─► normalise ─► per word: mean of hashed rows (W+word, char 2-4-grams of <word>, CRC32 % 65536), int8 bag
           [CTX_CROP, CTX_TARGET, w1 … w40] + learned positions
           ─► 4-layer pre-LN transformer encoder (4 heads, FFN 4d, GELU, d=160) ─► LN
              (word positions do not attend to the 2 context tokens; the context tokens attend to everything)
              ├─ mean over words ─► slot head (38 sigmoids, slots.json)
              ├─ mean over words ─► target head (the disease/pest the TEXT names, for <CONFIRM> and the dose gate)
              └─► 2-layer pre-LN decoder: input = E_items[previous item] (BOS at step 0) + step embedding,
                  causal self-attention over emitted items + cross-attention to the encoder, LN
                  logits = h · E_items^T + b_items  ─► greedy, constrained, ≤ 6 items
answer = e.g. [tomato.tomato_leaf_curl.biological.1, …, <END>]   or   [<ASK>] / [<NOT_SURE>] / [<WHICH_CROP>] / [<CONFIRM>]
```

## Files

| file | what |
|---|---|
| `facts/SCHEMA.md` | fact / control token / questions schema, answer policy, inference constraints (contract with the fact pipeline) |
| `facts/seed_facts.jsonl` | 75 seed facts from `brain/advice.json` + `brain/advice_i18n.json` (text copied exactly) |
| `factlm/build_seed.py` | builds the seed facts, seed questions and `factlm/assets/*` |
| `factlm/data/seed_train.jsonl` | 1158 rows: the 540 training questions + ctx variants (src `seed`) |
| `factlm/data/seed_test.jsonl` | the 270 held-out questions (different writer), empty ctx, as the old free chat was tested |
| `factlm/data/seed_test_ctx.jsonl` | 349 ctx variants of the held-out questions (crop known, disease confirmed, other disease confirmed) |
| `factlm/facts_lib.py` | loading + validation (`validate-facts`, `validate-questions`), item vocabulary, constraints, seed oracle |
| `factlm/text_features.py` | per-word hashed features, identical to `TextModel.features()` per word |
| `factlm/augment.py` | romanization (own casual Tamil romanizer + ITRANS for hi/kn), code-mixing, dialect lexicon, disease-name swap, typos, word dropout, context sampling |
| `factlm/model.py` | PyTorch model, constrained greedy/beam decoding, zero-shot fact addition |
| `factlm/train.py` | training (GPU bf16 or CPU), resume, validation selection, final test |
| `factlm/export.py` | `factlm.bin` (KRW1, int8) + `factlm.json` (+ `factlm_facts.json` texts/sources); `--add-facts` zero-shot |
| `factlm/eval.py` | metrics by language/script, free-chat style judgement, baseline comparison, zero-shot, retrieval |
| `factlm/compare_freechat.py` | runs the old free chat and maps its answers to item sequences (same metrics) |
| `factlm/vm_train.sh` | GPU VM: eval run (held-out facts scored zero-shot) + ship run (all facts) → export → int8 eval → parity |
| `android/src/in/krishi/doctor/FactLM.java` | Java runtime: `answer(text, crop, target)`, `slots(text)` |
| `android/src/in/krishi/doctor/FactLMKernels.java` | faster dense kernel + table GELU for FactLM |
| `android/test/factlm/` | parity test: `make_factlm_case.py`, `FactLMTest.java`, `run_parity.sh` |

## Data

**Seed facts.** Each disease card in `brain/advice.json` becomes facts: the `first` line (kind `first`), cultural and
biological items (kind `action`), and chemical examples (kind `dose`, `requires_confirmed: true`). Ids are
`<crop>.<disease>.<first|cultural|biological|chemical>.<n>`, and the canonical order is first, biological, cultural,
chemical. The quote is the KB's English item, and the doc/url come from the card's `source` string.

**Seed questions.** `y` is what `freechat/freechat.py` answers when it understands the question perfectly
(`facts_lib.oracle`). The text and ctx are kept, and `meta` holds the writer's intent/disease labels.

| intent | y |
|---|---|
| treatment, disease_info | the disease's `first` fact |
| organic | biological + cultural facts (or `<NOT_SURE>` if the card has none) |
| prevention | cultural facts (or `<NOT_SURE>`) |
| dose | chemical facts if `ctx.target` is that disease (confirmed), else `<CONFIRM>` |
| diagnose; no disease named; disease without facts | `<ASK>` |
| helpline, out_of_scope_known, off_topic | `<NOT_SURE>` (= KVK / KCC 1800-180-1551) |

A follow-up question that names no disease uses the confirmed `ctx.target` (as freechat's `known_disease` did). A named
disease of another crop than `ctx.crop` gives `<WHICH_CROP>`.

## Training

Losses:
- teacher-forced cross-entropy over the masked items, with label smoothing over allowed items only;
- the slot head, BCE on `data/text_train.jsonl` (positives weighted);
- the target head, trained on the disease the text names;
- a training-only intent head on `meta.intent`;
- contrastive InfoNCE between question and fact texts;
- an align loss `E_items[f] ≈ align(encode(fact text))`, which makes zero-shot facts possible.

`E_items` starts from the encoder-pooled fact text, averaged over the 4 languages.

Augmentation, on the fly:
- romanized and partly romanized hi/ta/kn;
- English code-mixing;
- dialect variants;
- disease-name swaps inside the same crop, with y recomputed by the oracle;
- typos, word dropout and fillers;
- context sampling for seed rows (empty, crop only, confirmed, another confirmed disease, conflicting crop) with y
  recomputed;
- label-preserving context changes for other rows.

Selection uses a 10% validation split grouped by question text:
`0.5·exact + 0.5·first − wrong_target − 5·WRONG_DOSE`.

## Inference constraints (Python `model.generate` = Java `FactLM.answer`)

1. No repeats.
2. If `ctx.crop` is known, facts of other crops are masked (`general` stays allowed).
3. A `requires_confirmed` fact needs `fact.target == ctx.target`.
4. **Dose gate** (extra safety): if the target head's top target is a real target ≠ `ctx.target`, every
   `requires_confirmed` fact is masked. The farmer named another disease, so the answer is `<CONFIRM>`, never the
   confirmed disease's doses. Turn it off with `"dose_gate": false` in factlm.json.
5. **Text crop** (`text_crop_min`, default 0.5). If the app gives no crop and the slot head finds `crop_X` with
   probability ≥ 0.5, rule 2 applies as if `ctx.crop = X`. This halves the wrong-crop answers.
6. `<END>` is never first.
7. **Unsure first fact** (`min_first_prob`, default 0.3). A first fact with probability < 0.3 becomes `<ASK>`
   (diagnose first, as the old free chat did on close calls).
8. Decoding stops at any control token or after 6 items. Greedy, since beam 2 gave identical results.
9. **Name guard** (deterministic second dose gate, no model involved). `factlm.json` carries `name_lexicon`: the local
   names of every disease/pest in the 4 languages and scripts (from `factlm/assets/disease_names.json` and
   `facts/target_names.json`), normalised like the text model, at least 4 characters, and only names that belong to
   exactly one target. If a disease is confirmed and the question names only *other* diseases (whole-word match),
   every `requires_confirmed` fact is masked. This catches what the target head misses (e.g. romanized names).

Rules 4, 5 and 7 come from the same single encoder pass: word positions do not see the context tokens, so the slot and
target heads read only the text. Each rule can be turned off in `factlm.json` or with `export.py` / `eval.py` flags.

## Results (local CPU smoke run on seed data only; see "Commands")

Trained on CPU for 7.3 min (720 steps, 1 thread), with seed data only: 540 questions, 75 facts, 15 diseases.
Selected on the 10% validation split. All numbers use the default decoding rules.

**Held-out test**: 270 questions by a different writer, empty context (as the old free chat was tested). The old free chat
was run on the same questions, and its answers were mapped to item sequences (`compare_freechat.py`), so both columns
use the same metrics.

| metric | FactLM | old free chat |
|---|---|---|
| first-item accuracy / exact item set | **84.1% / 84.1%** | 83.3% / 83.3% |
| set P / R / F1 | 0.869 / 0.843 / **0.856** | 0.870 / 0.836 / 0.853 |
| wrong crop / wrong target | 1.6% / 3.3% | 0.0% / 3.0% |
| **WRONG DOSE** | **0** | 0 |
| control-token accuracy | 84.3% | 84.9% |
| free-chat-style correct / safe / WRONG / wrongly refused | **83.0** / 11.9 / 4.8 / 0.4 % | 81.9 / 14.1 / 3.3 / 0.7 % |

The old judgement (`freechat/eval_freechat.py`) gives the old free chat 76.3% correct, 3.3% wrong and 0 wrong doses;
`compare_freechat.py` reproduces those numbers exactly.

Exact-set accuracy by group:

| | en | hi | kn | ta | native | roman |
|---|---|---|---|---|---|---|
| FactLM | 82.1 | 81.0 | 86.5 | 85.9 | 83.8 | 84.5 |
| old free chat | 89.7 | 79.7 | 79.7 | 87.2 | 85.1 | 81.0 |

**Context test** (`seed_test_ctx.jsonl`, 349 rows: crop known, disease confirmed, or another disease confirmed):
- exact 84.8%, F1 0.884, wrong crop 0, wrong target 4.0%, control accuracy 83.3%;
- **WRONG DOSE 0.6%** (2 rows). Both are romanized Tamil/Kannada questions that name another disease than the
  confirmed one, and the target head missed the name. Before the dose gate and the context-isolated words, a
  comparable run had 2.3% (8 rows).

**Other checks**

- **int8 export.** `factlm.bin` is 13.0 MB (bag 65536×160 int8 plus every matrix), plus a 10 kB `factlm.json`. Its
  metrics are identical to float32 on both test files.
- **Beam 2 vs greedy.** Identical on validation and test, so the phone uses greedy decoding.
- **Slot head** (shares the encoder; smoke-trained only). On `data/text_test.jsonl`: single-slot top-1 71.1%, exact
  set 60.5%, macro-F1 0.658. On the slang test: 65.6% top-1. The old TextModel gets 91%/93%, so the app should keep
  TextModel for slots until a GPU run catches up.
- **Zero-shot.** Trained 6 min without `groundnut_rust` and `tomato_early_blight`. Their 10 facts were then added from
  text via the align head.
  - On their 38 test questions: exact 26.3% (84.2% when trained), 57.9% safe fallback, 18.4% WRONG.
  - Question → fact-text retrieval: top-1 3.6% and top-5 40% (trained: 72.7% and 94.6%).
  - On the context rows the target head cannot recognise an unseen disease name, which gave 5 wrong doses (6%).
  - Conclusion: with only 13 training diseases the text-to-fact mapping does not generalise yet. **Retrain after
    adding facts** (cheap). Use the zero-shot path only for previews, never for dose facts.
- **Java parity** (`android/test/factlm`). Three models (random full-size, tiny trained, smoke trained) × 52 questions:
  - question types: 4 languages, romanized, code-mixed, empty, punctuation-only, emoji, 48 words (truncation),
    unknown crop/target, and a named disease that differs from the confirmed one;
  - the random model also carries a target-less dose fact and a `general` fact, so every mask path and the dose gate
    are exercised;
  - **52/52 identical item sequences** for every model;
  - max |logit diff| 4.3e-6 / 1.9e-6 / 5.3e-6; slots ≤ 7.9e-7; target head identical.
- **Java speed** (desktop x86 in a shared 2-core sandbox, trained model):
  - **1 thread: 7.7 ms CPU (7.8 ms wall) per question**, 2.0 decoder steps on average, worst 30 ms (wall);
  - "4 threads": 9.2 ms wall, which gains nothing on 2 shared cores;
  - the encoder matmuls are about 75% of the time;
  - `FactLMKernels` (4 time steps or 4 weight rows per pass, table GELU) is 2.5–3.5× faster than `Nn.linear`.
  - An ARM phone running ART may be 3–5× slower per core, so expect ~25–40 ms on 1 thread and ~10–15 ms on 4. This
    still needs a test on a real phone.

## Commands

```bash
# rebuild seed facts/questions (only if brain/advice*.json or data/free_questions_* change)
python3 factlm/build_seed.py
python3 factlm/facts_lib.py validate-facts facts/*.jsonl

# local CPU smoke training (< 10 min) + test
python3 factlm/train.py --out factlm/runs/seed --threads 1 --aux-every 2 --slot-batch 48 --epochs 45 --max-minutes 9.5 \
    --test factlm/data/seed_test.jsonl --test factlm/data/seed_test_ctx.jsonl
python3 factlm/compare_freechat.py            # old free chat on the same 270 questions -> factlm/results/
python3 factlm/eval.py --ckpt factlm/runs/seed/best.pt --questions factlm/data/seed_test.jsonl \
    --baseline factlm/results/freechat_preds_seed_test.json
python3 factlm/export.py --ckpt factlm/runs/seed/best.pt --out factlm/export          # factlm.bin + factlm.json
python3 factlm/eval.py --json factlm/export/factlm.json --bin factlm/export/factlm.bin --questions factlm/data/seed_test.jsonl
sh android/test/factlm/run_parity.sh /tmp/factlm_case --ckpt factlm/runs/seed/best.pt  # Java == PyTorch

# zero-shot check: train without two diseases, add their facts from text only, evaluate on their questions
python3 factlm/train.py --out factlm/runs/zeroshot --holdout-targets groundnut_rust,tomato_early_blight --threads 1 --aux-every 2 --max-minutes 9
python3 factlm/eval.py --ckpt factlm/runs/zeroshot/best.pt --facts facts/seed_facts.jsonl --zeroshot --retrieval \
    --only-targets groundnut_rust,tomato_early_blight --questions factlm/data/seed_test.jsonl --questions factlm/data/seed_test_ctx.jsonl
```

GPU VM (L4 24 GB), after the fact pipeline (`facts/README.md`, `bash facts/run_vm.sh all`, ~4–7 h of teacher time).
That pipeline writes `facts/facts.jsonl` (seed + extracted facts) and `facts/questions/{train,val,zeroshot}.jsonl` +
`holdout_facts.json`. Then:

```bash
bash factlm/vm_train.sh          # resumable: re-run the same command after an interruption
```

It runs two trainings:
- `runs/eval` leaves out `holdout_facts.json`. It is tested on the seed tests, the teacher `val.jsonl`, and
  `zeroshot.jsonl`, where the held-out facts are added from their text.
- `runs/ship` trains on all facts and questions, exports `runs/ship/export/factlm.{bin,json}`, evaluates the int8
  export, and runs the Java parity test if a JDK is present.

The model is small, so each run takes ~15–20 min and < 4 GB of GPU memory for ~60k question rows × 40 epochs (about
35 min in total).

Notes on the teacher data:
- `--seed-relabel oracle` lets seed questions use the new facts. For example, "what is X" maps to X's `info` facts
  when they exist, as in the teacher data.
- Teacher rows carry no `meta.intent`, so they are never relabelled.
- A target-less `requires_confirmed` fact (e.g. a herbicide dose) is allowed only when no disease is confirmed, the
  literal reading of rule 3. Python, Java and `facts_lib` agree, and the parity test checks it.

## Known risks

1. **Seed data is tiny** (540 questions, 15 diseases).
   - New facts are only learned from the fact pipeline's teacher questions (`facts/gen_questions.py`).
   - LLM-written Tamil/Kannada can be unnatural, and the LLM may write questions its answer unit does not answer.
     Spot-check about 100 rows per language before training.
2. **More WRONG answers than the old free chat** (4.8% vs 3.3%). They are mostly sibling-disease confusions
   (early/late leaf spot, tomato/chilli mosaic) and symptom descriptions answered directly instead of with `<ASK>`.
3. **Residual wrong doses** (0.6% on the context test before rule 9). They happened when a disease is confirmed and the
   farmer names another one in romanized ta/kn, which the target head missed. Rule 9 now masks doses whenever a known
   name of another disease appears; a name spelled in a way the lexicon does not know can still slip through.
4. **Zero-shot additions are weak.** Retrain whenever facts change; item ids are the output vocabulary.
5. **The policy is inherited from freechat.** Treatment is the `first` line only. Helpline and off-topic map to
   `<NOT_SURE>`. `<WHICH_CROP>` never occurs in the seed data.
6. **Two thresholds were set a priori**, because validation is too small to tune them: `min_first_prob=0.3` and
   `text_crop_min=0.5`. Re-tune them on the GPU run's validation split (`eval.py --min-first-prob/--text-crop-min`).
7. **The slot head** is weaker than TextModel in the smoke run.
8. **Speed is measured on desktop only.** Phone latency with 1–4 threads must be checked on a 2 GB device.
9. **The hash table** (2^16 rows × 160) is shared by 4 languages and romanized text, so collisions grow with teacher
   data. 2^17 rows would need a smaller row size (d≈96 plus a projection) to stay near 15 MB.
10. **Small, noisy tests.** About ±2–3 points of noise, and some held-out labels are debatable (e.g. "tikka rog se
    bachav" is labelled as naming no disease).
