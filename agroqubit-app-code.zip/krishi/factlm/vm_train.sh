#!/usr/bin/env bash
# FactLM training on a GPU VM (one NVIDIA L4 24 GB, Ubuntu, CUDA, internet), after the fact pipeline
# (facts/run_vm.sh all) has written facts/facts.jsonl and facts/questions/{train,val,zeroshot}.jsonl + holdout_facts.json.
# Resumable: if the VM stops, run the same command again (train.py continues from <run>/last.pt).
#
#   bash factlm/vm_train.sh            # eval run (held-out facts scored zero-shot) + ship run (all facts) + export + checks
#   STAGES=ship bash factlm/vm_train.sh
#
# Runs:
#   factlm/runs/eval  facts minus holdout_facts.json; tests: seed held-out, seed ctx, teacher val, teacher zero-shot
#   factlm/runs/ship  all facts; questions = seed + teacher train + teacher zero-shot rows; exported to factlm/runs/ship/export
set -euo pipefail
cd "$(dirname "$0")/.."                       # repo root
RUNS=${RUNS:-factlm/runs}
STAGES=${STAGES:-"eval ship"}
CPU=${CPU:-0}                                  # 1 = no GPU: train on the CPU threads (fewer epochs)
EPOCHS=${EPOCHS:-$([ "$CPU" = 1 ] && echo 20 || echo 40)}
WORKERS=${WORKERS:-$([ "$CPU" = 1 ] && echo 2 || echo 6)}
THREADS=${THREADS:-0}
FACTS=${FACTS:-$( [ -f facts/facts.jsonl ] && echo facts/facts.jsonl || echo facts/seed_facts.jsonl )}
TRAIN_Q=${TRAIN_Q:-"factlm/data/seed_train.jsonl facts/questions/train.jsonl"}
HOLDOUT=${HOLDOUT:-facts/questions/holdout_facts.json}
mkdir -p "$RUNS"
exec > >(tee -a "$RUNS/vm_train.log") 2>&1
echo "== $(date) FactLM VM run: FACTS=$FACTS STAGES=$STAGES"

python3 -c "import indic_transliteration" 2>/dev/null || pip install --break-system-packages -q indic_transliteration
python3 -c "import torch; print('torch', torch.__version__, 'cuda', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else '')"
[ "$CPU" = 1 ] || python3 -c "import torch, sys; sys.exit(0 if torch.cuda.is_available() else 'ERROR: no CUDA GPU visible (driver / CUDA toolkit?)')"
[ -f "$FACTS" ] || { echo "ERROR: fact table $FACTS not found"; exit 1; }
python3 factlm/facts_lib.py validate-facts "$FACTS" || echo "WARNING: invalid facts are skipped by train.py (listed above)"

q_args=(); for f in $TRAIN_Q; do if [ -f "$f" ]; then q_args+=(--questions "$f"); else echo "note: $f missing, skipped"; fi; done
t_args=(); for f in factlm/data/seed_test.jsonl factlm/data/seed_test_ctx.jsonl facts/questions/val.jsonl facts/questions/zeroshot.jsonl; do
  [ -f "$f" ] && t_args+=(--test "$f"); done
common=(--facts "$FACTS" --seed-relabel oracle --batch 256 --slot-batch 128 --fact-neg 128 --epochs "$EPOCHS" --lr 1e-3
        --bag-lr 3e-3 --warmup 1000 --workers "$WORKERS" --eval-every 1000 --aux-every 1 --resume --threads "$THREADS")

if [[ " $STAGES " == *" eval "* ]]; then
  h_args=(); [ -f "$HOLDOUT" ] && h_args=(--holdout-facts "$HOLDOUT")
  python3 factlm/train.py "${common[@]}" "${q_args[@]}" "${t_args[@]}" "${h_args[@]}" --out "$RUNS/eval" \
    || echo "WARNING: the eval run failed (see above); the ship run still runs"
fi
if [[ " $STAGES " == *" ship "* ]]; then
  s_args=("${q_args[@]}"); [ -f facts/questions/zeroshot.jsonl ] && s_args+=(--questions facts/questions/zeroshot.jsonl)
  python3 factlm/train.py "${common[@]}" "${s_args[@]}" --test factlm/data/seed_test.jsonl --test factlm/data/seed_test_ctx.jsonl \
    $( [ -f facts/questions/val.jsonl ] && echo --test facts/questions/val.jsonl ) --out "$RUNS/ship"
  python3 factlm/export.py --ckpt "$RUNS/ship/best.pt" --out "$RUNS/ship/export" --facts "$FACTS"
  e_args=(); for f in factlm/data/seed_test.jsonl factlm/data/seed_test_ctx.jsonl facts/questions/val.jsonl; do [ -f "$f" ] && e_args+=(--questions "$f"); done
  python3 factlm/eval.py --json "$RUNS/ship/export/factlm.json" --bin "$RUNS/ship/export/factlm.bin" --facts "$FACTS" "${e_args[@]}" \
    --out "$RUNS/ship/eval_int8.json" | tee "$RUNS/ship/eval_int8.txt"
  if command -v javac >/dev/null 2>&1; then
    sh android/test/factlm/run_parity.sh "$RUNS/parity" --ckpt "$RUNS/ship/best.pt" || echo "WARNING: Java parity failed"
  else
    echo "note: no JDK on the VM; run android/test/factlm/run_parity.sh elsewhere with --ckpt $RUNS/ship/best.pt"
  fi
  ls -la "$RUNS/ship/export"
fi
echo "== $(date) done. Ship: $RUNS/ship/export/factlm.bin + factlm.json (+ factlm_facts.json for display)"
