"""Fact and question tables for the fact-token model (FactLM).

Loading, schema validation (facts/SCHEMA.md), the item vocabulary (control tokens + facts), the inference constraints
shared with the Java runtime, and the seed answer oracle (what the old free chat answers with perfect understanding).

CLI:
  python3 factlm/facts_lib.py validate-facts facts/*.jsonl
  python3 factlm/facts_lib.py validate-questions --facts 'facts/*.jsonl' factlm/data/seed_train.jsonl
"""
import glob
import json
import os
import re
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)  # repo root (/home/claude/krishi)

CROPS = ["rice", "tomato", "chilli", "groundnut", "general"]
TOPICS = ["variety", "season_sowing", "seed_nursery", "land_prep", "nutrient", "irrigation", "weed", "pest", "disease",
          "natural_enemy", "pesticide_safety", "harvest_storage", "general"]
KINDS = ["first", "info", "action", "dose"]
SEED_CATS = ["first", "cultural", "biological", "chemical"]
LANGS = ["en", "hi", "ta", "kn"]
SCRIPTS = ["native", "roman", "mixed"]
REVIEW = ["seed", "auto", "human"]

END, ASK, NOT_SURE, WHICH_CROP, CONFIRM = "<END>", "<ASK>", "<NOT_SURE>", "<WHICH_CROP>", "<CONFIRM>"
CONTROLS = [END, ASK, NOT_SURE, WHICH_CROP, CONFIRM]   # item ids 0..4, in this order, in every model
STOP = set(CONTROLS)                                    # every control token ends decoding
MAX_STEPS = 6                                           # at most 6 output items
ID_RE = re.compile(r"^[a-z0-9_]+\.[a-z0-9_]+\.[a-z0-9_]+\.[0-9]+$")
TARGET_RE = re.compile(r"^[a-z0-9_]+$")


def expand(paths):
    """List of paths/globs (or one string) -> existing files, in the given order."""
    if isinstance(paths, str):
        paths = [paths]
    out = []
    for p in paths:
        hits = sorted(glob.glob(p)) if any(c in p for c in "*?[") else [p]
        for h in hits:
            if not os.path.exists(h):
                raise FileNotFoundError(h)
            if h not in out:
                out.append(h)
    return out


def read_jsonl(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        for n, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}:{n}: bad JSON: {e}")
    return rows


def write_jsonl(path, rows):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


# ----------------------------------------------------------------------------------------------- facts
def fact_errors(f):
    """Schema violations of one fact (empty list = valid)."""
    e = []
    for k in ["id", "crop", "topic", "target", "kind", "requires_confirmed", "text", "source", "order", "review"]:
        if k not in f:
            e.append(f"missing field {k}")
    if e:
        return e
    fid = f["id"]
    if not isinstance(fid, str) or not ID_RE.match(fid):
        e.append(f"bad id {fid!r}")
    else:
        p = fid.split(".")
        if p[0] != f["crop"]:
            e.append(f"id crop part {p[0]!r} != crop {f['crop']!r}")
        if p[1] != (f["target"] if f["target"] is not None else f["topic"]):
            e.append(f"id second part {p[1]!r} != target/topic")
        if p[2] not in KINDS + SEED_CATS:
            e.append(f"id kind part {p[2]!r} not in {KINDS + SEED_CATS}")
    if f["crop"] not in CROPS:
        e.append(f"crop {f['crop']!r} not in {CROPS}")
    if f["topic"] not in TOPICS:
        e.append(f"topic {f['topic']!r} not in {TOPICS}")
    if f["target"] is not None and not (isinstance(f["target"], str) and TARGET_RE.match(f["target"])):
        e.append(f"bad target {f['target']!r}")
    if f["kind"] not in KINDS:
        e.append(f"kind {f['kind']!r} not in {KINDS}")
    if not isinstance(f["requires_confirmed"], bool):
        e.append("requires_confirmed must be true/false")
    elif f["kind"] == "dose" and not f["requires_confirmed"]:
        e.append("dose facts must have requires_confirmed=true")
    t = f["text"]
    if not isinstance(t, dict):
        e.append("text must be an object")
    else:
        for L in LANGS:
            if not isinstance(t.get(L), str) or not t[L].strip():
                e.append(f"text.{L} missing/empty")
    s = f["source"]
    if not isinstance(s, dict):
        e.append("source must be an object")
    else:
        for k in ["doc", "url", "page", "quote"]:
            if k not in s:
                e.append(f"source.{k} missing")
        if not isinstance(s.get("quote"), str) or not s.get("quote", "").strip():
            e.append("source.quote must be non-empty English source text")
        if not isinstance(s.get("doc"), str) or not s.get("doc", "").strip():
            e.append("source.doc must be non-empty")
    if not isinstance(f["order"], int) or isinstance(f["order"], bool):
        e.append("order must be an int")
    if f["review"] not in REVIEW:
        e.append(f"review {f['review']!r} not in {REVIEW}")
    return e


def load_facts(paths, strict=True, log=print):
    """Load and merge fact files (later files override earlier ones on the same id). Invalid facts raise (strict) or are skipped."""
    by_id, bad = {}, 0
    for path in expand(paths):
        for n, f in enumerate(read_jsonl(path), 1):
            err = fact_errors(f)
            if err:
                msg = f"{path}:{n}: {f.get('id')}: " + "; ".join(err)
                if strict:
                    raise ValueError(msg)
                bad += 1
                log("skip invalid fact " + msg)
                continue
            if f["id"] in by_id:
                log(f"warning: fact {f['id']} redefined in {path} (later file wins)")
            by_id[f["id"]] = f
    if bad:
        log(f"{bad} invalid facts skipped")
    return sort_facts(by_id.values())


def group_key(f):
    return (f["crop"], f["target"] if f["target"] is not None else "#" + f["topic"])


def sort_facts(facts):
    return sorted(facts, key=lambda f: (group_key(f), f["order"], f["id"]))


def seed_cat(fid):
    """KB category of a seed id (first/cultural/biological/chemical); for other facts the kind part of the id."""
    return fid.split(".")[2]


# ----------------------------------------------------------------------------------------------- items
class Items:
    """Output vocabulary: CONTROLS (ids 0..4) then facts in canonical order, plus the per-item constraint metadata."""

    def __init__(self, facts, crops=None, targets=None):
        self.facts = list(facts)
        self.ids = CONTROLS + [f["id"] for f in self.facts]
        self.index = {x: i for i, x in enumerate(self.ids)}
        if len(self.index) != len(self.ids):
            raise ValueError("duplicate item ids")
        self.fact = {f["id"]: f for f in self.facts}
        n = len(self.ids)
        self.crop = [None] * len(CONTROLS) + [f["crop"] for f in self.facts]
        self.target = [None] * len(CONTROLS) + [f["target"] for f in self.facts]
        self.kind = ["control"] * len(CONTROLS) + [f["kind"] for f in self.facts]
        self.req = [False] * len(CONTROLS) + [bool(f["requires_confirmed"]) for f in self.facts]
        self.is_control = [True] * len(CONTROLS) + [False] * len(self.facts)
        # context vocabularies (index 0 = none, 1 = other/unknown)
        fc = sorted({f["crop"] for f in self.facts if f["crop"] != "general"} | set(CROPS[:4]) | set(crops or []))
        self.ctx_crops = ["<none>", "<other>"] + [c for c in fc if c != "general"]
        ft = sorted({f["target"] for f in self.facts if f["target"]} | set(targets or []))
        self.ctx_targets = ["<none>", "<other>"] + ft
        self.n = n

    def crop_index(self, crop):
        if not crop:
            return 0
        return self.ctx_crops.index(crop) if crop in self.ctx_crops else 1

    def target_index(self, target):
        if not target:
            return 0
        return self.ctx_targets.index(target) if target in self.ctx_targets else 1

    def base_mask(self, ctx_crop, ctx_target):
        """Items allowed by the context (constraints 2-3), cached per (crop, target)."""
        key = (ctx_crop or None, ctx_target or None)
        cache = self.__dict__.setdefault("_mask_cache", {})
        if key not in cache:
            ctx_crop, ctx_target = key
            ok = [True] * self.n
            for i in range(self.n):
                if self.is_control[i]:
                    continue
                if ctx_crop and self.crop[i] != "general" and self.crop[i] != ctx_crop:
                    ok[i] = False
                elif self.req[i] and self.target[i] != ctx_target:
                    ok[i] = False
            cache[key] = ok
        return cache[key]

    def allowed(self, ctx_crop, ctx_target, emitted=(), step=0):
        """Boolean list over items: the inference constraints 1-5 (facts/SCHEMA.md section 4)."""
        ok = list(self.base_mask(ctx_crop, ctx_target))
        for i in emitted:
            ok[i] = False
        if step == 0:
            ok[0] = False  # <END> is never the first item
        return ok

    def allowed_at(self, ctx_crop, ctx_target, y_idx, k):
        """Is y_idx[k] allowed at step k after y_idx[:k]? (fast check used to validate questions)"""
        i = y_idx[k]
        return self.base_mask(ctx_crop, ctx_target)[i] and i not in y_idx[:k] and not (k == 0 and i == 0)

    def meta_json(self):
        """Constraint metadata for factlm.json (read by FactLM.java)."""
        return {"ids": self.ids, "crop": self.crop, "target": self.target, "kind": self.kind, "requires_confirmed": self.req,
                "controls": CONTROLS, "stop": CONTROLS, "ctx_crops": self.ctx_crops, "ctx_targets": self.ctx_targets}


# ----------------------------------------------------------------------------------------------- questions
_LATIN = re.compile(r"[a-zA-Z]")


def detect_script(text, lang):
    """native / roman / mixed for hi/ta/kn; English is always native."""
    if lang == "en":
        return "native"
    has_latin = bool(_LATIN.search(text))
    has_native = any(ord(c) > 0x2FF and unicodedata.category(c)[0] in "LM" for c in text)
    if has_latin and has_native:
        # a few ASCII product names/abbreviations (KVK, NSKE, ml) inside native text still count as native
        latin_words = [w for w in text.split() if _LATIN.search(w)]
        if len(latin_words) <= 1 and all(w.isupper() or len(w) <= 3 for w in latin_words):
            return "native"
        return "mixed"
    if has_latin:
        return "roman"
    return "native"


def question_errors(r, items=None):
    e = []
    for k in ["q", "lang", "script", "ctx", "y", "src"]:
        if k not in r:
            e.append(f"missing field {k}")
    if e:
        return e
    if not isinstance(r["q"], str):
        e.append("q must be a string")
    if r["lang"] not in LANGS:
        e.append(f"lang {r['lang']!r} not in {LANGS}")
    if r["script"] not in SCRIPTS:
        e.append(f"script {r['script']!r} not in {SCRIPTS}")
    c = r["ctx"]
    if not isinstance(c, dict) or "crop" not in c or "target" not in c:
        e.append("ctx must be {crop, target}")
        return e
    y = r["y"]
    if not isinstance(y, list) or not y:
        return e + ["y must be a non-empty list"]
    if len(set(y)) != len(y):
        e.append("y has repeats")
    facts_part = [x for x in y if x not in STOP]
    ctrl = [k for k, x in enumerate(y) if x in STOP]
    if ctrl and ctrl[0] != len(y) - 1:
        e.append("a control token must be the last item")
    if y == [END]:
        e.append("y cannot be <END> alone")
    if len(facts_part) > MAX_STEPS:
        e.append(f"more than {MAX_STEPS} facts")
    if not ctrl and len(facts_part) < MAX_STEPS:
        e.append("y must end with a control token (<END> after facts)")
    if items is not None:
        for x in facts_part:
            if x not in items.index:
                e.append(f"unknown fact {x}")
        if not e:
            yi = [items.index[x] for x in y[:MAX_STEPS]]
            for k, x in enumerate(y[:MAX_STEPS]):
                if not items.allowed_at(c.get("crop"), c.get("target"), yi, k):
                    e.append(f"y[{k}]={x} violates the constraints for ctx {c}")
                    break
    return e


def load_questions(paths, items=None, log=print, tag_file=True):
    """Load question files; rows with errors (incl. unknown facts / constraint violations) are dropped with a summary."""
    out, drop = [], {}
    for path in expand(paths):
        for n, r in enumerate(read_jsonl(path), 1):
            err = question_errors(r, items)
            if err:
                key = re.sub(r"[^ ]*[.<][^ ]*", "X", err[0])   # group messages that differ only by ids
                drop.setdefault(key, []).append(f"{path}:{n} ({err[0]})")
                continue
            if tag_file:
                r = dict(r, _file=os.path.basename(path))
            out.append(r)
    for k, v in drop.items():
        log(f"dropped {len(v)} question rows: {k} (e.g. {v[0]})")
    return out


# ----------------------------------------------------------------------------------------------- seed oracle
SC_INTENTS = ["treatment", "dose", "prevention", "organic", "disease_info"]
INTENTS = SC_INTENTS + ["diagnose", "helpline", "out_of_scope_known", "off_topic"]


def by_target(facts):
    out = {}
    for f in sort_facts(facts):
        if f["target"]:
            out.setdefault(f["target"], []).append(f)
    return out


def target_crop(target, facts_by_target, app_crops=None):
    if target in facts_by_target:
        return facts_by_target[target][0]["crop"]
    if app_crops and target in app_crops:
        return app_crops[target]
    return target.split("_")[0] if target else None


def oracle(intent, disease, ctx, facts_by_target, app_crops=None):
    """The answer the old free chat (freechat/freechat.py) gives when it understands the question perfectly.

    intent: one of INTENTS; disease: the disease named in the question (or None); ctx: {"crop", "target"} where
    target is the CONFIRMED disease. Extra rule (no freechat equivalent): a named disease of another crop than
    ctx.crop -> <WHICH_CROP>, because its facts are masked."""
    ctx_crop, ctx_target = (ctx or {}).get("crop"), (ctx or {}).get("target")
    if intent in ("off_topic", "out_of_scope_known", "helpline"):
        return [NOT_SURE]
    D = disease or ctx_target                     # freechat: known_disease fills in when the text names no disease
    if intent == "diagnose" or D is None or not facts_by_target.get(D):
        return [ASK]                              # symptom talk / nothing named / no verified card -> diagnosis first
    F = facts_by_target[D]
    if ctx_crop and target_crop(D, facts_by_target, app_crops) not in (ctx_crop, "general"):
        return [WHICH_CROP]
    if intent == "dose":
        if ctx_target != D:
            return [CONFIRM]                      # doses only after the farmer confirms the disease
        sel = [f for f in F if f["kind"] == "dose"]
    elif intent == "organic":                     # biological + cultural (seed order puts biological first)
        sel = [f for f in F if not f["requires_confirmed"] and f["kind"] == "action"]
    elif intent == "prevention":
        sel = [f for f in F if not f["requires_confirmed"] and f["kind"] == "action" and seed_cat(f["id"]) in ("cultural", "action")]
    elif intent == "disease_info":                # info facts if the table has them (fact pipeline), else the first line
        sel = [f for f in F if f["kind"] == "info"] or [f for f in F if f["kind"] == "first"]
    else:                                         # treatment: the card's first-step line
        sel = [f for f in F if f["kind"] == "first"]
    if not sel:
        return [NOT_SURE]                         # empty section of the card -> KVK / KCC
    ids = [f["id"] for f in sel[:MAX_STEPS]]
    return ids + ([END] if len(ids) < MAX_STEPS else [])


# ----------------------------------------------------------------------------------------------- CLI
def _main(argv):
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("validate-facts")
    a.add_argument("files", nargs="+")
    b = sub.add_parser("validate-questions")
    b.add_argument("--facts", action="append", help="fact file or glob (repeatable); default facts/*.jsonl")
    b.add_argument("files", nargs="+")
    args = ap.parse_args(argv)
    if args.cmd == "validate-facts":
        bad = 0
        for p in expand(args.files):
            for n, f in enumerate(read_jsonl(p), 1):
                err = fact_errors(f)
                if err:
                    bad += 1
                    print(f"{p}:{n}: {f.get('id')}: " + "; ".join(err))
        facts = load_facts(args.files, strict=False, log=lambda m: None)
        print(f"{len(facts)} valid facts, {bad} invalid; crops {sorted({f['crop'] for f in facts})}; "
              f"kinds {sorted({f['kind'] for f in facts})}")
        return 1 if bad else 0
    facts = load_facts(args.facts or [os.path.join(ROOT, "facts", "*.jsonl")], strict=False)
    items = Items(facts)
    bad = 0
    for p in expand(args.files):
        for n, r in enumerate(read_jsonl(p), 1):
            err = question_errors(r, items)
            if err:
                bad += 1
                if bad <= 50:
                    print(f"{p}:{n}: " + "; ".join(err))
    print(f"{bad} invalid question rows")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
