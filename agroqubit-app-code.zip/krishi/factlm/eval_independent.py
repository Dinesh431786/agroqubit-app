"""Independent test of the fact-token model: 160 farmer questions written by hand (not by the teacher model that wrote the
training questions), in Hindi, Tamil, Kannada and English, native script and casual romanized. Labels are topic-level
(crop, allowed topics, pest/disease) plus the expected control token, so they do not depend on fact ids.

A question that expects facts is CORRECT when the model answers with facts, the first fact has the right crop (or is
'general'), one of the allowed topics and, if labelled, the right pest/disease, and no fact is about another crop.
If the fact bank has NO fact for that crop/topic/target, the right answer is <NOT_SURE> (KVK / Kisan Call Centre) -
those rows are scored against <NOT_SURE> and reported separately as 'not covered by the bank'.
A control question is correct when no fact is given and the control token matches.
Usage: python3 factlm/eval_independent.py <factlm.json> <factlm.bin> <facts.jsonl> [test.jsonl] [out.json]"""
import json, os, sys
from collections import Counter, defaultdict
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, "..", "android", "tools"))
import torch
from export import load_exported


def main():
    js, bn, fp = sys.argv[1:4]
    test = sys.argv[4] if len(sys.argv) > 4 else os.path.join(HERE, "data", "test_independent.jsonl")
    out = sys.argv[5] if len(sys.argv) > 5 else None
    model, _ = load_exported(js, bn)
    F = {f["id"]: f for f in (json.loads(l) for l in open(fp, encoding="utf-8"))}
    rows = [json.loads(l) for l in open(test, encoding="utf-8")]
    res = []
    for r in rows:
        with torch.no_grad():
            g = model.generate(model.make_batch([r["q"]], crops=[None], targets=[None]))[0]
        items = g["items"]; facts = [i for i in items if not i.startswith("<") and i in F]
        ctl = items[-1] if items and items[-1].startswith("<") else None
        expect = r["expect"]; covered = None
        if expect == "facts":
            covered = any((r["crop"] is None or f["crop"] in (r["crop"], "general")) and f["topic"] in r["topics"]
                          and (r["target"] is None or f.get("target") == r["target"]) for f in F.values())
            if not covered: expect = "<NOT_SURE>"
        if expect == "facts":
            f0 = F[facts[0]] if facts else None
            ok = bool(facts) and (r["crop"] is None or f0["crop"] in (r["crop"], "general")) and f0["topic"] in r["topics"] \
                and (r["target"] is None or f0.get("target") == r["target"]) \
                and all(r["crop"] is None or F[x]["crop"] in (r["crop"], "general") for x in facts)
            on_topic_any = any(F[x]["topic"] in r["topics"] and (r["target"] is None or F[x].get("target") == r["target"]) for x in facts)
        else:
            ok = not facts and ctl == expect; on_topic_any = None
        wrong_crop = any(r["crop"] is not None and F[x]["crop"] not in (r["crop"], "general") for x in facts)
        wrong_dose = any(F[x]["kind"] == "dose" and (r["target"] is None or F[x].get("target") != r["target"]) for x in facts)
        res.append({**r, "expect_scored": expect, "covered": covered, "items": items, "ok": ok, "on_topic_any": on_topic_any,
                    "wrong_crop": wrong_crop, "wrong_dose": wrong_dose,
                    "first": (F[facts[0]]["text"]["en"] if facts else None)})

    def summ(rs):
        n = len(rs)
        return {"n": n, "correct": round(sum(x["ok"] for x in rs) / max(1, n), 3), "wrong_crop": sum(x["wrong_crop"] for x in rs),
                "wrong_dose": sum(x["wrong_dose"] for x in rs)}
    rep = {"all": summ(res), "covered_fact_questions": summ([x for x in res if x["expect_scored"] == "facts"]),
           "not_covered_by_bank": summ([x for x in res if x["covered"] is False]),
           "controls": summ([x for x in res if x["expect"] != "facts"]),
           "by_lang": {L: summ([x for x in res if x["lang"] == L]) for L in ["hi", "ta", "kn", "en"]},
           "by_script": {s: summ([x for x in res if x["script"] == s]) for s in ["native", "roman"]},
           "by_expect": {e: summ([x for x in res if x["expect_scored"] == e]) for e in sorted({x["expect_scored"] for x in res})},
           "outputs": dict(Counter((x["items"][-1] if x["items"] and x["items"][-1].startswith("<") and len(x["items"]) == 1 else "facts") for x in res)),
           "failures": [{k: x[k] for k in ("lang", "script", "q", "expect_scored", "items", "first")} for x in res if not x["ok"]][:60]}
    print(json.dumps({k: v for k, v in rep.items() if k != "failures"}, ensure_ascii=False, indent=1))
    if out: json.dump({"report": rep, "rows": res}, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
