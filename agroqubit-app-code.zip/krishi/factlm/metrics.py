"""Metrics for FactLM answers (used by train.py for validation and by eval.py).

Per question: gold y vs predicted items (both end at a control token).
  first     predicted first item == gold first item
  exact     predicted item set == gold item set (<END> ignored)
  P/R/F1    item sets (<END> ignored), micro-averaged
  wrong_crop    a predicted fact of another crop than the question's crop (ctx crop, else the gold facts' crop, else meta crop)
  wrong_target  a predicted targeted fact of another disease/pest than the gold one (gold facts' target, else the named
                disease, else the confirmed ctx target)
  WRONG_DOSE    a predicted dose fact whose target != gold target (gold facts' target, else the named disease, else ctx target)
  control       among questions whose gold answer is a control token: predicted first item == that token
The free-chat style judgement (correct / safe_fallback / WRONG / wrongly_refused) mirrors freechat/eval_freechat.py.
"""
from collections import Counter, defaultdict

import torch

import facts_lib as FL

SC = set(FL.SC_INTENTS)


def predict(model, rows, batch=128, beam=0):
    """Greedy (or beam) answers + target-head prediction for question rows."""
    model.eval()
    out = []
    for i in range(0, len(rows), batch):
        chunk = rows[i:i + batch]
        crops = [r["ctx"].get("crop") for r in chunk]
        targets = [r["ctx"].get("target") for r in chunk]
        bt = model.make_batch([r["q"] for r in chunk], crops=crops, targets=targets)
        if beam and beam > 1:
            res = [model.beam(r["q"], c, t, k=beam) for r, c, t in zip(chunk, crops, targets)]
        else:
            res = model.generate(bt)
        _, tdist = model.heads(bt)
        tp, ti = tdist.max(-1)
        for x, p, k in zip(res, tp.tolist(), ti.tolist()):
            x["target_pred"] = model.meta["ctx_targets"][k] if k >= 2 else None
            x["target_prob"] = p
        out += res
    return out


class ItemInfo:
    def __init__(self, facts):
        self.f = {f["id"]: f for f in facts}

    def crop(self, x):
        return self.f[x]["crop"] if x in self.f else None

    def target(self, x):
        return self.f[x]["target"] if x in self.f else None

    def kind(self, x):
        return self.f[x]["kind"] if x in self.f else "control"


def gold_crop(r, info):
    if r["ctx"].get("crop"):
        return r["ctx"]["crop"]
    cs = {info.crop(x) for x in r["y"] if x not in FL.STOP} - {"general", None}
    if len(cs) == 1:
        return cs.pop()
    m = r.get("meta") or {}
    return m.get("crop")


def gold_target(r, info):
    ts = [info.target(x) for x in r["y"] if x not in FL.STOP and info.target(x)]
    if ts:
        return ts[0]
    m = r.get("meta") or {}
    return m.get("target") or r["ctx"].get("target")


def row_scores(r, p, info):
    gold, pred = r["y"][:FL.MAX_STEPS + 1], p["items"]
    gs, ps = set(gold) - {FL.END}, set(pred) - {FL.END}
    pf = [x for x in pred if x not in FL.STOP]
    gc, gt = gold_crop(r, info), gold_target(r, info)
    gt_targets = {info.target(x) for x in gold if x not in FL.STOP} | ({gt} if gt else set())   # right disease, other section: not wrong
    s = {"first": float(bool(pred) and pred[0] == gold[0]), "exact": float(gs == ps),
         "tp": len(gs & ps), "np": len(ps), "ng": len(gs),
         "wrong_crop": float(gc is not None and any(info.crop(x) not in (gc, "general") for x in pf)),
         "crop_known": float(gc is not None),
         "wrong_target": float(any(info.target(x) and info.target(x) not in gt_targets for x in pf)),
         "wrong_dose": float(any(info.kind(x) == "dose" and info.target(x) != gt for x in pf)),
         "gold_control": float(gold[0] in FL.STOP), "control_ok": float(gold[0] in FL.STOP and bool(pred) and pred[0] == gold[0])}
    return s


def judge(r, p, info):
    """Free-chat style outcome (freechat/eval_freechat.py), using gold y plus meta intent/target."""
    m = r.get("meta") or {}
    intent, D = m.get("intent"), m.get("target")
    gold, pred = r["y"], p["items"]
    gs, ps = set(gold) - {FL.END}, set(pred) - {FL.END}
    if gs == ps:
        if gold == [FL.CONFIRM] and "target_pred" in p and D:
            return "correct" if p["target_pred"] == D else "safe_fallback"   # confirm the right disease
        return "correct"
    pf = [x for x in pred if x not in FL.STOP]
    if pf:
        ok_t = {info.target(x) for x in gold if x not in FL.STOP}
        if intent in SC and D:
            ok_t.add(D)
        return "safe_fallback" if all(info.target(x) in ok_t for x in pf) else "WRONG"
    if pred and pred[0] == FL.NOT_SURE:
        return "wrongly_refused"
    return "safe_fallback"


def summarize(rows, preds, facts, by=("lang", "script")):
    info = ItemInfo(facts)
    S = [row_scores(r, p, info) for r, p in zip(rows, preds)]

    def agg(idx):
        if not idx:
            return {}
        n = len(idx)
        tp = sum(S[i]["tp"] for i in idx)
        npred = sum(S[i]["np"] for i in idx)
        ng = sum(S[i]["ng"] for i in idx)
        P, R = tp / max(npred, 1), tp / max(ng, 1)
        ck = sum(S[i]["crop_known"] for i in idx)
        gcn = sum(S[i]["gold_control"] for i in idx)
        return {"n": n, "first": round(sum(S[i]["first"] for i in idx) / n, 4), "exact": round(sum(S[i]["exact"] for i in idx) / n, 4),
                "P": round(P, 4), "R": round(R, 4), "F1": round(2 * P * R / max(P + R, 1e-9), 4),
                "wrong_crop": round(sum(S[i]["wrong_crop"] for i in idx) / max(ck, 1), 4),
                "wrong_target": round(sum(S[i]["wrong_target"] for i in idx) / n, 4),
                "WRONG_DOSE": round(sum(S[i]["wrong_dose"] for i in idx) / n, 4),
                "wrong_dose_n": int(sum(S[i]["wrong_dose"] for i in idx)),
                "control_acc": round(sum(S[i]["control_ok"] for i in idx) / gcn, 4) if gcn else None}

    out = {"all": agg(list(range(len(rows))))}
    for key in by:
        g = defaultdict(list)
        for i, r in enumerate(rows):
            g[r.get(key)].append(i)
        out["by_" + key] = {str(k): agg(v) for k, v in sorted(g.items(), key=lambda kv: str(kv[0]))}
    # control-token confusion (gold first item -> predicted first item)
    conf = defaultdict(Counter)
    for r, p in zip(rows, preds):
        g = r["y"][0] if r["y"][0] in FL.STOP else "fact"
        q = (p["items"][0] if p["items"] and p["items"][0] in FL.STOP else "fact") if p["items"] else "none"
        conf[g][q] += 1
    out["first_type_confusion"] = {k: dict(v) for k, v in conf.items()}
    if any((r.get("meta") or {}).get("intent") for r in rows):
        J = Counter(judge(r, p, info) for r, p in zip(rows, preds) if (r.get("meta") or {}).get("intent"))
        n = sum(J.values())
        out["freechat_style"] = {k: round(J.get(k, 0) / n, 4) for k in ["correct", "safe_fallback", "WRONG", "wrongly_refused"]}
        out["freechat_style"]["n"] = n
        out["freechat_style"]["wrong_dose_answers"] = sum(
            1 for r, p in zip(rows, preds) if (r.get("meta") or {}).get("intent") and judge(r, p, info) == "WRONG"
            and any(info.kind(x) == "dose" for x in p["items"]))
    return out


def selection_score(m):
    """Validation score for checkpoint selection (higher is better)."""
    a = m["all"]
    return 0.5 * a["exact"] + 0.5 * a["first"] - a["wrong_target"] - 5 * a["WRONG_DOSE"]


def slot_metrics(probs, Y, threshold=0.5):
    """probs, Y: [N, S] tensors. Single-slot top-1, exact set at threshold, macro F1."""
    pred = probs >= threshold
    none = ~pred.any(1)
    pred[none, probs[none].argmax(1)] = True
    Yb = Y > 0
    single = Yb.sum(1) == 1
    top1 = (probs[single].argmax(1) == Yb[single].float().argmax(1)).float().mean().item() if single.any() else float("nan")
    tp = (pred & Yb).sum(0).float()
    fp = (pred & ~Yb).sum(0).float()
    fn = (~pred & Yb).sum(0).float()
    f1 = (2 * tp / (2 * tp + fp + fn).clamp(min=1)).mean().item()
    return {"single_top1": round(top1, 4), "exact_set": round((pred == Yb).all(1).float().mean().item(), 4), "macro_f1": round(f1, 4)}
