"""Run the OLD free chat (freechat/freechat.py: intent + disease classifier -> verified card) on a questions file and
convert its answers into FactLM item sequences, so both systems are scored by the same metrics (eval.py --baseline).

Mapping (with the old model's predicted intent and disease): start_diagnosis / clarify -> <ASK>; confirm_disease ->
<CONFIRM> (+ its disease as target_pred); every other action -> facts_lib.oracle(intent, disease), i.e. exactly the
card section the old answer read out. Also prints the old judgement of freechat/eval_freechat.py for reference.
Needs the old local models (text/enc_AL_0.pt, enc_DL_0.pt, freechat/free_intent.pt) and the knowledge base.

  python3 factlm/compare_freechat.py --questions factlm/data/seed_test.jsonl --out factlm/results/freechat_preds_seed_test.json
"""
import argparse
import json
import os
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import facts_lib as FL  # noqa: E402

ROOT = FL.ROOT


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--questions", default=os.path.join(HERE, "data", "seed_test.jsonl"))
    ap.add_argument("--out", default=os.path.join(HERE, "results", "freechat_preds_seed_test.json"))
    a = ap.parse_args()
    sys.path.insert(0, os.path.join(ROOT, "freechat"))
    os.chdir(os.path.join(ROOT, "freechat"))
    from freechat import FreeChat
    fc = FreeChat()
    facts = FL.load_facts(os.path.join(ROOT, "facts", "seed_facts.jsonl"))
    bt = FL.by_target(facts)
    app = json.load(open(os.path.join(HERE, "assets", "app_diseases.json")))
    rows = FL.load_questions(a.questions)
    preds, old = [], Counter()
    SC = {"treatment", "dose", "prevention", "organic", "disease_info"}
    for r in rows:
        ans = fc.answer(r["q"], r["lang"])
        act, dis, intent = ans["action"], ans["disease"], ans["intent"]
        if act in ("start_diagnosis", "clarify"):
            y = [FL.ASK]
        elif act == "confirm_disease":
            y = [FL.CONFIRM]
        else:
            y = FL.oracle(intent, dis, r["ctx"], bt, app)
        preds.append({"q": r["q"], "items": y, "target_pred": dis, "old_action": act})
        # the old judgement (freechat/eval_freechat.py) for reference
        m = r.get("meta") or {}
        gi, gd = m.get("intent"), m.get("target")
        if act.startswith("answer_"):
            ok = gi in SC and dis == gd and act == "answer_" + gi
            k = "correct_answer" if ok else ("safe_fallback" if gi in SC and dis == gd else "WRONG_answer")
        elif act == "confirm_disease":
            k = "correct_answer" if gi == "dose" and dis == gd else "safe_fallback"
        elif act in ("refer_kcc", "off_topic"):
            k = "correct_answer" if gi in ("out_of_scope_known", "off_topic") else ("safe_fallback" if gi == "helpline" else "wrongly_refused")
        elif act == "helpline":
            k = "correct_answer" if gi == "helpline" else "safe_fallback"
        else:
            k = "correct_answer" if gi == "diagnose" or (gi in SC and not gd) else "safe_fallback"
        old[k] += 1
    n = len(rows)
    print("old judgement (eval_freechat.py):", {k: round(v / n, 3) for k, v in old.items()}, "n", n)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump({"name": "old freechat (freechat/freechat.py)", "old_judgement": {k: round(v / n, 4) for k, v in old.items()},
               "predictions": preds}, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=0)
    print("wrote", a.out)


if __name__ == "__main__":
    main()
