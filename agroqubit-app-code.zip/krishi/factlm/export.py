"""Export a FactLM checkpoint for the phone.

  factlm.bin   KRW1 (android/tools/krw.py): int8 rows for the hashed bag table and every matrix (attention, FFN, item
               embeddings); fp32 for LayerNorms, biases, positions, context embeddings and the small slot/target heads.
  factlm.json  dims, NB, item ids, control tokens, ctx crop/target vocabularies and the constraint metadata read by
               android/src/in/krishi/doctor/FactLM.java.
  factlm_facts.json (optional, --facts) fact texts + sources for display, keyed by id.

  python3 factlm/export.py --ckpt factlm/runs/seed/best.pt --out factlm/export
  python3 factlm/export.py --ckpt best.pt --add-facts facts/new_facts.jsonl --out ...   # append new facts zero-shot
"""
import argparse
import json
import os
import sys

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "android", "tools"))
import facts_lib as FL  # noqa: E402
from krw import f32, q8, read_krw1, write_krw1  # noqa: E402
from model import FactLM, load_checkpoint  # noqa: E402

FORMAT = "factlm-1"


def tensor_names(cfg):
    """(KRW1 name, state_dict key, int8?) for every exported tensor, in file order."""
    out = [("bag", "bag.weight", True), ("pos", "pos.weight", False), ("ctx_crop", "ctx_crop.weight", False),
           ("ctx_target", "ctx_target.weight", False)]
    for l in range(cfg["enc_layers"]):
        p, s = f"enc.{l}.", f"enc.{l}."
        out += [(p + "ln1.g", s + "ln1.weight", False), (p + "ln1.b", s + "ln1.bias", False)]
        for n in "qkvo":
            out += [(p + f"att.{n}.W", s + f"att.{n}.weight", True), (p + f"att.{n}.b", s + f"att.{n}.bias", False)]
        out += [(p + "ln2.g", s + "ln2.weight", False), (p + "ln2.b", s + "ln2.bias", False),
                (p + "fc1.W", s + "ffn.fc1.weight", True), (p + "fc1.b", s + "ffn.fc1.bias", False),
                (p + "fc2.W", s + "ffn.fc2.weight", True), (p + "fc2.b", s + "ffn.fc2.bias", False)]
    out += [("enc.ln.g", "enc_ln.weight", False), ("enc.ln.b", "enc_ln.bias", False),
            ("slot.W", "slot_head.weight", False), ("slot.b", "slot_head.bias", False),
            ("target.W", "target_head.weight", False), ("target.b", "target_head.bias", False),
            ("dec.bos", "bos", False), ("dec.step", "step.weight", False)]
    for l in range(cfg["dec_layers"]):
        p, s = f"dec.{l}.", f"dec.{l}."
        for ln in ("ln1", "ln2", "ln3"):
            out += [(p + ln + ".g", s + ln + ".weight", False), (p + ln + ".b", s + ln + ".bias", False)]
        for blk, mod in (("self", "self_att"), ("cross", "cross")):
            for n in "qkvo":
                out += [(p + f"{blk}.{n}.W", s + f"{mod}.{n}.weight", True), (p + f"{blk}.{n}.b", s + f"{mod}.{n}.bias", False)]
        out += [(p + "fc1.W", s + "ffn.fc1.weight", True), (p + "fc1.b", s + "ffn.fc1.bias", False),
                (p + "fc2.W", s + "ffn.fc2.weight", True), (p + "fc2.b", s + "ffn.fc2.bias", False)]
    out += [("dec.ln.g", "dec_ln.weight", False), ("dec.ln.b", "dec_ln.bias", False),
            ("items.E", "items_E", True), ("items.b", "items_b", False)]
    return out


def name_lexicon(model):
    """target -> normalised names (all languages + English) that belong to exactly ONE ctx target and have >= 4
    characters, from factlm/assets/disease_names.json (+ facts/target_names.json for pests). Used by the dose guard."""
    from text_features import normalise
    here = os.path.dirname(os.path.abspath(__file__)); src = {}
    for p in [os.path.join(here, "assets", "disease_names.json"), os.path.join(os.path.dirname(here), "facts", "target_names.json")]:
        if os.path.exists(p):
            for t, langs in json.load(open(p, encoding="utf-8")).items():
                for L, v in langs.items():
                    if L in ("hi", "ta", "kn", "en"):
                        for n in (v if isinstance(v, list) else [v]): src.setdefault(t, set()).add(normalise(n))
    targets = [t for t in model.meta["ctx_targets"][2:]]
    owner = {}
    for t in targets:
        for n in src.get(t, ()):
            if len(n) >= 4: owner.setdefault(n, set()).add(t)
    return {t: sorted(n for n in src.get(t, ()) if len(n) >= 4 and owner.get(n) == {t}) for t in targets if src.get(t)}


def config_json(model, extra=None):
    m = model.meta
    j = {"format": FORMAT, "cfg": dict({k: model.cfg[k] for k in ["d", "heads", "ffn", "enc_layers", "dec_layers", "nb", "max_words", "max_steps", "n_slots"]},
                                       dose_gate=bool(model.cfg.get("dose_gate", True)),
                                       min_first_prob=float(model.cfg.get("min_first_prob", 0.0) or 0.0),
                                       text_crop_min=float(model.cfg.get("text_crop_min", 0.0) or 0.0)),
         "features": {"normalise": "TextModel.normalise", "word_ids": "W+word, char 2-4-grams of <word>, CRC32 % nb",
                      "truncate": {"head": model.cfg["max_words"] // 2, "tail": model.cfg["max_words"] - model.cfg["max_words"] // 2}},
         "layer_norm_eps": 1e-5, "gelu": "erf",
         "items": {"ids": m["ids"], "crop": m["crop"], "target": m["target"], "kind": m["kind"], "requires_confirmed": m["requires_confirmed"]},
         "controls": FL.CONTROLS, "stop": FL.CONTROLS, "ctx_crops": m["ctx_crops"], "ctx_targets": m["ctx_targets"],
         "target_crop": m.get("target_crop"), "slots": model.slot_names,
         "constraints": ["no repeats", "ctx.crop known -> facts of other crops masked (general allowed)",
                         "requires_confirmed facts masked unless fact.target == ctx.target",
                         "dose gate: requires_confirmed facts masked when the target head's top target is a real target != ctx.target",
                         "<END> not first",
                         "text crop: no ctx crop and slot head crop_X >= text_crop_min -> mask as if ctx crop were X",
                         "step 0: a fact with probability < min_first_prob is replaced by <ASK>",
                         "name guard: ctx target set and the text names (name_lexicon, whole words) only OTHER targets -> requires_confirmed facts masked",
                         "stop at any control token or after max_steps items", "greedy"]}
    j["name_lexicon"] = model.meta.get("name_lexicon") or name_lexicon(model)
    j.update(extra or {})
    return j


def export(model, out_dir, name="factlm", facts=None, extra=None):
    os.makedirs(out_dir, exist_ok=True)
    sd = {k: v.detach().float().cpu().numpy() for k, v in model.state_dict().items()}
    T = {}
    for kname, key, quant in tensor_names(model.cfg):
        a = sd[key]
        T[kname] = q8(a) if quant else f32(a)
    bin_path, json_path = os.path.join(out_dir, name + ".bin"), os.path.join(out_dir, name + ".json")
    write_krw1(bin_path, T)
    json.dump(config_json(model, extra), open(json_path, "w", encoding="utf-8"), ensure_ascii=False)
    if facts:
        keep = {x for x in model.meta["ids"]}
        disp = {f["id"]: {"text": f["text"], "source": f["source"], "kind": f["kind"], "crop": f["crop"], "target": f["target"],
                          "review": f["review"]} for f in facts if f["id"] in keep}
        json.dump(disp, open(os.path.join(out_dir, name + "_facts.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=0)
    return bin_path, json_path


def load_exported(json_path, bin_path, device="cpu"):
    """Rebuild a PyTorch FactLM from factlm.json + factlm.bin (int8 tensors dequantised) - the reference for Java parity."""
    j = json.load(open(json_path, encoding="utf-8"))
    cfg = dict(j["cfg"], dropout=0.0)
    meta = dict(j["items"], ctx_crops=j["ctx_crops"], ctx_targets=j["ctx_targets"])
    meta["ids"] = list(meta["ids"])
    meta["app_crops"] = {t: c for t, c in zip(j["ctx_targets"], j.get("target_crop") or []) if c}
    meta["name_lexicon"] = j.get("name_lexicon") or {}
    model = FactLM(cfg, meta, j["slots"])
    W = read_krw1(bin_path)
    sd = model.state_dict()
    for kname, key, _ in tensor_names(cfg):
        sd[key] = torch.tensor(np.asarray(W[kname]).reshape(sd[key].shape))
    model.load_state_dict(sd)
    return model.to(device).eval(), j


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--out", default=os.path.join(HERE, "export"))
    ap.add_argument("--name", default="factlm")
    ap.add_argument("--facts", action="append", help="fact files for factlm_facts.json (default facts/*.jsonl)")
    ap.add_argument("--add-facts", action="append", default=[], help="append facts missing from the model zero-shot")
    ap.add_argument("--min-first-prob", type=float, help="override the model's confidence fallback (0 = off)")
    ap.add_argument("--text-crop-min", type=float, help="override the text-crop mask threshold (0 = off)")
    ap.add_argument("--no-dose-gate", action="store_true")
    a = ap.parse_args()
    model, ck = load_checkpoint(a.ckpt)
    if a.min_first_prob is not None:
        model.cfg["min_first_prob"] = a.min_first_prob
    if a.text_crop_min is not None:
        model.cfg["text_crop_min"] = a.text_crop_min
    if a.no_dose_gate:
        model.cfg["dose_gate"] = False
    facts = FL.load_facts(a.facts or [os.path.join(FL.ROOT, "facts", "*.jsonl")], strict=False)
    if a.add_facts:
        new = [f for f in FL.load_facts(a.add_facts, strict=True) if f["id"] not in set(model.meta["ids"])]
        model.add_items(new)
        facts += new
        print(f"appended {len(new)} facts zero-shot")
    thr = ((ck.get("val") or {}).get("slots") or {}).get("threshold", 0.5)
    b, j = export(model, a.out, a.name, facts, {"slot_threshold": thr, "trained_step": ck.get("step")})
    print(f"wrote {b} ({os.path.getsize(b) / 1e6:.2f} MB) and {j}; {len(model.meta['ids'])} items")


if __name__ == "__main__":
    main()
