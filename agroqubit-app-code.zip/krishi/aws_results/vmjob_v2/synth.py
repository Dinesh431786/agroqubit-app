import ctypes, numpy as np, espeakng_loader
from scipy.signal import resample_poly
LIB = ctypes.cdll.LoadLibrary(espeakng_loader.get_library_path()); _b = []
CB = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.POINTER(ctypes.c_short), ctypes.c_int, ctypes.c_void_p)
@CB
def _cb(w, n, e):
    if n > 0: _b.append(np.ctypeslib.as_array(w, shape=(n,)).copy())
    return 0
SR = LIB.espeak_Initialize(1, 500, espeakng_loader.get_data_path().encode(), 0); LIB.espeak_SetSynthCallback(_cb)
V = {"hi": "hi", "ta": "ta", "kn": "kn", "en": "en-us"}
def say(t, l, v, rate, pitch):
    _b.clear(); LIB.espeak_SetVoiceByName((V[l] + "+" + v).encode()); LIB.espeak_SetParameter(1, int(rate), 0); LIB.espeak_SetParameter(3, int(pitch), 0)
    b = t.encode() + b"\0"; LIB.espeak_Synth(ctypes.c_char_p(b), len(b), 0, 1, 0, 1, None, None); LIB.espeak_Synchronize()
    x = np.concatenate(_b).astype(np.float32) / 32768 if _b else np.zeros(1600, np.float32); return resample_poly(x, 16000, SR).astype(np.float32)
LIB.espeak_TextToPhonemes.restype = ctypes.c_char_p; LIB.espeak_TextToPhonemes.argtypes = [ctypes.POINTER(ctypes.c_char_p), ctypes.c_int, ctypes.c_int]
def phonemes(t, l):
    LIB.espeak_SetVoiceByName(V[l].encode()); p = ctypes.pointer(ctypes.c_char_p(t.encode())); o = []
    while p.contents.value:
        r = LIB.espeak_TextToPhonemes(p, 1, 2)
        if not r: break
        o.append(r.decode("utf-8", "ignore"))
    return " ".join(o)
