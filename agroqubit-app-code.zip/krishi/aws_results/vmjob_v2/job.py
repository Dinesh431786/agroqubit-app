"""Self-contained AWS job. Real speech (Google FLEURS, hi/ta/kn/en) vs synthetic speech for our phoneme recogniser.
Model A: synthetic only (our current recipe). Model B: synthetic + real. Both tested on REAL held-out voices."""
import os, sys, io, json, time, re, random, tarfile, csv, traceback, numpy as np, torch, torch.nn.functional as F
T0 = time.time(); W = os.environ.get("WORK", "/opt/work"); OUT = f"{W}/out"; os.makedirs(OUT, exist_ok=True); sys.path.insert(0, W)
DRY = os.environ.get("DRY") == "1"; N_TR = int(os.environ.get("N_TRAIN", "1000")); N_TE = int(os.environ.get("N_TEST", "200")); MIN = float(os.environ.get("TRAIN_MIN", "45"))
from speechenc import SpeechEncoder, logmel, HOP
from synth import say, phonemes
torch.set_num_threads(os.cpu_count() or 4); random.seed(0); np.random.seed(0); torch.manual_seed(0)
LOG = open(f"{OUT}/job.log", "a"); R = {"status": "running"}
def log(*a):
    s = f"[{(time.time()-T0)/60:6.1f}m] " + " ".join(map(str, a)); print(s, flush=True); LOG.write(s + "\n"); LOG.flush()
def save(): json.dump(R, open(f"{OUT}/results.json", "w"), indent=1, ensure_ascii=False)
LANGS = {"hi": "hi_in", "ta": "ta_in", "kn": "kn_in", "en": "en_us"}
TRV = "m1 m2 m4 m5 m7 f1 f3 f5 Andy Annie belinda benjamin caleb david ed grandpa iven john linda max paul rob steph travis klatt klatt3".split()
TEV = "m3 m6 m8 f2 f4 aunty grandma adam anika edward ian victor klatt2".split()
clean = lambda p: re.sub(r"[ˈˌ]", "", p)
def per(h, r):
    h, r = h.replace(" ", ""), r.replace(" ", ""); d = np.arange(len(h) + 1)
    for i in range(1, len(r) + 1):
        pv, d[0] = d.copy(), i
        for j in range(1, len(h) + 1): d[j] = min(pv[j] + 1, d[j-1] + 1, pv[j-1] + (r[i-1] != h[j-1]))
    return d[-1] / max(len(r), 1)
def fleurs(code):
    from huggingface_hub import HfApi, hf_hub_download; import soundfile as sf
    files = HfApi().list_repo_files("google/fleurs", repo_type="dataset"); mine = [f for f in files if f"/{code}/" in f]
    log(code, "files", mine[:8]); out = {}
    for sp, n in [("train", N_TR), ("test", N_TE)]:
        tsv = next(f for f in mine if f.endswith(f"/{sp}.tsv")); tar = next(f for f in mine if f.endswith(f"/{sp}.tar.gz"))
        meta = {r[1]: r[2] for r in csv.reader(open(hf_hub_download("google/fleurs", tsv, repo_type="dataset"), encoding="utf-8"), delimiter="\t", quoting=csv.QUOTE_NONE) if len(r) > 2}
        items = []
        with tarfile.open(hf_hub_download("google/fleurs", tar, repo_type="dataset")) as tf:
            for m in tf:
                b = os.path.basename(m.name)
                if m.isfile() and b in meta:
                    x, sr = sf.read(io.BytesIO(tf.extractfile(m).read()), dtype="float32")
                    if x.ndim > 1: x = x.mean(1)
                    if sr != 16000:
                        from scipy.signal import resample_poly; x = resample_poly(x, 16000, sr).astype(np.float32)
                    if len(x) <= 16000 * 12: items.append((x, meta[b]))
                    if len(items) >= n: break
        out[sp] = items; log(code, sp, len(items), f"{sum(len(a) for a,_ in items)/16000/3600:.2f}h")
    return out
def fake(code):
    l = [k for k, v in LANGS.items() if v == code][0]; txt = {"hi": "खेत में पानी है", "ta": "வயலில் தண்ணீர் உள்ளது", "kn": "ಹೊಲದಲ್ಲಿ ನೀರು ಇದೆ", "en": "there is water in the field"}[l]
    return {sp: [(say(txt, l, "m3", 150, 50), txt) for _ in range(6)] for sp in ["train", "test"]}
# ---- data ----
real, syn_tr, syn_te = {}, [], {}
for l, c in LANGS.items():
    try: d = fake(c) if DRY else fleurs(c)
    except Exception as e: log("FLEURS FAIL", l, repr(e)[:300]); R.setdefault("errors", []).append(f"{l}: {e!r}"[:300]); save(); continue
    real[l] = {sp: [(x, clean(phonemes(t, l))) for x, t in d[sp]] for sp in d}
    for x, t in d["train"]:   # synthetic twin of every real training sentence (same text, robot voices)
        for _ in range(2): syn_tr.append((say(t, l, random.choice(TRV), random.uniform(100, 220), random.uniform(20, 80)), clean(phonemes(t, l))))
    syn_te[l] = [(say(t, l, random.choice(TEV), random.uniform(110, 210), random.uniform(25, 75)), clean(phonemes(t, l))) for _, t in d["test"]]
if not real: R["status"] = "failed: no real speech"; save(); sys.exit(1)
VOCAB = sorted({ch for d in [syn_tr] + [real[l]["train"] for l in real] for _, p in d for ch in p}); VOC = {c: i + 1 for i, c in enumerate(VOCAB)}
json.dump({"vocab": VOCAB}, open(f"{OUT}/vocab.json", "w"), ensure_ascii=False)
R["data"] = {"real": {l: {sp: len(v) for sp, v in real[l].items()} for l in real}, "synthetic_train": len(syn_tr), "vocab": len(VOCAB)}; log("data", R["data"]); save()
# ---- train / eval ----
def noise(n):
    w = np.random.randn(n).astype(np.float32); k = np.random.choice(["white", "pink", "brown"])
    if k != "white":
        f = np.fft.rfft(w); fr = np.arange(len(f)) + 1; w = np.fft.irfft(f / fr ** (0.5 if k == "pink" else 1.0), n).astype(np.float32); w /= w.std() + 1e-8
    return w
def batch(items, aug):
    xs = []
    for a, _ in items:
        x = a.astype(np.float32)
        if aug:
            x = x * np.random.uniform(.4, 1.4)
            if np.random.rand() < .5: x = x + noise(len(x)) * np.sqrt((x ** 2).mean()) / 10 ** (np.random.uniform(5, 30) / 20)
        xs.append(x)
    n = max(len(x) for x in xs); X = np.zeros((len(xs), n), np.float32); M = np.zeros((len(xs), n // HOP + 1), bool)
    for k, x in enumerate(xs): X[k, :len(x)] = x; M[k, :len(x) // HOP + 1] = True
    mel = logmel(torch.tensor(X))
    if aug:
        for k in range(len(xs)):
            f0 = np.random.randint(0, 56); mel[k, f0:f0 + np.random.randint(0, 9)] = mel[k].min()
            t0 = np.random.randint(0, max(1, mel.shape[2] - 30)); mel[k, :, t0:t0 + np.random.randint(0, 25)] = mel[k].min()
    return mel, torch.tensor(M[:, :mel.shape[2]])
def decode(net, items):
    net.eval(); H = []
    with torch.no_grad():
        for i in range(0, len(items), 16):
            mel, M = batch(items[i:i+16], False); z, h = net(mel, M, return_frames=True); ids = net.ctc(h).argmax(1).numpy()
            for k in range(len(ids)):
                s, pv = [], 0
                for t in ids[k, :int((M[k].sum() + 1) // 2)]:
                    if t != pv and t != 0: s.append(VOCAB[t - 1])
                    pv = t
                H.append("".join(s))
    return H
def evaluate(net, tag):
    r = {}
    for l in real:
        r[f"real_{l}"] = round(float(np.mean([per(h, p) for h, (_, p) in zip(decode(net, real[l]["test"]), real[l]["test"])])), 4)
        r[f"synthetic_{l}"] = round(float(np.mean([per(h, p) for h, (_, p) in zip(decode(net, syn_te[l]), syn_te[l])])), 4)
    r["real_mean"] = round(float(np.mean([v for k, v in r.items() if k.startswith("real_")])), 4)
    r["synthetic_mean"] = round(float(np.mean([v for k, v in r.items() if k.startswith("synthetic_")])), 4); log("EVAL", tag, r); return r
def train(tag, data):
    torch.manual_seed(0); net = SpeechEncoder(torch.randn(38, 256), n_phon=len(VOCAB)); opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
    t0 = time.time(); ep = 0; hist = []; st = 0
    while (time.time() - t0) / 60 < MIN and ep < (1 if DRY else 60):
        ep += 1; net.train(); d = sorted(data, key=lambda it: len(it[0])); ch = [d[i:i+16] for i in range(0, len(d), 16)]; random.shuffle(ch); tot = 0
        for c in ch:
            mel, M = batch(c, True); z, h = net(mel, M, return_frames=True); lp = net.ctc(h).log_softmax(1).permute(2, 0, 1)
            il = torch.clamp((M.sum(1) + 1) // 2, max=lp.shape[0]); tg = [torch.tensor([VOC[x] for x in p if x in VOC] or [1]) for _, p in c]
            loss = F.ctc_loss(lp, torch.cat(tg), il, torch.tensor([len(t) for t in tg]), zero_infinity=True)
            lr = 2e-3 * min(1, (st + 1) / 100); [g.__setitem__("lr", lr) for g in opt.param_groups]
            opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(net.parameters(), 5.0); opt.step(); tot += loss.item(); st += 1
            if (time.time() - t0) / 60 > MIN: break
        hist.append({"epoch": ep, "loss": round(tot / len(ch), 3)}); log(tag, hist[-1])
    for g in opt.param_groups: g["lr"] = 2e-4
    R[f"{tag}_epochs"] = hist; R[f"{tag}_PER"] = evaluate(net, tag); torch.save({"state": net.state_dict(), "vocab": VOCAB}, f"{OUT}/{tag}.pt"); save()
real_tr = [it for l in real for it in real[l]["train"]]
train("A_synthetic_only", syn_tr)
train("B_synthetic_plus_real", syn_tr + real_tr * 2)
R["status"] = "done"; R["minutes"] = round((time.time() - T0) / 60, 1); save(); log("DONE")
