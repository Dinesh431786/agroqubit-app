"""Speech -> meaning encoder (no ASR). Log-mel -> small depthwise-separable CNN -> attention pooling -> 256-d unit vector
in the SAME meaning space as the text encoder. Slot scores use the text encoder's own slot prototypes (frozen), so all
modalities share one space. ~0.5 M parameters."""
import math, numpy as np, torch, torch.nn as nn, torch.nn.functional as F

SR, NFFT, HOP, NMEL = 16000, 400, 160, 64
def mel_fb(n_mels=NMEL, n_fft=NFFT, sr=SR, fmin=60, fmax=7600):
    m = lambda f: 2595 * np.log10(1 + f / 700); im = lambda m_: 700 * (10 ** (m_ / 2595) - 1)
    pts = im(np.linspace(m(fmin), m(fmax), n_mels + 2)); bins = np.fft.rfftfreq(n_fft, 1 / sr)
    fb = np.zeros((n_mels, len(bins)))
    for i in range(n_mels):
        l, c, r = pts[i], pts[i + 1], pts[i + 2]
        fb[i] = np.clip(np.minimum((bins - l) / (c - l), (r - bins) / (r - c)), 0, None)
    return torch.tensor(fb, dtype=torch.float32)
FB = mel_fb(); WIN = torch.hann_window(NFFT)
def logmel(x):  # x: (B, N) float -> (B, NMEL, T)
    X = torch.stft(x, NFFT, HOP, window=WIN, return_complex=True).abs() ** 2
    return torch.log(FB @ X + 1e-6)

class DS(nn.Module):
    def __init__(s, cin, cout, stride):
        super().__init__(); s.dw = nn.Conv2d(cin, cin, 3, stride, 1, groups=cin, bias=False); s.pw = nn.Conv2d(cin, cout, 1, bias=False); s.bn = nn.BatchNorm2d(cout)
    def forward(s, x): return F.gelu(s.bn(s.pw(s.dw(x))))

class SpeechEncoder(nn.Module):
    def __init__(s, slot_protos, dim=256, n_phon=0):
        super().__init__()
        s.stem = nn.Sequential(nn.Conv2d(1, 32, 3, 2, 1, bias=False), nn.BatchNorm2d(32), nn.GELU())
        s.blocks = nn.Sequential(DS(32, 64, (2, 1)), DS(64, 96, (2, 1)), DS(96, 128, (2, 1)), DS(128, 160, 1))
        s.tconv = nn.Sequential(nn.Conv1d(160 * 4, 256, 5, 1, 2), nn.GELU(), nn.Conv1d(256, 256, 5, 1, 2), nn.GELU())
        s.att = nn.Conv1d(256, 4, 1); s.proj = nn.Linear(256 * 4, dim)
        s.register_buffer("slots", F.normalize(torch.as_tensor(slot_protos, dtype=torch.float32), dim=-1))
        s.scale = nn.Parameter(torch.tensor(10.0)); s.bias = nn.Parameter(torch.tensor(-5.0))
        s.ctc = nn.Conv1d(256, n_phon + 1, 1) if n_phon else None   # training-only auxiliary phoneme head
    def forward(s, mel, mask=None, return_frames=False):          # mel (B, NMEL, T); mask (B, T) True = valid frame
        m = (mel - mel.mean((1, 2), keepdim=True)) / (mel.std((1, 2), keepdim=True) + 1e-5)
        h = s.blocks(s.stem(m[:, None]))      # (B, C, 4, T/4)
        B, C, Fq, T = h.shape; h = s.tconv(h.reshape(B, C * Fq, T))
        a = s.att(h)
        if mask is not None:
            mk = F.interpolate(mask[:, None].float(), size=T, mode="nearest")[:, 0] > 0.5
            a = a.masked_fill(~mk[:, None], -1e4)
        a = a.softmax(-1); pooled = torch.einsum("bht,bct->bhc", a, h).reshape(B, -1)
        z = F.normalize(s.proj(pooled), dim=-1)
        return (z, h) if return_frames else z
    def slot_logits(s, z): return s.scale * (z @ s.slots.T) + s.bias
