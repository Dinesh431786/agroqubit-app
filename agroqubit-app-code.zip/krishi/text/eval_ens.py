import json, sys, re, unicodedata, random, numpy as np, torch
sys.path.insert(0, "."); from textenc import TextEncoder, pack, pack_windows, mil_logits
K = "/home/claude/krishi"; SL = list(json.load(open(f"{K}/slots.json"))); S = {s: i for i, s in enumerate(SL)}
allr = [json.loads(l) for l in open(f"{K}/data/text_train.jsonl")]; te = [json.loads(l) for l in open(f"{K}/data/text_test.jsonl")]
norm = lambda s: re.sub(r"[^\w\s]", "", unicodedata.normalize("NFC", s.lower())).strip()
trs = {norm(x["text"]) for x in allr}; te = [x for x in te if norm(x["text"]) not in trs]
Yt = np.zeros((len(te), len(SL)))
for i, r in enumerate(te): Yt[i, [S[s] for s in r["slots"]]] = 1
def load(p):
    ck = torch.load(p); n = TextEncoder(len(SL)); n.load_state_dict(ck["state"]); n.eval(); return n, ck["threshold"]
def P_whole(n):
    with torch.no_grad(): i, o = pack([r["text"] for r in te]); return torch.sigmoid(n.slot_logits(n.embed(i, o))).numpy()
def P_mil(n):
    with torch.no_grad(): i, o, w, h = pack_windows([r["text"] for r in te]); return torch.sigmoid(mil_logits(n, i, o, w, len(te))).numpy()
single = [i for i, r in enumerate(te) if len(r["slots"]) == 1]; multi = [i for i, r in enumerate(te) if len(r["slots"]) > 1]
def score(P, t):
    pred = P >= t
    for i in range(len(pred)):
        if not pred[i].any(): pred[i, P[i].argmax()] = True
    tp = (pred & (Yt > 0)).sum(0); fp = (pred & (Yt == 0)).sum(0); fn = (~pred & (Yt > 0)).sum(0)
    by = {L: round(float(np.mean([P[i].argmax() == Yt[i].argmax() for i in single if te[i]["lang"] == L])), 3) for L in sorted({r["lang"] for r in te})}
    return dict(single_top1=round(float(np.mean([P[i].argmax() == Yt[i].argmax() for i in single])), 3), exact=round(float((pred == (Yt > 0)).all(1).mean()), 3),
                multi_exact=round(float((pred[multi] == (Yt[multi] > 0)).all(1).mean()), 3), macro_f1=round(float((2*tp/np.maximum(2*tp+fp+fn, 1)).mean()), 3), by_lang=by)
rows = []
for s in [0, 1, 2]:
    A, ta = load(f"enc_A_{s}.pt"); D, td = load(f"enc_D_{s}.pt"); pa, pd = P_whole(A), P_mil(D)
    for name, P, t in [("A", pa, ta), ("D", pd, td), ("A+D mean", (pa + pd) / 2, (ta + td) / 2)]:
        r = score(P, t); r.update(model=name, seed=s); rows.append(r); print(json.dumps(r, ensure_ascii=False))
json.dump(rows, open("results_text_ensemble.json", "w"), ensure_ascii=False, indent=1)
for name in ["A", "D", "A+D mean"]:
    R = [r for r in rows if r["model"] == name]
    print(f"{name:9s} single {np.mean([r['single_top1'] for r in R]):.3f}  exact {np.mean([r['exact'] for r in R]):.3f}  multi {np.mean([r['multi_exact'] for r in R]):.3f}  F1 {np.mean([r['macro_f1'] for r in R]):.3f}  Latn {np.mean([np.mean([r['by_lang'][l] for l in ['hi-Latn','ta-Latn','kn-Latn']]) for r in R]):.3f}")
