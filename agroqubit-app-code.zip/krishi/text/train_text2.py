"""Text encoder training with optional cross-script JEPA consistency.
variant A: supervised slots only.  variant B: + casual-romanised copies of native sentences + consistency loss
(the romanised view must land on the same meaning vector as the native view; native view is the stop-grad target)."""
import json, random, sys, re, unicodedata, numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "/home/claude/krishi/text"); from textenc import TextEncoder, pack, pack_windows, mil_logits; from casual_roman import casual
variant, seed = sys.argv[1], int(sys.argv[2]); LEX = "L" in variant; MIL = "C" in variant or "D" in variant; XS = "B" in variant or "D" in variant; W = 0.3 if "D" in variant else 1.0; torch.manual_seed(seed); random.seed(seed); np.random.seed(seed)
K = "/home/claude/krishi"; SL = list(json.load(open(f"{K}/slots.json"))); S = {s: i for i, s in enumerate(SL)}
allr = [json.loads(l) for l in open(f"{K}/data/text_train.jsonl")]; te = [json.loads(l) for l in open(f"{K}/data/text_test.jsonl")]
norm = lambda s: re.sub(r"[^\w\s]", "", unicodedata.normalize("NFC", s.lower())).strip()
trs = {norm(x["text"]) for x in allr}; te = [x for x in te if norm(x["text"]) not in trs]
random.shuffle(allr); nv = len(allr) // 10; va, tr = allr[:nv], allr[nv:]          # validation only for thresholds

def Y(rows):
    y = torch.zeros(len(rows), len(SL))
    for i, r in enumerate(rows): y[i, [S[s] for s in r["slots"]]] = 1
    return y
def aug(t):
    c = list(t)
    for _ in range(random.randint(0, 3)):
        if len(c) < 4: break
        k = random.randrange(len(c)); op = random.random()
        if op < .35: del c[k]
        elif op < .6: c.insert(k, c[k])
        elif k + 1 < len(c): c[k], c[k+1] = c[k+1], c[k]
    w = "".join(c).split()
    if len(w) > 3 and random.random() < .3: del w[random.randrange(len(w))]
    return " ".join(w)
LEXI = json.load(open(f"{K}/data/dialect_lexicon.json"))
PAIRS = {L: [(s, v) for c in d.values() for s in c["standard"] for v in c["variants"] if s and v and s != v] for L, d in LEXI.items()}
def dialectise(r):
    """Swap standard words for dialect/slang variants from an independent lexicon (never sees the test set)."""
    L = r["lang"].split("-")[0]; t = r["text"]; hit = False
    for s, v in random.sample(PAIRS.get(L, []), len(PAIRS.get(L, []))):
        if s in t and random.random() < .6: t = t.replace(s, v, 1); hit = True
    return {"text": t, "lang": r["lang"], "slots": r["slots"]} if hit else None
def mix(rows):
    by = {}; out = []
    for r in rows: by.setdefault(r["lang"], []).append(r)
    for _ in range(len(rows) // 2):
        L = random.choice(list(by)); a, b = random.sample(by[L], 2)
        out.append({"text": a["text"] + " " + b["text"], "lang": L, "slots": sorted(set(a["slots"]) | set(b["slots"]))})
    return out

net = TextEncoder(len(SL)); opt = torch.optim.AdamW(net.parameters(), lr=3e-3, weight_decay=1e-4); EP = 40
for ep in range(EP):
    net.train(); rows = tr + mix(tr)
    if LEX: rows = rows + [x for x in (dialectise(r) for r in tr) if x]
    if XS:
        rows = rows + [{"text": casual(r["text"], r["lang"]), "lang": r["lang"] + "-Latn", "slots": r["slots"], "src": r["text"]}
                       for r in tr if r["lang"] in ("hi", "ta", "kn") and (W == 1.0 or random.random() < .5)]
    random.shuffle(rows)
    for i in range(0, len(rows), 64):
        b = rows[i:i+64]
        if MIL:
            ids, off, own, wh = pack_windows([r["text"] for r in b], aug); zall = net.embed(ids, off); z = zall[wh]
            L = net.slot_logits(zall); lg = torch.full((len(b), L.shape[1]), -1e4).scatter_reduce(0, own[:, None].expand_as(L), L, reduce="amax", include_self=True)
        else:
            ids, off = pack([r["text"] for r in b], aug); z = net.embed(ids, off); lg = net.slot_logits(z)
        loss = F.binary_cross_entropy_with_logits(lg, Y(b))
        if XS:
            pairs = [(j, r["src"]) for j, r in enumerate(b) if "src" in r]
            if pairs:
                with torch.no_grad():
                    i2, o2 = pack([p[1] for p in pairs]); zt = net.embed(i2, o2)
                loss = loss + W * (1 - (z[[p[0] for p in pairs]] * zt).sum(-1)).mean()
        opt.zero_grad(); loss.backward(); opt.step()
    for g in opt.param_groups: g["lr"] = 3e-3 * 0.5 * (1 + np.cos(np.pi * (ep + 1) / EP))

net.eval()
def probs(rows):
    with torch.no_grad():
        if MIL: ids, off, own, wh = pack_windows([r["text"] for r in rows]); return torch.sigmoid(mil_logits(net, ids, off, own, len(rows))).numpy()
        ids, off = pack([r["text"] for r in rows]); return torch.sigmoid(net.slot_logits(net.embed(ids, off))).numpy()
Pv, Yv = probs(va), Y(va).numpy()
best_t = max(np.arange(.2, .8, .05), key=lambda t: ((Pv >= t) == (Yv > 0)).all(1).mean())   # one global threshold, tuned on val
P, Yt = probs(te), Y(te).numpy()
pred = P >= best_t
for i in range(len(pred)):
    if not pred[i].any(): pred[i, P[i].argmax()] = True
single = [i for i, r in enumerate(te) if len(r["slots"]) == 1]; multi = [i for i, r in enumerate(te) if len(r["slots"]) > 1]
tp = (pred & (Yt > 0)).sum(0); fp = (pred & (Yt == 0)).sum(0); fn = (~pred & (Yt > 0)).sum(0)
by = {L: round(float(np.mean([P[i].argmax() == Yt[i].argmax() for i in single if te[i]["lang"] == L])), 3) for L in sorted({r["lang"] for r in te})}
R = dict(variant=variant, seed=seed, threshold=round(float(best_t), 2), single_top1=round(float(np.mean([P[i].argmax() == Yt[i].argmax() for i in single])), 3),
         exact_set=round(float((pred == (Yt > 0)).all(1).mean()), 3), multi_exact=round(float((pred[multi] == (Yt[multi] > 0)).all(1).mean()), 3),
         macro_f1=round(float((2 * tp / np.maximum(2 * tp + fp + fn, 1)).mean()), 3), by_lang=by)
print(json.dumps(R, ensure_ascii=False))
json.dump(R, open(f"{K}/text/res_{variant}_{seed}.json", "w"), ensure_ascii=False)
torch.save({"state": net.state_dict(), "slots": SL, "threshold": float(best_t)}, f"{K}/text/enc_{variant}_{seed}.pt")
