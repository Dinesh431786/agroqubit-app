import json, sys, numpy as np, torch
sys.path.insert(0, "."); from textenc import TextEncoder, pack, pack_windows, mil_logits
K = "/home/claude/krishi"; SL = list(json.load(open(f"{K}/slots.json"))); S = {s: i for i, s in enumerate(SL)}
A_PT, D_PT = (sys.argv[1], sys.argv[2]) if len(sys.argv) > 2 else (f"{K}/text/enc_A_0.pt", f"{K}/text/enc_D_0.pt")
def probs(rows):
    out = []
    for p, mil in [(A_PT, False), (D_PT, True)]:
        ck = torch.load(p); n = TextEncoder(len(SL)); n.load_state_dict(ck["state"]); n.eval()
        with torch.no_grad():
            if mil: i, o, w, h = pack_windows([r["text"] for r in rows]); out.append(torch.sigmoid(mil_logits(n, i, o, w, len(rows))).numpy())
            else: i, o = pack([r["text"] for r in rows]); out.append(torch.sigmoid(n.slot_logits(n.embed(i, o))).numpy())
    return (out[0] + out[1]) / 2
R = {}
for name, f in [("normal_test", "text_test.jsonl"), ("slang_test", "text_slang_test.jsonl")]:
    rows = [json.loads(l) for l in open(f"{K}/data/{f}")]; P = probs(rows)
    Y = np.zeros((len(rows), len(SL)), bool)
    for i, r in enumerate(rows): Y[i, [S[s] for s in r["slots"]]] = True
    single = [i for i, r in enumerate(rows) if len(r["slots"]) == 1]; pred = P >= 0.45
    for i in range(len(pred)):
        if not pred[i].any(): pred[i, P[i].argmax()] = True
    tp = (pred & Y).sum(0); fp = (pred & ~Y).sum(0); fn = (~pred & Y).sum(0)
    R[name] = dict(n=len(rows), single_top1=round(float(np.mean([P[i].argmax() == Y[i].argmax() for i in single])), 3),
                   macro_f1=round(float((2 * tp / np.maximum(2 * tp + fp + fn, 1)).mean()), 3),
                   by_lang={L: round(float(np.mean([P[i].argmax() == Y[i].argmax() for i in single if rows[i]["lang"] == L])), 3) for L in sorted({r["lang"] for r in rows})})
    if name == "slang_test":
        f1 = 2 * tp / np.maximum(2 * tp + fp + fn, 1); R[name]["worst_slots"] = sorted(zip(np.round(f1, 2).tolist(), SL))[:8]
        R[name]["missed_examples"] = [(rows[i]["text"], rows[i]["slots"][0], SL[int(P[i].argmax())]) for i in single if P[i].argmax() != Y[i].argmax()][:12]
print(json.dumps(R, indent=1, ensure_ascii=False))
json.dump(R, open(f"{K}/text/results_slang_{sys.argv[3] if len(sys.argv) > 3 else 'baseline'}.json", "w"), indent=1, ensure_ascii=False)
