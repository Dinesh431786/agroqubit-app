import json, random, sys, numpy as np, torch, torch.nn.functional as F, re, unicodedata
sys.path.insert(0, "/home/claude/krishi/text"); from textenc import TextEncoder, pack, normalise
torch.manual_seed(int(sys.argv[1]) if len(sys.argv) > 1 else 0); random.seed(0)
K = "/home/claude/krishi"; SL = list(json.load(open(f"{K}/slots.json"))); S = {s: i for i, s in enumerate(SL)}
tr = [json.loads(l) for l in open(f"{K}/data/text_train.jsonl")]
te = [json.loads(l) for l in open(f"{K}/data/text_test.jsonl")]
norm = lambda s: re.sub(r"[^\w\s]", "", unicodedata.normalize("NFC", s.lower())).strip()
trs = {norm(x["text"]) for x in tr}; te = [x for x in te if norm(x["text"]) not in trs]

def Y(rows): y = torch.zeros(len(rows), len(SL)); [y[i].index_fill_(0, torch.tensor([S[s] for s in r["slots"]]), 1) for i, r in enumerate(rows)]; return y
def aug(t):  # farmer typing / ASR-like noise: drop, duplicate, swap characters; drop a word
    c = list(t)
    for _ in range(random.randint(0, 3)):
        if len(c) < 4: break
        k = random.randrange(len(c)); op = random.random()
        if op < .35: del c[k]
        elif op < .6: c.insert(k, c[k])
        elif k + 1 < len(c): c[k], c[k+1] = c[k+1], c[k]
    w = "".join(c).split()
    if len(w) > 3 and random.random() < .3: del w[random.randrange(len(w))]
    return " ".join(w)
def mix(rows):  # synthetic multi-slot: concatenate two sentences of the same language (teaches compositionality)
    out = []
    by = {}
    for r in rows: by.setdefault(r["lang"], []).append(r)
    for _ in range(len(rows) // 2):
        L = random.choice(list(by)); a, b = random.sample(by[L], 2)
        out.append({"text": a["text"] + " " + b["text"], "lang": L, "slots": sorted(set(a["slots"]) | set(b["slots"]))})
    return out

net = TextEncoder(len(SL)); opt = torch.optim.AdamW(net.parameters(), lr=3e-3, weight_decay=1e-4)
EP = 40
for ep in range(EP):
    net.train(); rows = tr + mix(tr); random.shuffle(rows)
    for i in range(0, len(rows), 64):
        b = rows[i:i+64]; ids, off = pack([r["text"] for r in b], aug); y = Y(b)
        loss = F.binary_cross_entropy_with_logits(net.slot_logits(net.embed(ids, off)), y)
        opt.zero_grad(); loss.backward(); opt.step()
    for g in opt.param_groups: g["lr"] = 3e-3 * 0.5 * (1 + np.cos(np.pi * (ep + 1) / EP))

net.eval()
with torch.no_grad():
    ids, off = pack([r["text"] for r in te]); P = torch.sigmoid(net.slot_logits(net.embed(ids, off))).numpy()
Yt = Y(te).numpy()
def report(P, Yt, rows, thr=0.5):
    pred = P >= thr
    for i in range(len(pred)):
        if not pred[i].any(): pred[i, P[i].argmax()] = True        # always output at least one meaning
    exact = float((pred == (Yt > 0)).all(1).mean())
    single = [i for i, r in enumerate(rows) if len(r["slots"]) == 1]
    top1 = float(np.mean([P[i].argmax() == Yt[i].argmax() for i in single]))
    tp = (pred & (Yt > 0)).sum(0); fp = (pred & (Yt == 0)).sum(0); fn = (~pred & (Yt > 0)).sum(0)
    f1 = 2 * tp / np.maximum(2 * tp + fp + fn, 1)
    by = {}
    for L in sorted({r["lang"] for r in rows}):
        idx = [i for i in single if rows[i]["lang"] == L]; by[L] = round(float(np.mean([P[i].argmax() == Yt[i].argmax() for i in idx])), 3)
    multi = [i for i, r in enumerate(rows) if len(r["slots"]) > 1]
    return dict(n=len(rows), single_slot_top1=round(top1, 3), exact_set_match=round(exact, 3), macro_f1=round(float(f1.mean()), 3),
                multi_slot_exact=round(float((pred[multi] == (Yt[multi] > 0)).all(1).mean()), 3), top1_by_lang=by,
                worst_slots=sorted(zip(np.round(f1, 2).tolist(), SL))[:6])
R = report(P, Yt, te); print(json.dumps(R, indent=1, ensure_ascii=False))
torch.save({"state": net.state_dict(), "slots": SL}, f"{K}/text/text_encoder.pt")
json.dump(R, open(f"{K}/text/results_text_seed{sys.argv[1] if len(sys.argv)>1 else 0}.json", "w"), indent=1, ensure_ascii=False)
