"""Shrink text/phoneme encoders for phones: int8 per-row embedding table (+ fp16 MLP). Check accuracy is unchanged."""
import json, sys, re, unicodedata, numpy as np, torch
sys.path.insert(0, "/home/claude/krishi/text"); from textenc import TextEncoder, pack, pack_windows, mil_logits
K = "/home/claude/krishi"; SL = list(json.load(open(f"{K}/slots.json"))); S = {s: i for i, s in enumerate(SL)}
def q8(net):
    W = net.bag.weight.data; sc = W.abs().max(1, keepdim=True).values / 127 + 1e-12; Wq = torch.round(W / sc).clamp(-127, 127).to(torch.int8)
    net.bag.weight.data = Wq.float() * sc                                      # dequantised copy for accuracy check
    for p in net.mlp.parameters(): p.data = p.data.half().float()
    return Wq.numel() + sc.numel() * 2 + sum(p.numel() * 2 for p in net.mlp.parameters()) + net.slots.numel() * 2
te = [json.loads(l) for l in open(f"{K}/data/text_test.jsonl")]; trs = {re.sub(r"[^\w\s]", "", unicodedata.normalize("NFC", json.loads(l)["text"].lower())).strip() for l in open(f"{K}/data/text_train.jsonl")}
te = [x for x in te if re.sub(r"[^\w\s]", "", unicodedata.normalize("NFC", x["text"].lower())).strip() not in trs]
Y = np.zeros((len(te), len(SL)), bool)
for i, r in enumerate(te): Y[i, [S[s] for s in r["slots"]]] = True
single = [i for i, r in enumerate(te) if len(r["slots"]) == 1]
def probs(quant):
    out, size = [], 0
    for name, mil in [("A", False), ("D", True)]:
        ck = torch.load(f"{K}/text/enc_{name}_0.pt"); n = TextEncoder(len(SL)); n.load_state_dict(ck["state"]); n.eval()
        size += q8(n) if quant else sum(p.numel() * 4 for p in n.parameters())
        with torch.no_grad():
            if mil: i, o, w, h = pack_windows([r["text"] for r in te]); out.append(torch.sigmoid(mil_logits(n, i, o, w, len(te))).numpy())
            else: i, o = pack([r["text"] for r in te]); out.append(torch.sigmoid(n.slot_logits(n.embed(i, o))).numpy())
    return (out[0] + out[1]) / 2, size
for quant in [False, True]:
    P, size = probs(quant); print("int8" if quant else "fp32", f"size {size/1e6:.1f} MB", "single top1", round(float(np.mean([P[i].argmax() == Y[i].argmax() for i in single])), 4))
