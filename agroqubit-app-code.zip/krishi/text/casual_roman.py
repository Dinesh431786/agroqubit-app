"""Turn native-script Hindi/Tamil/Kannada into the casual, inconsistent Latin spelling farmers type/ASR emits
(e.g. 'पत्तों पर सफेद पाउडर' -> 'patton par safed powder'/'pattom pe safed paudar'). Randomised so the encoder
sees many spellings of the same meaning. Used for cross-script JEPA consistency training."""
import random, re, unicodedata
from indic_transliteration.sanscript import transliterate
SCRIPT = {"hi": "devanagari", "ta": "tamil", "kn": "kannada"}

def _strip(s):
    s = unicodedata.normalize("NFD", s); s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s

def casual(text, lang, rng=random):
    t = transliterate(text, SCRIPT[lang], "itrans")
    t = t.replace("~N", "n").replace("~n", "n").replace(".N", "n").replace(".n", "n").replace("M", "n").replace("H", "h")
    t = t.replace("RRi", "ri").replace("R^i", "ri").replace(".h", "").replace("^", "")
    t = _strip(t).lower()
    t = t.replace("chh", "chh" if rng.random() < .5 else "ch").replace("sh", "sh" if rng.random() < .6 else "s")
    t = t.replace("ph", "f" if rng.random() < .7 else "ph").replace("w", "v" if rng.random() < .5 else "w")
    if lang == "ta":  # Tamil script has no voiced/aspirated letters; casual writing uses plain p/t/k/d
        if rng.random() < .6: t = t.replace("jj", "ch")
        for a, b in [("bh", "p"), ("dh", "d"), ("gh", "k"), ("jh", "j"), ("th", "th"), ("zh", "zh" if rng.random() < .5 else "l")]: t = t.replace(a, b)
        t = re.sub(r"(?<![aeiou])g(?=[aeiou])", "k", t) if rng.random() < .5 else t
    words = []
    for w in t.split():
        if lang == "hi" and len(w) > 2 and w.endswith("a") and not w.endswith("aa") and rng.random() < .85: w = w[:-1]   # schwa deletion
        if rng.random() < .5: w = w.replace("aa", "a")
        if rng.random() < .5: w = w.replace("ii", "ee" if rng.random() < .5 else "i")
        if rng.random() < .5: w = w.replace("uu", "oo" if rng.random() < .5 else "u")
        words.append(w)
    return " ".join(words)

if __name__ == "__main__":
    for s, l in [("पत्तों पर सफेद पाउडर है", "hi"), ("இலையில வெள்ளை பொடி இருக்கு", "ta"), ("ಎಲೆ ಮೇಲೆ ಬಿಳಿ ಪುಡಿ ಇದೆ", "kn"),
                 ("धान की पत्तियाँ नोक से पीली हो रही हैं", "hi"), ("நெல் பயிர் மஞ்சளா ஆயிடுச்சு", "ta")]:
        print([casual(s, l, random.Random(i)) for i in range(3)])
