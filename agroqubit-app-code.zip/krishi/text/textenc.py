"""M1: tiny multilingual text -> meaning encoder (Hindi/Tamil/Kannada/English, native + romanised, code-mixed).
Hashed char n-grams + word n-grams (script-agnostic, robust to spelling) -> EmbeddingBag -> MLP -> 256-d unit
'meaning' vector. Slots are unit prototype vectors in the SAME space (multi-label via cosine). This 256-d space is
the shared target that the speech encoder (M2) is distilled into."""
import json, re, unicodedata, zlib, numpy as np, torch, torch.nn as nn, torch.nn.functional as F

NB = 1 << 16; DIM = 256

def normalise(s):
    s = unicodedata.normalize("NFC", s.lower())
    s = re.sub(r"[।॥.,!?;:\"'()\-–—/]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()

def features(s, nmin=2, nmax=4):
    s = normalise(s); ids = []
    words = s.split()
    for w in words:
        ids.append(zlib.crc32(("W" + w).encode()) % NB)
        t = f"<{w}>"
        for n in range(nmin, nmax + 1):
            for i in range(len(t) - n + 1): ids.append(zlib.crc32(t[i:i+n].encode()) % NB)
    for a, b in zip(words, words[1:]): ids.append(zlib.crc32(("B" + a + " " + b).encode()) % NB)
    return ids or [0]

class TextEncoder(nn.Module):
    def __init__(self, n_slots, emb=96):
        super().__init__()
        self.bag = nn.EmbeddingBag(NB, emb, mode="mean")
        self.mlp = nn.Sequential(nn.Linear(emb, 384), nn.GELU(), nn.Dropout(0.2), nn.Linear(384, DIM))
        self.slots = nn.Parameter(torch.randn(n_slots, DIM) * 0.05)
        self.scale = nn.Parameter(torch.tensor(10.0)); self.bias = nn.Parameter(torch.tensor(-5.0))
    def embed(self, ids, offsets): return F.normalize(self.mlp(self.bag(ids, offsets)), dim=-1)
    def slot_logits(self, z): return self.scale * (z @ F.normalize(self.slots, dim=-1).T) + self.bias

def pack(texts, aug=None):
    ids, offs = [], []
    for t in texts:
        f = features(aug(t) if aug else t); offs.append(len(ids)); ids += f
    return torch.tensor(ids), torch.tensor(offs)

def pack_windows(texts, aug=None, win=4, stride=2):
    """Bags for the whole sentence + overlapping word windows. Returns ids, offsets, owner (sentence index per bag), is_whole."""
    ids, offs, owner, whole = [], [], [], []
    for si, t in enumerate(texts):
        t = aug(t) if aug else t; w = normalise(t).split() or [""]
        spans = [(0, len(w))] + ([(i, min(i + win, len(w))) for i in range(0, max(1, len(w) - win + stride), stride)] if len(w) > win else [])
        for a, b in spans:
            offs.append(len(ids)); ids += features(" ".join(w[a:b])); owner.append(si); whole.append(a == 0 and b == len(w))
    return torch.tensor(ids), torch.tensor(offs), torch.tensor(owner), torch.tensor(whole)

def mil_logits(net, ids, offs, owner, n):
    """Slot logits = max over the sentence's bags (whole + windows): a slot fires if any part of the sentence says it."""
    L = net.slot_logits(net.embed(ids, offs))
    out = torch.full((n, L.shape[1]), -1e4)
    return out.scatter_reduce(0, owner[:, None].expand_as(L), L, reduce="amax", include_self=True)
