import json, sys, numpy as np
sys.path.insert(0, "."); from freechat import FreeChat
K = "/home/claude/krishi"; te = [json.loads(l) for l in open(f"{K}/data/free_questions_test.jsonl")]; fc = FreeChat()
SC = {"treatment", "dose", "prevention", "organic", "disease_info"}; cnt = {"correct_answer": 0, "safe_fallback": 0, "WRONG_answer": 0, "wrongly_refused": 0}; rows = []
for r in te:
    lang = r["lang"].split("-")[0]; a = fc.answer(r["text"], lang); act = a["action"]
    if act.startswith("answer_"):
        ok = (r["intent"] in SC and a["disease"] == r.get("disease") and act == "answer_" + r["intent"])
        same_card = (r["intent"] in SC and a["disease"] == r.get("disease"))      # right disease, different section of the same verified card
        k = "correct_answer" if ok else ("safe_fallback" if same_card else "WRONG_answer")
    elif act == "confirm_disease":
        k = "correct_answer" if (r["intent"] == "dose" and a["disease"] == r.get("disease")) else "safe_fallback"
    elif act in ("refer_kcc", "off_topic"):
        k = "correct_answer" if r["intent"] in ("out_of_scope_known", "off_topic") else ("safe_fallback" if r["intent"] == "helpline" else "wrongly_refused")
    elif act == "helpline": k = "correct_answer" if r["intent"] == "helpline" else "safe_fallback"
    else:   # clarify / start_diagnosis
        k = "correct_answer" if r["intent"] == "diagnose" or (r["intent"] in SC and not r.get("disease")) else "safe_fallback"
    cnt[k] += 1; rows.append({**r, "app": a, "outcome": k})
R = {k: round(v / len(te), 3) for k, v in cnt.items()}; R["n"] = len(te)
R["wrong_dose_answers"] = sum(1 for x in rows if x["outcome"] == "WRONG_answer" and x["app"]["action"] == "answer_dose"); R["wrong_examples"] = [(x["text"], x["intent"], x.get("disease"), x["app"]["action"], x["app"]["disease"]) for x in rows if x["outcome"] == "WRONG_answer"][:10]
print(json.dumps(R, indent=1, ensure_ascii=False)); json.dump(R, open("results_freechat.json", "w"), indent=1, ensure_ascii=False)
json.dump(rows[:30], open("freechat_examples.json", "w"), indent=1, ensure_ascii=False)
