"""LLM-style free chat WITHOUT an LLM: understand the question (intent + disease), then compose the answer ONLY from
verified government-sourced cards in the farmer's language. Unsure -> ask/diagnose; out of scope -> KCC. Never invents."""
import json, sys, numpy as np, torch, torch.nn.functional as F
def sents(items):
    """Join advice items as separate sentences (English IPM items have no full stop of their own)."""
    return " ".join(t if t.rstrip()[-1:] in (".", "।", "!", "?") else t.rstrip() + "." for t in items)
sys.path.insert(0, "/home/claude/krishi/text"); sys.path.insert(0, "/home/claude/krishi/freechat"); from textenc import pack
K = "/home/claude/krishi"; ADV = json.load(open(f"{K}/brain/advice.json"))["advice"]; I18 = json.load(open(f"{K}/brain/advice_i18n.json"))
PH = I18["phrases"]; CAT = json.load(open(f"{K}/voice/catalogue.json")); KB = json.load(open("/home/claude/agri_reason/v2/knowledge_v2.json"))
class FreeChat:
    def __init__(self, conf_min=0.5, dis_min=0.6):
        import train_free_net as T
        import os; ck = torch.load(os.environ.get("KRISHI_FREE_CK", f"{K}/freechat/free_intent.pt")); self.I, self.D = ck["intents"], ck["diseases"]
        self.net = T.Net(len(self.I), len(self.D)); self.net.load_state_dict(ck["state"]); self.net.eval(); self.cm, self.dm = conf_min, dis_min
    def crop_of_text(self, text):
        if not hasattr(self, "tu"):
            sys.path.insert(0, f"{K}/brain"); from chat import TextUnderstanding; self.tu = TextUnderstanding()
            self.SL = list(json.load(open(f"{K}/slots.json")))
        P = self.tu(text); cp = {c: P[self.SL.index(f"crop_{c}")] for c in ["rice", "tomato", "chilli", "groundnut"]}
        c = max(cp, key=cp.get); return c if cp[c] >= 0.5 else None
    def understand(self, text):
        with torch.no_grad():
            i, o = pack([text]); li, ld = self.net(i, o); pi, pd = F.softmax(li, 1)[0].numpy(), F.softmax(ld, 1)[0].numpy()
        crop = self.crop_of_text(text); self.last_margin = 1.0
        if crop:   # crop consistency: a named crop restricts which diseases are possible
            keep = np.array([1.0] + [1.0 if KB["diseases"][d]["crop"] == crop else 0.0 for d in self.D]); pd = pd * keep; pd = pd / max(pd.sum(), 1e-9)
        top = np.argsort(-pd)[:2]; self.last_margin = float(pd[top[0]] - pd[top[1]])
        return self.I[int(pi.argmax())], float(pi.max()), (self.D[int(pd.argmax()) - 1] if pd.argmax() > 0 else None), float(pd.max())
    def items(self, d, field, lang):
        if lang == "en": return ADV[d][field]
        return I18[d][field][lang]
    def answer(self, text, lang="hi", known_disease=None, confirmed=False):
        intent, ci, dis, cd = self.understand(text)
        if known_disease and (dis is None or cd < self.dm): dis, cd = known_disease, 1.0      # from the ongoing diagnosis
        out = {"intent": intent, "intent_conf": round(ci, 2), "disease": dis, "disease_conf": round(cd, 2)}
        if ci < self.cm: return {**out, "action": "clarify", "say": PH["need_diagnosis"][lang]}
        if intent == "off_topic": return {**out, "action": "off_topic", "say": PH["off_topic"][lang]}
        if intent == "out_of_scope_known": return {**out, "action": "refer_kcc", "say": PH["out_of_scope"][lang]}
        if intent == "helpline": return {**out, "action": "helpline", "say": CAT["generic_kvk"][lang]}
        if intent == "diagnose" or dis is None or cd < self.dm or dis not in ADV or self.last_margin < 0.25:   # close call -> ask, don't guess
            return {**out, "action": "start_diagnosis", "say": PH["need_diagnosis"][lang]}
        name = CAT.get(f"name_{dis}", {}).get(lang, dis); src = ADV[dis]["source"]
        if intent == "dose" and not confirmed:    # safety: chemical doses only after the farmer confirms the disease
            return {**out, "action": "confirm_disease", "say": f"{name}? " + {"hi": "क्या यही रोग है? हाँ या ना बोलिए।", "ta": "இந்த நோய் தானா? ஆமா இல்ல இல்லன்னு சொல்லுங்க.",
                    "kn": "ಇದೇ ರೋಗನಾ? ಹೌದು ಅಥವಾ ಇಲ್ಲ ಅಂತ ಹೇಳ್ರಿ.", "en": "Is this the disease? Please say yes or no."}[lang]}
        if intent == "dose":
            ex = self.items(dis, "chemical_examples", lang)
            say = f"{name}. {PH['dose_intro'][lang]} " + sents(ex) + " " + PH["dose_caution"][lang] if ex else f"{name}. {CAT['generic_kvk'][lang]}"
        elif intent == "organic":
            b = self.items(dis, "biological", lang) + self.items(dis, "cultural", lang)
            say = f"{name}. {PH['organic_intro'][lang]} " + sents(b) if b else f"{name}. {PH['organic_none'][lang]}"
        elif intent == "prevention":
            c = self.items(dis, "cultural", lang); say = f"{name}. {PH['prevention_intro'][lang]} " + sents(c) if c else f"{name}. {CAT['generic_kvk'][lang]}"
        elif intent == "disease_info":
            say = f"{PH['info_intro'][lang]} {name}. " + CAT.get(f"adv_{dis}", {}).get(lang, "")
        else:   # treatment
            say = f"{name}. " + CAT.get(f"adv_{dis}", {}).get(lang, "")
        return {**out, "action": "answer_" + intent, "say": say.strip(), "source": src}
