import sys, torch, torch.nn as nn
sys.path.insert(0, '/home/claude/krishi/text')
from textenc import NB
class Net(nn.Module):
    def __init__(s, n_int, n_dis):
        super().__init__(); s.bag = nn.EmbeddingBag(NB, 96, mode="mean"); s.h = nn.Sequential(nn.Linear(96, 256), nn.GELU(), nn.Dropout(.2))
        s.intent = nn.Linear(256, n_int); s.dis = nn.Linear(256, n_dis + 1)
    def forward(s, i, o): z = s.h(s.bag(i, o)); return s.intent(z), s.dis(z)
