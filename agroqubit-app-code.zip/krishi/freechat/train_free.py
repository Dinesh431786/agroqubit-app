"""Free-question understanding: intent (9 classes) + disease mentioned (21 + none). Hashed char/word n-grams (same family as
the text encoder), trained on the independent training questions + KB disease names + dialect lexicon + typo noise."""
import json, random, sys, numpy as np, torch, torch.nn as nn, torch.nn.functional as F
sys.path.insert(0, "/home/claude/krishi/text"); from textenc import pack, NB
random.seed(0); torch.manual_seed(0); K = "/home/claude/krishi"
INTENTS = ["treatment", "dose", "prevention", "organic", "disease_info", "diagnose", "helpline", "out_of_scope_known", "off_topic"]
kb = json.load(open("/home/claude/agri_reason/v2/knowledge_v2.json"))
DIS = [d for d, e in kb["diseases"].items() if not e.get("healthy")]; DIDX = {d: i + 1 for i, d in enumerate(DIS)}   # 0 = none
tr = [json.loads(l) for l in open(f"{K}/data/free_questions_train.jsonl")]; te = [json.loads(l) for l in open(f"{K}/data/free_questions_test.jsonl")]
# extra disease-name rows from the knowledge base (all languages)
extra = []
for d in DIS:
    for l, n in kb["diseases"][d].get("names", {}).items():
        for tmpl in {"hi": ["{} का इलाज क्या है", "{} क्यों होता है"], "ta": ["{} க்கு என்ன மருந்து", "{} எதனால வருது"], "kn": ["{} ಗೆ ಏನು ಔಷಧಿ", "{} ಯಾಕೆ ಬರುತ್ತೆ"], "en": ["what to do for {}", "why does {} come"]}[l]:
            extra.append({"text": tmpl.format(n), "lang": l, "intent": "treatment" if "इलाज" in tmpl or "மருந்து" in tmpl or "ಔಷಧಿ" in tmpl or "what to do" in tmpl else "disease_info", "disease": d})
LEX = json.load(open(f"{K}/data/dialect_lexicon.json")); PAIRS = {L: [(s, v) for c in d.values() for s in c["standard"] for v in c["variants"] if s != v] for L, d in LEX.items()}
def aug(t, lang):
    L = lang.split("-")[0]
    for s, v in random.sample(PAIRS.get(L, []), min(40, len(PAIRS.get(L, [])))):
        if s in t and random.random() < .5: t = t.replace(s, v, 1)
    c = list(t)
    for _ in range(random.randint(0, 2)):
        if len(c) > 4: k = random.randrange(len(c)); del c[k]
    return "".join(c)
class Net(nn.Module):
    def __init__(s):
        super().__init__(); s.bag = nn.EmbeddingBag(NB, 96, mode="mean"); s.h = nn.Sequential(nn.Linear(96, 256), nn.GELU(), nn.Dropout(.2))
        s.intent = nn.Linear(256, len(INTENTS)); s.dis = nn.Linear(256, len(DIS) + 1)
    def forward(s, i, o): z = s.h(s.bag(i, o)); return s.intent(z), s.dis(z)
net = Net(); opt = torch.optim.AdamW(net.parameters(), lr=3e-3, weight_decay=1e-4); rows = tr + extra
for ep in range(60):
    net.train(); random.shuffle(rows)
    for k in range(0, len(rows), 32):
        b = rows[k:k+32]; i, o = pack([aug(r["text"], r["lang"]) for r in b]); li, ld = net(i, o)
        loss = F.cross_entropy(li, torch.tensor([INTENTS.index(r["intent"]) for r in b])) + F.cross_entropy(ld, torch.tensor([DIDX.get(r.get("disease"), 0) for r in b]))
        opt.zero_grad(); loss.backward(); opt.step()
net.eval()
with torch.no_grad(): i, o = pack([r["text"] for r in te]); li, ld = net(i, o)
pi = li.argmax(1).numpy(); pd = ld.argmax(1).numpy(); conf = F.softmax(li, 1).max(1).values.numpy()
yi = np.array([INTENTS.index(r["intent"]) for r in te]); yd = np.array([DIDX.get(r.get("disease"), 0) for r in te])
scope_true = np.isin(yi, [7, 8]); scope_pred = np.isin(pi, [7, 8])
R = {"n_test": len(te), "intent_acc": round(float((pi == yi).mean()), 3),
     "by_intent": {INTENTS[c]: round(float((pi[yi == c] == c).mean()), 3) for c in range(len(INTENTS))},
     "disease_acc_when_named": round(float((pd[yd > 0] == yd[yd > 0]).mean()), 3), "disease_false_alarm_when_none": round(float((pd[yd == 0] > 0).mean()), 3),
     "out_of_scope_correctly_refused": round(float(scope_pred[scope_true].mean()), 3), "in_scope_wrongly_refused": round(float(scope_pred[~scope_true].mean()), 3),
     "by_lang": {L: round(float((pi[[k for k, r in enumerate(te) if r["lang"] == L]] == yi[[k for k, r in enumerate(te) if r["lang"] == L]]).mean()), 3) for L in sorted({r["lang"] for r in te})}}
print(json.dumps(R, indent=1)); json.dump(R, open("results_free.json", "w"), indent=1)
torch.save({"state": net.state_dict(), "intents": INTENTS, "diseases": DIS}, "free_intent.pt")
