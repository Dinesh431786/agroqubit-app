# AI Assistants for Farmers: Competitive Landscape (India first, then global)

*Research date: 11 October 2026. Compiled from web search plus primary-source fetches (arXiv papers, model cards, NGO/government pages, company pages).*

**How to read this report**
- Each factual claim links to its source. Where only a secondary source (news site, exam-prep site, vendor blog, third-party directory) was available, it is labeled **[secondary]**.
- **[UNVERIFIED]** marks a claim I could not confirm from a primary or reasonably authoritative source, or an inference of mine.
- "Accuracy" numbers come from very different metrics: multiple-choice exam scores, F1 against expert answers, WER, image-classification accuracy, and self-reported "farmers acted on advice" surveys. **They are not comparable across rows.**
- Almost no deployed Indian farmer assistant publishes an independent accuracy evaluation of its live answers. Treat claims about scale and impact as vendor/government self-reports unless noted otherwise.

---

## 1. Summary comparison table

| System | Builder | Modality | LLM / model | Grounded on real farmer data? | Languages | Offline? | Low-end / feature phone | Reported eval (caveated) | Scale (self-reported) |
|---|---|---|---|---|---|---|---|---|---|
| **Farmer.Chat** | Digital Green (NGO) | Text, voice, photo (Android app; earlier Telegram/WhatsApp) | RAG; GPT-4 + GPT-3.5 (2024 paper); later fine-tuned GPT-4o/4o-mini + Gemma 3n research | **Yes**: ~12k expert-validated Q&A pairs drawn from real farmer queries; 1.16M real farmer photos; field-recorded farmer speech | Hindi, Bhojpuri, Odia, Telugu, Swahili, Kikuyu, Amharic, Hausa, English, and others | No (low-connectivity "friendly" only) | Android smartphone needed | ~75% of queries answered (2024); FT F1 56.7% vs expert facts; 60% of active users act on advice (survey) | >1M users in India; ~2.06M across countries (FY25) |
| **Bharat-VISTAAR** ("Bharati") | MoA&FW (GoI), with state stacks (MahaVISTAAR etc.) | Voice helpline 155261, app, web, chat | Not disclosed | Not disclosed; grounded in AgriStack, ICAR PoPs, IMD, mandi data | Hindi + English at launch; 11 planned | No | **Yes**: basic-phone voice call | None published | Claims 140M+ farmers "connected" (platform, not users) |
| **MahaVISTAAR-AI** | Govt of Maharashtra + EkStep, COSS, FIDE | App (voice, photo), voice telephony | Not disclosed (Bhashini, OpenAgriNet stack) | Not disclosed | Marathi + others | No | Voice telephony added 2026 | None published | >1M downloads; "3M+ farmers supported" |
| **Kisan e-Mitra** | MoA&FW + Wadhwani AI (Google.org support) | Text + voice | Unnamed LLM + NLP intent; Bhashini IndicTrans2 | Scheme records (PM-KISAN beneficiary data), not agronomy | 11 | No | Smartphone/web | None published | 9.3M queries by Dec 2025 |
| **NPSS** | MoA&FW (uses ICAR AI-DISC models) | Photo upload | CV models (unnamed) | Field images (extension workers) | Not stated | No | Smartphone | None published | 10k+ extension workers; 66 crops, 432+ pests |
| **AI-DISC** | ICAR-IASRI | Photo | Deep learning on NIBPP image base | Expert-curated images | Not stated (regional langs planned) | Not stated | Smartphone | None published | >10k downloads |
| **Oilseeds Kisaan Mitra** | ICAR-IIOR + oilseed institutes | WhatsApp text | Not disclosed | ICAR knowledge base | "Any Indian language" (claim) | No | WhatsApp | None published | Not stated |
| **KissanAI / Dhenu** | KissanAI (startup, Pratik Desai) | Voice + text app; vision model | Dhenu2 (Llama 3.1 8B / 3.2 3B / 1B FT); earlier GPT-3.5 + Whisper | **Partly**: "mobile extension service logs", farmer feedback + synthetic (1.5M instructions) | 9 Indic (KissanGPT, 2023) | Small models could run locally; app is cloud | Smartphone | Dhenu Vision: 36.13% disease ID; no text benchmark numbers | 100k+ farmers (Microsoft page) |
| **AgriParam** | BharatGen (IIT Bombay-led, IndiaAI) | Text model only | Param-1 2.9B FT | **No**: synthetic Q&A from ~17k news/info passages | English, Hindi | Weights open (Apache-2.0); 2k context | n/a | BBK 32.18 (≈ Llama-3.2-3B's 31.96) | Model, not product |
| **Plantix** | PEAT (German/Indian) | Photo (app + WhatsApp bot) | Image recognition; no LLM | **Yes**: 150M+ farmer images since 2016 | 19 | No (upload needed) | Smartphone | Rated best of 17 apps on app *quality*; no diagnostic accuracy published | 10M+ downloads |
| **AgroStar** | AgroStar (Pune) | Photo, voice search, content, call centre | Proprietary, unnamed | **Yes**: real farm problems; 50k+ AI advisory posts | Multilingual (unspecified) | No | Smartphone + 10k stores | Survey: 81% "increased yield" (self-reported) | 10–12M farmers |
| **DeHaat** | DeHaat | Advisory via app + 11k centres | Not disclosed | Satellite, pest, soil, weather | "Multiple regional" | No | Phygital centres | None | 1.8M farmers |
| **BharatAgri** | BharatAgri | Text chatbot | GPT-based | Farmer field data + weather/soil/satellite | En, Hi, Mr (2023) | No | Smartphone | Bot handles ~30% of queries | 500k MAU (2023 claim) |
| **Gram Vaani / Mobile Vaani** | Gram Vaani | IVR voice (3 keys, missed-call) | Hindi NLP only (~70% transcription acc.) | **Yes**: community voice recordings | 12 languages incl. Desiya | Works on feature phones via IVR | **Yes** | Hindi ASR ~70% | 1M+ users |
| **Jugalbandi** | Microsoft + AI4Bharat + OpenNyAI | WhatsApp text/voice | Azure OpenAI + AI4Bharat models | Scheme docs | 10 | No | WhatsApp | None | Not stated |
| **Sarvam AI** | Sarvam | Voice agents (telephony + WhatsApp); STT/TTS APIs | Sarvam-105B, Saaras STT, Bulbul TTS | Not for agronomy | Indic auto-detect | On-prem possible (enterprise) | **Yes**: 8 kHz PSTN | None for agri | DCS pilot: 4 lakh farmers (Oct 2025) |
| **Cropin** (Sage, akṣara) | Cropin | B2B platform; akṣara text model | Gemini (Sage); Mistral-7B FT (akṣara) | Enterprise farm data; 5k Q&A for akṣara | Not specified | akṣara 4-bit open weights | n/a | akṣara "~40% more relevant than GPT-4 Turbo" by ROUGE (weak) | B2B |
| **Fasal** | Fasal | IoT sensors + app advisories | No GenAI assistant found | On-farm sensor data | Not stated | No | Smartphone + IoT | None | 75k+ acres (2024) |
| **Khetiyaar** | Khetiyaar (Gujarat) | Chat + photo (Android) | Not disclosed | Not disclosed | "Multiple" | No | Android | None | Not stated |
| **Microsoft** (FarmVibes, ITC Krishi Mitra) | Microsoft / ITC | FarmVibes = geospatial toolkit; Krishi Mitra = voice chatbot | Azure / Copilot stack | n/a | Regional (unspecified) | FarmVibes runs locally (for data scientists) | n/a | None | n/a |
| **Google** (ALU / AMED) | Google DeepMind | Satellite field-level APIs, not chat | Remote-sensing models; Gemini used by partners | Satellite imagery | n/a | n/a | n/a | None public | Used by Telangana ADEX (5M farmers design target) |
| **PxD PaddyAI** | Precision Development | Outbound voice calls/IVR, SMS | Not named (OpenAI is a partner) | Coffee advisories; A/B tested on real farmers | Kannada (+Ta/Te/Ml planned) | No | **Yes**: no smartphone needed | AI advisories non-inferior on listening rate (RCT A/B) | Pilot, one state |
| **Farmerline Darli** | Farmerline (Ghana) | IVR voice (toll-free), WhatsApp, image | NLU/ML; LLM not named | **Yes**: in-house ASR trained on real helpline farmer calls | 27 (55 planned) | No | **Yes**: basic phone IVR | None quantitative | 1M+ users, 8.5M interactions |
| **Farm Vaidya** | Farm Vaidya (startup) + IFPRI | Phone voice agent | Several LLMs + RAG restricted to verified advisories | **Yes**: 30k hrs farm audio; scientist–farmer recordings | Telugu, Tamil (10 langs of audio) | No | **Yes**: phone | Open-source STT ≥50% WER in field; target <3% | Beta: 5k+ minutes |
| **PlantVillage Nuru** | Penn State / FAO / IITA | Photo, **offline on-device** | On-device CNN | Field images | Not stated | **Yes** | Android | "Twice as accurate as extension workers" (claim) | 40+ countries |
| **UlizaLlama** | Jacaranda Health (Kenya) | Text LLM | Llama-2 7B, Swahili-adapted | **Not agricultural**: general Swahili; maternal health origin | Swahili, English | Weights available (non-commercial) | n/a | None for agri | n/a |

---

## 2. India: per-system notes

### 2.1 Digital Green, Farmer.Chat
- **Builder and history:** Digital Green (NGO). Launched in India in October 2024 ([AgroSpectrum, Aug 2026](https://agrospectrumindia.com/news/67/34548/farmerchat-digital-greens-ai-farming-assistant-crosses-10-lakh-users-in-india-smarter-2-0-version-launched.html)) [secondary]. Earlier deployments were in Kenya, Ethiopia and Nigeria ([arXiv 2409.08916](https://arxiv.org/html/2409.08916v2)).
- **Architecture (2024 paper):** RAG over a vector knowledge base, with GPT-4 used for filtering and re-ranking and GPT-3.5 for other steps. Queries are translated to English and back, which the authors found worked better than answering natively. ASR/TTS is pluggable (Google, Whisper). Plantix is used for disease diagnosis and TomorrowIO for weather ([arXiv 2409.08916](https://arxiv.org/html/2409.08916v2)).
- **Knowledge sources:** Research papers, policy documents, training manuals, banned-chemical tables, and transcribed YouTube/extension videos, all described as "expert vetted" ([arXiv 2409.08916](https://arxiv.org/html/2409.08916v2)). Kenya content comes partly from KALRO ([GitLab Foundation](https://www.gitlabfoundation.org/our-journey/empowering-kenyan-farmers-how-ai-is-revolutionizing-agriculture-with-digital-green)).
- **Real farmer data (strongest of anyone):**
  - 11,966 expert-validated "Golden" Q&A pairs built from real Farmer.Chat queries, out of more than 25,000 reviewed, yielding 110,723 "golden facts" across 60 crops ([arXiv 2603.03294](https://arxiv.org/html/2603.03294v1)).
  - About 1.16M real farmer photos from cheap phones; 46.8% were rejected by the quality gate ([arXiv 2609.21651](https://arxiv.org/abs/2609.21651)).
  - Field-recorded farmer speech in Hindi, Telugu and Odia ([arXiv 2609.20504](https://arxiv.org/abs/2609.20504)).
  - About 200K Q&A pairs released as open datasets ([DG FY25 Annual Report](https://digitalgreen.org/wp-content/uploads/2025/07/Digital-Green-FY25-Annual-Report.pdf)).
- **Languages:** Hindi, Bhojpuri, Odia, Telugu, Swahili, Kikuyu, Amharic, Hausa, English, and Portuguese in testing ([DG FY25](https://digitalgreen.org/wp-content/uploads/2025/07/Digital-Green-FY25-Annual-Report.pdf); [arXiv 2409.08916](https://arxiv.org/html/2409.08916v2)). The report says about 70% of interactions are in local languages. Digital Green is also refining small language models for Kikuyu, Bhojpuri, Hausa and Nigerian Pidgin ([CGAP](https://www.cgap.org/blog/beyond-chat-ai-powered-advice-for-women-farmers)).
- **Offline and low-end support:** Requires an Android app and data. Users explicitly asked for an offline mode ([arXiv 2409.08916](https://arxiv.org/html/2409.08916v2)). Zero-rated access via Safaricom raised messages about 1.2x ([CGAP](https://www.cgap.org/blog/beyond-chat-ai-powered-advice-for-women-farmers)).
- **Evaluation:**
  - About 75% of queries answered. Of unanswered queries, 66% were knowledge gaps. Mean latency was 9.05 s ([arXiv 2409.08916](https://arxiv.org/html/2409.08916v2)).
  - Fact-recall F1: vanilla GPT-4o-mini 37.2%, fine-tuned GPT-4o (130k) 56.7%. Fine-tuning *lowered* precision by about 11 points. The judge model was also one of the models being evaluated ([arXiv 2603.03294](https://arxiv.org/html/2603.03294v1)).
  - About 60% of active users act on advice (60 Decibels / IDinsight) ([AgroSpectrum](https://agrospectrumindia.com/news/67/34548/farmerchat-digital-greens-ai-farming-assistant-crosses-10-lakh-users-in-india-smarter-2-0-version-launched.html)).
  - A Kenya cluster RCT (600 villages, 2x2 design) is ongoing until March 2027, with no results yet ([AEA registry](https://www.socialscienceregistry.org/trials/17035)).
- **Scale:** More than 10 lakh users in India, more than 30 lakh queries, about 45% women ([AgroSpectrum](https://agrospectrumindia.com/news/67/34548/farmerchat-digital-greens-ai-farming-assistant-crosses-10-lakh-users-in-india-smarter-2-0-version-launched.html)). The FY25 report's query figures conflict internally: 165K overall vs ">1M in India" ([DG FY25](https://digitalgreen.org/wp-content/uploads/2025/07/Digital-Green-FY25-Annual-Report.pdf)).
- **Business model:** Grant-funded NGO (Meta Llama grant, GitLab Foundation, Gates, and others). Claimed cost is about Rs 33 per farmer per year versus about Rs 3,300 for in-person extension ([AgroSpectrum](https://agrospectrumindia.com/news/67/34548/farmerchat-digital-greens-ai-farming-assistant-crosses-10-lakh-users-in-india-smarter-2-0-version-launched.html); [Tech-ish](https://tech-ish.com/2024/09/30/meta-kenyan-ai-digital-green-jacaranda-health/)).
- **Weaknesses:**
  - Answers about a quarter of queries with nothing.
  - Usage is concentrated: 35% of users generate about 80% of queries.
  - Users find answers too technical.
  - Requires a smartphone, data and literacy.
  - Over a quarter of photo diagnoses return no crop name, and 35.8% of "disease" labels are actually pests ([arXiv 2409.08916](https://arxiv.org/html/2409.08916v2); [arXiv 2609.21651](https://arxiv.org/abs/2609.21651)).
- **Bottom line:** This is the most serious incumbent on data and evaluation rigour.

### 2.2 Bharat-VISTAAR (and the VISTAAR state stacks)
- **Builder and launch:** Ministry of Agriculture & Farmers Welfare. Announced in Budget 2026-27 and launched 17 Feb 2026 in Jaipur ([c4scourses](https://c4scourses.in/agriculture/bharat-vistaar-farmers-digital-companion/) [secondary]; [Drishti IAS](https://www.drishtiias.com/daily-updates/daily-news-analysis/bharat-vistaar/print_manually) [secondary]). ₹150 crore was allocated for 2026-27 ([Rising Kashmir](https://risingkashmir.com/bharat-vistaar155261) [secondary]).
- **Modality:** Toll-free voice helpline **155261** with an AI voice assistant, "Bharati", that works on basic phones. Also an app, a web portal and a chatbot ([c4scourses](https://c4scourses.in/agriculture/bharat-vistaar-farmers-digital-companion/); [InsightsIAS](https://www.insightsonindia.com/2026/02/17/bharat-vistaar/) [secondary]).
- **LLM:** Not disclosed in any source found. One opinion piece claims farmer data will be given to Microsoft to build the UFSP farmer interface **[UNVERIFIED; single secondary source]** ([Rising Kashmir](https://risingkashmir.com/bharat-vistaar155261)).
- **Knowledge sources:** AgriStack (farmer registry, land records, crop sown), ICAR packages of practice, IMD, mandi prices, and 10 central schemes ([c4scourses](https://c4scourses.in/agriculture/bharat-vistaar-farmers-digital-companion/); [NITI Frontier Tech](https://frontiertech.niti.gov.in/story/how-bharat-vistaar-is-connecting-140m-farmers-to-smarter-agriculture/)).
- **Languages:** Hindi and English at launch; 11 languages planned ([Drishti IAS](https://www.drishtiias.com/daily-updates/daily-news-analysis/bharat-vistaar/print_manually)). Dialect handling is not described.
- **States in Phase 1:** Maharashtra (MahaVISTAAR), Bihar (BiharKrishi), Gujarat (Sarlaben), Rajasthan ([c4scourses](https://c4scourses.in/agriculture/bharat-vistaar-farmers-digital-companion/)).
- **Stack (likely):** EkStep's "Voice AI for All" says MahaVISTAAR and Amul's Sarlaben were built with EkStep under "the VISTAAR DPI initiative". The stack uses the open-source VoicERA (telephony + ASR/TTS + LLM orchestration on Bhashini) and AI4Bharat IndicConformer/IndicTrans/IndicParler, at a claimed cost below ₹1 per minute ([voiceai.ekstep.org](https://voiceai.ekstep.org/)). Whether national "Bharati" runs on the same stack is **[UNVERIFIED]**.
- **Evaluation:** None published. NITI's own story frames success as better decisions, not answer accuracy ([NITI Frontier Tech](https://frontiertech.niti.gov.in/story/how-bharat-vistaar-is-connecting-140m-farmers-to-smarter-agriculture/)).
- **Scale:** The "140M+ farmers connected" figure is a platform reach claim, not active users ([NITI Frontier Tech](https://frontiertech.niti.gov.in/story/how-bharat-vistaar-is-connecting-140m-farmers-to-smarter-agriculture/)).
- **Business model:** Free public DPI.
- **Weaknesses and criticism:** No published accuracy, only two languages at launch, opacity about the model and data sharing, and the general risk of AI trained on industrial-farm data that NITI flags ([NITI Frontier Tech](https://frontiertech.niti.gov.in/story/how-bharat-vistaar-is-connecting-140m-farmers-to-smarter-agriculture/)).
- **Why it matters:** It has the distribution moat (free number, government data, AgriStack farm ID). Any new entrant competes with "free and official".

**MahaVISTAAR-AI (Maharashtra)**
- Launched 21 May 2025 with PoCRA ([Hitavada](https://www.thehitavada.com//Encyc/2026/6/16/ai-farmer-106-lakh-farmers-from-ngp-district-embrace-ai-powered-guidance-.html) [secondary]). Built with EkStep, COSS and FIDE on OpenAgriNet and Bhashini ([eGov](https://egov.eletsonline.com/2025/05/maharashtra-launches-mahavistaar-ai-to-digitally-empower-farmers-with-ai-driven-services/) [secondary]).
- More than 10 lakh downloads, a voice interface in Marathi, and photo upload ([Hitavada](https://www.thehitavada.com//Encyc/2026/6/16/ai-farmer-106-lakh-farmers-from-ngp-district-embrace-ai-powered-guidance-.html)). "3M+ farmers supported", and MahaVISTAAR Voice Telephony launched in Feb 2026 ([AgroSpectrum](https://agrospectrumindia.com/news/71/33499/maharashtra-launches-mahaagx-and-indias-first-bhili-tribal-llm-at-ai4agri2026.html)).
- Maharashtra also launched a Bhili tribal-language LLM. EkStep describes a Dehwali Bhili model for a language with about 10M speakers and no script ([AgroSpectrum](https://agrospectrumindia.com/news/71/33499/maharashtra-launches-mahaagx-and-indias-first-bhili-tribal-llm-at-ai4agri2026.html); [voiceai.ekstep.org](https://voiceai.ekstep.org/)). **This is the closest public effort to "dialect-native".**
- Farmers are asking for WhatsApp delivery ([Hitavada](https://www.thehitavada.com//Encyc/2026/6/16/ai-farmer-106-lakh-farmers-from-ngp-district-embrace-ai-powered-guidance-.html)).

**Sarlaben (Amul, Gujarat)**
- Voice AI for 3.6M dairy farmers in Gujarati, drawing on 5 decades of Amul data, launched Feb 2026 ([voiceai.ekstep.org](https://voiceai.ekstep.org/)).

### 2.3 Kisan e-Mitra (Wadhwani AI)
- **Builder:** MoA&FW. Launched Sept 2023; Wadhwani AI added AI/ML in Feb 2024 with Google.org support, plus Bhashini, EkStep, NIC and Samagra ([Wadhwani AI](https://www.wadhwaniai.org/empowering-millions-of-indian-farmers-with-instant-ai-chatbot-support/)).
- **Scope:** Scheme grievances (PM-KISAN first, then KCC and PMFBY). It is **not an agronomy assistant**.
- **Model:** NLP intent detection plus an unnamed LLM, with templated responses filled with beneficiary data. Translation uses IndicTrans2 ([Wadhwani AI](https://www.wadhwaniai.org/empowering-millions-of-indian-farmers-with-instant-ai-chatbot-support/)).
- **Languages and modality:** 11 languages, voice and text ([PIB, Feb 2026](https://static.pib.gov.in/WriteReadData/specificdocs/documents/2026/feb/doc2026214789901.pdf)).
- **Scale:** 2.69M queries in 186 days in 2024 ([Wadhwani AI](https://www.wadhwaniai.org/empowering-millions-of-indian-farmers-with-instant-ai-chatbot-support/)). More than 93 lakh queries by Dec 2025, about 8,000 per day ([PIB](https://static.pib.gov.in/WriteReadData/specificdocs/documents/2026/feb/doc2026214789901.pdf)). Apolitical reports 20k per day in April 2025 ([Apolitical](https://apolitical.co/en/navigator/case-studies/kisan-e-mitra-indias-voice-enabled-ai-support-for-farmers)), which suggests usage fluctuates or the sources count differently.
- **Evaluation:** No accuracy published.

### 2.4 ICAR AI-DISC and NPSS
- **AI-DISC (ICAR-IASRI):** Photo diagnosis of 55 diseases across 22 crops and 66 pests across 8 crops, using deep learning on the National Image Base for Plant Protection. More than 10k Play downloads. Regional languages are listed as a future plan. Its models are shared via API with NPSS and PoCRA ([ICAR-IASRI PDF](https://iasri.res.in/API/Content/UploadContent/638953620285071208.pdf)).
- **NPSS:** Launched 15 Aug 2024 by Minister Chouhan. Farmers and extension workers photograph pests and upload them ([Deccan Herald](https://deccanherald.com/india/agriculture-ministry-launches-national-app-to-collect-info-on-pest-attacks-in-crops-3153384) [secondary]). The government reports 66 crops, 432+ pest species and 10,000+ extension-worker users, with no farmer count or accuracy given ([PIB](https://static.pib.gov.in/WriteReadData/specificdocs/documents/2026/feb/doc2026214789901.pdf)).
- **Weakness:** Positioned as surveillance (data collection for government) more than farmer-facing advice. No published field accuracy.

### 2.5 Oilseeds Kisaan Mitra (ICAR-IIOR)
- WhatsApp AI advisory at +91 40 2459 8180, launched 6 Feb 2026. It covers groundnut, mustard, sesame, sunflower, soybean and niger, using a knowledge base from ICAR-IIOR, NSRI, DGR, DRMR and the sesame/niger PCU ([OpenGov Asia](https://opengovasia.com/india-launches-whatsapp-based-ai-advisory-service-for-oilseed-farmers/) [secondary]).
- The model, voice and photo support are not stated. The "any Indian language" claim is **[UNVERIFIED]**.
- It is a template for single-commodity ICAR bots: narrow crop scope with authoritative content.

### 2.6 KissanAI (KissanGPT, Dhenu models)
- **Builder:** KissanAI, founded by Pratik Desai.
- **KissanGPT (Mar 2023):** GPT-3.5 + Whisper, voice-first, 9 Indic languages ([IndiaAI](https://indiaai.gov.in/article/how-kissangpt-helps-indian-farmers-earn-profit)).
- **Current stack:** "Voice-based Copilot" on Azure OpenAI + Azure Speech, with 100k+ farmers reached by word of mouth ([Microsoft AI First Movers](https://microsoft.com/en-in/aifirstmovers/kissanai)).
- **Dhenu2 models:** Llama 3.1 8B, Llama 3.2 3B and 1B fine-tunes trained on more than 1.5M instructions. Sources are real and synthetic conversations, "mobile extension service logs", farmer feedback, PoP documents and localized studies. Licence is the Llama community licence. No quantitative benchmark is reported, only "expert review" ([HF model card](https://huggingface.co/KissanAI/Dhenu2-In-Llama3.2-3B-Instruct); [Featherless](https://featherless.ai/models/KissanAI/Dhenu2-In-Llama3.1-8B-Instruct)). The model card does not state languages.
- **Dhenu Vision (Qwen-VL LoRA):** Trained on synthetic data for 3 crops and 10 diseases, with **36.13%** identification success, below GPT-4 ([Analytics Vidhya](https://www.analyticsvidhya.com/blog/2024/03/kissanai-introduces-dhenu-vision-llms-for-crop-disease-detection/) [secondary]).
- **Offline:** 1B/3B models are small enough for on-device use in principle. No offline farmer app was found **[UNVERIFIED]**.
- **Business model:** Appears to be B2B "copilot" plus partnerships (UNDP announced) **[UNVERIFIED: AIM article did not load]**.

### 2.7 BharatGen AgriParam
- **Builder:** BharatGen (IndiaAI Mission, IIT Bombay-led). Released Aug 2025 ([BharatGen blog](https://bharatgen.com/agriparam-foundational-llm/); [X post](https://x.com/BharatGen_Com/status/1954026201288179890)).
- **Model:** Fine-tuned from Param-1-2.9B-Instruct, English and Hindi, 2,048-token context, Apache-2.0 ([HF card](https://huggingface.co/bharatgenai/AgriParam)).
- **Data:** About 17k agriculture news and information passages were expanded synthetically into about 2M Q&A pairs and about 6M multi-turn conversations, then translated to Hindi. **No real farmer data** ([BharatGen blog](https://bharatgen.com/agriparam-foundational-llm/)).
- **Evaluation:** On BhashaBench-Krishi, the overall score is **32.18**, essentially tied with Llama-3.2-3B (31.96) and granite-3.1-3b (32.17). Hindi scores 27.97, and hard questions are near chance ([HF card](https://huggingface.co/bharatgenai/AgriParam)). For comparison, GPT-4o scores 73.50 on the same benchmark ([arXiv 2510.25409](https://arxiv.org/html/2510.25409v1)).
- **Takeaway:** Sovereign branding, but no measurable domain advantage over generic small models. Param2 17B MoE (22 languages, Feb 2026) targets agriculture among other sectors ([Voice&Data](https://www.voicendata.com/artificialintelligence/bharatgen-launches-17b-ai-model-in-22-indian-languages-11100173) [secondary]).

### 2.8 Plantix (PEAT)
- **Modality:** Photo diagnosis via app and a free WhatsApp bot. Covers 400+ plant problems on 40+ crops, with 10M+ downloads ([Plantix blog](https://plantix.net/fr/blog/plant-disease-detection-whatsapp)).
- **Data:** More than 150M field images since 2016, 118M+ geotagged, in 19 languages ([Plantix Intelligence](https://plantix.net/en/plantix-intelligence/research/)). In 2019, India was about 80% of downloads and there were about 1M monthly active users ([CGIAR Big Data](https://bigdata.cgiar.org/digital-intervention/plant-disease-diagnosis-using-artificial-intelligence-a-case-study-on-plantix/)).
- **Evaluation:** Rated best of 17 apps (4.56/5) on *app quality*. **That study did not measure diagnostic accuracy** ([arXiv 2208.02446](https://arxiv.org/pdf/2208.02446)). The general caution for field accuracy: a classic PlantVillage CNN scored 99.35% on lab images but **31.4%** on images from other sources ([arXiv 1604.03169](https://arxiv.org/abs/1604.03169)).
- **Business model:** Free to farmers. Monetised through "Plantix Intelligence" (API, crop insights, "demand creation" for input companies) ([Plantix Intelligence](https://plantix.net/en/plantix-intelligence/research/)).
- **Offline:** No; images are uploaded for analysis ([CGIAR](https://bigdata.cgiar.org/digital-intervention/plant-disease-diagnosis-using-artificial-intelligence-a-case-study-on-plantix/)).
- **Possible conflict of interest:** Input "demand creation" incentivises product recommendations **[inference]**.

### 2.9 AgroStar
- **Scale and model:** Pune, founded 2013, 10M+ farmers, 10k+ retail stores, $30M raised for "AI-led agronomy". Content-led commerce: photo-based crop-problem advice, voice search to buy inputs, 200+ own-brand inputs ([Inc42](https://inc42.com/?p=539168) [secondary]).
- **AI:** Photo diagnosis with agronomist fallback and 50k+ AI advisory posts. Survey claims 81% "increased yield"; the methodology is not given ([AgroStar blog](https://corporate.agrostar.in/post/ai-that-listens-to-the-land-technology-that-works-for-farmers)).
- **ICAR:** MoU in May 2026 for AI-led advisory ([AgroSpectrum](https://agrospectrumindia.com/news/67/34055/icar-signs-mou-with-agrostar-to-spread-scientific-farming-practices-and-farmer-empowerment-in-india.html)).
- **Weakness:** Advice is coupled to selling inputs.

### 2.10 DeHaat
- 1.8M farmers in 12 states, 11,000+ DeHaat Centres, 503+ FPOs.
- AI advisory uses satellite, pest, weather and soil data in "multiple regional languages".
- No chatbot, voice or accuracy details are public ([NITI Frontier Tech](https://frontiertech.niti.gov.in/story/dehaats-ai-enabled-agriculture-network-driving-market-access-and-efficiency-for-1-8-million-farmers/)).
- A farmer-facing LLM assistant is **[UNVERIFIED]**.
- Its strength is the physical last-mile network.

### 2.11 BharatAgri
- GPT-based chatbot in English, Hindi and Marathi (2023), handling about 30% of queries. Recommends and sells inputs. Claims 500k monthly users ([YourStory Hindi, 2023](https://yourstory.com/hindi/iit-madras-agritech-startup-bharatagri-helping-farmers-farming-through-generative-ai) [secondary]).
- Voice was "under consideration" in 2023. Current status is **[UNVERIFIED]**.

### 2.12 Gram Vaani / Mobile Vaani
- IVR using only 3 keys and missed-call callback, so it is free to users. Runs in 120+ districts, about 20 states and 12 languages including Desiya (about 230k speakers), with 1M+ users ([GSMA case study](https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-for-development/wp-content/uploads/2024/04/Language-and-Digital-Humanitarian-Action_CaseStudies_MobileVaani_R.pdf)).
- **Human moderators** curate community audio. Only Hindi has NLP, at about **70% transcription accuracy**. Hindi dialect variation is a cited challenge ([GSMA](https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-for-development/wp-content/uploads/2024/04/Language-and-Digital-Humanitarian-Action_CaseStudies_MobileVaani_R.pdf)).
- **Lesson:** Voice-first community media works on feature phones, but is donor-dependent and costly per language.

### 2.13 Jugalbandi (Microsoft + AI4Bharat + OpenNyAI)
- WhatsApp text and voice access to 170+ government programmes in 10 languages. Uses AI4Bharat language models plus Azure OpenAI reasoning ([TechCrunch, May 2023](https://techcrunch.com/2023/05/24/microsoft-ai-chatgpt-reaches-rural-india/)).
- It is a scheme-information reference architecture, not agronomy. Its descendants are effectively the Bhashini/EkStep VISTAAR stacks **[inference]**.

### 2.14 Sarvam AI
- **Agriculture use case:** Sarvam's docs describe an agri/rural voice agent ("Krishi Mitra" example):
  - Saaras STT with language auto-detect, tolerant of 8 kHz telephony.
  - Sarvam-105B LLM.
  - Bulbul TTS.
  - Mandi prices and weather **must come from tools, not memory**.
  - The docs admit there is "no published cookbook example" yet ([Sarvam docs](https://docs.sarvam.ai/api-reference-docs/api-guides-tutorials/speech-to-text/use-cases/agri-rural.md)).
- **Real deployment:** MoA&FW Digital Crop Survey voice agents reached 4 lakh+ farmers in UP, Gujarat, Odisha and Kerala (Oct 2025). The target is up to 8 crore in Rabi 2026 ([Sarvam story](https://www.sarvam.ai/stories/dcs)). This is data *collection* from farmers, not advice.
- Dialect handling is not discussed ([Sarvam docs](https://docs.sarvam.ai/api-reference-docs/api-guides-tutorials/speech-to-text/use-cases/agri-rural.md)).
- **Role:** Sarvam is more likely an infrastructure supplier, or a competitor-enabler, than a direct farmer-app competitor.

### 2.15 Cropin
- **Sage:** A B2B agri-intelligence platform built with Gemini ([Google India blog](https://blog.google/intl/en-in/company-news/new-milestones-in-our-journey-to-build-inclusive-and-helpful-ai-for-india/)).
- **akṣara:** Open "micro language model" (Apr 2024), Mistral-7B fine-tuned with QLoRA 4-bit, covering 9 crops and trained on about 5k Q&A pairs. Claimed "~40% more relevant than GPT-4 Turbo" by ROUGE, which is a weak metric ([Cropin PR](https://www.cropin.com/press-release/cropin-launches-akṣara-a-micro-language-model-µ-lm-for-climate-smart-agriculture-targeting-underserved-farmers-in-the-global-south/)).
- Not a farmer-facing voice product.

### 2.16 Fasal
- AI + IoT SaaS for horticulture: 15+ crops, 75k+ acres, 13+ states, FY22 revenue ₹5.5 Cr ([Business Today, Jan 2024](https://www.businesstoday.in/amp/magazine/corporate/story/indias-coolest-start-ups-how-ai-powered-saas-platform-fasal-disrupted-indias-horticulture-space-412997-2024-01-12) [secondary]).
- No public LLM/voice assistant was found **[UNVERIFIED]**.
- Its strength is sensor ground truth from the farmer's own plot, which no chat assistant has.

### 2.17 Khetiyaar
- Gujarat Android app with chatbot, photo diagnosis, crop planning, mandi prices and a marketplace.
- Freemium coin model ("coins auto-refund if the AI fails").
- Languages and model are not disclosed. The only source is a third-party directory ([Stork.ai](https://www.stork.ai/en/khetiyaar) [secondary]).
- Everything about it is **[UNVERIFIED]** beyond the listing.

### 2.18 Microsoft (FarmVibes, Krishi)
- **FarmVibes.AI:** An open-source *geospatial* toolkit for data scientists (satellite, drone and weather fusion). **Not farmer-facing chat** ([GitHub](https://github.com/microsoft/farmvibes-ai)).
- **ITC Krishi Mitra:** A voice-to-text chatbot in ITCMAARS, built with Microsoft (Copilot), supporting regional languages ([ITC press report](https://itcportal.com/media-centre/press-report/itcs-krishi-mitra-uses-microsoft-copilot-to-help-farmers.html)).
- Microsoft also underpins Jugalbandi and KissanAI (Azure).

### 2.19 Google (ALU, AMED, Gemini)
- **ALU / AMED:** Field-boundary and crop-monitoring APIs from Google DeepMind, refreshed about every 2 weeks ([Google India blog](https://blog.google/intl/en-in/company-news/new-milestones-in-our-journey-to-build-inclusive-and-helpful-ai-for-india/)). Used by Telangana ADEX (designed for 5M+ farmers), the Krishivaas pilot, TerraStack and CarbonFarm (with Gemini) ([RuralVoice, Aug 2026](https://eng.ruralvoice.in/india-first-google-ai-models-scale-agricultural-solutions-from-farms-to-global-food-systems) [secondary]).
- **Project Vaani (with IISc):** About 21.5k hours of speech, 835 hours transcribed, 86 languages, 112k speakers, 120 districts. A dialect-rich open speech resource ([Google India blog](https://blog.google/intl/en-in/company-news/new-milestones-in-our-journey-to-build-inclusive-and-helpful-ai-for-india/)).
- A Google-branded "Gemini for farmers" or "AgriGenAI" farmer product was **not found**, so that name is **[UNVERIFIED]**. Google's role is infrastructure and data.

### 2.20 Other Indian items worth knowing
- **Farm Vaidya (Telugu voice agent, with IFPRI)** ([IFPRI blog, Apr 2026](https://www.ifpri.org/blog/generative-ai-powered-voice-technology-in-agricultural-advisory-services-lessons-from-india/)):
  - RAG restricted to verified university and government advisories.
  - Prompts force clarifying questions.
  - Own STT trained on 30k hours of farm audio. Open-source STT showed **≥50% error in field conditions**.
  - 5,000+ undocumented vernacular crop and pest terms collected.
  - Early answers sounded "robotic, textbook-like" even when correct.
  - **This is the closest existing design to the proposed app** (but cloud, phone-call based).
- **KisanSLM (independent, HF):** Qwen 2B QLoRA trained on about 13k real **Kisan Call Centre** Q&A pairs from data.gov.in, shipped as a 1.3 GB GGUF for offline use. Its own card says it "confidently fabricates market prices, phone numbers, and exact pesticide product names" ([HF card](https://huggingface.co/prabhu09/KisanSLM-GGUF)). The AIKosh listing calls it Qwen3-1.7B, which is inconsistent. **This shows that KCC transcripts are an open, real-farmer corpus** ([data.gov.in KCC](https://www.data.gov.in/resource/kisan-call-centre-kcc-transcripts-farmers-queries-answers)).
- **Wadhwani AI CottonAce:** Pest-trap photo early warning for cotton bollworm, reaching 6,000 farmers in 10 states (2021) ([Wadhwani AI](https://wadhwaniai.org/rcats/pest-management)). Offline operation is not confirmed on the page.
- **Tamil Nadu "Uzhavar AI":** ₹2 Cr voice-first advisory scheme in the 2026 agri budget; vendor not named ([DT Next](https://www.dtnext.in/news/tamilnadu/tn-budget-2026-govt-bets-on-ai-machine-learning-to-deliver-real-time-assistance-to-farmers) [secondary]).

---

## 3. Global systems

### 3.1 Precision Development (PxD), PaddyAI
- LLM-generated advisories for Coffee Krushi Taranga (Karnataka, Kannada), delivered by outbound voice call. No smartphone needed.
- **Randomised A/B test:** AI-written + AI voice vs AI-written + human voice vs human control. AI advisories met **non-inferiority** on listening rate, with slightly higher engagement.
- Partners: Coffee Board, OpenAI, Agency Fund, CGD. The LLM is not named ([PxD](https://precisiondev.org/project/accelerating-smallholder-access-to-ai-powered-agricultural-advice/)).
- PxD's earlier RCT evidence: $12–19 farmer profit per $1 ([PxD](https://precisiondev.org/project/accelerating-smallholder-access-to-ai-powered-agricultural-advice/)).
- **Strength:** The most rigorous causal-evaluation culture in the field. Its model is *push* advisories, not Q&A.

### 3.2 Farmerline Darli (Ghana / Africa)
- Toll-free IVR + WhatsApp + image diagnosis. 27 languages (55 planned), 1M+ users, 8.5M interactions ([GSMA](https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-for-development/programme/agritech/agronomic-advisory-enhanced-by-ai-insights-from-farmerline/); [GNA](https://gna.org.gh/2024/10/farmerlines-darli-ai-recognised-on-times-list-of-best-inventions-of-2024/)).
- **In-house ASR trained on real helpline calls** because open models fail on informal dialects.
- Pipeline translates to English and back, using Google Translate for translation. It translates *concepts*, not terms (e.g. mulching becomes "dead leaves on soil").
- Agronomists spot-test answers, and sentiment analysis escalates problem calls to humans. **No quantitative accuracy published** ([GSMA](https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-for-development/programme/agritech/agronomic-advisory-enhanced-by-ai-insights-from-farmerline/)).
- **Business model:** Agribusinesses pay to reach farmers through the call centre (B2B2F).
- TIME Best Inventions 2024 ([GNA](https://gna.org.gh/2024/10/farmerlines-darli-ai-recognised-on-times-list-of-best-inventions-of-2024/)).

### 3.3 Digital Green Kenya (Farmer.Chat Kenya)
- 14,000 users and 260,000 questions by end of 2023, with KALRO content and banned-pesticide guardrails.
- Self-reported: 57% improved quality of life in 45 days ([GitLab Foundation](https://www.gitlabfoundation.org/our-journey/empowering-kenyan-farmers-how-ai-is-revolutionizing-agriculture-with-digital-green)).
- Meta Llama grant of $500k for Swahili/Kikuyu work ([Tech-ish](https://tech-ish.com/2024/09/30/meta-kenyan-ai-digital-green-jacaranda-health/)).
- The 600-village RCT with IFPRI/UChicago runs until 2027 ([AEA](https://www.socialscienceregistry.org/trials/17035)).

### 3.4 UlizaLlama (Jacaranda Health, Kenya)
- **Correction to the brief: not an agricultural assistant.** It is a Llama-2 7B model continually pretrained on about 321.5M Swahili tokens, then instruction-tuned. Licence is CC BY-NC-SA. It lists agriculture only as one possible use ([HF card](https://huggingface.co/Jacaranda/UlizaLlama)). Jacaranda's core product is maternal health ([Tech-ish](https://tech-ish.com/2024/09/30/meta-kenyan-ai-digital-green-jacaranda-health/)).

### 3.5 PlantVillage Nuru (Penn State / FAO / IITA)
- **Works offline** on-device for cassava (and other crops). Claimed "twice as accurate as extension workers"; users in 40+ countries ([CGIAR Big Data](https://bigdata.cgiar.org/divi_overlay/plantvillage-nuru/)).
- **The main existing proof that offline photo diagnosis is viable.**

### 3.6 Cautionary incident
- A farmer in Chuzhou, China, lost about 25 acres of sesame after following a general chatbot's herbicide mix. The plan included a broadleaf herbicide on a broadleaf crop, despite an "AI may be incorrect" disclaimer ([TechRadar, Aug 2026](https://techradar.com/pro/farmer-ends-up-killing-25-acres-of-his-crops-after-trusting-ai-on-herbicide-advice) [secondary]).
- Farm Vaidya reports the same failure mode: wrong dosages from LLMs ([IFPRI](https://www.ifpri.org/blog/generative-ai-powered-voice-technology-in-agricultural-advisory-services-lessons-from-india/)).

---

## 4. 2025–2026 Indic agri LLM and speech benchmarks / papers

| Paper | What it measures | Key numbers | Caveats |
|---|---|---|---|
| **BhashaBench V1 / BhashaBench-Krishi** ([arXiv 2510.25409](https://arxiv.org/html/2510.25409v1)) | MCQs from 40+ Indian govt/professional agri exams, En + Hi, 25 subdomains | GPT-4o 75.3 En / 65.2 Hi; Llama-3.1-8B-Instruct 47.1 / 35.1; Llama-3.2-3B 40.6 / 29.1. **Every model is worse in Hindi** (about 10–18 pts) | Exam knowledge ≠ advising a farmer; MCQ format; no dialect or speech |
| **Benchmarking ASR for Indian languages in agriculture** ([arXiv 2602.03868](https://arxiv.org/abs/2602.03868)) | 10,934 real field recordings, Hindi/Telugu/Odia | Best WER Hindi 16.2%, Odia 35.1%; diarization cuts WER up to 66% on multi-speaker audio; proposes agri-weighted WER (AWWER) | Advisory content recordings; the abstract does not name the models |
| **Voice pipeline improvement (Digital Green)** ([arXiv 2609.20504](https://arxiv.org/abs/2609.20504)) | Model-agnostic pipeline: enhancement → diarization → ASR → agri-lexicon correction → quality gate | 16–23% relative WER reduction for cloud ASR, **only 5% for on-device ASR**; 32–42% on multi-speaker audio | Abstract gives relative numbers only |
| **Fine-tuning conversational AI for agri advisory (Digital Green)** ([arXiv 2603.03294](https://arxiv.org/html/2603.03294v1)) | Fact recall vs ~12k expert answers from real queries (Bihar, En/Hi) | F1 37.2% (vanilla 4o-mini) → 56.7% (FT 4o, 130k); Gemma 3n E4B best "stitcher" | LLM judge bias; no RAG baseline; one region |
| **Multi-stage vision pipeline (Digital Green)** ([arXiv 2609.21651](https://arxiv.org/abs/2609.21651)) | 1.16M real farmer photos | 46.8% rejected by quality gate; DaViT crop accuracy 95.41%; VLMs often decline to diagnose | Crop ID accuracy, not disease accuracy |
| **Synthetic data for multilingual agri QA (CSIR-CSIO)** ([arXiv 2507.16974](https://arxiv.org/html/2507.16974v2)) | En/Hi/Punjabi QA, human-rated | Zero-shot factuality: En 66.6%, **Hi 35.6%, Pa 24.3%**; translate-test beats native FT; LLM-judge vs human ρ ≈ 0.24–0.49 | 7–8B models only; text only |
| **Intent-aware multi-turn agri QA** ([arXiv 2508.03719](https://arxiv.org/abs/2508.03719)) | Clarifying-question dialogue + RAG, En/Hi with ASR/TTS | Claims 97.53% "query response accuracy" | Self-defined metric; small-scale; treat as optimistic |
| **AgriParam on BBK** ([HF](https://huggingface.co/bharatgenai/AgriParam)) | — | 32.18 overall, tied with generic 3B models | — |
| **Project Vaani** dataset ([Google](https://blog.google/intl/en-in/company-news/new-milestones-in-our-journey-to-build-inclusive-and-helpful-ai-for-india/)) | District-level dialect speech | 21.5k h audio, 835 h transcribed, 86 languages | Not agri-specific; mostly untranscribed |

**Industry WER claims (vendor, unaudited):** About 6–9% on clean Delhi Hindi, **17–24% on rural Bhojpuri-Maithili**, and 12–18% on rural Tamil/Telugu. Santhali, Mundari and Gondi are "still mostly a research problem" ([Caller.Digital blog](https://caller.digital/blog/voice-ai-agritech-farmer-calls-mandi-kcc-india-2026) [secondary, vendor]).

---

## 5. Gaps nobody fills

1. **Offline, on-device voice Q&A.**
   - Every LLM assistant found (Farmer.Chat, VISTAAR, KissanAI, Darli, Farm Vaidya, Kisan e-Mitra) is cloud-dependent.
   - Offline exists only for **photo** diagnosis (Nuru) or as a hobby model (KisanSLM GGUF).
   - Farmer.Chat users asked for offline mode ([arXiv 2409.08916](https://arxiv.org/html/2409.08916v2)).
2. **Published, independent answer accuracy for live systems.**
   - Bharat-VISTAAR, Kisan e-Mitra, NPSS, AgroStar, Plantix, Darli and KissanAI publish **no** accuracy on real farmer questions.
   - Digital Green is the partial exception, and even its best F1 against expert facts is about 57% ([arXiv 2603.03294](https://arxiv.org/html/2603.03294v1)).
3. **"Verified-only" answers with refusal.**
   - Systems either generate freely or use RAG that still paraphrases. Only Farm Vaidya explicitly restricts sources to verified advisories.
   - Incumbents rarely say "I don't know; here is who to call", although Farmer.Chat does decline about 25% of the time.
   - Wrong-dose risk is documented ([IFPRI](https://www.ifpri.org/blog/generative-ai-powered-voice-technology-in-agricultural-advisory-services-lessons-from-india/); [TechRadar](https://techradar.com/pro/farmer-ends-up-killing-25-acres-of-his-crops-after-trusting-ai-on-herbicide-advice)).
4. **Dialect-native speech.**
   - Most systems translate to English and back (Farmer.Chat, Darli) and use standard-language ASR/TTS.
   - Hindi factuality collapses relative to English (66.6% → 35.6%), and Punjabi reaches only 24.3% ([arXiv 2507.16974](https://arxiv.org/html/2507.16974v2)).
   - Open-source STT shows ≥50% error in the field ([IFPRI](https://www.ifpri.org/blog/generative-ai-powered-voice-technology-in-agricultural-advisory-services-lessons-from-india/)).
   - Bhojpuri and Bhili are just starting (Digital Green SLMs, EkStep Bhili).
   - TTS that *sounds like the farmer's own speech* is cited as missing ([IFPRI](https://www.ifpri.org/blog/generative-ai-powered-voice-technology-in-agricultural-advisory-services-lessons-from-india/)).
5. **Structured diagnostic questioning.**
   - Assistants answer the question as asked. Farmers often describe symptoms vaguely, and Farmer.Chat reported low query clarity ([arXiv 2409.08916](https://arxiv.org/html/2409.08916v2)).
   - No deployed system was found that uses explicit probabilistic (Bayesian) differential diagnosis to choose the next most-informative question.
   - Farm Vaidya and the intent-aware paper use prompt-driven clarifying questions, not calibrated probabilities.
6. **Pest vs disease confusion and abstention on photos.**
   - 35.8% of "disease" labels in real Farmer.Chat photos are pests, and 46.8% of photos are unusable ([arXiv 2609.21651](https://arxiv.org/abs/2609.21651)).
   - Lab-to-field accuracy collapse is well known (99% → 31%) ([arXiv 1604.03169](https://arxiv.org/abs/1604.03169)).
7. **Neutral advice.** Commercial leaders (AgroStar, BharatAgri, DeHaat, Plantix's demand-creation arm) monetise input sales. No scaled, input-neutral, verified advisor exists outside government and NGOs.
8. **Feature-phone voice plus agronomy depth.**
   - IVR systems (Gram Vaani, Darli, VISTAAR 155261, PxD) reach feature phones but are shallow, push-based or cloud-heavy.
   - Deep apps (Farmer.Chat, Plantix) require smartphones and data.

---

## 6. How an offline, verified-only, voice-to-voice, dialect-native app with Bayesian questioning could differentiate

### Where it could genuinely win
- **Works with zero connectivity and zero marginal cost per query.**
  - No incumbent LLM assistant does this. Fields, sheds and night-time irrigation (KissanGPT's observed use pattern ([IndiaAI](https://indiaai.gov.in/article/how-kissangpt-helps-indian-farmers-earn-profit))) are often low-signal.
  - Cloud systems pay per minute: about ₹1/min on the EkStep stack ([voiceai.ekstep.org](https://voiceai.ekstep.org/)), plus Farmer.Chat's GPT costs.
- **Safety by construction.**
  - Answers are retrieved from a closed, versioned, expert-signed corpus (ICAR PoPs, CIB&RC label claims, SAU advisories, KCC-validated answers). Doses are read verbatim from the corpus, never generated.
  - "I don't know" is the default when posterior confidence is low.
  - This directly targets the documented failure modes: wrong doses, fabricated product names ([KisanSLM card](https://huggingface.co/prabhu09/KisanSLM-GGUF)), and the sesame incident.
- **Bayesian questioning as the core UX.**
  - Ask the 2–4 questions that most reduce uncertainty: crop stage, leaf-underside vs top, pattern in field, recent spray or weather, insect seen.
  - Fuse those answers with an optional photo likelihood.
  - This addresses vague queries, pest-vs-disease confusion, and photo abstention better than one-shot LLM answers. It also produces auditable reasoning ("I think X 70%, Y 20% because…").
- **Dialect-native voice in and out.**
  - Speak in the farmer's dialect (Bhojpuri, Marwari, Bundeli, Varhadi, etc.), not "standard Hindi TTS". Farm Vaidya and Darli both found textbook speech hurts trust.
  - A narrow-domain, offline ASR with an agri lexicon and constrained vocabulary can beat general ASR on the terms that matter. Digital Green's AWWER and lexicon-correction work supports this ([arXiv 2602.03868](https://arxiv.org/abs/2602.03868); [arXiv 2609.20504](https://arxiv.org/abs/2609.20504)).
- **Neutrality.** No input sales and no "demand creation" make it a trust position the commercial apps cannot credibly claim.

### Where incumbents are stronger (be honest)
- **Distribution and legitimacy:**
  - Bharat-VISTAAR is free, official, has a short code (155261), works on feature phones, and is linked to the farmer's AgriStack ID, land record and scheme status. No standalone app can replicate this.
  - Kisan e-Mitra already handles scheme queries at more than 9M volume.
- **Real-farmer data scale:**
  - Digital Green has millions of real queries, 1.16M photos, field audio and expert-labeled gold sets.
  - Plantix has 150M images.
  - Darli has helpline audio.
  - A newcomer starts with roughly public KCC transcripts and must build its own field audio, which is slow and costly.
- **Live, dynamic data:** Mandi prices, weather, pest outbreaks and scheme status *require* connectivity. An offline app must sync opportunistically and will be stale. Sarvam's own guidance is that such facts must come from tools, not the model ([Sarvam docs](https://docs.sarvam.ai/api-reference-docs/api-guides-tutorials/speech-to-text/use-cases/agri-rural.md)).
- **Model quality:**
  - Cloud frontier models are far stronger: GPT-4o scores 73.5 on BBK vs about 38–45 for 3B–8B open models ([arXiv 2510.25409](https://arxiv.org/html/2510.25409v1)).
  - On-device ASR benefits least from pipeline fixes (5% vs 16–23% relative WER gain) ([arXiv 2609.20504](https://arxiv.org/abs/2609.20504)).
  - Verified-only retrieval narrows what the generator must do, but offline STT quality in dialects is the hardest technical risk.
- **Low-end phones:** True feature phones cannot run on-device models. "Offline" therefore means a low-to-mid Android with 2–4 GB RAM and storage for models plus the corpus. The very poorest farmers will still be better served by IVR (VISTAAR, Gram Vaani-style) **[inference]**.
- **Coverage:**
  - A verified-only corpus will refuse more often, and Farmer.Chat already fails about 25% of queries mostly for content gaps.
  - Refusal is safe but frustrating. It needs a warm handoff to KCC (1800-180-1551), KVK or 155261.
- **Human-in-the-loop:** AgroStar, Darli and Gram Vaani all route hard cases to humans or moderators. An offline app has no live human. It can only queue callbacks when back online.
- **Evidence bar:** PxD and Digital Green run RCTs. Credibility with government and funders will require the same.

### Practical positioning implications
1. Position as the **"trusted offline field companion that complements 155261/VISTAAR"**, not a replacement. Hand off scheme, price and status questions to official channels.
2. Build the verified corpus from **ICAR PoPs + CIB&RC label data + KCC transcripts (filtered and expert-validated) + Digital Green's open Golden Q&A**, the latter where licences allow ([DG FY25](https://digitalgreen.org/wp-content/uploads/2025/07/Digital-Green-FY25-Annual-Report.pdf)) **[licence terms UNVERIFIED]**.
3. Publish a benchmark from day one: answer accuracy on held-out real farmer questions, dose-error rate, abstention rate, and dialect WER (AWWER). Almost nobody else publishes this, so it is a differentiator in itself.
4. Start with 1–2 dialects and a few crops where you can reach measurable quality, rather than "22 languages". Breadth is where government and Digital Green will always win.
