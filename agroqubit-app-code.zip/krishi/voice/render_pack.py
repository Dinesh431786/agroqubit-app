"""Render every catalogue utterance to audio, per language, offline. Engine here = espeak-ng (the only offline TTS in this
workspace). Same ids/layout are used by render_parler.py for human-like voices on a GPU. Output: Opus 24 kbps mono."""
import json, os, subprocess, sys, numpy as np, soundfile as sf
sys.path.insert(0, "/home/claude/krishi/speech"); from synth import say
C = json.load(open("catalogue.json")); OUT = "pack_espeak"; os.makedirs(OUT, exist_ok=True)
VOICE = {"hi": ("f3", 140, 55), "ta": ("f3", 140, 55), "kn": ("f3", 140, 55), "en": ("f3", 150, 55)}
stats = {}
for cid, texts in C.items():
    for lang, text in texts.items():
        v, rate, pitch = VOICE[lang]; x = say(text, lang, v, rate, pitch)
        x = np.concatenate([np.zeros(1600, np.float32), x / (np.abs(x).max() + 1e-6) * 0.8, np.zeros(2400, np.float32)])
        wav = f"/tmp/claude-0/{cid}_{lang}.wav"; os.makedirs("/tmp/claude-0", exist_ok=True); sf.write(wav, x, 16000)
        out = f"{OUT}/{lang}/{cid}.opus"; os.makedirs(os.path.dirname(out), exist_ok=True)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libopus", "-b:a", "24k", "-ac", "1", out], check=True)
        os.remove(wav); s = stats.setdefault(lang, [0, 0.0, 0]); s[0] += 1; s[1] += len(x) / 16000; s[2] += os.path.getsize(out)
for l, (n, sec, b) in stats.items(): print(f"{l}: {n} clips, {sec/60:.1f} min of speech, {b/1e6:.2f} MB")
print("total MB", round(sum(s[2] for s in stats.values()) / 1e6, 2))
