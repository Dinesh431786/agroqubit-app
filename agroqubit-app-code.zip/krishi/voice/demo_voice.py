"""Listenable voice-to-voice demos. Farmer turns = held-out test audio (unseen voices); app turns = voice pack.
Writes demo_<lang>.mp3 + transcript."""
import json, os, sys, random, subprocess, numpy as np, soundfile as sf
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/krishi/brain")
from voice_chat import VoiceChat, load_clip
from chat import SpeechUnderstanding
K = "/home/claude/krishi"; random.seed(5)
SPD = dict(np.load(f"{K}/speech/test.npz")); SPM = json.load(open(f"{K}/speech/test_meta.json")); OFF = np.concatenate([[0], np.cumsum(SPD["lens"])])
CAT = json.load(open("catalogue.json"))  # colloquial spoken script
SP = SpeechUnderstanding(enc=f"{K}/speech/speech_enc_v2.pt", p2m=f"{K}/speech/phon2meaning_v2.pt")
def clip(lang, slots):
    c = [i for i, m in enumerate(SPM) if m["lang"] == lang and sorted(m["slots"]) == sorted(slots)]
    if not c: return None, None
    i = random.choice(c); return SPD["audio"][OFF[i]:OFF[i+1]].astype(np.float32), SPM[i]
gap = np.zeros(int(16000 * 0.5), np.float32); results = {}
for lang, disease, opening in [("ta", "rice_blast", ["crop_rice"]), ("hi", "tomato_leaf_curl", ["crop_tomato"]), ("kn", "groundnut_rust", ["crop_groundnut"]),
                               ("en", "chilli_powdery_mildew", ["crop_chilli"])]:
    vc = VoiceChat(lang, speech=SP); track = [load_clip("greet", lang), gap]; lines = [f"APP: {CAT['greet'][lang]}"]
    a, m = clip(lang, opening); track += [a, gap]; lines.append(f"FARMER ({m['voice']}): {m['text']}")
    r, ids, audio = vc.turn_voice(a); n = 0
    while True:
        track += [audio, gap]; lines.append("APP: " + " ".join(CAT[c][lang] for c in ids))
        if r["type"] not in ("question", "not_understood") or n > 7: break
        q = r["qid"]; n += 1
        if q == "__crop__": r = vc.turn(tap=vc.brain.core.crops[vc.brain.core.names.index(disease)]); ids = ["filler_ok", f"q_{r['qid']}"] if r["type"] == "question" else []; lines.append("FARMER taps crop"); audio = np.concatenate([load_clip(c, lang) for c in ids]); continue
        if q.startswith("pic_"):
            r = vc.turn(tap=disease); lines.append("FARMER taps the matching photo")
            from voice_chat import clips_for; ids = clips_for(r, lang); audio = np.concatenate([load_clip(c, lang) for c in ids]); continue
        th = vc.brain.core.theta[q][vc.brain.core.names.index(disease)]
        want = ["part_" + vc.brain.core.opts[q][int(np.argmax(th))]] if q == "part" else (["ans_yes"] if th[0] > .5 else ["ans_no"])
        a, m = clip(lang, want); track += [a, gap]; lines.append(f"FARMER ({m['voice']}): {m['text']}")
        r, ids, audio = vc.turn_voice(a)
    out = np.concatenate(track); TAG = os.environ.get("DEMO_TAG", ""); sf.write(f"demo{TAG}_{lang}.wav", out, 16000)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", f"demo{TAG}_{lang}.wav", "-b:a", "48k", f"demo{TAG}_{lang}.mp3"], check=True)
    ok = r.get("disease") == disease
    results[lang] = dict(true=disease, got=r.get("disease"), correct=ok, seconds=round(len(out) / 16000, 1))
    open(f"demo{TAG}_{lang}.txt", "w").write("\n".join(lines) + f"\n\nRESULT: {r.get('disease')} (true: {disease})\n")
    print(f"\n=== {lang} ===\n" + "\n".join(lines) + f"\nRESULT {r.get('disease')} conf {r.get('confidence')}  correct={ok}")
json.dump(results, open(f"demo{TAG}_results.json", "w"), indent=1); print(results)
