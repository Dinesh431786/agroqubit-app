"""Checks: (1) every clip decodes, is non-silent, sensible length; (2) round-trip: our own phoneme recogniser listens to the
app's clips and we measure phoneme error vs espeak's phoneme transcription; (3) 'didn't understand' path re-asks."""
import json, sys, re, numpy as np, torch
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/krishi/speech")
from voice_chat import load_clip, VoiceChat
from decode import load, decode, per
from synth import phonemes
CAT = json.load(open("catalogue.json")); R = {"clips": {}, "roundtrip_PER": {}}
net = load("/home/claude/krishi/speech/speech_enc_v2.pt")
for lang in ["hi", "ta", "kn", "en"]:
    xs, bad, durs = [], [], []
    for cid in CAT:
        x = load_clip(cid, lang); xs.append(x); durs.append(len(x) / 16000)
        if np.sqrt((x ** 2).mean()) < 0.01 or len(x) < 16000 * 0.5: bad.append(cid)
    R["clips"][lang] = dict(n=len(xs), silent_or_too_short=bad, min_s=round(min(durs), 2), max_s=round(max(durs), 2))
    lens = np.array([len(x) for x in xs]); hyp = decode(net, np.concatenate(xs), lens, "clean")
    refs = [re.sub(r"[ˈˌ\s]", "", phonemes(CAT[c][lang], lang)) for c in CAT]
    R["roundtrip_PER"][lang] = round(float(np.mean([per(h, r) for h, r in zip(hyp, refs)])), 3)
# (3) farmer answers a question with pure noise -> app must say "didn't understand" and repeat the question
from chat import SpeechUnderstanding
SP = SpeechUnderstanding(enc="/home/claude/krishi/speech/speech_enc_v2.pt", p2m="/home/claude/krishi/speech/phon2meaning_v2.pt")
vc = VoiceChat("hi", speech=SP); vc.turn(tap=None); vc.brain.set_crop("rice"); r0 = vc.turn(); q = r0.get("qid")
r, ids, _ = vc.turn_voice((np.random.default_rng(0).standard_normal(16000 * 2) * 0.05).astype(np.float32))
R["noise_answer"] = dict(question=q, reply_type=r["type"], clips=ids)
print(json.dumps(R, indent=1, ensure_ascii=False)); json.dump(R, open("verify_voice.json", "w"), indent=1, ensure_ascii=False)
