"""Render the full app voice pack with human-recorded voices (AI4Bharat Indic-TTS, female speaker), offline.
Text is normalised so nothing is silently dropped: Latin acronyms/words inside Indic text are spelled in native script,
the helpline number is read digit by digit, punctuation the model doesn't know is mapped to pauses."""
import json, os, re, subprocess, sys, numpy as np, soundfile as sf, torch
sys.path.insert(0, "."); from indic_tts import synth, say
from scipy.signal import resample_poly
C = json.load(open("catalogue.json")); import os
OUT = os.environ.get("PACK_OUT", "pack_human"); SPK = os.environ.get("SPEAKER", "female")
DIG = {"hi": "शून्य एक दो तीन चार पाँच छह सात आठ नौ".split(), "ta": "பூஜ்யம் ஒன்று இரண்டு மூன்று நான்கு ஐந்து ஆறு ஏழு எட்டு ஒன்பது".split(),
       "kn": "ಸೊನ್ನೆ ಒಂದು ಎರಡು ಮೂರು ನಾಲ್ಕು ಐದು ಆರು ಏಳು ಎಂಟು ಒಂಬತ್ತು".split(), "en": "zero one two three four five six seven eight nine".split()}
LATIN = {"hi": {"KVK": "के वी के", "AM": "", "PM": ""}, "ta": {"KVK": "கே வி கே"}, "kn": {"KVK": "ಕೆ ವಿ ಕೆ"}, "en": {"KVK": "K V K", "6 AM-10 PM": "six in the morning to ten at night"}}
WORD = {"hi": {"4": "चार", "5": "पाँच", "6": "छह", "10": "दस"}, "ta": {"4": "நான்கு", "5": "ஐந்து", "6": "ஆறு", "10": "பத்து"},
        "kn": {"4": "ನಾಲ್ಕು", "5": "ಐದು", "6": "ಆರು", "10": "ಹತ್ತು"}, "en": {"4": "four", "5": "five", "6": "six", "10": "ten"}}
PCT = {"hi": "प्रतिशत", "ta": "சதவீதம்", "kn": "ಶೇಕಡಾ", "en": "percent"}
def norm(t, lang):
    t = re.sub(r"\d{4}-\d{3}-\d{4}", lambda m: ", ".join(" ".join(DIG[lang][int(c)] for c in g) for g in m.group(0).split("-")), t)
    for k, v in LATIN[lang].items(): t = t.replace(k, v)
    t = re.sub(r"(\d+)\s*%", lambda m: f"{WORD[lang][m.group(1)]} {PCT[lang]}", t)
    t = re.sub(r"\b(\d+)\b", lambda m: WORD[lang].get(m.group(1), " ".join(DIG[lang][int(c)] for c in m.group(1))), t)
    t = t.replace("AM-", " ").replace("AM", "").replace("PM", "") if lang == "en" else t
    t = t.replace("।", ".").replace("—", ",").replace("–", ",").replace(";", ",").replace(":", ",").replace("/", " ").replace("(", ", ").replace(")", ", ")
    return re.sub(r"\s+", " ", re.sub(r"\s*,\s*(,\s*)+", ", ", t)).strip(" ,")
def oov(t, lang):
    chars = synth(lang).tts_model.tokenizer.characters.vocab if hasattr(synth(lang).tts_model, "tokenizer") else None
    return sorted({c for c in t if chars is not None and c not in chars and c != " "})
if __name__ == "__main__":
    report = {}
    for lang in ["hi", "ta", "kn", "en"]:
        bad = {}
        for cid, texts in C.items():
            t = norm(texts[lang], lang); o = oov(t, lang)
            if o: bad[cid] = o
            out = f"{OUT}/{lang}/{cid}.opus"
            if os.path.exists(out): continue
            os.makedirs(os.path.dirname(out), exist_ok=True)
            w, sr = say(t, lang, SPK); w = resample_poly(w, 16000, sr).astype(np.float32)
            w = np.concatenate([np.zeros(1600, np.float32), w / (np.abs(w).max() + 1e-6) * 0.85, np.zeros(2400, np.float32)])
            tmp = f"/tmp/claude-0/h_{OUT.replace('/', '_')}_{cid}_{lang}.wav"; os.makedirs("/tmp/claude-0", exist_ok=True); sf.write(tmp, w, 16000)
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libopus", "-b:a", "24k", "-ac", "1", out], check=True); os.remove(tmp)
        report[lang] = bad; print(lang, "done; characters still unknown:", bad, flush=True)
    json.dump(report, open("render_human_report.json", "w"), ensure_ascii=False, indent=1)
