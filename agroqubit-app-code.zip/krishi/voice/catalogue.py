"""Every sentence the app can SAY, per language. Because answers are never generated, this list is complete:
questions, disease names, advice first-steps, referral, fillers, greetings. Each gets a stable id -> one audio clip."""
import json, sys
sys.path.insert(0, "/home/claude/krishi/brain")
K = "/home/claude/krishi"; LANGS = ["hi", "ta", "kn", "en"]
kb = json.load(open("/home/claude/agri_reason/v2/knowledge_v2.json")); adv = json.load(open(f"{K}/brain/advice.json"))
from brain import Brain
b = Brain(); C = {}
def add(cid, texts): C[cid] = {l: texts[l] for l in LANGS}
add("greet", {"en": "Namaste. Tell me your crop and what you see on the plant. You can also take a photo.",
              "hi": "नमस्ते। अपनी फसल और पौधे पर जो दिख रहा है वो बताइए। आप फोटो भी ले सकते हैं।",
              "ta": "வணக்கம். உங்கள் பயிர் என்ன, செடியில் என்ன தெரிகிறது என்று சொல்லுங்கள். படமும் எடுக்கலாம்.",
              "kn": "ನಮಸ್ಕಾರ. ನಿಮ್ಮ ಬೆಳೆ ಮತ್ತು ಗಿಡದಲ್ಲಿ ಏನು ಕಾಣುತ್ತಿದೆ ಎಂದು ಹೇಳಿ. ಫೋಟೋ ಕೂಡ ತೆಗೆಯಬಹುದು."})
add("filler_think", {"en": "Hmm, let me see.", "hi": "हम्म, देखते हैं।", "ta": "ம்ம், பார்க்கலாம்.", "kn": "ಹ್ಮ್, ನೋಡೋಣ."})
add("filler_ok", {"en": "Okay.", "hi": "अच्छा।", "ta": "சரி.", "kn": "ಸರಿ."})
add("didnt_hear", {"en": "Sorry, I did not understand. Please say yes or no, or tap the button.",
                   "hi": "माफ़ कीजिए, समझ नहीं आया। हाँ या ना बोलिए, या बटन दबाइए।",
                   "ta": "மன்னிக்கவும், புரியவில்லை. ஆம் அல்லது இல்லை என்று சொல்லுங்கள், அல்லது பொத்தானை அழுத்துங்கள்.",
                   "kn": "ಕ್ಷಮಿಸಿ, ಅರ್ಥವಾಗಲಿಲ್ಲ. ಹೌದು ಅಥವಾ ಇಲ್ಲ ಎಂದು ಹೇಳಿ, ಅಥವಾ ಬಟನ್ ಒತ್ತಿ."})
add("likely", {"en": "Most likely this is:", "hi": "सबसे ज़्यादा संभावना है:", "ta": "பெரும்பாலும் இது:", "kn": "ಹೆಚ್ಚಾಗಿ ಇದು:"})
add("first_step", {"en": "First do this:", "hi": "पहले यह करें:", "ta": "முதலில் இதைச் செய்யுங்கள்:", "kn": "ಮೊದಲು ಇದನ್ನು ಮಾಡಿ:"})
add("generic_kvk", adv["generic"])
for q in b.core.qids + ["__crop__"]:
    add(f"q_{q}", {l: b.question_text(q, l) for l in LANGS})
NAMES_EN = {k: k.replace("_", " ") for k in kb["diseases"]}
for k, e in kb["diseases"].items():
    nm = e.get("names", {}); add(f"name_{k}", {l: nm.get(l, NAMES_EN[k]) for l in LANGS})
for k, a in adv["advice"].items(): add(f"adv_{k}", a["first"])
json.dump(C, open("catalogue.json", "w"), ensure_ascii=False, indent=1)
missing = [k for k in kb["diseases"] if not kb["diseases"][k].get("names", {}).get("hi")]
print(len(C), "utterances x", len(LANGS), "languages;", len(missing), "diseases still lack local names")
