"""Voice-to-voice loop: farmer speaks -> app understands (speech -> phonemes -> meaning) -> app ANSWERS BY VOICE by
playing pre-rendered clips (no TTS model on the phone, zero compute, fully offline). Text + buttons stay on screen too."""
import json, subprocess, sys, numpy as np
sys.path.insert(0, "/home/claude/krishi/brain"); from chat import Chat, SpeechUnderstanding
import os
PACK = os.environ.get("KRISHI_VOICE_PACK", "/home/claude/krishi/voice/pack_human")

def clips_for(reply, lang):
    t = reply["type"]
    if t == "question": return ["filler_ok", f"q_{reply['qid']}"]
    if t == "diagnosis":
        ids = ["filler_think", "likely", f"name_{reply['disease']}", "first_step"]
        ids += [f"adv_{reply['disease']}"] if reply.get("source") else ["generic_kvk"]
        if reply["confidence"] < 0.75: ids.append("generic_kvk")
        return ids
    if t in ("not_sure", "referral"): return ["filler_think", "generic_kvk"]
    if t == "not_understood": return ["didnt_hear"]
    return []

def load_clip(cid, lang):
    p = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", f"{PACK}/{lang}/{cid}.opus", "-f", "f32le", "-ac", "1", "-ar", "16000", "-"], capture_output=True, check=True)
    return np.frombuffer(p.stdout, np.float32)

class VoiceChat(Chat):
    def turn_voice(self, audio):
        before = (len(self.brain.st["asked"]) if self.brain.st else 0, self.last_q)
        r = self.turn(audio=audio)
        # if the farmer's reply to a question changed nothing, say "didn't understand" and re-ask (instead of guessing)
        if r["type"] == "question" and before[1] not in (None, "__crop__") and r.get("qid") == before[1]:
            r = {"type": "not_understood", "qid": before[1]}
        ids = clips_for(r, self.lang)
        if r["type"] == "not_understood": ids += [f"q_{before[1]}"]
        return r, ids, np.concatenate([load_clip(c, self.lang) for c in ids]) if ids else np.zeros(1, np.float32)
