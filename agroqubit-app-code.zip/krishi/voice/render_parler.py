"""Human-like voice pack with AI4Bharat Indic Parler-TTS (Apache-2.0, 0.9B). Run on a GPU machine with internet
(Colab / AWS g5). It writes the SAME ids and layout as render_pack.py, so the app just swaps pack_espeak -> pack_parler.
NOT run in the build workspace (no GPU, Hugging Face blocked) — untested here.

    pip install git+https://github.com/huggingface/parler-tts.git soundfile
    python render_parler.py catalogue.json pack_parler
"""
import json, os, re, subprocess, sys, torch, soundfile as sf
from parler_tts import ParlerTTSForConditionalGeneration
from transformers import AutoTokenizer

CAT, OUT = sys.argv[1], sys.argv[2]
dev = "cuda" if torch.cuda.is_available() else "cpu"
model = ParlerTTSForConditionalGeneration.from_pretrained("ai4bharat/indic-parler-tts").to(dev)
tok = AutoTokenizer.from_pretrained("ai4bharat/indic-parler-tts")
desc_tok = AutoTokenizer.from_pretrained(model.config.text_encoder._name_or_path)
# Recommended speakers from the model card (Hindi: Divya, Tamil: Jaya, Kannada: Anu). English speaker: check the card.
SPEAKER = {"hi": "Divya", "ta": "Jaya", "kn": "Anu", "en": "Mary"}
STYLE = ("{s} speaks in a warm, calm, slow and respectful voice, like a friendly village agriculture officer, "
         "with very clear audio and no background noise.")
DIGITS = {"hi": "शून्य एक दो तीन चार पाँच छह सात आठ नौ".split(), "ta": "பூஜ்யம் ஒன்று இரண்டு மூன்று நான்கு ஐந்து ஆறு ஏழு எட்டு ஒன்பது".split(),
          "kn": "ಸೊನ್ನೆ ಒಂದು ಎರಡು ಮೂರು ನಾಲ್ಕು ಐದು ಆರು ಏಳು ಎಂಟು ಒಂಬತ್ತು".split(), "en": "zero one two three four five six seven eight nine".split()}

def speakable(text, lang):
    # read the helpline number digit by digit, drop symbols TTS models stumble on
    text = re.sub(r"\d{4}-\d{3}-\d{4}", lambda m: " ".join(DIGITS[lang][int(c)] for c in m.group(0) if c.isdigit()), text)
    return text.replace("—", ",").replace("(", ",").replace(")", ",")

C = json.load(open(CAT))
for cid, texts in C.items():
    for lang, text in texts.items():
        out = f"{OUT}/{lang}/{cid}.opus"
        if os.path.exists(out): continue
        os.makedirs(os.path.dirname(out), exist_ok=True)
        d = desc_tok(STYLE.format(s=SPEAKER[lang]), return_tensors="pt").to(dev)
        p = tok(speakable(text, lang), return_tensors="pt").to(dev)
        with torch.no_grad():
            wav = model.generate(input_ids=d.input_ids, attention_mask=d.attention_mask,
                                 prompt_input_ids=p.input_ids, prompt_attention_mask=p.attention_mask).cpu().numpy().squeeze()
        tmp = f"/tmp/{cid}_{lang}.wav"; sf.write(tmp, wav, model.config.sampling_rate)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-ar", "16000", "-ac", "1", "-c:a", "libopus", "-b:a", "24k", out], check=True)
        os.remove(tmp)
print("done:", OUT)
