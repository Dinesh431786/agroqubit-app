"""Render the closed-world voice pack: every sentence the app can say (segments.json from closed_world.py) with a human
neural voice (AI4Bharat Indic-TTS FastPitch + HiFi-GAN, MIT), offline, at build time.
Speech text comes from verbalize.py (numbers, product names, helpline said the way people say them; Hindi verbs follow
the speaker). Long answers are synthesised one sentence at a time and joined with short natural pauses.
Output: <PACK_OUT>/<lang>/<id>.ogg  (16 kHz mono Opus, 16 kbps - speech-band audio, ~2 KB per second)
Usage: SPEAKER=female PACK_OUT=pack_f LANGS=hi,ta python3 render_segments.py segments.json"""
import json, os, subprocess, sys, time, numpy as np, soundfile as sf
from scipy.signal import resample_poly
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from indic_tts import say
from verbalize import sentences

SEG = json.load(open(sys.argv[1])); OUT = os.environ.get("PACK_OUT", "pack_f"); SPK = os.environ.get("SPEAKER", "female")
V = "m" if SPK == "male" else "f"; LANGS = os.environ.get("LANGS", "hi,ta,kn,en").split(","); BR = os.environ.get("BITRATE", "16k")
TMP = os.environ.get("TMPDIR", "/tmp"); GAP = np.zeros(int(0.28 * 16000), np.float32)
report = {}
for lang in LANGS:
    rows = []; t_lang = time.time()
    for cid, s in SEG[lang].items():
        out = f"{OUT}/{lang}/{cid}.ogg"
        if os.path.exists(out): continue
        os.makedirs(os.path.dirname(out), exist_ok=True); t0 = time.time(); parts = []
        for sent in sentences(s[V]):
            w, sr = say(sent, lang, SPK); w = resample_poly(np.asarray(w, np.float32), 16000, sr).astype(np.float32)
            nz = np.where(np.abs(w) > 0.01 * (np.abs(w).max() + 1e-9))[0]             # trim the model's own leading/trailing silence
            if len(nz): w = w[max(0, nz[0] - 800): nz[-1] + 1600]
            parts += [w, GAP]
        w = np.concatenate(parts[:-1]); w = w / (np.abs(w).max() + 1e-6) * 0.85
        w = np.concatenate([np.zeros(800, np.float32), w, np.zeros(1600, np.float32)])
        tmp = f"{TMP}/r_{V}_{lang}_{cid}.wav"; sf.write(tmp, w, 16000)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libopus", "-b:a", BR, "-ac", "1", "-application", "voip", out], check=True)
        os.remove(tmp); rows.append({"id": cid, "sec": round(len(w) / 16000, 2), "render_s": round(time.time() - t0, 2), "kb": round(os.path.getsize(out) / 1024, 1)})
    report[lang] = {"clips": len(rows), "audio_min": round(sum(r["sec"] for r in rows) / 60, 1), "render_min": round((time.time() - t_lang) / 60, 1),
                    "kb": round(sum(r["kb"] for r in rows)), "rows": rows}
    print(lang, SPK, {k: v for k, v in report[lang].items() if k != "rows"}, flush=True)
json.dump(report, open(f"{OUT}/render_report_{V}_{'_'.join(LANGS)}.json", "w"), indent=0)
