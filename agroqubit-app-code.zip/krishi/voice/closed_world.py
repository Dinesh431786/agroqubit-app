"""Closed-world voice. The app never generates text: everything it can say is a verified sentence that already exists
at build time (questions, disease names, government IPM advice items, fixed phrases). So instead of shipping a TTS model
to a 2 GB phone, EVERY sayable sentence is enumerated here and pre-rendered with a human neural voice (Indic-TTS).
The phone stitches answers from these clips: zero synthesis time, no TTS model in RAM, human voice for every answer.
Clip ids are the ones the Java app plays (Chat.java / FreeChat.java):
  <catalogue id>            questions, names, first-step advice, fillers   (catalogue.json)
  ph_<key>                  answer phrases                                 (advice_i18n.json 'phrases')
  <key>                     app phrases (photo, mic, confirm)              (app_phrases.json)
  it_<disease>_<c|b|x><i>   cultural / biological / chemical advice items  (advice.json, advice_i18n.json)
  generic                   'not sure -> KVK / Kisan Call Centre'          (advice.json 'generic')
Usage: python3 closed_world.py <assets_dir> <out segments.json>"""
import json, sys
from verbalize import verbalize
LANGS = ["hi", "ta", "kn", "en"]; FIELDS = (("cultural", "c"), ("biological", "b"), ("chemical_examples", "x"))

def segments(assets):
    C = json.load(open(f"{assets}/catalogue.json")); A = json.load(open(f"{assets}/advice.json"))
    I = json.load(open(f"{assets}/advice_i18n.json")); P = json.load(open(f"{assets}/app_phrases.json"))
    seg = {l: {} for l in LANGS}
    for l in LANGS:
        for k, v in C.items(): seg[l][k] = v[l]
        for k, v in I["phrases"].items(): seg[l]["ph_" + k] = v[l]
        for k, v in P.items():
            assert k not in C, k; seg[l][k] = v[l]
        seg[l]["generic"] = A["generic"][l]
    for d, adv in A["advice"].items():
        for f, s in FIELDS:
            for i, t in enumerate(adv.get(f, [])): seg["en"][f"it_{d}_{s}{i}"] = t
            if d in I:
                for l in ["hi", "ta", "kn"]:
                    for i, t in enumerate(I[d][f][l]): seg[l][f"it_{d}_{s}{i}"] = t
    # verified facts answered by the fact-token model (facts.json): seed facts reuse the clips above, new facts get their
    # own clip (id = fact id); new disease / pest targets get a name clip
    import os
    if os.path.exists(f"{assets}/facts.json"):
        FJ = json.load(open(f"{assets}/facts.json", encoding="utf-8"))
        for fid, f in FJ["facts"].items():
            if f.get("clip"): continue
            for l in LANGS:
                if f["text"].get(l): seg[l][fid] = f["text"][l]
        for t, n in FJ.get("targets", {}).items():
            if f"name_{t}" in C: continue
            for l in LANGS:
                if n.get(l): seg[l][f"name_{t}"] = n[l]
    return seg

if __name__ == "__main__":
    seg = segments(sys.argv[1]); out = {}
    for l in LANGS:
        out[l] = {k: {"text": t, "f": verbalize(t, l, "f"), "m": verbalize(t, l, "m")} for k, t in seg[l].items()}
    json.dump(out, open(sys.argv[2], "w"), ensure_ascii=False, indent=0)
    from verbalize import FALLBACK
    print("words spelled letter by letter (no reading yet):", len(FALLBACK), FALLBACK.most_common(12))
    print({l: len(v) for l, v in out.items()}, "chars:", {l: sum(len(x["f"]) for x in v.values()) for l, v in out.items()})
