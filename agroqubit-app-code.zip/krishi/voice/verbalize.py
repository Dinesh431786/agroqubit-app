"""Display text -> what the voice should SAY (build time only; the phone just plays the clip).
The screen keeps numbers and product names as printed on the label; the voice says them the way a person would:
'mancozeb 75% WG' -> 'मैंकोज़ेब पचहत्तर परसेंट डब्ल्यू जी', '200-300 लीटर' -> 'दो सौ से तीन सौ लीटर', helpline digit by digit.
Hindi first-person verbs follow the speaker ('पूछती हूँ' for the female voice, 'पूछता हूँ' for the male one).
verbalize() raises if anything the voice model can't read (Latin letters, digits) would be left in Indic speech."""
import re

LEX = {  # product, organism and variety names as farmers hear them (hi, ta, kn)
    "mancozeb": ("मैंकोज़ेब", "மேன்கோசெப்", "ಮ್ಯಾಂಕೋಜೆಬ್"), "azoxystrobin": ("एज़ॉक्सीस्ट्रोबिन", "அசாக்சிஸ்ட்ரோபின்", "ಅಜಾಕ್ಸಿಸ್ಟ್ರೋಬಿನ್"),
    "thiamethoxam": ("थायामेथोक्साम", "தயாமெத்தாக்சாம்", "ಥಯಾಮೆಥಾಕ್ಸಾಮ್"), "spiromesifen": ("स्पाइरोमेसिफ़ेन", "ஸ்பைரோமெசிஃபென்", "ಸ್ಪೈರೋಮೆಸಿಫೆನ್"),
    "cymoxanil": ("साइमोक्सानिल", "சைமோக்சானில்", "ಸೈಮೋಕ್ಸಾನಿಲ್"), "streptomycin": ("स्ट्रेप्टोमाइसिन", "ஸ்ட்ரெப்டோமைசின்", "ಸ್ಟ್ರೆಪ್ಟೋಮೈಸಿನ್"),
    "sulfate": ("सल्फ़ेट", "சல்பேட்", "ಸಲ್ಫೇಟ್"), "tetracycline": ("टेट्रासाइक्लिन", "டெட்ராசைக்ளின்", "ಟೆಟ್ರಾಸೈಕ್ಲಿನ್"),
    "hydrochloride": ("हाइड्रोक्लोराइड", "ஹைட்ரோகுளோரைடு", "ಹೈಡ್ರೋಕ್ಲೋರೈಡ್"), "propineb": ("प्रोपिनेब", "புரோபினெப்", "ಪ್ರೊಪಿನೆಬ್"),
    "difenoconazole": ("डाइफ़ेनोकोनाज़ोल", "டைஃபெனோகோனசோல்", "ಡೈಫೆನೊಕೊನಜೋಲ್"), "sulphur": ("सल्फ़र", "சல்பர்", "ಸಲ್ಫರ್"),
    "imidacloprid": ("इमिडाक्लोप्रिड", "இமிடாக்ளோப்ரிட்", "ಇಮಿಡಾಕ್ಲೋಪ್ರಿಡ್"), "copper": ("कॉपर", "காப்பர்", "ಕಾಪರ್"),
    "oxy": ("ऑक्सी", "ஆக்சி", "ಆಕ್ಸಿ"), "chloride": ("क्लोराइड", "குளோரைடு", "ಕ್ಲೋರೈಡ್"),
    "hexaconazole": ("हेक्साकोनाज़ोल", "ஹெக்சகோனசோல்", "ಹೆಕ್ಸಾಕೊನಜೋಲ್"), "propiconazole": ("प्रोपिकोनाज़ोल", "புரோபிகோனசோல்", "ಪ್ರೊಪಿಕೊನಜೋಲ್"),
    "tricyclazole": ("ट्राइसाइक्लाज़ोल", "ட்ரைசைக்ளசோல்", "ಟ್ರೈಸೈಕ್ಲಜೋಲ್"), "azadirachtin": ("एज़ाडिरेक्टिन", "அசாடிராக்டின்", "ಅಜಾಡಿರಾಕ್ಟಿನ್"),
    "pseudomonas": ("स्यूडोमोनास", "சூடோமோனாஸ்", "ಸ್ಯೂಡೋಮೊನಾಸ್"), "fluorescens": ("फ्लोरेसेंस", "ஃப்ளோரசன்ஸ்", "ಫ್ಲೋರೆಸೆನ್ಸ್"),
    "encarsia": ("एनकार्सिया", "என்கார்சியா", "ಎನ್ಕಾರ್ಸಿಯಾ"), "eretmocerus": ("एरेटमोसेरस", "எரெட்மோசெரஸ்", "ಎರೆಟ್ಮೋಸೆರಸ್"),
    "arka": ("अर्का", "அர்கா", "ಅರ್ಕಾ"), "suphal": ("सुफल", "சுபல்", "ಸುಫಲ್"), "harita": ("हरिता", "ஹரிதா", "ಹರಿತಾ"),
    "meghana": ("मेघना", "மேகனா", "ಮೇಘನಾ"), "hisar": ("हिसार", "ஹிசார்", "ಹಿಸಾರ್"), "shakti": ("शक्ति", "சக்தி", "ಶಕ್ತಿ"),
    "vijay": ("विजय", "விஜய்", "ವಿಜಯ್"), "phule": ("फुले", "புலே", "ಫುಲೆ"), "mukta": ("मुक्ता", "முக்தா", "ಮುಕ್ತಾ"),
    "ppm": ("पी पी एम", "பி பி எம்", "ಪಿ ಪಿ ಎಂ"),
}
LEX.update({  # units as people say them
    "kg": ("किलो", "கிலோ", "ಕಿಲೋ"), "kgs": ("किलो", "கிலோ", "ಕಿಲೋ"), "g": ("ग्राम", "கிராம்", "ಗ್ರಾಂ"), "gm": ("ग्राम", "கிராம்", "ಗ್ರಾಂ"),
    "ml": ("एम एल", "எம் எல்", "ಎಂ ಎಲ್"), "l": ("लीटर", "லிட்டர்", "ಲೀಟರ್"), "lit": ("लीटर", "லிட்டர்", "ಲೀಟರ್"), "litre": ("लीटर", "லிட்டர்", "ಲೀಟರ್"),
    "litres": ("लीटर", "லிட்டர்", "ಲೀಟರ್"), "liter": ("लीटर", "லிட்டர்", "ಲೀಟರ್"), "ha": ("हेक्टेयर", "ஹெக்டேர்", "ಹೆಕ್ಟೇರ್"),
    "hectare": ("हेक्टेयर", "ஹெக்டேர்", "ಹೆಕ್ಟೇರ್"), "acre": ("एकड़", "ஏக்கர்", "ಎಕರೆ"), "cm": ("सेंटीमीटर", "சென்டிமீட்டர்", "ಸೆಂಟಿಮೀಟರ್"),
    "mm": ("मिलीमीटर", "மில்லிமீட்டர்", "ಮಿಲಿಮೀಟರ್"), "m": ("मीटर", "மீட்டர்", "ಮೀಟರ್"), "q": ("क्विंटल", "குவிண்டால்", "ಕ್ವಿಂಟಾಲ್"),
    "quintal": ("क्विंटल", "குவிண்டால்", "ಕ್ವಿಂಟಾಲ್"), "t": ("टन", "டன்", "ಟನ್"), "kvk": ("के वी के", "கே வி கே", "ಕೆ ವಿ ಕೆ"),
})
import json as _json, os as _os, collections as _collections
LEX_AUTO = {}   # build-time transliterations of new product / pest / variety names (facts/lexicon.py, teacher model)
_p = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "lex_auto.json")
if _os.path.exists(_p):
    for _w, _r in _json.load(open(_p, encoding="utf-8")).items(): LEX_AUTO[_w.lower()] = (_r.get("hi"), _r.get("ta"), _r.get("kn"))
FALLBACK = _collections.Counter()      # words that had no reading and were spelled out letter by letter (reported, never silent)
STRICT = _os.environ.get("VERBALIZE_STRICT") == "1"
def latin_word(w, lang):
    k = w.lower()
    if k in LEX: return LEX[k][LI[lang]]
    if k in LEX_AUTO and LEX_AUTO[k][LI[lang]]: return LEX_AUTO[k][LI[lang]]
    if STRICT: raise ValueError(f"no reading for '{w}' ({lang})")
    FALLBACK[(lang, k)] += 1; return spell(w.upper(), lang)

LETTER = dict(zip("ABCDEFGHIJKLMNOPQRSTUVWXYZ", zip(
    "ए बी सी डी ई एफ जी एच आई जे के एल एम एन ओ पी क्यू आर एस टी यू वी डब्ल्यू एक्स वाई ज़ेड".split(),
    "ஏ பி சி டி இ எஃப் ஜி ஹெச் ஐ ஜே கே எல் எம் என் ஓ பி க்யூ ஆர் எஸ் டி யூ வி டபிள்யூ எக்ஸ் ஒய் இசட்".split(),
    "ಎ ಬಿ ಸಿ ಡಿ ಇ ಎಫ್ ಜಿ ಹೆಚ್ ಐ ಜೆ ಕೆ ಎಲ್ ಎಂ ಎನ್ ಒ ಪಿ ಕ್ಯೂ ಆರ್ ಎಸ್ ಟಿ ಯು ವಿ ಡಬ್ಲ್ಯೂ ಎಕ್ಸ್ ವೈ ಜೆಡ್".split())))
LI = {"hi": 0, "ta": 1, "kn": 2}
DIG = {"hi": "शून्य एक दो तीन चार पाँच छह सात आठ नौ".split(), "ta": "பூஜ்யம் ஒன்று இரண்டு மூன்று நான்கு ஐந்து ஆறு ஏழு எட்டு ஒன்பது".split(),
       "kn": "ಸೊನ್ನೆ ಒಂದು ಎರಡು ಮೂರು ನಾಲ್ಕು ಐದು ಆರು ಏಳು ಎಂಟು ಒಂಬತ್ತು".split(), "en": "zero one two three four five six seven eight nine".split()}
NUM = {  # every number the verified content uses, said the way people say it
    "hi": {1: "एक", 4: "चार", 5: "पाँच", 6: "छह", 8: "आठ", 9: "नौ", 10: "दस", 15: "पंद्रह", 23: "तेईस", 25: "पच्चीस", 40: "चालीस", 50: "पचास",
           64: "चौंसठ", 70: "सत्तर", 75: "पचहत्तर", 80: "अस्सी", 100: "सौ", 160: "एक सौ साठ", 200: "दो सौ", 250: "ढाई सौ", 300: "तीन सौ", 400: "चार सौ",
           500: "पाँच सौ", 600: "छह सौ", 800: "आठ सौ", 1000: "एक हज़ार", 1252: "एक हज़ार दो सौ बावन", 1500: "पंद्रह सौ", 22: "बाईस"},
    "ta": {1: "ஒன்று", 4: "நாலு", 5: "அஞ்சு", 6: "ஆறு", 8: "எட்டு", 9: "ஒன்பது", 10: "பத்து", 15: "பதினைஞ்சு", 23: "இருபத்தி மூணு", 25: "இருபத்தஞ்சு",
           40: "நாப்பது", 50: "அம்பது", 64: "அறுபத்தி நாலு", 70: "எழுபது", 75: "எழுபத்தஞ்சு", 80: "எம்பது", 100: "நூறு", 160: "நூத்தி அறுபது",
           200: "இருநூறு", 250: "இருநூத்தி அம்பது", 300: "முந்நூறு", 400: "நானூறு", 500: "ஐநூறு", 600: "அறுநூறு", 800: "எண்ணூறு", 1000: "ஆயிரம்",
           1252: "ஆயிரத்தி இருநூத்தி அம்பத்தி ரெண்டு", 1500: "ஆயிரத்தி ஐநூறு", 22: "இருபத்தி ரெண்டு"},
    "kn": {1: "ಒಂದು", 4: "ನಾಲ್ಕು", 5: "ಐದು", 6: "ಆರು", 8: "ಎಂಟು", 9: "ಒಂಬತ್ತು", 10: "ಹತ್ತು", 15: "ಹದಿನೈದು", 23: "ಇಪ್ಪತ್ತಮೂರು", 25: "ಇಪ್ಪತ್ತೈದು",
           40: "ನಲವತ್ತು", 50: "ಐವತ್ತು", 64: "ಅರವತ್ತನಾಲ್ಕು", 70: "ಎಪ್ಪತ್ತು", 75: "ಎಪ್ಪತ್ತೈದು", 80: "ಎಂಬತ್ತು", 100: "ನೂರು", 160: "ನೂರ ಅರವತ್ತು",
           200: "ಇನ್ನೂರು", 250: "ಇನ್ನೂರ ಐವತ್ತು", 300: "ಮುನ್ನೂರು", 400: "ನಾನೂರು", 500: "ಐನೂರು", 600: "ಆರುನೂರು", 800: "ಎಂಟುನೂರು", 1000: "ಸಾವಿರ",
           1252: "ಸಾವಿರದ ಇನ್ನೂರ ಐವತ್ತೆರಡು", 1500: "ಸಾವಿರದ ಐನೂರು", 22: "ಇಪ್ಪತ್ತೆರಡು"}}
POINT = {"hi": "पॉइंट", "ta": "பாயிண்ட்", "kn": "ಪಾಯಿಂಟ್", "en": "point"}
PCT = {"hi": "परसेंट", "ta": "பர்சன்ட்", "kn": "ಪರ್ಸೆಂಟ್", "en": "percent"}
PLUS = {"hi": "और", "ta": "கூட", "kn": "ಜೊತೆಗೆ", "en": "plus"}
TO = {"hi": " से ", "ta": " ", "kn": " ", "en": " to "}          # '200-300 l': hi 'दो सौ से तीन सौ'; ta/kn say it colloquially ('இருநூறு முந்நூறு')

ONES = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
TENS = "_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()
def en_num(n):
    if n < 20: return ONES[n]
    if n < 100: return TENS[n // 10] + ("" if n % 10 == 0 else " " + ONES[n % 10])
    if n < 1000: return ONES[n // 100] + " hundred" + ("" if n % 100 == 0 else " " + en_num(n % 100))
    if n < 10000 and n % 100 == 0 and n % 1000 != 0: return en_num(n // 100) + " hundred"
    return en_num(n // 1000) + " thousand" + ("" if n % 1000 == 0 else " " + en_num(n % 1000))

# any other number, said the same spoken way as the table above (the table wins, so existing clips never change)
TA_U = ["", "ஒன்று", "ரெண்டு", "மூணு", "நாலு", "அஞ்சு", "ஆறு", "ஏழு", "எட்டு", "ஒன்பது"]
TA_TEEN = ["பத்து", "பதினொன்று", "பன்னிரண்டு", "பதிமூணு", "பதினாலு", "பதினைஞ்சு", "பதினாறு", "பதினேழு", "பதினெட்டு", "பத்தொன்பது"]
TA_T = ["", "", "இருபது", "முப்பது", "நாப்பது", "அம்பது", "அறுபது", "எழுபது", "எம்பது", "தொண்ணூறு"]
TA_TS = ["", "", "இருபத்", "முப்பத்", "நாப்பத்", "அம்பத்", "அறுபத்", "எழுபத்", "எம்பத்", "தொண்ணூத்"]
TA_H = ["", "நூறு", "இருநூறு", "முந்நூறு", "நானூறு", "ஐநூறு", "அறுநூறு", "எழுநூறு", "எண்ணூறு", "தொள்ளாயிரம்"]
TA_HC = ["", "நூத்தி", "இருநூத்தி", "முந்நூத்தி", "நானூத்தி", "ஐநூத்தி", "அறுநூத்தி", "எழுநூத்தி", "எண்ணூத்தி", "தொள்ளாயிரத்தி"]
TA_K = ["", "ஆயிரம்", "ரெண்டாயிரம்", "மூவாயிரம்", "நாலாயிரம்", "அஞ்சாயிரம்", "ஆறாயிரம்", "ஏழாயிரம்", "எட்டாயிரம்", "ஒன்பதாயிரம்", "பத்தாயிரம்"]
def ta_num(n):
    if n == 0: return "பூஜ்யம்"
    if n >= 100000:
        l, r = divmod(n, 100000); head = "ஒரு" if l == 1 else ta_num(l)
        return head + (" லட்சம்" if r == 0 else " லட்சத்தி " + ta_num(r))
    if n >= 1000:
        k, r = divmod(n, 1000); w = TA_K[k] if k <= 10 else ta_num(k) + " ஆயிரம்"
        return w if r == 0 else w[:-2] + "த்தி " + ta_num(r)        # ஆயிரம் -> ஆயிரத்தி
    if n >= 100:
        h, r = divmod(n, 100); return TA_H[h] if r == 0 else TA_HC[h] + " " + ta_num(r)
    if n >= 20:
        t, u = divmod(n, 10)
        return TA_T[t] if u == 0 else (TA_TS[t] + "தஞ்சு" if u == 5 else TA_TS[t] + "தி " + TA_U[u])
    return TA_TEEN[n - 10] if n >= 10 else TA_U[n]

KN_U = ["", "ಒಂದು", "ಎರಡು", "ಮೂರು", "ನಾಲ್ಕು", "ಐದು", "ಆರು", "ಏಳು", "ಎಂಟು", "ಒಂಬತ್ತು"]
KN_FUSE = ["", "ೊಂದು", "ೆರಡು", "ಮೂರು", "ನಾಲ್ಕು", "ೈದು", "ಾರು", "ೇಳು", "ೆಂಟು", "ೊಂಬತ್ತು"]   # after a tens stem ending in 'ತ್ತ'
KN_TEEN = ["ಹತ್ತು", "ಹನ್ನೊಂದು", "ಹನ್ನೆರಡು", "ಹದಿಮೂರು", "ಹದಿನಾಲ್ಕು", "ಹದಿನೈದು", "ಹದಿನಾರು", "ಹದಿನೇಳು", "ಹದಿನೆಂಟು", "ಹತ್ತೊಂಬತ್ತು"]
KN_T = ["", "", "ಇಪ್ಪತ್ತು", "ಮೂವತ್ತು", "ನಲವತ್ತು", "ಐವತ್ತು", "ಅರವತ್ತು", "ಎಪ್ಪತ್ತು", "ಎಂಬತ್ತು", "ತೊಂಬತ್ತು"]
KN_H = ["", "ನೂರು", "ಇನ್ನೂರು", "ಮುನ್ನೂರು", "ನಾನೂರು", "ಐನೂರು", "ಆರುನೂರು", "ಏಳುನೂರು", "ಎಂಟುನೂರು", "ಒಂಬೈನೂರು"]
def kn_num(n):
    if n == 0: return "ಸೊನ್ನೆ"
    if n >= 100000:
        l, r = divmod(n, 100000); return kn_num(l) + (" ಲಕ್ಷ" if r == 0 else " ಲಕ್ಷದ " + kn_num(r))
    if n >= 1000:
        k, r = divmod(n, 1000); w = "ಸಾವಿರ" if k == 1 else kn_num(k) + " ಸಾವಿರ"
        return w if r == 0 else w + "ದ " + kn_num(r)
    if n >= 100:
        h, r = divmod(n, 100); return KN_H[h] if r == 0 else KN_H[h][:-1] + " " + kn_num(r)    # ನೂರು -> ನೂರ
    if n >= 20:
        t, u = divmod(n, 10); return KN_T[t] if u == 0 else KN_T[t][:-1] + KN_FUSE[u]
    return KN_TEEN[n - 10] if n >= 10 else KN_U[n]

def hi_num(n):
    try:
        from indic_numtowords import num2words as _inw
        return _inw(n, lang="hi")
    except Exception:
        return " ".join(DIG["hi"][int(c)] for c in str(n))

def number(s, lang):
    if "." in s:
        a, b = s.split("."); return number(a, lang) + " " + POINT[lang] + " " + " ".join(DIG[lang][int(c)] for c in b)
    n = int(s)
    if lang == "en": return en_num(n)
    if n in NUM[lang]: return NUM[lang][n]
    if n >= 10 ** 7: return " ".join(DIG[lang][int(c)] for c in s)
    return {"hi": hi_num, "ta": ta_num, "kn": kn_num}[lang](n)

def spell(tok, lang):  # acronyms / codes letter by letter, digits one by one
    if lang == "en": return " ".join(tok)
    out = []
    for ch in tok:
        if ch.isdigit(): out.append(DIG[lang][int(ch)])
        elif ch.upper() in LETTER: out.append(LETTER[ch.upper()][LI[lang]])
    return " ".join(out)

def male_hi(t):
    """Hindi first-person verbs agree with the speaker; the text is written for the female voice."""
    for a, b in [("सकती हूँ", "सकता हूँ"), ("रही हूँ", "रहा हूँ"), ("ती हूँ", "ता हूँ"), ("ूँगी", "ूँगा"), ("गई हूँ", "गया हूँ")]: t = t.replace(a, b)
    return t

def verbalize(t, lang, voice="f"):
    if lang == "hi" and voice == "m": t = male_hi(t)
    t = re.sub(r"\d{4}-\d{3}-\d{4}", lambda m: ", ".join(" ".join(DIG[lang][int(c)] for c in g) for g in m.group(0).split("-")), t)   # helpline
    if lang == "en":
        t = t.replace("6 AM-10 PM", "6 in the morning to 10 at night").replace("e.g.", "for example").replace(" NO ", " no ")
        t = re.sub(r"\s@\s", ", ", t); t = t.replace("@ ", "")
        t = re.sub(r"(\d)\s*/\s*acre", r"\1 per acre", t); t = re.sub(r"/acre", " per acre", t); t = re.sub(r"g\s*/\s*kg", "grams per kilogram", t)
        t = re.sub(r"(\d)\s*ml\s*/\s*(\d+)\s*lit\.?", r"\1 millilitres in \2 litres", t)
        t = re.sub(r"(\d)\s*ml\b", r"\1 millilitres", t); t = re.sub(r"(\d)\s*g\b", r"\1 grams", t); t = re.sub(r"(\d)\s*l\b", r"\1 litres", t)
        t = re.sub(r"(\d)\s*kgs?\b", r"\1 kilograms", t); t = re.sub(r"\s*/\s*ha\b", " per hectare", t); t = re.sub(r"(\d)\s*ha\b", r"\1 hectares", t)
        t = re.sub(r"(\d)\s*q\b", r"\1 quintals", t)
        t = re.sub(r"(\d)-day\b", r"\1 day", t); t = t.replace("W/W", "")
        t = re.sub(r"\b(KVK|IPM|NSKE|FDRS|ICG|WP|WG|WS|SC|EC|SP)\b", lambda m: " ".join(m.group(1)), t)
        t = re.sub(r"\bICGV(\d+)", lambda m: "I C G V " + " ".join(DIG["en"][int(c)] for c in m.group(1)), t)
        t = re.sub(r"\bR(\d{4})\b", lambda m: "R " + " ".join(DIG["en"][int(c)] for c in m.group(1)), t)
        t = re.sub(r"\bppm\b", "P P M", t)
    else:
        t = t.replace("W/W", "")
        t = re.sub(r"\bICGV(\d+)", lambda m: spell("ICGV", lang) + " " + spell(m.group(1), lang), t)
        t = re.sub(r"\bR(\d{4})\b", lambda m: spell("R", lang) + " " + spell(m.group(1), lang), t)
        t = re.sub(r"\b[A-Z]{2,}\b", lambda m: spell(m.group(0), lang), t)
        t = re.sub(r"[A-Za-z]+", lambda m: latin_word(m.group(0), lang), t)
    t = re.sub(r"(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)", lambda m: number(m.group(1), lang) + TO[lang] + number(m.group(2), lang), t)
    t = re.sub(r"(\d+(?:\.\d+)?)\s*%", lambda m: number(m.group(1), lang) + " " + PCT[lang], t)
    t = re.sub(r"\d+(?:\.\d+)?", lambda m: number(m.group(0), lang), t)
    t = t.replace("+", f", {PLUS[lang]}, ")
    if lang == "en": t = re.sub(r"(?<=[a-z])/(?=[a-z])", " or ", t)
    t = re.sub(r"\s-\s", ", ", t); t = re.sub(r"(?<=\S)-(?=\S)", " ", t)
    t = t.replace("।", ".").replace("—", ",").replace("–", ",").replace(";", ",").replace(":", ",").replace("/", " ").replace("(", ", ").replace(")", ", ")
    t = re.sub(r"\s+", " ", re.sub(r"\s*,\s*(,\s*)+", ", ", t)).strip(" ,")
    t = re.sub(r"\s+([,.?!])", r"\1", t)
    left = re.findall(r"[A-Za-z0-9]" if lang != "en" else r"[0-9@%]", t)
    if left: raise ValueError(f"unreadable left in {lang}: {left} :: {t}")
    return t

def sentences(t):
    """Split for synthesis: one sentence at a time sounds more natural than one long run-on (joined with short pauses)."""
    parts = [p.strip() for p in re.split(r"(?<=[.?!])\s+", t) if p.strip()]
    return parts or [t]
