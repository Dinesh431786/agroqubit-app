"""Human-recorded-voice TTS: AI4Bharat Indic-TTS (MIT licence; FastPitch + HiFi-GAN trained on the IndicTTS corpus of
real native speakers). Used OFFLINE at build time to pre-render the app's fixed voice pack."""
import os, sys, numpy as np, torch
from TTS.utils.synthesizer import Synthesizer
M = os.environ.get("TTS_MODELS", "/home/claude/tts_models"); _cache = {}
def synth(lang):
    if lang not in _cache:
        d = f"{M}/{lang}"
        _cache[lang] = Synthesizer(tts_checkpoint=f"{d}/fastpitch/best_model.pth", tts_config_path=f"{d}/fastpitch/config.json",
                                   tts_speakers_file=f"{d}/fastpitch/speakers.pth", vocoder_checkpoint=f"{d}/hifigan/best_model.pth",
                                   vocoder_config=f"{d}/hifigan/config.json", use_cuda=os.environ.get("TTS_CUDA") == "1" and torch.cuda.is_available())
    return _cache[lang]
def say(text, lang, speaker="female"):
    s = synth(lang); wav = np.array(s.tts(text, speaker_name=speaker), np.float32)
    return wav, s.output_sample_rate
if __name__ == "__main__":
    import soundfile as sf, time
    for l, t in [("ta", "வணக்கம். உங்கள் பயிர் என்ன என்று சொல்லுங்கள்."), ("hi", "नमस्ते। अपनी फसल के बारे में बताइए।"), ("kn", "ನಮಸ್ಕಾರ. ನಿಮ್ಮ ಬೆಳೆ ಯಾವುದು?"), ("en", "Namaste. Please tell me about your crop.")]:
        t0 = time.time(); w, sr = say(t, l); sf.write(f"/home/claude/krishi/voice/human_sample_{l}.wav", w, sr)
        print(l, sr, f"{len(w)/sr:.2f}s audio in {time.time()-t0:.1f}s", "rms", round(float(np.sqrt((w**2).mean())), 3))
