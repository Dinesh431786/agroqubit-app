"""KrishiVoice audio definitions: the ONE mel spectrogram used everywhere (training targets, vocoder input/loss,
eval), audio I/O and pitch.

Mel: 16 kHz, n_fft 1024, hop 256 (16 ms), win 1024 (periodic Hann), 80 slaney mels 0-8000 Hz, magnitude STFT with
centre (reflect) padding, natural log with clamp 1e-5.  T frames = 1 + n_samples // 256, and the vocoder's
centred iSTFT turns T frames back into (T - 1) * 256 samples, so a segment of K*256 samples <-> K+1 frames exactly.
16 kHz matches the app's clips (speech band, Opus 16 kbps) and 8 kHz is its Nyquist; the 1024/256 STFT is the one
the vocoder inverts, so the phone needs a single 1024-point (512 complex) FFT per 16 ms frame.

Pitch: YIN (vectorised numpy, ~300x real time on one core; librosa.pyin was measured at ~1x real time here, too slow
for 60+ hours) on the same frame grid, with a voicing decision from the YIN aperiodicity and frame energy.
"""
import os, subprocess
import numpy as np

SR, N_FFT, HOP, WIN, N_MELS, FMIN, FMAX, LOG_CLAMP = 16000, 1024, 256, 1024, 80, 0.0, 8000.0, 1e-5
F0_MIN, F0_MAX = 60.0, 600.0


def params():
    return {"sample_rate": SR, "n_fft": N_FFT, "hop": HOP, "win": WIN, "n_mels": N_MELS, "fmin": FMIN, "fmax": FMAX,
            "log_clamp": LOG_CLAMP, "window": "hann_periodic", "center": True, "mel_scale": "slaney", "mel_norm": "slaney"}


def n_frames(n_samples): return 1 + n_samples // HOP


# ------------------------------------------------------------------ mel filterbank (librosa slaney, no librosa needed)
def _hz_to_mel(f):
    f = np.asarray(f, np.float64); f_sp = 200.0 / 3; mels = f / f_sp
    min_log_hz = 1000.0; min_log_mel = min_log_hz / f_sp; logstep = np.log(6.4) / 27.0
    return np.where(f >= min_log_hz, min_log_mel + np.log(np.maximum(f, 1e-10) / min_log_hz) / logstep, mels)


def _mel_to_hz(m):
    m = np.asarray(m, np.float64); f_sp = 200.0 / 3; freqs = f_sp * m
    min_log_hz = 1000.0; min_log_mel = min_log_hz / f_sp; logstep = np.log(6.4) / 27.0
    return np.where(m >= min_log_mel, min_log_hz * np.exp(logstep * (m - min_log_mel)), freqs)


def mel_basis(sr=SR, n_fft=N_FFT, n_mels=N_MELS, fmin=FMIN, fmax=FMAX):
    """[n_mels, n_fft//2+1] float32, identical to librosa.filters.mel(sr, n_fft, n_mels, fmin, fmax) (slaney/slaney)."""
    fftfreqs = np.linspace(0, sr / 2, 1 + n_fft // 2)
    mel_f = _mel_to_hz(np.linspace(_hz_to_mel(fmin), _hz_to_mel(fmax), n_mels + 2))
    fdiff = np.diff(mel_f); ramps = mel_f[:, None] - fftfreqs[None, :]
    lower = -ramps[:-2] / fdiff[:-1, None]; upper = ramps[2:] / fdiff[1:, None]
    w = np.maximum(0, np.minimum(lower, upper))
    w *= (2.0 / (mel_f[2:n_mels + 2] - mel_f[:n_mels]))[:, None]
    return w.astype(np.float32)


_TORCH_CACHE = {}


def mel_torch(wav):
    """wav [B, N] or [N] float tensor -> log-mel [B, 80, 1 + N//256] (float32, computed in fp32 even under autocast)."""
    import torch
    squeeze = wav.dim() == 1
    if squeeze: wav = wav[None]
    key = (wav.device, "mel")
    if key not in _TORCH_CACHE:
        _TORCH_CACHE[key] = (torch.hann_window(WIN, periodic=True, device=wav.device), torch.from_numpy(mel_basis()).to(wav.device))
    window, basis = _TORCH_CACHE[key]
    with torch.autocast(device_type=wav.device.type, enabled=False):
        spec = torch.stft(wav.float(), N_FFT, HOP, WIN, window=window, center=True, pad_mode="reflect", return_complex=True)
        mag = torch.sqrt(spec.real ** 2 + spec.imag ** 2 + 1e-9)
        mel = torch.log(torch.clamp(torch.matmul(basis, mag), min=LOG_CLAMP))
    return mel[0] if squeeze else mel


def mel_np(wav):
    import torch
    return mel_torch(torch.from_numpy(np.asarray(wav, np.float32))).numpy()


# ------------------------------------------------------------------ I/O
def load_wav(path, sr=SR):
    """Any audio file -> mono float32 at `sr`. wav/flac via soundfile, everything else (opus, mp3, ogg) via ffmpeg."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".wav", ".flac"):
        import soundfile as sf
        w, fs = sf.read(path, dtype="float32", always_2d=True); w = w.mean(1)
        if fs != sr:
            from math import gcd
            from scipy.signal import resample_poly
            g = gcd(int(fs), int(sr)); w = resample_poly(w, sr // g, int(fs) // g).astype(np.float32)
        return w
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-f", "f32le", "-ac", "1", "-ar", str(sr), "-"],
                         capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).copy()


def save_wav(path, wav, sr=SR):
    import soundfile as sf
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    sf.write(path, np.clip(np.asarray(wav, np.float32), -1, 1), sr, subtype="PCM_16")


def trim(w, rel=0.01, lead=800, tail=1600):
    """Same trimming as voice/render_segments.py: cut below 1% of peak, keep 50 ms before and 100 ms after."""
    nz = np.where(np.abs(w) > rel * (np.abs(w).max() + 1e-9))[0]
    return w[max(0, nz[0] - lead): nz[-1] + tail] if len(nz) else w


# ------------------------------------------------------------------ pitch (YIN)
def _frames(y, frame, hop, n):
    return np.lib.stride_tricks.as_strided(y, shape=(n, frame), strides=(y.strides[0] * hop, y.strides[0]), writeable=False)


def pitch_yin(wav, sr=SR, hop=HOP, frame=N_FFT, fmin=F0_MIN, fmax=F0_MAX, threshold=0.15, max_aperiodicity=0.45,
              silence_db=-60.0):
    """f0 in Hz per mel frame (1 + len//hop values), 0 where unvoiced. Returns (f0 float32, aperiodicity float32)."""
    w = np.asarray(wav, np.float32); n = 1 + len(w) // hop
    pad = frame // 2
    y = np.pad(w, (pad, pad), mode="reflect" if len(w) > pad else "constant").astype(np.float64)
    if len(y) < (n - 1) * hop + frame: y = np.pad(y, (0, (n - 1) * hop + frame - len(y)))
    fr = _frames(y, frame, hop, n)
    tmin, tmax = int(np.floor(sr / fmax)), int(np.ceil(sr / fmin)); W = frame - tmax - 1
    # difference function d(tau) = E0 + E_tau - 2 r(tau) over an integration window of W samples
    L = 1 << int(np.ceil(np.log2(frame + W)))
    F0 = np.fft.rfft(fr[:, :W], L); F1 = np.fft.rfft(fr, L)
    r = np.fft.irfft(np.conj(F0) * F1, L)[:, :tmax + 2]
    cs = np.concatenate([np.zeros((n, 1)), np.cumsum(fr ** 2, axis=1)], axis=1)
    taus = np.arange(tmax + 2)
    E = cs[:, taus + W] - cs[:, taus]
    d = np.maximum(E[:, :1] + E - 2 * r, 0.0)
    cm = np.cumsum(d[:, 1:], axis=1)
    cmnd = np.ones_like(d); cmnd[:, 1:] = d[:, 1:] * np.arange(1, tmax + 2) / np.maximum(cm, 1e-12)
    rng = cmnd[:, tmin:tmax + 1]                                    # candidate periods
    below = rng < threshold; has = below.any(1)
    first = np.where(has, below.argmax(1), rng.argmin(1))
    # walk from the first dip below threshold to its local minimum
    idx = np.arange(rng.shape[1])[None, :]
    rising = np.concatenate([rng[:, 1:] >= rng[:, :-1], np.ones((n, 1), bool)], axis=1)
    lm = np.where(has, (rising & (idx >= first[:, None])).argmax(1), first)
    tau = lm + tmin
    tl = np.clip(tau - 1, 0, tmax + 1); tr = np.clip(tau + 1, 0, tmax + 1); rows = np.arange(n)
    a, b, c = cmnd[rows, tl], cmnd[rows, tau], cmnd[rows, tr]
    den = a - 2 * b + c
    shift = np.where(np.abs(den) > 1e-12, 0.5 * (a - c) / np.where(np.abs(den) > 1e-12, den, 1), 0.0)
    shift = np.clip(shift, -1, 1)
    f0 = sr / np.maximum(tau + shift, 1e-3); aper = cmnd[rows, tau]
    rms = np.sqrt((fr[:, pad - hop // 2: pad + hop // 2] ** 2).mean(1) + 1e-12)
    db = 20 * np.log10(rms + 1e-9); db -= db.max() if n else 0
    voiced = (aper < max_aperiodicity) & (db > silence_db) & (f0 >= fmin) & (f0 <= fmax)
    # remove isolated voiced frames and octave jumps: median of each voiced frame with its voiced neighbours
    f0 = np.where(voiced, f0, 0.0)
    if n >= 3:
        st = np.stack([np.r_[f0[:1], f0[:-1]], f0, np.r_[f0[1:], f0[-1:]]], 1)
        nb = (st > 0).sum(1)
        med = np.where(st > 0, st, np.nan)
        with np.errstate(all="ignore"):
            m = np.nanmedian(np.where(nb[:, None] > 0, med, 1.0), axis=1)
        f0 = np.where(voiced & (nb >= 2), m, 0.0)
    return f0.astype(np.float32), aper.astype(np.float32)


if __name__ == "__main__":
    import sys, time
    import librosa
    B = librosa.filters.mel(sr=SR, n_fft=N_FFT, n_mels=N_MELS, fmin=FMIN, fmax=FMAX)
    print("mel basis max diff vs librosa:", float(np.abs(B - mel_basis()).max()))
    for p in sys.argv[1:]:
        w = load_wav(p); t = time.time(); f0, ap = pitch_yin(w); ty = time.time() - t
        t = time.time(); fp, vf, _ = librosa.pyin(w, fmin=60, fmax=600, sr=SR, frame_length=N_FFT, hop_length=HOP); tp = time.time() - t
        fp = np.nan_to_num(fp); both = (f0 > 0) & (fp > 0)
        cents = 1200 * np.abs(np.log2(f0[both] / fp[both]))
        print(os.path.basename(p), f"{len(w)/SR:.1f}s yin {ty*1000:.0f}ms pyin {tp:.1f}s | voiced yin {np.mean(f0>0):.2f} pyin {np.mean(fp>0):.2f}"
              f" agree {np.mean((f0>0)==(fp>0)):.3f} | median cents err {np.median(cents):.1f}, >50c {np.mean(cents>50):.3f} | mel {mel_np(w).shape} frames {len(f0)}")
