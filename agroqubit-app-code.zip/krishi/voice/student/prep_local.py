"""Smoke-test corpus from the teacher clips already in the repo (no GPU, no teacher model needed):
voice/pack_human/<lang>/<id>.opus (female) and voice/pack_human_male/<lang>/<id>.opus (male), rendered by
voice/render_human.py / render_human_spk.py from voice/catalogue.json with render_human.norm(). The spoken text of a
clip is therefore norm(catalogue[id][lang], lang). Output has the same layout as prep_teacher.py:
<out>/wavs/<lang>_<speaker>/<id>.wav, <out>/pitch/.../<id>.npy, <out>/metadata.jsonl.
Usage: python3 prep_local.py <out_dir> [--max_sec 12] [--langs hi,ta,kn,en]"""
import argparse, json, os, sys, time, types
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); VOICE = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from audio import load_wav, save_wav, pitch_yin, trim, SR


def clip_texts():
    """{lang: {clip id: spoken text}} exactly as render_human.py normalised it (its TTS import is stubbed out)."""
    sys.modules.setdefault("indic_tts", types.SimpleNamespace(synth=None, say=None))
    sys.path.insert(0, VOICE); cwd = os.getcwd(); os.chdir(VOICE)
    try:
        import render_human
    finally:
        os.chdir(cwd)
    C = json.load(open(os.path.join(VOICE, "catalogue.json"), encoding="utf-8"))
    return {l: {cid: render_human.norm(t[l], l) for cid, t in C.items()} for l in ["hi", "ta", "kn", "en"]}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("out"); ap.add_argument("--max_sec", type=float, default=12.0)
    ap.add_argument("--langs", default="hi,ta,kn,en"); a = ap.parse_args()
    texts = clip_texts(); rows = []; t0 = time.time()
    for spk, pack in [("female", "pack_human"), ("male", "pack_human_male")]:
        for lang in a.langs.split(","):
            for cid, txt in texts[lang].items():
                src = os.path.join(VOICE, pack, lang, cid + ".opus")
                if not os.path.exists(src): print("missing", src); continue
                w = trim(load_wav(src)); sec = len(w) / SR
                if sec > a.max_sec: continue
                rel = f"wavs/{lang}_{spk}/{cid}.wav"; prel = f"pitch/{lang}_{spk}/{cid}.npy"
                save_wav(os.path.join(a.out, rel), w)
                f0, _ = pitch_yin(w); os.makedirs(os.path.dirname(os.path.join(a.out, prel)), exist_ok=True); np.save(os.path.join(a.out, prel), f0)
                rows.append({"id": f"{lang}_{spk}_{cid}", "text": txt, "lang": lang, "speaker": spk, "path": rel, "pitch": prel,
                             "seconds": round(sec, 3), "samples": len(w), "source": src})
    with open(os.path.join(a.out, "metadata.jsonl"), "w", encoding="utf-8") as f:
        for r in rows: f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"{len(rows)} clips, {sum(r['seconds'] for r in rows) / 3600:.2f} h, {time.time() - t0:.0f}s -> {a.out}")


if __name__ == "__main__":
    main()
