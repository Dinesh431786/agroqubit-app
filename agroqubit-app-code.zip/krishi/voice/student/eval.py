"""Evaluate KrishiVoice against the teacher on held-out sentences (the deterministic split of data.py).

Per utterance (teacher audio x, its log-mel M):
  mel_l1_tf     AM with the aligner's durations and the teacher's pitch (pure acoustic-model error), frame aligned
  dur_mae       |predicted - aligner durations| in frames per token (16 ms), and total-length error in %
  pitch_rmse    per-token pitch prediction error (normalised log-f0 units)
  mcd           MCD-DTW (dB) between the student's free-running synthesis and the teacher audio, on cepstra c1..c24
                of the log-mel (DCT); copy_mcd = vocoder alone (teacher mel -> student vocoder) for reference;
                with --export also the int8 phone weights (mcd_int8)
  rtf           Python CPU synthesis time / audio time (1 thread unless --threads)
WAVs for listening: <out>/wavs/<voice>_<n>_{teacher,student,student_int8,copysyn}.wav
  python3 eval.py --data /data/kv --am runs/am/final.pt --voc runs/voc_ft/final.pt --export export/ --out eval/
"""
import argparse, json, math, os, sys, time
from collections import defaultdict
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import data as D
import text as T
from audio import SR, HOP, mel_torch, mel_np, save_wav
from export import load_checkpoints, load_exported

K_MCD = 10.0 * math.sqrt(2.0) / math.log(10.0)


def cepstra(logmel, n=25):
    from scipy.fft import dct
    return dct(np.asarray(logmel, np.float64), type=2, norm="ortho", axis=0)[1:n]   # [24, T], c0 (energy) dropped


try:
    import numba

    @numba.njit(cache=True)
    def _dtw(C):
        n, m = C.shape; Dm = np.full((n + 1, m + 1), np.inf); Dm[0, 0] = 0.0; L = np.zeros((n + 1, m + 1))
        for i in range(1, n + 1):
            for j in range(1, m + 1):
                a, b, c = Dm[i - 1, j - 1], Dm[i - 1, j], Dm[i, j - 1]
                if a <= b and a <= c: Dm[i, j] = C[i - 1, j - 1] + a; L[i, j] = L[i - 1, j - 1] + 1
                elif b <= c: Dm[i, j] = C[i - 1, j - 1] + b; L[i, j] = L[i - 1, j] + 1
                else: Dm[i, j] = C[i - 1, j - 1] + c; L[i, j] = L[i, j - 1] + 1
        return Dm[n, m] / L[n, m]
except Exception:
    def _dtw(C):
        n, m = C.shape; Dm = np.full((n + 1, m + 1), np.inf); Dm[0, 0] = 0.0; L = np.zeros((n + 1, m + 1))
        for i in range(1, n + 1):
            for j in range(1, m + 1):
                cands = ((Dm[i - 1, j - 1], L[i - 1, j - 1]), (Dm[i - 1, j], L[i - 1, j]), (Dm[i, j - 1], L[i, j - 1]))
                d, l = min(cands, key=lambda x: x[0]); Dm[i, j] = C[i - 1, j - 1] + d; L[i, j] = l + 1
        return Dm[n, m] / L[n, m]


def mcd_dtw(wav_a, wav_b):
    A, B = cepstra(mel_np(wav_a)), cepstra(mel_np(wav_b))
    C = K_MCD * np.sqrt(((A[:, :, None] - B[:, None, :]) ** 2).sum(0))
    return float(_dtw(C))


@torch.no_grad()
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--data", required=True); ap.add_argument("--am", required=True); ap.add_argument("--voc", required=True)
    ap.add_argument("--export", default=""); ap.add_argument("--out", required=True); ap.add_argument("--n", type=int, default=12, help="utterances per voice")
    ap.add_argument("--wavs", type=int, default=3, help="listening wavs per voice"); ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--eval_pct", type=float, default=2.0); ap.add_argument("--max_sec", type=float, default=15.0)
    a = ap.parse_args(); torch.set_num_threads(a.threads); os.makedirs(os.path.join(a.out, "wavs"), exist_ok=True)
    am, voc, stats, info = load_checkpoints(a.am, a.voc)
    amq = vocq = None
    if a.export: amq, vocq, _ = load_exported(a.export)
    held = D.Corpus(a.data.split(","), "eval", a.eval_pct, max_sec=a.max_sec)
    by_voice = defaultdict(list)
    for r in held.rows:
        if len(by_voice[r["voice_i"]]) < a.n: by_voice[r["voice_i"]].append(r)
    res = defaultdict(lambda: defaultdict(list))
    for vi, rows in sorted(by_voice.items()):
        lang, spk = T.LANGS[vi // 2], T.SPEAKERS[vi % 2]; key = f"{lang}_{spk}"
        for n, r in enumerate(rows):
            w = D.load_wav16(r["path"]); w = w[:(len(w) // HOP) * HOP]
            b = D.collate_utts([{"ids": np.asarray(r["ids"]), "lang": r["lang_i"], "voice": vi, "wav": w, "pitch": np.load(r["pitch"]).astype(np.float32), "idx": 0}])
            mel = mel_torch(b["wav"]); Tm = mel.shape[2]; mlens = torch.clamp(b["mlens"], max=Tm)
            pitch, voiced = D.normalise_pitch(b["pitch_hz"][:, :Tm], b["voice"], stats)
            out = am(b["tokens"], b["tlens"], b["lang"], b["voice"], mel, mlens, pitch, voiced)
            res[key]["mel_l1_tf"].append(float((out["mel"] - mel).abs().mean()))
            dur_t = out["dur_t"][0].numpy(); ptok = out["pitch_t"][0].numpy()
            t0 = time.time(); mel_s, dur_p, _, p_pred = am.infer(r["ids"], r["lang_i"], vi); y = voc.infer(mel_s); dt = time.time() - t0
            res[key]["rtf"].append(dt / max(1e-9, len(y) / SR))
            res[key]["dur_mae"].append(float(np.abs(dur_p - dur_t).mean())); res[key]["len_err_pct"].append(float(100 * abs(dur_p.sum() - dur_t.sum()) / dur_t.sum()))
            res[key]["pitch_rmse"].append(float(np.sqrt(((p_pred - ptok) ** 2).mean())))
            res[key]["mcd"].append(mcd_dtw(y, w))
            ycs = voc.infer(mel[0].T.numpy()); res[key]["copy_mcd"].append(mcd_dtw(ycs, w))
            if amq is not None:
                mq, _, _, _ = amq.infer(r["ids"], r["lang_i"], vi); yq = vocq.infer(mq); res[key]["mcd_int8"].append(mcd_dtw(yq, w))
            if n < a.wavs:
                p = os.path.join(a.out, "wavs", f"{key}_{n}_")
                save_wav(p + "teacher.wav", w); save_wav(p + "student.wav", y); save_wav(p + "copysyn.wav", ycs)
                if amq is not None: save_wav(p + "student_int8.wav", yq)
        print(key, {k: round(float(np.mean(v)), 3) for k, v in res[key].items()}, flush=True)
    summary = {k: {m: round(float(np.mean(v)), 4) for m, v in d.items()} for k, d in res.items()}
    allm = defaultdict(list)
    for d in res.values():
        for m, v in d.items(): allm[m] += v
    summary["all"] = {m: round(float(np.mean(v)), 4) for m, v in allm.items()}
    summary["info"] = {**info, "utterances": sum(len(v) for v in by_voice.values()), "mcd_definition": "DTW, c1..c24 DCT cepstra of ln-magnitude log-mel"}
    json.dump(summary, open(os.path.join(a.out, "eval.json"), "w"), indent=1)
    print("ALL", summary["all"])


if __name__ == "__main__":
    main()
