"""Train the KrishiVoice acoustic model (model_am.py) on teacher audio.

GPU:  python3 train_am.py --data /data/kv --out runs/am --steps 70000            (bf16 autocast on an L4)
CPU smoke: python3 train_am.py --data smoke_data --out runs/am_smoke --preset tiny --cpu --steps 300 --max_frames 3000
Resumes automatically from <out>/ckpt_last.pt (model, optimiser, step, data epoch). SIGTERM/SIGINT save first.
Logs: <out>/train.log (text) and <out>/metrics.jsonl (one JSON per log step).
"""
import argparse, json, math, os, signal, sys, time
from dataclasses import asdict
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import data as D
from audio import mel_torch
from model_am import AcousticModel, AMConfig, am_losses


def get_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", required=True, help="data root(s), comma separated")
    ap.add_argument("--out", required=True)
    ap.add_argument("--preset", default="base", choices=["base", "small", "tiny"])
    ap.add_argument("--steps", type=int, default=70000)
    ap.add_argument("--max_frames", type=int, default=20000, help="padded mel frames per batch (~5.3 min of audio)")
    ap.add_argument("--max_batch", type=int, default=64)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--warmup", type=int, default=4000)
    ap.add_argument("--min_lr_ratio", type=float, default=0.05)
    ap.add_argument("--wd", type=float, default=1e-6)
    ap.add_argument("--clip", type=float, default=1.0)
    ap.add_argument("--w_dur", type=float, default=0.5); ap.add_argument("--w_pitch", type=float, default=0.5)
    ap.add_argument("--w_align", type=float, default=1.0)
    ap.add_argument("--bin_start", type=float, default=0.1, help="fraction of steps before the binarisation loss starts")
    ap.add_argument("--bin_warmup", type=float, default=0.1, help="fraction of steps to ramp it to 1")
    ap.add_argument("--amp", default="bf16", choices=["bf16", "fp16", "off"])
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--threads", type=int, default=0, help="torch CPU threads (0 = default)")
    ap.add_argument("--cpu", action="store_true")
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--max_sec", type=float, default=15.0); ap.add_argument("--min_sec", type=float, default=0.4)
    ap.add_argument("--eval_pct", type=float, default=2.0)
    ap.add_argument("--log_every", type=int, default=100); ap.add_argument("--save_every", type=int, default=2000)
    ap.add_argument("--eval_every", type=int, default=5000); ap.add_argument("--keep_every", type=int, default=20000)
    ap.add_argument("--budget_h", type=float, default=0.0, help="fit the step count (and LR schedule) to this many hours, "
                    "measured over the first ~300 steps; 0 = use --steps")
    ap.add_argument("--fresh", action="store_true", help="ignore an existing checkpoint")
    ap.add_argument("--init", default="", help="start from these weights (e.g. a previous run) with a new optimiser")
    return ap.parse_args(argv)


class Logger:
    def __init__(self, out):
        self.f = open(os.path.join(out, "train.log"), "a", buffering=1, encoding="utf-8")
        self.m = open(os.path.join(out, "metrics.jsonl"), "a", buffering=1, encoding="utf-8")

    def log(self, s):
        line = f"{time.strftime('%H:%M:%S')} {s}"; print(line, flush=True); self.f.write(line + "\n")

    def metrics(self, d): self.m.write(json.dumps(d) + "\n")


class Budget:
    """--budget_h: time steps [start+50, start+350), then set a.steps so the whole run fits the budget (cosine LR follows)."""
    def __init__(self, a, step, L, after=0):
        self.a, self.L, self.t0, self.s0 = a, L, None, max(step, after) + 50
        self.on = a.budget_h > 0 and not getattr(a, "budget_fixed", False)

    def tick(self, step):
        if not self.on: return
        if step == self.s0: self.t0 = time.time()
        elif self.t0 is not None and step == self.s0 + 300:
            rate = 300 / (time.time() - self.t0)
            total = int(step + rate * (self.a.budget_h * 3600 * 0.97 - (time.time() - START)))
            new = max(step + 1000, min(self.a.steps, total))
            self.L.log(f"budget {self.a.budget_h} h at {rate:.2f} it/s -> {new} steps (was {self.a.steps})"); self.a.steps = new; self.on = False; self.a.budget_done = True


START = time.time()


def lr_at(step, a):
    if step < a.warmup: return a.lr * (step + 1) / a.warmup
    p = min(1.0, (step - a.warmup) / max(1, a.steps - a.warmup))
    return a.lr * (a.min_lr_ratio + (1 - a.min_lr_ratio) * 0.5 * (1 + math.cos(math.pi * p)))


def save(path, obj):
    tmp = path + ".tmp"; torch.save(obj, tmp); os.replace(tmp, path)


def batch_to(b, dev, stats):
    b = {k: (v.to(dev, non_blocking=True) if torch.is_tensor(v) else v) for k, v in b.items()}
    b["mel"] = mel_torch(b["wav"]); T = b["mel"].shape[2]
    b["mlens"] = torch.clamp(b["mlens"], max=T)
    b["pitch"], b["voiced"] = D.normalise_pitch(b["pitch_hz"][:, :T], b["voice"], stats)
    return b


def run_model(model, b, dur=None):
    return model(b["tokens"], b["tlens"], b["lang"], b["voice"], b["mel"], b["mlens"], b["pitch"], b["voiced"], dur=dur)


def main(argv=None):
    a = get_args(argv); os.makedirs(a.out, exist_ok=True); L = Logger(a.out)
    if a.threads: torch.set_num_threads(a.threads)
    dev = torch.device("cuda" if torch.cuda.is_available() and not a.cpu else "cpu")
    if dev.type == "cpu" and not a.cpu: L.log("WARNING: CUDA not available, training on CPU (use --cpu to silence)")
    amp = a.amp if dev.type == "cuda" else "off"
    if amp == "bf16" and not torch.cuda.is_bf16_supported(): amp = "fp16"; L.log("bf16 unsupported on this GPU -> fp16")
    torch.manual_seed(a.seed); np.random.seed(a.seed)
    roots = a.data.split(",")
    train = D.Corpus(roots, "train", a.eval_pct, a.min_sec, a.max_sec); held = D.Corpus(roots, "eval", a.eval_pct, a.min_sec, a.max_sec, verbose=False) if a.eval_pct > 0 else None
    stats = D.pitch_stats(train.rows, os.path.join(a.out, "pitch_stats.json"))
    ck_path = os.path.join(a.out, "ckpt_last.pt"); ck = None
    if os.path.exists(ck_path) and not a.fresh:
        ck = torch.load(ck_path, map_location="cpu", weights_only=False); cfg = AMConfig.from_dict(ck["cfg"])
        L.log(f"resuming from {ck_path} at step {ck['step']}")
    else:
        cfg = AMConfig.preset(a.preset)
    model = AcousticModel(cfg).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.98), eps=1e-9, weight_decay=a.wd)
    step, epoch = 0, 0
    if ck is not None:
        model.load_state_dict(ck["model"]); opt.load_state_dict(ck["opt"]); step, epoch = ck["step"], ck["epoch"]
        if ck.get("steps_total") and a.budget_h > 0: a.steps = ck["steps_total"]; a.budget_fixed = a.budget_done = True; L.log(f"step budget from checkpoint: {a.steps}")
    elif a.init:
        sd = torch.load(a.init, map_location="cpu", weights_only=False)["model"]; missing = model.load_state_dict(sd, strict=False); L.log(f"init from {a.init}: {missing}")
    L.log(f"device {dev} amp {amp} | AM {model.n_params() / 1e6:.2f}M exported params (+{(model.n_params(False) - model.n_params()) / 1e6:.2f}M aligner) | cfg {asdict(cfg)}")
    scaler = torch.amp.GradScaler("cuda", enabled=(amp == "fp16"))
    ds = D.UttDataset(train); sampler = D.BucketBatches([r["frames"] for r in train.rows], a.max_frames, a.max_batch, a.seed, epoch)
    mk_loader = lambda s: torch.utils.data.DataLoader(ds, batch_sampler=s, num_workers=a.workers, collate_fn=D.collate_utts,
                                                      pin_memory=dev.type == "cuda", persistent_workers=False, prefetch_factor=4 if a.workers else None)
    stop = {"flag": False}
    def on_signal(sig, _):
        stop["flag"] = True; L.log(f"signal {sig}: saving and stopping after this step")
    signal.signal(signal.SIGTERM, on_signal); signal.signal(signal.SIGINT, on_signal)

    def state(): return {"model": model.state_dict(), "opt": opt.state_dict(), "step": step, "epoch": epoch, "cfg": asdict(cfg),
                         "stats": stats, "args": vars(a), "steps_total": a.steps if getattr(a, "budget_done", False) else None}
    budget = Budget(a, step, L)

    acc, n_acc, t_log, frames_log, bad = {}, 0, time.time(), 0, 0
    autocast = lambda: torch.autocast(device_type=dev.type, dtype=torch.bfloat16 if amp == "bf16" else torch.float16, enabled=amp != "off")
    model.train()
    while step < a.steps and not stop["flag"]:
        sampler.set_epoch(epoch)
        for b in mk_loader(sampler):
            if step >= a.steps or stop["flag"]: break
            b = batch_to(b, dev, stats)
            for g in opt.param_groups: g["lr"] = lr_at(step, a)
            w_bin = min(1.0, max(0.0, (step - a.bin_start * a.steps) / max(1.0, a.bin_warmup * a.steps)))
            with autocast():
                out = run_model(model, b)
            loss, d = am_losses(out, b["mel"], a.w_dur, a.w_pitch, a.w_align, w_bin, b["tlens"], b["mlens"])
            if not torch.isfinite(loss):
                bad += 1; opt.zero_grad(set_to_none=True); L.log(f"step {step}: non-finite loss {d} (skipped, {bad} in a row)")
                if bad >= 20: L.log("ERROR: 20 non-finite losses in a row - lower --lr or use --amp off"); save(ck_path, state()); sys.exit(2)
                continue
            bad = 0
            opt.zero_grad(set_to_none=True); scaler.scale(loss).backward(); scaler.unscale_(opt)
            gn = torch.nn.utils.clip_grad_norm_(model.parameters(), a.clip)
            if not torch.isfinite(gn) and amp != "fp16":            # (fp16: GradScaler already skips the step)
                bad += 1; opt.zero_grad(set_to_none=True); L.log(f"step {step}: non-finite gradient norm (skipped, {bad} in a row)")
                if bad >= 20: L.log("ERROR: 20 non-finite gradients in a row - lower --lr or use --amp off"); save(ck_path, state()); sys.exit(2)
                continue
            scaler.step(opt); scaler.update()
            step += 1; n_acc += 1; frames_log += int(b["mlens"].sum()); budget.tick(step)
            d["gnorm"] = float(gn); d["w_bin"] = w_bin
            for k, v in d.items(): acc[k] = acc.get(k, 0.0) + v
            if step % a.log_every == 0 or step == a.steps:
                dt = time.time() - t_log; m = {k: v / n_acc for k, v in acc.items()}
                L.log(f"step {step} ep {epoch} lr {lr_at(step, a):.2e} " + " ".join(f"{k} {v:.4f}" for k, v in m.items())
                      + f" | {n_acc / dt:.2f} it/s, {frames_log * 256 / 16000 / dt:.0f} s audio/s")
                L.metrics({"step": step, "epoch": epoch, "lr": lr_at(step, a), "it_s": n_acc / dt, **m}); acc, n_acc, t_log, frames_log = {}, 0, time.time(), 0
            if step % a.save_every == 0: save(ck_path, state())
            if a.keep_every and step % a.keep_every == 0: save(os.path.join(a.out, f"ckpt_{step}.pt"), state())
            if held is not None and (step % a.eval_every == 0 or step == a.steps): evaluate(model, held, stats, dev, autocast, L, step, a)
        else:
            epoch += 1
            continue
        if step >= a.steps or stop["flag"]: break
    save(ck_path, state())
    if step >= a.steps: save(os.path.join(a.out, "final.pt"), state()); L.log(f"done: {step} steps -> {a.out}/final.pt")
    else: L.log(f"stopped at step {step} (resume by running the same command)")


@torch.no_grad()
def evaluate(model, held, stats, dev, autocast, L, step, a, max_batches=8):
    """Held-out: teacher-forced mel L1 (durations from the aligner), duration and pitch predictor errors."""
    model.eval(); ds = D.UttDataset(held)
    sampler = D.BucketBatches([r["frames"] for r in held.rows], a.max_frames, a.max_batch, 0, 0, shuffle=False)
    tot, n, dur_abs, ntok = {}, 0, 0.0, 0
    for i, b in enumerate(torch.utils.data.DataLoader(ds, batch_sampler=sampler, num_workers=0, collate_fn=D.collate_utts)):
        if i >= max_batches: break
        b = batch_to(b, dev, stats)
        with autocast(): out = run_model(model, b)
        _, d = am_losses(out, b["mel"], tlens=b["tlens"], mlens=b["mlens"])
        for k, v in d.items(): tot[k] = tot.get(k, 0.0) + v
        tm = out["tmask"]; pred = torch.clamp(torch.exp(out["logd"].float()) - 1, min=0)
        dur_abs += float(((pred - out["dur_t"]).abs() * tm).sum()); ntok += int(tm.sum()); n += 1
    m = {k: v / max(1, n) for k, v in tot.items()}; m["dur_mae_frames"] = dur_abs / max(1, ntok)
    L.log(f"EVAL step {step}: " + " ".join(f"{k} {v:.4f}" for k, v in m.items())); L.metrics({"step": step, "eval": m})
    model.train()


if __name__ == "__main__":
    main()
