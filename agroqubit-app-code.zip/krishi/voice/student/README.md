# KrishiVoice: our own trained voice model (student of the Indic-TTS teacher)

KrishiVoice is a small multilingual, multi-speaker TTS. It covers Hindi, Tamil, Kannada and English, each with the
female and male voice, and runs in pure Java on the phone (`Speak.java`, no ML runtime, no native code). The app
plays the pre-rendered human-quality clips for verified facts and uses KrishiVoice for everything else (numbers,
names, any text). KrishiVoice is trained only on audio rendered by the teacher, AI4Bharat Indic-TTS (FastPitch +
HiFi-GAN, MIT). So it copies the same eight voices, their pacing and their loudness, and its speech blends with the
clips.

## Design

```
text --text.py / SpeakText.java--> sentences --> [bnd] chars [bnd]       (386 symbols: Devanagari, Tamil, Kannada, a-z, ' , . ? !)
  --> acoustic model (model_am.py, 9.3M params)
        token emb + language emb + voice emb (+ sinusoid positions)
        4 x FFT block (2-head self-attention + conv FFN k3, d 256, ffn 768, post-LN)
        duration predictor -> log(1+frames)      pitch predictor -> per-token mean normalised log-f0 -> conv k3 embedding
        length regulator (float64 cumulative rounding, half-to-even; speed control)
        + positions + decoder voice emb -> 4 x FFT block -> linear -> 80-bin log-mel   (16 ms frames)
  --> vocoder (model_voc.py, Vocos-style, 3.6M params)
        conv k7 -> LN -> 8 x ConvNeXt (dw k7, LN, 256->768->256 GELU, layer scale) -> LN -> linear -> 513 log-mag | 513 phase
        -> iSTFT (n_fft 1024, hop 256, Hann, centred) -> 16 kHz
```

* **Voices.** The teacher's "female" and "male" are different people in each language. KrishiVoice therefore has a
  language embedding (4) plus a voice embedding per (language, speaker) pair (8): `voice = lang * 2 + speaker`.
* **Alignment** follows "One TTS Alignment To Rule Them All". An alignment encoder takes the token embeddings and
  the target mel and computes L2 attention, with a beta-binomial prior. The forward-sum (CTC) loss trains it. MAS
  (numba, with a numpy fallback) produces hard durations, and the binarization loss starts at 10% of training. No
  external aligner or phonemizer is used. The aligner (0.5M params) exists only for training and is not exported.
  The batched CTC matches NeMo's per-item loss exactly. On 4 smoke clips it learns a sharp alignment in 300 CPU
  steps (forward-sum 1.82 → 0.58, mean attention peak 0.29 → 0.93).
* **Losses.** Mel L1, duration MSE ×0.5, pitch MSE ×0.5, forward-sum ×1, binarization (ramped to ×1). The vocoder
  uses hinge GAN losses with a multi-period discriminator (periods 2,3,5,7,11) and a band-split multi-resolution
  STFT discriminator (windows 512/1024/2048, ×0.1), plus feature matching and mel L1 ×45, as in Vocos.
* **Mel** (`audio.py`, one definition everywhere). 16 kHz, n_fft 1024, hop 256, win 1024, 80 slaney mels 0–8 kHz,
  ln(clamp 1e-5), centred STFT. A segment of K·256 samples gives exactly K+1 frames, and the centred iSTFT returns
  K·256 samples. 16 kHz matches the clips (speech band, Opus 16 kbps). The phone needs one 512-point complex FFT
  per 16 ms frame and no mel filterbank.
* **Pitch.** YIN, vectorised numpy, about 300× real time on one core. librosa's pyin ran at about 1× here, too slow
  for 64 h. Voicing uses aperiodicity < 0.45 and energy > −60 dB. Against pyin it has 6 cents median error and
  82% voicing agreement, which is enough for per-token mean pitch.
* **Text** (`text.py`). NFC; zero-width marks deleted; ASCII lower-cased; accents folded; digits (ASCII, Devanagari,
  Tamil, Kannada) spoken digit by digit with the language's words; `2.5` read as "two point five"; Latin letters
  inside hi/ta/kn text spelled with the verbalize.py letter names; punctuation mapped (danda → `.`, `; : — (` → `,`);
  anything else becomes a space; spaces and punctuation tidied. Sentences are cut after `. ? !` followed by a space,
  synthesised one by one and joined with 0.28 s pauses, as in `render_segments.py`. The tables travel in
  voice.json, and `SpeakText.java` runs the same algorithm (314/314 test strings identical, 300 of them random fuzz).
* **Output format.** Same as the clips: peak 0.85, 50 ms silence before, 100 ms after.

## Files

| file | what |
|---|---|
| `text.py`, `audio.py` | front end, mel, YIN, wav I/O |
| `model_am.py`, `model_voc.py` | acoustic model + aligner + MAS + losses; vocoder + discriminators + losses |
| `data.py` | metadata, held-out split (crc32 of the sentence text, 2%), pitch stats, length-bucketed batches |
| `prep_teacher.py` | renders the corpus with the teacher on the VM: sharded, resumable, reports hours |
| `prep_local.py` | smoke corpus from the repo's Opus clips (`pack_human*`, text = `render_human.norm(catalogue)`) |
| `train_am.py`, `train_voc.py` | GPU bf16 autocast, resume from `ckpt_last.pt`, SIGTERM-safe, `--budget_h`, `--cpu --preset tiny` |
| `export.py` | `voice_am.bin` + `voice_voc.bin` (KRW1) + `voice.json`; `--check` = int8 vs float |
| `infer.py`, `eval.py` | Python reference synthesis; held-out evaluation vs the teacher |
| `run_vm.sh` | the whole VM pipeline (`SMOKE=1` rehearses every stage on CPU) |
| `android/src/in/krishi/doctor/Speak.java`, `SpeakText.java`, `SpeakOps.java` | phone runtime |
| `android/test/voice/` | `make_voice_case.py` (PyTorch references), `SpeakTest.java` (parity + speed), `run.sh` |

## Phone files and Java API

`export.py` writes:

* **voice_am.bin, 9.6 MB.** int8 rows with an fp32 scale per row for every GEMM weight, fp16 token table, fp32 for
  norms, biases and small tensors.
* **voice_voc.bin, 3.7 MB.**
* **voice.json** with the text tables, mel/STFT parameters, dimensions and pitch stats.

Total: **13.3 MB**.

```java
Speak tts = new Speak(dir);                                  // or new Speak(jsonStream, amStream, vocStream)
float[] pcm = tts.synth("दो सौ पचास ग्राम, एक लीटर पानी में।", "hi", "female");      // 16 kHz mono
float[] fast = tts.synth(text, "ta", "male", 1.15f);        // 15% faster
```

For long answers, split with `tts.sentences(tts.normalize(text, lang))`, call `synth` per sentence and play each
one while the next is computed, adding 0.28 s gaps.

Conv weights are stored tap-major (`[cout][k*cin]`), so a k-tap conv over row-major `[T][cin]` activations is one
strided GEMM. `SpeakOps.gemm` dequantises 4 int8 rows into an interleaved float tile and accumulates 4 rows × 4
frames in registers. It runs 3–4× faster than `Nn.linear` (≈2.0–2.4 vs 0.6 GMAC/s on one x86 core). Threads come
from `Nn.par`. The iSTFT is a radix-2 real IFFT through a half-size complex FFT and matches `torch.istft`.

## Tests and results (this sandbox: 2 shared x86 vCPUs, no GPU)

`bash android/test/voice/run.sh [am.pt voc.pt]` builds the cases (PyTorch with the *exported* int8 weights), compiles
at `--release 8` and runs `SpeakTest`:

| case | text | durations | mel max abs diff | wave (vocoder) | full `synth()` text |
|---|---|---|---|---|---|
| random init, full size (9.3M + 3.6M) | 314/314 identical (14 hand-written + 300 fuzz) | 318/318 tokens identical | 1.7e-6 (limit 1e-3) | 1.6e-7 | 1.3e-6 |
| tiny model trained on CPU | 314/314 identical | 318/318 identical | 3.8e-6 | 4.5e-7 | 9.5e-7 |

**Speed of the full-size model** on a 3.7 s sentence (median of 6 runs):

| threads | acoustic model | vocoder | RTF |
|---|---|---|---|
| 1 | 0.51 s | 0.36 s | 0.24 |
| 2 | 0.33 s | 0.23 s | 0.15 |
| 4 | 0.59 s | 0.38 s | 0.27 (box has only 2 shared vCPUs) |

Compute is about 520 M multiply-adds per second of audio: the AM decoder ≈ 4.7 M per frame and the vocoder ≈ 3.6 M
per frame. Phone RTF is not measured. It should be the same order on a Cortex-A53 with 4 threads (an estimate of
0.3–0.5). The small presets (`AM_PRESET=small VOC_PRESET=small` in run_vm.sh: AM 5.3M, vocoder 2.1M) cut compute
by about 40%.

**Smoke training** on CPU used 591 local clips (0.75 h, 8 voices) and the tiny presets.

* AM, 718 steps on a heavily shared CPU: mel L1 4.89 → 1.12, duration MSE 0.89 → 0.19, pitch MSE 1.06 → 0.54,
  binarization 2.18 → 1.28, forward-sum 3.41 → 3.20. The forward-sum loss is still slow at this scale; on 4 clips
  alone it falls 1.82 → 0.58 in 300 steps.
* Vocoder, 400 steps (2 min): mel L1 1.86 → 0.94; the discriminator is learning (2.18 → 1.76).
* Export: 0.98 MB. int8 vs float gives mean |Δmel| 0.0045 and vocoder SNR 42 dB.
* Java writes WAVs (`java_<i>.wav`, `Speak` CLI). The speech is not intelligible at this size, as expected.
* `prep_teacher.py` rendered real teacher audio on CPU at max RSS 1.8 GB, because checkpoints are memory-mapped
  and their optimiser state is never read. Teacher vocabularies cover every default sentence.
* `SMOKE=1 run_vm.sh` ran every stage in 6 min: render → AM ∥ vocoder → fine-tune on AM mels → export → eval → Java
  parity, all OK. Resume after SIGTERM was also exercised (the AM saved at step 718 and resumed).

## GPU VM plan (one L4 24 GB, ≥ 8 vCPUs, ~150 GB disk)

```bash
cd /home/claude/krishi
# Text lists (one text per line): /data/texts/{hi,ta,kn,en}.txt. 'default' adds every sentence the app says + number phrases.
TEXTS=default,/data/texts HOURS=8 AM_BUDGET_H=7 VOC_BUDGET_H=7 FT_BUDGET_H=1 bash voice/student/run_vm.sh
# progress: /opt/kv/progress.txt, logs /opt/kv/logs, results /opt/kv/out/{export,eval}, krishivoice_results.tgz
```

| stage | command (inside run_vm.sh) | L4 estimate | GPU memory |
|---|---|---|---|
| setup + teacher download (4 × 1.6 GB) | pip, curl (as `android/tools/job.sh`) | 0.3 h, GPU idle | – |
| render 8 voices × 8 h = 64 h audio | `prep_teacher.py --langs <L> --texts … --hours 8 --device cuda`, 4 processes, then `--merge` | **~1 h** (teacher ≈ 60–120× real time per process) | 4 × ~1.5 GB |
| acoustic model | `train_am.py --data D --out runs/am --budget_h 7` (bf16, ~20k frames ≈ 5 min audio per batch) | **7 h**, in parallel with ↓ | ~8 GB |
| vocoder, ground-truth mels | `train_voc.py --data D --out runs/voc --budget_h 7 --pretrain_mel_steps 5000` (batch 16 × 0.8 s) | (same 7 h) | ~6 GB |
| vocoder fine-tune on AM mels | `train_voc.py --init runs/voc/final.pt --am_ckpt runs/am/final.pt --budget_h 1 --lr 1e-4` | **1 h** | ~6 GB |
| export + eval + Java test | `export.py --check`, `eval.py`, `android/test/voice/run.sh` | 0.3 h | – |
| **total** | | **≈ 9.5–10 GPU-hours** of the 12–16 h budget, which leaves room to rerun one training stage | |

* **Speed estimates and the budget.** Training speeds are estimates; no GPU was available here. My guesses are
  4–7 it/s for the AM and 4–6 it/s for the vocoder when the two share the GPU. `--budget_h` handles the
  uncertainty: after about 300 steps each trainer measures its real speed and fits the step count and cosine
  schedule to the hours given. So a 7 h budget gives roughly 80–150k AM steps and 80–120k vocoder steps. Resumed
  runs keep the fitted schedule.
* **Corpus recommendation.** 8 h per voice is about 6k sentences of ~5 s per language; the same list is used for both
  speakers. Use diverse general text plus agriculture, number, unit and name sentences. Rendering is cheap (~1 h), and
  the training budget, not the corpus, limits quality. So use the full 8 h if the text lists allow it (up to 10 h is
  fine). Below about 3 h per voice, expect mispronounced rare conjuncts. If the lists are short, the default list
  alone gives only about 400 sentences (~0.5 h) per voice, and `prep_teacher.py` warns.
* **Expected quality.**
  * Same voices, pacing and loudness as the clips, since everything is learned from the teacher.
  * Prosody close to the teacher: its durations and pitch are deterministic and easy to distil.
  * Intelligibility close to the teacher. Somewhat less crisp: AM over-smoothing plus a 3.6M-parameter 16 kHz
    vocoder can add slight buzz or phasiness. That is perhaps 0.3–0.6 MOS below the teacher, an estimate, not a
    measurement. A listener can tell a synthesised number apart from a neighbouring clip, but both are the same voice.
  * `eval.py` reports AM mel L1 (teacher-forced), duration error in frames per token and % of length, pitch RMSE,
    and MCD-DTW against the teacher (c1–c24 DCT cepstra of the log-mel; relative numbers only). It also gives
    copy-synthesis MCD (vocoder alone), the int8 impact and Python RTF, and writes teacher/student WAVs to listen to.

## Known risks

* GPU throughput, and so the steps reached in 7 h, is estimated, not measured. Convergence on the real corpus is
  untested beyond CPU smoke runs.
* The text lists determine coverage. The default list is small, and the corpus must cover numbers and names in all
  languages.
* Phone speed is unmeasured on ARM/ART. If it is too slow, retrain with `AM_PRESET=small VOC_PRESET=small`
  (about 40% less compute).
* Very long sentences (> 15 s, the training cap) may degrade. Speak.java splits only at `. ? !`.
* Latin words inside Indic text are spelled letter by letter. Real product names should be transliterated upstream
  (verbalize.py).
* Java and Python durations were identical in every test, but a rounding tie could in theory differ by one frame.
