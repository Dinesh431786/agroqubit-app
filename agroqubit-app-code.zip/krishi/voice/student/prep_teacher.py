"""Render the KrishiVoice training corpus with the teacher (AI4Bharat Indic-TTS FastPitch + HiFi-GAN, MIT, coqui-tts
0.27.5) on the GPU VM: every sentence x both speakers, the same post-processing as the app's clips
(voice/render_segments.py: 22.05 -> 16 kHz, trim at 1% of peak keeping 50/100 ms, peak 0.85), plus YIN pitch.

Text: --texts default         sentences the app says (closed-world segments: catalogue, app phrases, advice items,
                              formal catalogue) + number / code phrases, verbalised per voice (voice/verbalize.py)
      --texts DIR             DIR/<lang>.txt, UTF-8, one text per line ('#' comments); several sentences per line OK
      --texts default,DIR     both
Each text goes through verbalize() (falls back to the student's own normaliser when verbalize cannot read it, so the
teacher speaks exactly what the student will read), is split into sentences, de-duplicated, and characters the
teacher's model does not know are removed first (the teacher would silently drop them and the text/audio pair would
disagree). Sentences are shuffled per voice (fixed seed) and rendered until --hours per voice is reached.

Output (resumable, sharded): <out>/wavs/<lang>_<speaker>/<n>.wav, <out>/pitch/<lang>_<speaker>/<n>.npy,
<out>/meta/<lang>_<speaker>_s<shard>.jsonl (one row per rendered sentence; rows are appended and flushed, a rerun
skips done ids), <out>/logs/. Finish with --merge (metadata.jsonl + report.json with hours per voice).

  python3 prep_teacher.py --out /data/kv --langs hi --texts default,/data/texts --hours 8          (one process per language)
  python3 prep_teacher.py --out /data/kv --merge
Local test (CPU, tiny): python3 prep_teacher.py --out /tmp/kv --langs en --speakers female --limit 2 --device cpu
"""
import argparse, glob, hashlib, json, os, random, re, sys, tempfile, time
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); VOICE = os.path.dirname(HERE); KRISHI = os.path.dirname(VOICE)
sys.path.insert(0, HERE)
import text as T
from audio import SR, save_wav, pitch_yin, trim

MODELS = os.environ.get("TTS_MODELS", "/home/claude/tts_models")

# ------------------------------------------------------------------ text lists
NUM_TEMPLATES = {
    "hi": ["{n} ग्राम दवाई {m} लीटर पानी में मिलाइए.", "{n} दिन बाद फिर से छिड़काव कीजिए.", "एक एकड़ में {n} किलो डालिए.",
           "नंबर है {d}.", "कोड {d} लिखिए.", "कीमत {n} रुपये है."],
    "ta": ["{n} கிராம் மருந்தை {m} லிட்டர் தண்ணீரில் கலக்குங்க.", "{n} நாள் கழித்து மறுபடியும் தெளிங்க.", "ஒரு ஏக்கருக்கு {n} கிலோ போடுங்க.",
           "நம்பர் {d}.", "கோட் {d}.", "விலை {n} ரூபாய்."],
    "kn": ["{n} ಗ್ರಾಂ ಔಷಧಿಯನ್ನ {m} ಲೀಟರ್ ನೀರಿಗೆ ಹಾಕಿ.", "{n} ದಿನದ ನಂತರ ಮತ್ತೆ ಸಿಂಪಡಿಸಿ.", "ಒಂದು ಎಕರೆಗೆ {n} ಕಿಲೋ ಹಾಕಿ.",
           "ನಂಬರ್ {d}.", "ಕೋಡ್ {d}.", "ಬೆಲೆ {n} ರೂಪಾಯಿ."],
    "en": ["Mix {n} grams in {m} litres of water.", "Spray again after {n} days.", "Use {n} kilograms per acre.",
           "The number is {d}.", "Enter code {d}.", "The price is {n} rupees."],
}


def number_phrases(lang, k=150, seed=0):
    """Phrases with numbers said as words (verbalize.py tables) and digit strings said digit by digit."""
    sys.path.insert(0, VOICE)
    from verbalize import NUM, en_num
    rng = random.Random(f"{seed}-{lang}")
    words = [en_num(n) for n in rng.sample(range(1, 2000), 120)] if lang == "en" else list(NUM[lang].values())
    out = []
    for i in range(k):
        t = NUM_TEMPLATES[lang][i % len(NUM_TEMPLATES[lang])]
        d = " ".join(T.DIGIT_WORDS[lang][rng.randrange(10)] for _ in range(rng.choice([3, 4, 6, 10])))
        out.append(t.format(n=rng.choice(words), m=rng.choice(words), d=d))
    return out


def default_texts(lang):
    """Every sentence the app can say (closed_world.py segments) + the formal catalogue + number phrases."""
    sys.path.insert(0, VOICE)
    from closed_world import segments
    with tempfile.TemporaryDirectory() as td:
        for src in ("voice/catalogue.json", "voice/app_phrases.json", "brain/advice.json", "brain/advice_i18n.json"):
            os.symlink(os.path.join(KRISHI, src), os.path.join(td, os.path.basename(src)))
        seg = segments(td)
    texts = list(seg[lang].values())
    formal = os.path.join(VOICE, "catalogue_formal.json")
    if os.path.exists(formal): texts += [v[lang] for v in json.load(open(formal, encoding="utf-8")).values() if lang in v]
    return texts + number_phrases(lang)


def load_texts(spec, lang):
    texts = []
    for part in spec.split(","):
        part = part.strip()
        if not part: continue
        if part == "default": texts += default_texts(lang); continue
        f = os.path.join(part, f"{lang}.txt")
        if not os.path.exists(f): print(f"note: {f} not found, skipped"); continue
        texts += [ln.strip() for ln in open(f, encoding="utf-8") if ln.strip() and not ln.lstrip().startswith("#")]
    return texts


def speech_sentences(texts, lang, speaker, vocab, max_chars=250):
    """Raw texts -> unique spoken sentences for this voice (verbalized, split, teacher-vocabulary clean)."""
    sys.path.insert(0, VOICE)
    from verbalize import verbalize, sentences
    v = "m" if speaker == "male" else "f"; seen, out, fallback = set(), [], 0
    for t in texts:
        try: s = verbalize(t, lang, v)
        except Exception: s = T.normalize(t, lang); fallback += 1
        for sent in sentences(s):
            if vocab is not None: sent = "".join(c if (c in vocab or c == " ") else " " for c in sent)
            sent = re.sub(r"\s+", " ", sent).strip(" ,")
            sent = re.sub(r"\s+([,.?!])", r"\1", sent)
            if not (3 <= len(sent) <= max_chars) or not re.search(r"\w", sent) or sent in seen: continue
            seen.add(sent); out.append(sent)
    return out, fallback


# ------------------------------------------------------------------ teacher
def _mmap_load(path, map_location=None, cache=False, **kw):
    import torch
    if os.path.exists(str(path)): return torch.load(str(path), map_location="cpu", mmap=True, weights_only=False)
    from trainer.io import load_fsspec
    return load_fsspec(path, map_location=map_location, cache=cache, **kw)


def load_teacher(lang, device):
    """indic_tts.synth() with a device choice; checkpoints are memory-mapped (their optimiser state is never read)."""
    import torch
    import TTS.model, TTS.vocoder.models.gan, TTS.vocoder.models.hifigan_generator
    for m in (TTS.model, TTS.vocoder.models.gan, TTS.vocoder.models.hifigan_generator): m.load_fsspec = _mmap_load
    from TTS.utils.synthesizer import Synthesizer
    d = f"{MODELS}/{lang}"
    for f in ("fastpitch/best_model.pth", "fastpitch/config.json", "hifigan/best_model.pth", "hifigan/config.json"):
        if not os.path.exists(f"{d}/{f}"): raise FileNotFoundError(f"teacher file missing: {d}/{f} (see android/tools/job.sh download step; set TTS_MODELS)")
    spk = f"{d}/fastpitch/speakers.pth" if os.path.exists(f"{d}/fastpitch/speakers.pth") else f"{d}/speakers.pth"
    s = Synthesizer(tts_checkpoint=f"{d}/fastpitch/best_model.pth", tts_config_path=f"{d}/fastpitch/config.json", tts_speakers_file=spk,
                    vocoder_checkpoint=f"{d}/hifigan/best_model.pth", vocoder_config=f"{d}/hifigan/config.json", use_cuda=device == "cuda")
    return s


def teacher_vocab(s):
    try:
        ch = s.tts_model.tokenizer.characters
        return set(ch.vocab) | set(getattr(ch, "punctuations", "") or "")
    except Exception:
        return None


def render(s, sentence, speaker):
    import torch
    from scipy.signal import resample_poly
    with torch.inference_mode():
        w = np.asarray(s.tts(sentence, speaker_name=speaker, split_sentences=False), np.float32)
    sr = s.output_sample_rate
    if sr != SR:
        from math import gcd
        g = gcd(SR, int(sr)); w = resample_poly(w, SR // g, int(sr) // g).astype(np.float32)
    w = trim(w)
    return (w / (np.abs(w).max() + 1e-6) * 0.85).astype(np.float32)


# ------------------------------------------------------------------ main
def merge(out):
    rows = []
    for f in sorted(glob.glob(os.path.join(out, "meta", "*.jsonl"))):
        for line in open(f, encoding="utf-8"):
            try: rows.append(json.loads(line))
            except json.JSONDecodeError: pass
    rows.sort(key=lambda r: r["id"])
    with open(os.path.join(out, "metadata.jsonl.tmp"), "w", encoding="utf-8") as f:
        for r in rows: f.write(json.dumps(r, ensure_ascii=False) + "\n")
    os.replace(os.path.join(out, "metadata.jsonl.tmp"), os.path.join(out, "metadata.jsonl"))
    rep = {}
    for r in rows:
        k = f"{r['lang']}_{r['speaker']}"; e = rep.setdefault(k, {"utterances": 0, "hours": 0.0}); e["utterances"] += 1; e["hours"] += r["seconds"] / 3600
    rep = {k: {"utterances": v["utterances"], "hours": round(v["hours"], 3)} for k, v in sorted(rep.items())}
    rep["total_hours"] = round(sum(v["hours"] for v in rep.values() if isinstance(v, dict)), 3)
    json.dump(rep, open(os.path.join(out, "report.json"), "w"), indent=1); print(json.dumps(rep, indent=1))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", required=True); ap.add_argument("--langs", default="hi,ta,kn,en"); ap.add_argument("--speakers", default="female,male")
    ap.add_argument("--texts", default="default"); ap.add_argument("--hours", type=float, default=8.0, help="hours per voice (this many over all shards)")
    ap.add_argument("--shard", type=int, default=0); ap.add_argument("--nshards", type=int, default=1)
    ap.add_argument("--device", default="cuda"); ap.add_argument("--limit", type=int, default=0, help="max sentences per voice (tests)")
    ap.add_argument("--seed", type=int, default=0); ap.add_argument("--merge", action="store_true")
    a = ap.parse_args()
    if a.merge: merge(a.out); return
    import torch
    if a.device == "cuda" and not torch.cuda.is_available(): sys.exit("ERROR: --device cuda but CUDA is not available (use --device cpu for a small test)")
    os.makedirs(os.path.join(a.out, "meta"), exist_ok=True); os.makedirs(os.path.join(a.out, "logs"), exist_ok=True)
    log = open(os.path.join(a.out, "logs", f"prep_{a.langs.replace(',', '_')}_s{a.shard}.log"), "a", buffering=1, encoding="utf-8")
    def say(m):
        line = f"{time.strftime('%H:%M:%S')} {m}"; print(line, flush=True); log.write(line + "\n")
    for lang in a.langs.split(","):
        t0 = time.time(); s = load_teacher(lang, a.device); vocab = teacher_vocab(s)
        say(f"{lang}: teacher loaded on {a.device} in {time.time() - t0:.0f}s, vocab {len(vocab) if vocab else '?'} chars")
        texts = load_texts(a.texts, lang)
        for spk in a.speakers.split(","):
            sents, fb = speech_sentences(texts, lang, spk, vocab)
            random.Random(f"{a.seed}-{lang}-{spk}").shuffle(sents)
            if a.limit: sents = sents[:a.limit]
            key = f"{lang}_{spk}"; meta = os.path.join(a.out, "meta", f"{key}_s{a.shard}.jsonl")
            done, hours = set(), 0.0
            if os.path.exists(meta):
                for line in open(meta, encoding="utf-8"):
                    try: r = json.loads(line); done.add(r["id"]); hours += r["seconds"] / 3600
                    except json.JSONDecodeError: pass
            budget = a.hours / a.nshards
            say(f"{key}: {len(sents)} sentences ({fb} texts via fallback normaliser), shard {a.shard}/{a.nshards}: {len(done)} done, {hours:.2f} h of {budget:.2f} h")
            mf = open(meta, "a", encoding="utf-8"); n_new, t_voice, audio_new, errors = 0, time.time(), 0.0, 0
            for k, sent in enumerate(sents):
                if k % a.nshards != a.shard: continue
                if hours >= budget: break
                uid = f"{key}_{hashlib.sha1(sent.encode()).hexdigest()[:12]}"
                if uid in done: continue
                try:
                    w = render(s, sent, spk)
                except Exception as e:
                    errors += 1; say(f"  render error ({type(e).__name__}: {e}) for: {sent[:80]}")
                    if errors > 50 and n_new == 0: raise
                    continue
                if len(w) < 0.3 * SR: continue
                rel = f"wavs/{key}/{uid}.wav"; prel = f"pitch/{key}/{uid}.npy"
                tmp = os.path.join(a.out, rel + ".tmp.wav"); save_wav(tmp, w); os.replace(tmp, os.path.join(a.out, rel))
                os.makedirs(os.path.dirname(os.path.join(a.out, prel)), exist_ok=True); np.save(os.path.join(a.out, prel), pitch_yin(w)[0])
                sec = len(w) / SR
                mf.write(json.dumps({"id": uid, "text": sent, "lang": lang, "speaker": spk, "path": rel, "pitch": prel, "seconds": round(sec, 3),
                                     "samples": int(len(w))}, ensure_ascii=False) + "\n"); mf.flush()
                hours += sec / 3600; audio_new += sec; n_new += 1
                if n_new % 100 == 0:
                    el = time.time() - t_voice
                    say(f"  {key}: +{n_new} ({hours:.2f}/{budget:.2f} h), {audio_new / el:.1f}x real time, ETA {max(0, budget - hours) * 3600 / max(1e-9, audio_new / el) / 60:.0f} min")
            mf.close(); el = time.time() - t_voice
            say(f"{key}: done, {n_new} new sentences, {audio_new / 60:.1f} min audio in {el / 60:.1f} min ({audio_new / max(el, 1e-9):.1f}x real time), total {hours:.2f} h, {errors} errors")
            if hours < 0.9 * budget and not a.limit:
                say(f"WARNING {key}: only {hours:.2f} h for a {budget:.2f} h budget - the text list is too small (add --texts DIR with more sentences)")
        del s
        if a.device == "cuda": torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
