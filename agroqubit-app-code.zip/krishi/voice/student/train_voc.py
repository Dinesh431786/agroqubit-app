"""Train the KrishiVoice vocoder (model_voc.py).

Stage 1 (universal, all 8 voices): ground-truth mels of teacher audio -> audio.
  python3 train_voc.py --data /data/kv --out runs/voc --steps 120000
Stage 2 (optional, after the AM): fine-tune on AM-predicted mels (teacher-forced durations and pitch, so they line
up with the real audio), which removes most of the 'AM mel is smoother than real mel' mismatch.
  python3 train_voc.py --data /data/kv --out runs/voc_ft --init runs/voc/final.pt --am_ckpt runs/am/final.pt --steps 15000 --lr 1e-4
CPU smoke: --preset tiny --disc tiny --cpu --steps 300 --batch 4 --seg_frames 24
Resumes from <out>/ckpt_last.pt; SIGTERM/SIGINT save first; logs in <out>/train.log + metrics.jsonl; listening samples
in <out>/samples/.
"""
import argparse, json, math, os, signal, sys, time
from dataclasses import asdict
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import data as D
from audio import HOP, SR, mel_torch, save_wav
from model_voc import Vocoder, VocConfig, Discriminators, d_hinge, g_hinge, feature_matching, mel_l1
from train_am import Logger, save, batch_to, Budget


def get_args(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--preset", default="base", choices=["base", "small", "large", "tiny"])
    ap.add_argument("--disc", default="base", choices=["base", "tiny"])
    ap.add_argument("--steps", type=int, default=120000)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--seg_frames", type=int, default=50, help="segment = seg_frames*256 samples (50 -> 0.8 s)")
    ap.add_argument("--lr", type=float, default=5e-4); ap.add_argument("--warmup", type=int, default=1000)
    ap.add_argument("--min_lr_ratio", type=float, default=0.1)
    ap.add_argument("--mel_coeff", type=float, default=45.0); ap.add_argument("--mrd_coeff", type=float, default=0.1)
    ap.add_argument("--pretrain_mel_steps", type=int, default=0, help="first steps with the mel loss only (no GAN)")
    ap.add_argument("--clip", type=float, default=1000.0)
    ap.add_argument("--amp", default="bf16", choices=["bf16", "fp16", "off"])
    ap.add_argument("--workers", type=int, default=6); ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("--cpu", action="store_true"); ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--eval_pct", type=float, default=2.0); ap.add_argument("--max_sec", type=float, default=15.0)
    ap.add_argument("--log_every", type=int, default=100); ap.add_argument("--save_every", type=int, default=2000)
    ap.add_argument("--eval_every", type=int, default=10000); ap.add_argument("--keep_every", type=int, default=40000)
    ap.add_argument("--budget_h", type=float, default=0.0, help="fit the step count (and LR schedule) to this many hours; 0 = use --steps")
    ap.add_argument("--fresh", action="store_true")
    ap.add_argument("--init", default="", help="initial generator (+discriminator) weights, new optimisers")
    ap.add_argument("--am_ckpt", default="", help="fine-tune on mels predicted by this AM checkpoint (teacher forced)")
    ap.add_argument("--ft_max_frames", type=int, default=12000, help="utterance batch size (padded frames) in AM fine-tuning")
    return ap.parse_args(argv)


def lr_at(step, a):
    if step < a.warmup: return a.lr * (step + 1) / a.warmup
    p = min(1.0, (step - a.warmup) / max(1, a.steps - a.warmup))
    return a.lr * (a.min_lr_ratio + (1 - a.min_lr_ratio) * 0.5 * (1 + math.cos(math.pi * p)))


class AMSegments:
    """Batches of (AM-predicted mel segment [B,80,K+1], matching audio [B,K*256]) from whole utterances."""
    def __init__(self, a, corpus, dev, L):
        from model_am import AcousticModel, AMConfig
        ck = torch.load(a.am_ckpt, map_location="cpu", weights_only=False)
        self.am = AcousticModel(AMConfig.from_dict(ck["cfg"])).to(dev).eval(); self.am.load_state_dict(ck["model"])
        self.stats = {int(k): tuple(v) for k, v in ck["stats"].items()}
        self.corpus, self.a, self.dev, self.epoch = corpus, a, dev, 0
        L.log(f"fine-tuning on mels from AM {a.am_ckpt} (step {ck['step']})")

    def __iter__(self):
        a = self.a; K = a.seg_frames
        while True:
            s = D.BucketBatches([r["frames"] for r in self.corpus.rows], a.ft_max_frames, a.batch, a.seed, self.epoch); self.epoch += 1
            for b in torch.utils.data.DataLoader(D.UttDataset(self.corpus), batch_sampler=s, num_workers=a.workers, collate_fn=D.collate_utts):
                b = batch_to(b, self.dev, self.stats)
                with torch.no_grad():
                    out = self.am(b["tokens"], b["tlens"], b["lang"], b["voice"], b["mel"], b["mlens"], b["pitch"], b["voiced"])
                mel_hat = out["mel"].float(); mels, wavs = [], []
                for i in range(mel_hat.shape[0]):
                    n = int(b["mlens"][i])
                    if n < K + 2: continue
                    st = np.random.randint(0, n - K - 1)
                    mels.append(mel_hat[i, :, st:st + K + 1]); wavs.append(b["wav"][i, st * HOP:(st + K) * HOP])
                if mels: yield torch.stack(wavs), torch.stack(mels)


def main(argv=None):
    a = get_args(argv); os.makedirs(os.path.join(a.out, "samples"), exist_ok=True); L = Logger(a.out)
    if a.threads: torch.set_num_threads(a.threads)
    dev = torch.device("cuda" if torch.cuda.is_available() and not a.cpu else "cpu")
    if dev.type == "cpu" and not a.cpu: L.log("WARNING: CUDA not available, training on CPU")
    amp = a.amp if dev.type == "cuda" else "off"
    if amp == "bf16" and not torch.cuda.is_bf16_supported(): amp = "fp16"
    torch.manual_seed(a.seed); np.random.seed(a.seed)
    roots = a.data.split(","); seg = a.seg_frames * HOP
    train = D.Corpus(roots, "train", a.eval_pct, min_sec=(seg + 2 * HOP) / SR, max_sec=a.max_sec)
    held = D.Corpus(roots, "eval", a.eval_pct, min_sec=0.5, max_sec=a.max_sec, verbose=False) if a.eval_pct > 0 else None
    ck_path = os.path.join(a.out, "ckpt_last.pt"); ck = None
    if os.path.exists(ck_path) and not a.fresh:
        ck = torch.load(ck_path, map_location="cpu", weights_only=False); cfg = VocConfig.from_dict(ck["cfg"]); a.disc = ck.get("disc", a.disc)
        L.log(f"resuming from {ck_path} at step {ck['step']}")
    elif a.init:
        cfg = VocConfig.from_dict(torch.load(a.init, map_location="cpu", weights_only=False)["cfg"])
    else:
        cfg = VocConfig.preset(a.preset)
    G = Vocoder(cfg).to(dev); Dm = Discriminators.preset(a.disc).to(dev)
    oG = torch.optim.AdamW(G.parameters(), lr=a.lr, betas=(0.8, 0.9)); oD = torch.optim.AdamW(Dm.parameters(), lr=a.lr, betas=(0.8, 0.9))
    step = 0
    if ck is not None:
        G.load_state_dict(ck["G"]); Dm.load_state_dict(ck["D"]); oG.load_state_dict(ck["oG"]); oD.load_state_dict(ck["oD"]); step = ck["step"]
        if ck.get("steps_total") and a.budget_h > 0: a.steps = ck["steps_total"]; a.budget_fixed = a.budget_done = True; L.log(f"step budget from checkpoint: {a.steps}")
    elif a.init:
        i0 = torch.load(a.init, map_location="cpu", weights_only=False); G.load_state_dict(i0["G"])
        if "D" in i0 and i0.get("disc", a.disc) == a.disc: Dm.load_state_dict(i0["D"])
        L.log(f"init from {a.init} (step {i0['step']})")
    L.log(f"device {dev} amp {amp} | generator {G.n_params() / 1e6:.2f}M, discriminators {sum(p.numel() for p in Dm.parameters()) / 1e6:.1f}M | cfg {asdict(cfg)}")
    scG = torch.amp.GradScaler("cuda", enabled=amp == "fp16"); scD = torch.amp.GradScaler("cuda", enabled=amp == "fp16")
    autocast = lambda: torch.autocast(device_type=dev.type, dtype=torch.bfloat16 if amp == "bf16" else torch.float16, enabled=amp != "off")
    if a.am_ckpt:
        src = iter(AMSegments(a, train, dev, L))
    else:
        loader = torch.utils.data.DataLoader(D.SegmentDataset(train, seg), batch_size=a.batch, shuffle=True, num_workers=a.workers,
                                             drop_last=True, pin_memory=dev.type == "cuda", persistent_workers=a.workers > 0,
                                             worker_init_fn=lambda w: np.random.seed((a.seed * 7919 + w * 104729 + int(time.time())) % 2 ** 31))
        def gen():
            while True:
                for wav in loader:
                    wav = wav.to(dev, non_blocking=True); yield wav, mel_torch(wav)
        src = gen()
    stop = {"flag": False}
    def on_signal(sig, _): stop["flag"] = True; L.log(f"signal {sig}: saving and stopping")
    signal.signal(signal.SIGTERM, on_signal); signal.signal(signal.SIGINT, on_signal)
    state = lambda: {"G": G.state_dict(), "D": Dm.state_dict(), "oG": oG.state_dict(), "oD": oD.state_dict(), "step": step,
                     "cfg": asdict(cfg), "disc": a.disc, "args": vars(a), "steps_total": a.steps if getattr(a, "budget_done", False) else None}
    budget = Budget(a, step, L, after=a.pretrain_mel_steps)   # time GAN steps, not the cheaper mel-only ones
    acc, n_acc, t_log = {}, 0, time.time(); G.train(); Dm.train()
    while step < a.steps and not stop["flag"]:
        wav, mel = next(src)
        lr = lr_at(step, a)
        for o in (oG, oD):
            for g in o.param_groups: g["lr"] = lr
        gan = step >= a.pretrain_mel_steps; d = {}
        with autocast(): wav_hat = G(mel)
        wav_hat = wav_hat[:, :wav.shape[1]]
        if gan:
            with autocast():
                r_mp, r_mr = Dm(wav); f_mp, f_mr = Dm(wav_hat.detach())
                ld = d_hinge(r_mp, f_mp) + a.mrd_coeff * d_hinge(r_mr, f_mr)
            oD.zero_grad(set_to_none=True); scD.scale(ld).backward(); scD.unscale_(oD)
            gd = torch.nn.utils.clip_grad_norm_(Dm.parameters(), a.clip)
            if torch.isfinite(gd) or amp == "fp16": scD.step(oD); scD.update()
            else: oD.zero_grad(set_to_none=True); L.log(f"step {step}: non-finite discriminator gradient - D step skipped")
            d["d"] = ld.item()
            Dm.requires_grad_(False)                       # generator step: no gradients for D's own weights (saves ~1/3 of D backward)
            with autocast():
                f_mp, f_mr = Dm(wav_hat)
                lg = g_hinge(f_mp) + a.mrd_coeff * g_hinge(f_mr)
                fm = feature_matching(r_mp, f_mp) + a.mrd_coeff * feature_matching(r_mr, f_mr)
            d["g"] = lg.item(); d["fm"] = fm.item()
        else:
            lg = fm = torch.zeros((), device=dev)
        ml = mel_l1(wav_hat.float(), wav.float()); lossG = lg + fm + a.mel_coeff * ml; d["mel"] = ml.item()
        if not torch.isfinite(lossG):
            L.log(f"step {step}: non-finite generator loss {d} - skipped"); oG.zero_grad(set_to_none=True); Dm.requires_grad_(True); step += 1; continue
        oG.zero_grad(set_to_none=True); scG.scale(lossG).backward(); scG.unscale_(oG)
        gn = torch.nn.utils.clip_grad_norm_(G.parameters(), a.clip); d["gnorm"] = float(gn)
        if not torch.isfinite(gn) and amp != "fp16":
            L.log(f"step {step}: non-finite generator gradient - skipped"); oG.zero_grad(set_to_none=True); Dm.requires_grad_(True); step += 1; continue
        scG.step(oG); scG.update(); Dm.requires_grad_(True)
        step += 1; n_acc += 1; budget.tick(step)
        for k, v in d.items(): acc[k] = acc.get(k, 0.0) + v
        if step % a.log_every == 0 or step == a.steps:
            dt = time.time() - t_log; m = {k: v / n_acc for k, v in acc.items()}
            L.log(f"step {step} lr {lr:.2e} " + " ".join(f"{k} {v:.4f}" for k, v in m.items()) + f" | {n_acc / dt:.2f} it/s")
            L.metrics({"step": step, "lr": lr, "it_s": n_acc / dt, **m}); acc, n_acc, t_log = {}, 0, time.time()
        if step % a.save_every == 0: save(ck_path, state())
        if a.keep_every and step % a.keep_every == 0: save(os.path.join(a.out, f"ckpt_{step}.pt"), state())
        if held is not None and (step % a.eval_every == 0 or step == a.steps): evaluate(G, held, dev, L, step, a)
    save(ck_path, state())
    if step >= a.steps: save(os.path.join(a.out, "final.pt"), state()); L.log(f"done: {step} steps -> {a.out}/final.pt")
    else: L.log(f"stopped at step {step} (resume by running the same command)")


@torch.no_grad()
def evaluate(G, held, dev, L, step, a, n=6):
    """Copy synthesis of held-out utterances: mel L1 of G(mel(x)) vs x; writes the first 2 as wavs."""
    G.eval(); tot = 0.0; rows = held.rows[:: max(1, len(held.rows) // n)][:n]
    for i, r in enumerate(rows):
        w = torch.from_numpy(D.load_wav16(r["path"])).to(dev)[None]; w = w[:, :(w.shape[1] // HOP) * HOP]
        y = G(mel_torch(w))[:, :w.shape[1]].float(); tot += mel_l1(y, w).item()
        if i < 2: save_wav(os.path.join(a.out, "samples", f"step{step:07d}_{os.path.basename(r['path'])}"), y[0].cpu().numpy())
    L.log(f"EVAL step {step}: copy-synthesis mel L1 {tot / len(rows):.4f} on {len(rows)} held-out utterances"); L.metrics({"step": step, "eval": {"mel_l1": tot / len(rows)}})
    G.train()


if __name__ == "__main__":
    main()
