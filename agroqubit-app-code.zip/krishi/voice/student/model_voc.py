"""KrishiVoice vocoder: Vocos-style (Siuzdak 2023). Everything runs at the 16 ms frame rate; the waveform comes from
one inverse STFT, so the phone needs no upsampling convolutions:

  log-mel [80,T] -> conv k7 -> LayerNorm -> N x ConvNeXt (depthwise conv k7, LayerNorm, Linear C->3C, GELU,
  Linear 3C->C, layer scale, residual) -> LayerNorm -> Linear C -> 2*513  = log-magnitude | phase
  -> S = min(exp(logmag), 100) * (cos(phase) + i sin(phase)) -> iSTFT (n_fft 1024, hop 256, Hann, centred)
  -> (T-1)*256 samples at 16 kHz.

Training (train_voc.py): multi-period discriminator (HiFi-GAN periods 2,3,5,7,11) + multi-resolution discriminator
(DAC/Vocos band-split complex-STFT discriminators at windows 512/1024/2048), hinge GAN losses, feature matching,
and L1 on the log-mel (x45), as in Vocos.
"""
from dataclasses import dataclass, asdict, fields
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.parametrizations import weight_norm

from audio import N_FFT, HOP, WIN, N_MELS, mel_torch


@dataclass
class VocConfig:
    n_mels: int = N_MELS
    dim: int = 256
    inter: int = 768
    layers: int = 8
    kernel: int = 7
    n_fft: int = N_FFT
    hop: int = HOP
    win: int = WIN
    max_logmag: float = 4.605170185988092  # log(100), Vocos clip

    @staticmethod
    def preset(name, **over):
        p = {"base": {}, "small": dict(dim=192, inter=576), "large": dict(dim=320, inter=960),
             "tiny": dict(dim=64, inter=192, layers=3)}[name]
        return VocConfig(**{**p, **over})

    @staticmethod
    def from_dict(d):
        names = {f.name for f in fields(VocConfig)}
        return VocConfig(**{k: v for k, v in d.items() if k in names})


class ConvNeXtBlock(nn.Module):
    def __init__(self, dim, inter, k, layer_scale):
        super().__init__()
        self.dw = nn.Conv1d(dim, dim, k, padding=k // 2, groups=dim)
        self.norm = nn.LayerNorm(dim, eps=1e-6)
        self.pw1 = nn.Linear(dim, inter); self.pw2 = nn.Linear(inter, dim)
        self.gamma = nn.Parameter(torch.full((dim,), layer_scale))

    def forward(self, x):  # [B,C,T]
        y = self.dw(x).transpose(1, 2)
        y = self.pw2(F.gelu(self.pw1(self.norm(y)))) * self.gamma
        return x + y.transpose(1, 2)


class Vocoder(nn.Module):
    def __init__(self, cfg: VocConfig):
        super().__init__()
        self.cfg = c = cfg
        self.embed = nn.Conv1d(c.n_mels, c.dim, c.kernel, padding=c.kernel // 2)
        self.norm = nn.LayerNorm(c.dim, eps=1e-6)
        self.blocks = nn.ModuleList([ConvNeXtBlock(c.dim, c.inter, c.kernel, 1.0 / c.layers) for _ in range(c.layers)])
        self.final_norm = nn.LayerNorm(c.dim, eps=1e-6)
        self.head = nn.Linear(c.dim, c.n_fft + 2)
        self.register_buffer("window", torch.hann_window(c.win, periodic=True), persistent=False)

    def n_params(self): return sum(p.numel() for p in self.parameters())

    def spec(self, mel):
        """mel [B,80,T] -> (logmag [B,513,T], phase [B,513,T])."""
        x = self.embed(mel)
        x = self.norm(x.transpose(1, 2)).transpose(1, 2)
        for b in self.blocks: x = b(x)
        h = self.head(self.final_norm(x.transpose(1, 2))).transpose(1, 2)
        return h.chunk(2, dim=1)

    def forward(self, mel):
        """mel [B,80,T] -> wav [B,(T-1)*hop]."""
        logmag, phase = self.spec(mel)
        with torch.autocast(device_type=mel.device.type, enabled=False):
            mag = torch.exp(logmag.float()).clamp(max=100.0)   # Vocos: exp then clip at 1e2
            S = torch.complex(mag * torch.cos(phase.float()), mag * torch.sin(phase.float()))
            return torch.istft(S, self.cfg.n_fft, self.cfg.hop, self.cfg.win, window=self.window, center=True)

    @torch.no_grad()
    def infer(self, mel):
        """mel [T,80] numpy/tensor -> wav numpy float32."""
        m = torch.as_tensor(mel, dtype=torch.float32, device=self.head.weight.device).transpose(0, 1)[None]
        return self.forward(m)[0].cpu().numpy()


# ------------------------------------------------------------------ discriminators
class DiscriminatorP(nn.Module):
    def __init__(self, period, ch=(32, 128, 512, 1024, 1024)):
        super().__init__()
        self.period = period; c0 = 1; L = []
        for i, c in enumerate(ch):
            L.append(weight_norm(nn.Conv2d(c0, c, (5, 1), (3, 1) if i < len(ch) - 1 else (1, 1), padding=(2, 0)))); c0 = c
        self.convs = nn.ModuleList(L); self.post = weight_norm(nn.Conv2d(c0, 1, (3, 1), 1, padding=(1, 0)))

    def forward(self, x):  # [B,N]
        b, t = x.shape
        if t % self.period: x = F.pad(x, (0, self.period - t % self.period), mode="reflect"); t = x.shape[1]
        x = x.view(b, 1, t // self.period, self.period); fmap = []
        for c in self.convs:
            x = F.leaky_relu(c(x), 0.1); fmap.append(x)
        x = self.post(x); fmap.append(x)
        return x.flatten(1), fmap


class DiscriminatorR(nn.Module):
    """Band-split complex STFT discriminator (DAC / Vocos MRD)."""
    def __init__(self, win, ch=32, bands=((0.0, 0.1), (0.1, 0.25), (0.25, 0.5), (0.5, 0.75), (0.75, 1.0))):
        super().__init__()
        self.win, self.hop = win, win // 4; nb = win // 2 + 1
        self.bands = [(int(a * nb), int(b * nb)) for a, b in bands]
        mk = lambda: nn.ModuleList([weight_norm(nn.Conv2d(2, ch, (3, 9), (1, 1), padding=(1, 4))),
                                    weight_norm(nn.Conv2d(ch, ch, (3, 9), (1, 2), padding=(1, 4))),
                                    weight_norm(nn.Conv2d(ch, ch, (3, 9), (1, 2), padding=(1, 4))),
                                    weight_norm(nn.Conv2d(ch, ch, (3, 9), (1, 2), padding=(1, 4))),
                                    weight_norm(nn.Conv2d(ch, ch, (3, 3), (1, 1), padding=(1, 1)))])
        self.band_convs = nn.ModuleList([mk() for _ in self.bands])
        self.post = weight_norm(nn.Conv2d(ch, 1, (3, 3), (1, 1), padding=(1, 1)))
        self.register_buffer("window", torch.hann_window(win), persistent=False)

    def forward(self, x):
        x = x - x.mean(dim=-1, keepdim=True)
        x = 0.8 * x / (x.abs().max(dim=-1, keepdim=True)[0] + 1e-9)
        with torch.autocast(device_type=x.device.type, enabled=False):
            s = torch.stft(x.float(), self.win, self.hop, self.win, window=self.window, return_complex=True)
        s = torch.view_as_real(s).permute(0, 3, 2, 1)  # [B,2,T,F]
        fmap, outs = [], []
        for (a, b), stack in zip(self.bands, self.band_convs):
            h = s[..., a:b]
            for i, layer in enumerate(stack):
                h = F.leaky_relu(layer(h), 0.1)
                if i > 0: fmap.append(h)
            outs.append(h)
        h = self.post(torch.cat(outs, dim=-1)); fmap.append(h)
        return h.flatten(1), fmap


class Discriminators(nn.Module):
    def __init__(self, periods=(2, 3, 5, 7, 11), mpd_ch=(32, 128, 512, 1024, 1024), wins=(512, 1024, 2048), mrd_ch=32):
        super().__init__()
        self.mpd = nn.ModuleList([DiscriminatorP(p, mpd_ch) for p in periods])
        self.mrd = nn.ModuleList([DiscriminatorR(w, mrd_ch) for w in wins])

    @staticmethod
    def preset(name):
        return {"base": Discriminators(), "tiny": Discriminators(periods=(2, 3, 5), mpd_ch=(8, 16, 32, 32, 32), wins=(512, 1024), mrd_ch=8)}[name]

    def forward(self, x):
        return [d(x) for d in self.mpd], [d(x) for d in self.mrd]


def d_hinge(real, fake):
    return sum(torch.mean(F.relu(1 - r)) + torch.mean(F.relu(1 + f)) for (r, _), (f, _) in zip(real, fake)) / len(real)


def g_hinge(fake):
    return sum(torch.mean(F.relu(1 - f)) for f, _ in fake) / len(fake)


def feature_matching(real, fake):
    return sum(sum(torch.mean(torch.abs(a.detach() - b)) for a, b in zip(fr, ff)) for (_, fr), (_, ff) in zip(real, fake)) / len(real)


def mel_l1(wav_hat, wav):
    return F.l1_loss(mel_torch(wav_hat), mel_torch(wav))
