"""KrishiVoice acoustic model: FastPitch-style text -> 80-bin log-mel, one model for 4 languages x 2 speakers.

  tokens -> embedding + language embedding + voice embedding (+ sinusoid positions)
         -> encoder FFT blocks (multi-head self-attention + conv FFN, post-LN)
         -> duration predictor (log(1+frames) per token)   pitch predictor (per-token mean normalised log-f0)
         -> + pitch embedding (conv k3 of the per-token pitch)
         -> length regulator (repeat each token by its duration)
         -> + positions + decoder voice embedding -> decoder FFT blocks -> linear -> mel
Alignment (training only, not exported) as in "One TTS Alignment To Rule Them All" (Badlani et al. 2022):
an alignment encoder scores every (mel frame, token) pair from the token embeddings and the target mel, a
beta-binomial prior keeps it near the diagonal, the forward-sum (CTC) loss trains it, monotonic alignment search
(MAS) turns the soft alignment into hard durations, and a binarisation loss pulls soft towards hard. So no external
aligner and no phonemiser: characters in, mel out.
"voice" = (language, speaker): the teacher's 'female'/'male' voices are different people in each language.
"""
import math
from dataclasses import dataclass, asdict, fields
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from text import SYMBOLS, LANGS, SPEAKERS


@dataclass
class AMConfig:
    n_symbols: int = len(SYMBOLS)
    n_langs: int = len(LANGS)
    n_voices: int = len(LANGS) * len(SPEAKERS)
    d: int = 256
    heads: int = 2
    enc_layers: int = 4
    dec_layers: int = 4
    dff: int = 768
    ff_kernel: int = 3
    pred_filters: int = 256
    pred_kernel: int = 3
    pitch_kernel: int = 3
    n_mels: int = 80
    dropout: float = 0.1
    max_dur: float = 50.0          # frames per token at inference (0.8 s)
    align_channels: int = 80
    align_temp: float = 0.0005

    @staticmethod
    def preset(name, **over):
        p = {"base": {}, "small": dict(d=192, dff=576, pred_filters=192),
             "tiny": dict(d=96, enc_layers=2, dec_layers=2, dff=256, pred_filters=96, dropout=0.0)}[name]
        c = AMConfig(**{**p, **over}); return c

    @staticmethod
    def from_dict(d):
        names = {f.name for f in fields(AMConfig)}
        return AMConfig(**{k: v for k, v in d.items() if k in names})


def sinusoid(T, d, device=None):
    """FastPitch positions: [sin(t*f_i) | cos(t*f_i)], f_i = 1/10000^(2i/d). Computed in float64 (Java does the same)."""
    inv = 1.0 / (10000.0 ** (np.arange(0, d, 2, dtype=np.float64) / d))
    ang = np.arange(T, dtype=np.float64)[:, None] * inv[None, :]
    return torch.from_numpy(np.concatenate([np.sin(ang), np.cos(ang)], 1).astype(np.float32)).to(device)


class MHA(nn.Module):
    def __init__(self, d, heads, dropout):
        super().__init__()
        self.qkv = nn.Linear(d, 3 * d); self.o = nn.Linear(d, d); self.h = heads; self.p = dropout

    def forward(self, x, mask):  # x [B,T,d], mask [B,T] bool (True = real token)
        B, T, d = x.shape
        q, k, v = self.qkv(x).view(B, T, 3, self.h, d // self.h).permute(2, 0, 3, 1, 4)
        y = F.scaled_dot_product_attention(q, k, v, attn_mask=mask[:, None, None, :], dropout_p=self.p if self.training else 0.0)
        return self.o(y.transpose(1, 2).reshape(B, T, d))


class FFTBlock(nn.Module):
    """Post-LN transformer block with a conv FFN (k=ff_kernel then k=1), as FastPitch."""
    def __init__(self, d, heads, dff, k, dropout):
        super().__init__()
        self.att = MHA(d, heads, dropout); self.ln1 = nn.LayerNorm(d)
        self.ff1 = nn.Conv1d(d, dff, k, padding=k // 2); self.ff2 = nn.Conv1d(dff, d, 1); self.ln2 = nn.LayerNorm(d)
        self.drop = nn.Dropout(dropout)

    def forward(self, x, mask):
        m = mask[..., None].to(x.dtype)
        x = self.ln1(x + self.drop(self.att(x, mask))) * m
        y = self.ff2(self.drop(F.relu(self.ff1(x.transpose(1, 2))))).transpose(1, 2)
        return self.ln2(x + self.drop(y)) * m


class Predictor(nn.Module):
    """FastPitch temporal predictor: 2 x (conv k3 -> ReLU -> LayerNorm -> dropout) -> linear -> 1 value per token."""
    def __init__(self, d, f, k, dropout, n_layers=2):
        super().__init__()
        self.convs = nn.ModuleList([nn.Conv1d(d if i == 0 else f, f, k, padding=k // 2) for i in range(n_layers)])
        self.lns = nn.ModuleList([nn.LayerNorm(f) for _ in range(n_layers)])
        self.out = nn.Linear(f, 1); self.drop = nn.Dropout(dropout)

    def forward(self, x, mask):
        m = mask[..., None].to(x.dtype); h = x * m
        for conv, ln in zip(self.convs, self.lns):
            h = self.drop(ln(F.relu(conv(h.transpose(1, 2)).transpose(1, 2)))) * m
        return self.out(h).squeeze(-1) * mask.to(h.dtype)


class Aligner(nn.Module):
    """RAD-TTS alignment encoder: L2 distance between projected tokens (keys) and projected mel frames (queries)."""
    def __init__(self, d_text, n_mels, ch, temp):
        super().__init__()
        self.key = nn.Sequential(nn.Conv1d(d_text, 2 * d_text, 3, padding=1), nn.ReLU(), nn.Conv1d(2 * d_text, ch, 1))
        self.query = nn.Sequential(nn.Conv1d(n_mels, 2 * n_mels, 3, padding=1), nn.ReLU(), nn.Conv1d(2 * n_mels, n_mels, 1),
                                   nn.ReLU(), nn.Conv1d(n_mels, ch, 1))
        self.temp = temp

    def forward(self, mel, emb, tmask, log_prior):
        """mel [B,80,T], emb [B,N,d], tmask [B,N], log_prior [B,T,N] -> (soft [B,T,N], logprob [B,T,N])."""
        with torch.autocast(device_type=mel.device.type, enabled=False):
            k = self.key(emb.float().transpose(1, 2)); q = self.query(mel.float())
            dist = (q * q).sum(1)[:, :, None] + (k * k).sum(1)[:, None, :] - 2 * torch.bmm(q.transpose(1, 2), k)
            logits = (-self.temp * dist).masked_fill(~tmask[:, None, :], float("-inf"))
            logprob = F.log_softmax(logits, dim=-1) + log_prior
            soft = torch.softmax(logprob, dim=-1)
        return soft, logprob


def beta_binomial_log_prior(tlens, mlens, N, T, scale=1.0):
    """log(prior + 1e-8) [B,T,N] of NeMo's beta_binomial_prior_distribution(N_b, T_b, scale); -inf outside the item."""
    dev = tlens.device
    k = torch.arange(N, device=dev, dtype=torch.float32)[None, None, :]
    i = torch.arange(1, T + 1, device=dev, dtype=torch.float32)[None, :, None]
    n = tlens.float()[:, None, None]; M = mlens.float()[:, None, None]
    valid = (k < n) & (i <= M)
    a = scale * i; b = torch.where(valid, scale * (M + 1 - i), torch.ones_like(i * M))
    kk = torch.where(valid, k.expand_as(valid), torch.zeros_like(valid, dtype=torch.float32))
    nn_ = torch.where(valid, n.expand_as(valid), torch.ones_like(valid, dtype=torch.float32))
    lg = torch.lgamma
    lbeta = lambda x, y: lg(x) + lg(y) - lg(x + y)
    logp = lg(nn_ + 1) - lg(kk + 1) - lg(nn_ - kk + 1) + lbeta(kk + a, nn_ - kk + b) - lbeta(a.expand_as(valid), b)
    logp = torch.logaddexp(logp, torch.full_like(logp, math.log(1e-8)))
    # padded tokens are impossible; padded frames get a flat prior (finite rows; MAS / CTC / losses ignore them)
    return logp.masked_fill(~valid, 0.0).masked_fill((k >= n).expand_as(valid), float("-inf"))


def forward_sum_loss(logprob, tlens, mlens, blank_logprob=-1.0):
    """CTC over (blank + tokens) with targets 1..N: every monotonic alignment counts (batched NeMo ForwardSumLoss)."""
    B, T, N = logprob.shape
    lp = torch.clamp(logprob, min=-1e4)                       # CTC backward turns -inf (masked tokens) into NaN
    lp = F.log_softmax(F.pad(lp, (1, 0), value=blank_logprob), dim=-1)
    tgt = torch.arange(1, N + 1, device=logprob.device)[None].expand(B, N)
    return F.ctc_loss(lp.transpose(0, 1), tgt, mlens, tlens, blank=0, reduction="mean", zero_infinity=True)


# ------------------------------------------------------------------ monotonic alignment search
def _mas_numpy(logp, tl, ml):
    """Batched MAS (vectorised over batch x tokens, loop over frames). logp [B,T,N] -> hard [B,T,N] float32."""
    B, T, N = logp.shape; NEG = np.float32(-1e30)
    lp = np.where(np.arange(N)[None, None, :] < tl[:, None, None], logp, NEG).astype(np.float32)
    Q = np.empty_like(lp); Q[:, 0, :] = NEG; Q[:, 0, 0] = lp[:, 0, 0]
    for j in range(1, T):
        prev = Q[:, j - 1, :]; sh = np.empty_like(prev); sh[:, 0] = NEG; sh[:, 1:] = prev[:, :-1]
        Q[:, j, :] = lp[:, j, :] + np.maximum(prev, sh)
    hard = np.zeros((B, T, N), np.float32); idx = (tl - 1).astype(np.int64).copy(); rows = np.arange(B)
    for j in range(T - 1, -1, -1):
        act = j < ml
        hard[rows[act], j, idx[act]] = 1.0
        if j == 0: break
        cur = idx; left = np.maximum(cur - 1, 0)
        go = act & (cur > 0) & ((cur == j) | (Q[rows, j - 1, left] > Q[rows, j - 1, cur]))
        idx = np.where(go, cur - 1, cur)
    return hard


try:
    import numba

    @numba.njit(cache=True, parallel=True)
    def _mas_numba(logp, tl, ml):
        B, T, N = logp.shape; hard = np.zeros((B, T, N), np.float32)
        for b in numba.prange(B):
            n, m = tl[b], ml[b]; Q = np.full((m, n), -1e30, np.float32); Q[0, 0] = logp[b, 0, 0]
            for j in range(1, m):
                for i in range(min(j + 1, n)):
                    best = Q[j - 1, i]
                    if i > 0 and Q[j - 1, i - 1] > best: best = Q[j - 1, i - 1]
                    Q[j, i] = logp[b, j, i] + best
            i = n - 1
            for j in range(m - 1, -1, -1):
                hard[b, j, i] = 1.0
                if j > 0 and i > 0 and (i == j or Q[j - 1, i - 1] > Q[j - 1, i]): i -= 1
        return hard
except Exception:  # numba missing or broken: numpy path
    _mas_numba = None


def mas(log_soft, tlens, mlens):
    """log_soft [B,T,N] tensor -> hard alignment tensor (same device). Each frame -> one token, monotonic, every token >= 1 frame."""
    lp = log_soft.detach().float().cpu().numpy(); tl = tlens.cpu().numpy().astype(np.int64); ml = mlens.cpu().numpy().astype(np.int64)
    lp = np.nan_to_num(lp, nan=-1e30, neginf=-1e30)
    hard = _mas_numba(lp, tl, ml) if _mas_numba is not None else _mas_numpy(lp, tl, ml)
    return torch.from_numpy(hard).to(log_soft.device)


def durations_from_logd(logd, speed=1.0, max_dur=50.0):
    """Predicted log(1+d) -> integer frames. float64 cumulative rounding (round half to even), so the sentence keeps
    its total length at any speed; Speak.java does exactly this with Math.exp/Math.rint."""
    d = np.exp(np.asarray(logd, np.float32).astype(np.float64)) - 1.0
    d = np.minimum(np.maximum(d, 0.0), max_dur) / speed
    ends = np.rint(np.cumsum(d))
    dur = np.diff(np.concatenate([[0.0], ends])).astype(np.int64)
    if dur.sum() == 0: dur[int(np.argmax(d))] = 1
    return dur


class AcousticModel(nn.Module):
    def __init__(self, cfg: AMConfig):
        super().__init__()
        self.cfg = c = cfg
        self.tok = nn.Embedding(c.n_symbols, c.d, padding_idx=0)
        self.lang = nn.Embedding(c.n_langs, c.d); self.voice_enc = nn.Embedding(c.n_voices, c.d); self.voice_dec = nn.Embedding(c.n_voices, c.d)
        for e in (self.lang, self.voice_enc, self.voice_dec): nn.init.normal_(e.weight, std=0.1)
        self.enc = nn.ModuleList([FFTBlock(c.d, c.heads, c.dff, c.ff_kernel, c.dropout) for _ in range(c.enc_layers)])
        self.dur = Predictor(c.d, c.pred_filters, c.pred_kernel, c.dropout)
        self.pitch = Predictor(c.d, c.pred_filters, c.pred_kernel, c.dropout)
        self.pitch_emb = nn.Conv1d(1, c.d, c.pitch_kernel, padding=c.pitch_kernel // 2)
        self.dec = nn.ModuleList([FFTBlock(c.d, c.heads, c.dff, c.ff_kernel, c.dropout) for _ in range(c.dec_layers)])
        self.mel = nn.Linear(c.d, c.n_mels)
        self.aligner = Aligner(c.d, c.n_mels, c.align_channels, c.align_temp)
        self._pe = None

    def pe(self, T, device):
        if self._pe is None or self._pe.shape[0] < T or self._pe.device != device:
            self._pe = sinusoid(max(T, 1024), self.cfg.d, device)
        return self._pe[:T]

    def n_params(self, exported_only=True):
        return sum(p.numel() for n, p in self.named_parameters() if not (exported_only and n.startswith("aligner.")))

    def encode(self, tokens, tmask, lang, voice):
        emb = self.tok(tokens)
        x = emb + self.lang(lang)[:, None] + self.voice_enc(voice)[:, None] + self.pe(tokens.shape[1], tokens.device)[None]
        x = x * tmask[..., None].to(x.dtype)
        for blk in self.enc: x = blk(x, tmask)
        return x, emb

    def decode(self, y, fmask, voice):
        y = y + self.pe(y.shape[1], y.device)[None] + self.voice_dec(voice)[:, None]
        y = y * fmask[..., None].to(y.dtype)
        for blk in self.dec: y = blk(y, fmask)
        return self.mel(y).transpose(1, 2)  # [B,80,T]

    def forward(self, tokens, tlens, lang, voice, mel, mlens, pitch, voiced, dur=None):
        """Training / teacher forcing. pitch [B,T] normalised log-f0 per frame, voiced [B,T] bool.
        dur [B,N] optional: use these durations instead of the aligner (eval with known durations)."""
        B, N = tokens.shape; T = mel.shape[2]; dev = tokens.device
        tmask = torch.arange(N, device=dev)[None] < tlens[:, None]; fmask = torch.arange(T, device=dev)[None] < mlens[:, None]
        x, emb = self.encode(tokens, tmask, lang, voice)
        out = {}
        if dur is None:
            log_prior = beta_binomial_log_prior(tlens, mlens, N, T)
            soft, logprob = self.aligner(mel, emb, tmask, log_prior)
            hard = mas(F.log_softmax(logprob, dim=-1), tlens, mlens)
            out.update(soft=soft, logprob=logprob, hard=hard)
        else:
            ends = torch.cumsum(dur, 1); starts = ends - dur; t = torch.arange(T, device=dev)[None, :, None]
            hard = ((t >= starts[:, None, :]) & (t < ends[:, None, :])).float()
            out["hard"] = hard
        dur_t = hard.sum(1)                                                                   # [B,N] frames
        v = (voiced & fmask).float()
        cnt = torch.bmm(hard.transpose(1, 2), v[..., None]).squeeze(-1)
        ptok = torch.bmm(hard.transpose(1, 2), (pitch * v)[..., None]).squeeze(-1) / cnt.clamp(min=1)  # per-token mean, 0 if unvoiced
        logd = self.dur(x, tmask); p = self.pitch(x, tmask)
        x = x + self.pitch_emb(ptok[:, None].to(x.dtype)).transpose(1, 2)
        y = torch.bmm(hard.to(x.dtype), x)                                                  # length regulator
        out.update(mel=self.decode(y, fmask, voice), logd=logd, logd_t=torch.log1p(dur_t), pitch=p, pitch_t=ptok,
                   tmask=tmask, fmask=fmask, dur_t=dur_t)
        return out

    @torch.no_grad()
    def infer(self, ids, lang, voice, speed=1.0, dur=None):
        """One sentence. ids list/1-D LongTensor, lang/voice ints -> (mel [T,80] float32, dur int64[N], logd, pitch)."""
        dev = self.tok.weight.device
        tok = torch.as_tensor(ids, dtype=torch.long, device=dev)[None]; tmask = torch.ones_like(tok, dtype=torch.bool)
        lang_t = torch.tensor([lang], device=dev); voice_t = torch.tensor([voice], device=dev)
        x, _ = self.encode(tok, tmask, lang_t, voice_t)
        logd = self.dur(x, tmask)[0].float().cpu().numpy(); p = self.pitch(x, tmask)
        x = x + self.pitch_emb(p[:, None]).transpose(1, 2)
        if dur is None: dur = durations_from_logd(logd, speed, self.cfg.max_dur)
        dur = np.asarray(dur, np.int64)
        y = torch.repeat_interleave(x[0], torch.as_tensor(dur, device=dev), dim=0)[None]
        mel = self.decode(y, torch.ones(1, y.shape[1], dtype=torch.bool, device=dev), voice_t)
        return mel[0].transpose(0, 1).float().cpu().numpy(), dur, logd, p[0].float().cpu().numpy()


def am_losses(out, mel, w_dur=0.5, w_pitch=0.5, w_align=1.0, w_bin=0.0, tlens=None, mlens=None):
    """Masked mel L1 + duration/pitch MSE + forward-sum + binarisation. Returns (total, dict of floats)."""
    fm = out["fmask"][:, None, :].float(); tm = out["tmask"].float()
    l_mel = ((out["mel"].float() - mel).abs() * fm).sum() / (fm.sum() * mel.shape[1])
    l_dur = (((out["logd"].float() - out["logd_t"]) ** 2) * tm).sum() / tm.sum()
    l_pitch = (((out["pitch"].float() - out["pitch_t"]) ** 2) * tm).sum() / tm.sum()
    tot = l_mel + w_dur * l_dur + w_pitch * l_pitch; d = {"mel": l_mel.item(), "dur": l_dur.item(), "pitch": l_pitch.item()}
    if "logprob" in out and tlens is not None:
        l_ctc = forward_sum_loss(out["logprob"], tlens, mlens)
        hard = out["hard"]; l_bin = -(torch.log(out["soft"].clamp(min=1e-12)) * hard).sum() / hard.sum()
        tot = tot + w_align * l_ctc + w_bin * l_bin; d.update(ctc=l_ctc.item(), bin=l_bin.item())
    d["total"] = tot.item()
    return tot, d
