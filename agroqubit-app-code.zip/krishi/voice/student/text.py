"""KrishiVoice text front end: normalisation, sentence split and tokenizer.

The phone (android/src/in/krishi/doctor/SpeakText.java) runs exactly the same algorithm with the tables that
export.py copies into voice.json, so every rule here is a plain per-character rule that Java can reproduce:

  1. Unicode NFC.
  2. per character (code point):
       DELETE (zero-width joiners, soft hyphen, BOM, direction marks)  -> dropped
       ASCII 'A'..'Z'                                                  -> lower case
       FOLD (accented Latin, e.g. 'é')                                 -> plain lower-case letter
       digit (ASCII, Devanagari, Tamil, Kannada)                       -> ' ' + digit word of the language + ' '
       '.' / ',' between two digits                                    -> ' point ' (language word) / ' '
       Latin letter in hi/ta/kn text                                   -> ' ' + letter name in that script + ' '
       PUNCT_MAP (danda, ; : dashes brackets quotes ...)               -> one of , . ? ! ' (or space)
       anything not in SYMBOLS                                         -> space
  3. clean-up: collapse spaces, no space before , . ? !, one space after them, no punctuation at the start,
     repeated punctuation keeps one mark (a ',' is replaced by a following stronger mark), strip.
Sentences: the normalised text is cut after . ? ! when a space follows (each sentence is synthesised on its own and
joined with a 0.28 s pause, like the pre-rendered clips). Tokens: [<bnd>] + one id per character + [<bnd>]; the
boundary tokens absorb leading/trailing silence.
"""
import unicodedata

LANGS = ["hi", "ta", "kn", "en"]
SPEAKERS = ["female", "male"]
SPEAKER_ALIASES = {"f": "female", "m": "male", "female": "female", "male": "male"}

PAD, BND, SPACE = "<pad>", "<bnd>", " "
PUNCT = [",", ".", "?", "!"]
LATIN = list("abcdefghijklmnopqrstuvwxyz")
# script blocks kept whole (deterministic across Python/Java/Unicode versions); digits are spoken, dandas are '.'
BLOCKS = [(0x0900, 0x0980), (0x0B80, 0x0C00), (0x0C80, 0x0D00)]  # Devanagari, Tamil, Kannada
DIGIT_BASES = [0x30, 0x0966, 0x0BE6, 0x0CE6]                       # ASCII, Devanagari, Tamil, Kannada 0..9

DIGIT_WORDS = {  # same words as voice/verbalize.py DIG
    "hi": "शून्य एक दो तीन चार पाँच छह सात आठ नौ".split(),
    "ta": "பூஜ்யம் ஒன்று இரண்டு மூன்று நான்கு ஐந்து ஆறு ஏழு எட்டு ஒன்பது".split(),
    "kn": "ಸೊನ್ನೆ ಒಂದು ಎರಡು ಮೂರು ನಾಲ್ಕು ಐದು ಆರು ಏಳು ಎಂಟು ಒಂಬತ್ತು".split(),
    "en": "zero one two three four five six seven eight nine".split(),
}
POINT_WORDS = {"hi": "पॉइंट", "ta": "பாயிண்ட்", "kn": "ಪಾಯಿಂಟ್", "en": "point"}  # '2.5' (verbalize.py POINT)
LETTER_WORDS = {  # Latin letters inside hi/ta/kn text are spelled (verbalize.py LETTER), a..z
    "hi": "ए बी सी डी ई एफ जी एच आई जे के एल एम एन ओ पी क्यू आर एस टी यू वी डब्ल्यू एक्स वाई ज़ेड".split(),
    "ta": "ஏ பி சி டி இ எஃப் ஜி ஹெச் ஐ ஜே கே எல் எம் என் ஓ பி க்யூ ஆர் எஸ் டி யூ வி டபிள்யூ எக்ஸ் ஒய் இசட்".split(),
    "kn": "ಎ ಬಿ ಸಿ ಡಿ ಇ ಎಫ್ ಜಿ ಹೆಚ್ ಐ ಜೆ ಕೆ ಎಲ್ ಎಂ ಎನ್ ಒ ಪಿ ಕ್ಯೂ ಆರ್ ಎಸ್ ಟಿ ಯು ವಿ ಡಬ್ಲ್ಯೂ ಎಕ್ಸ್ ವೈ ಜೆಡ್".split(),
}
PUNCT_MAP = {
    "।": ".", "॥": ".", "|": ".", "…": ".", ";": ",", ":": ",", "—": ",", "–": ",",
    "(": ",", ")": ",", "[": ",", "]": ",", "{": ",", "}": ",", "‘": "'", "’": "'", "`": "'",
    "¿": "?", "¡": "!", "؟": "?",
}
DELETE = "​‌‍‎‏­﻿⁠"
_FOLD_SRC = {"a": "àáâãäåāăą", "c": "çćč", "e": "èéêëēėęě", "i": "ìíîïīį", "n": "ñńň", "o": "òóôõöōő", "u": "ùúûüūůű",
             "y": "ýÿ", "s": "śšş", "z": "źżž", "g": "ğ", "l": "ł", "r": "ř", "t": "ţť", "d": "ď"}
FOLD = {}
for _b, _cs in _FOLD_SRC.items():
    for _c in _cs:
        FOLD[_c] = _b
        if _c.upper() != _c and len(_c.upper()) == 1: FOLD[_c.upper()] = _b


def _block_symbols():
    out = []
    for a, b in BLOCKS:
        for c in range(a, b):
            ch = chr(c)
            if any(base <= c < base + 10 for base in DIGIT_BASES) or ch in PUNCT_MAP: continue
            out.append(ch)
    return out


SYMBOLS = [PAD, BND, SPACE] + PUNCT + ["'"] + LATIN + _block_symbols()
SYM2ID = {s: i for i, s in enumerate(SYMBOLS)}
PAD_ID, BND_ID, SPACE_ID = 0, 1, 2
DIGIT_VALUE = {chr(base + d): d for base in DIGIT_BASES for d in range(10)}
GAP_SECONDS = 0.28  # pause between sentences (voice/render_segments.py GAP)

for _tab in (DIGIT_WORDS, LETTER_WORDS, {k: [v] for k, v in POINT_WORDS.items()}):  # every word must be speakable
    for _l, _ws in _tab.items():
        for _w in _ws:
            assert all(c in SYM2ID for c in _w), (_l, _w)
assert all(len(v) == 26 for v in LETTER_WORDS.values())


def lang_id(lang):
    if lang not in LANGS: raise ValueError(f"unknown language {lang!r}; expected one of {LANGS}")
    return LANGS.index(lang)


def speaker_id(speaker):
    s = SPEAKER_ALIASES.get(speaker)
    if s is None: raise ValueError(f"unknown speaker {speaker!r}; expected one of {SPEAKERS}")
    return SPEAKERS.index(s)


def voice_id(lang, speaker):
    """One embedding per (language, speaker): the teacher's female/male voices are different people per language."""
    return lang_id(lang) * len(SPEAKERS) + speaker_id(speaker)


def normalize(text, lang):
    digits, letters = DIGIT_WORDS[lang], LETTER_WORDS.get(lang)
    s = "".join(c for c in unicodedata.normalize("NFC", text) if c not in DELETE)
    buf = []
    for i, ch in enumerate(s):
        if "A" <= ch <= "Z": ch = chr(ord(ch) + 32)
        ch = FOLD.get(ch, ch)
        d = DIGIT_VALUE.get(ch)
        if d is not None:
            buf.append(" " + digits[d] + " "); continue
        if (ch == "." or ch == ",") and 0 < i < len(s) - 1 and s[i - 1] in DIGIT_VALUE and s[i + 1] in DIGIT_VALUE:
            buf.append(" " + POINT_WORDS[lang] + " " if ch == "." else " "); continue    # 2.5 -> two point five; 1,500
        if letters is not None and "a" <= ch <= "z":
            buf.append(" " + letters[ord(ch) - 97] + " "); continue
        ch = PUNCT_MAP.get(ch, ch)
        if ch not in SYM2ID or ch == PAD or ch == BND: ch = " "
        buf.append(ch)
    out = []
    for ch in "".join(buf):
        if ch == " ":
            if out and out[-1] != " ": out.append(" ")
        elif ch in ",.?!":
            while out and out[-1] == " ": out.pop()
            if not out: continue
            if out[-1] in ",.?!":
                if out[-1] == ",": out[-1] = ch
                continue
            out.append(ch)
        else:
            if out and out[-1] in ",.?!": out.append(" ")
            out.append(ch)
    while out and out[-1] == " ": out.pop()
    return "".join(out)


def split_sentences(norm):
    """Cut a normalised text after . ? ! followed by a space."""
    out, start = [], 0
    for i, ch in enumerate(norm):
        if ch in ".?!" and i + 1 < len(norm) and norm[i + 1] == " ":
            out.append(norm[start:i + 1]); start = i + 2
    if start < len(norm): out.append(norm[start:])
    return [s for s in out if s]


def encode(norm_sentence):
    """Token ids of one normalised sentence: <bnd> chars <bnd>."""
    return [BND_ID] + [SYM2ID[c] for c in norm_sentence] + [BND_ID]


def text_to_sentences(text, lang):
    """Raw text -> list of token-id lists (one per sentence)."""
    return [encode(s) for s in split_sentences(normalize(text, lang))]


def tables():
    """Everything SpeakText.java needs (written into voice.json by export.py)."""
    return {"symbols": SYMBOLS, "langs": LANGS, "speakers": SPEAKERS, "digit_words": DIGIT_WORDS,
            "point_words": POINT_WORDS, "letter_words": LETTER_WORDS,
            "punct_map": PUNCT_MAP, "delete": DELETE, "fold": FOLD, "gap_seconds": GAP_SECONDS,
            "pad_id": PAD_ID, "bnd_id": BND_ID}


TEST_STRINGS = [  # tricky inputs shared with the Java test
    ("hi", "नमस्ते जी। बताइए, कौन सी फसल है?"), ("hi", "क़ीमत 1551 रुपये है।।  और (KVK) से पूछिए!"),
    ("hi", "ज़्यादा   पानी — मत दीजिए ; 20% घोल…"), ("ta", "வணக்கம்ங்க. போன் 1800-180-1551, சரியா?"),
    ("ta", "௧௨௩ ரூபாய்!!  'சரி'"), ("kn", "ಫೋನ್‌ನಲ್ಲಿ ಸೌಲಭ್ಯ ಇಲ್ಲ. ಬರೀರಿ, ಅಥವಾ ಬಟನ್ ಒತ್ತಿ."),
    ("kn", "೨೫ ಗ್ರಾಂ ಪುಡಿ?\t"), ("en", "Café owner's TOMATO crop: 2.5 kg/acre — OK?!"),
    ("en", "  ,,Hello...   world  ;  done "), ("en", "Mix 200-300 L @ 6 AM. Then wait!"), ("hi", "🌾 फसल 👍 ठीक है"),
    ("en", ""), ("ta", "..."), ("hi", "Ⅻ ẞ ﬁ © ®"),
]

if __name__ == "__main__":
    print(len(SYMBOLS), "symbols")
    for lang, t in TEST_STRINGS:
        n = normalize(t, lang); print(lang, repr(t), "->", repr(n), split_sentences(n))
