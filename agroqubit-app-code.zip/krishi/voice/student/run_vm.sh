#!/bin/bash
# KrishiVoice on one GPU VM (NVIDIA L4 24 GB, Ubuntu, CUDA, internet): teacher corpus -> student training -> phone export.
# Every stage is resumable: rerun the same command after a crash or preemption; finished stages are skipped
# (markers in $W/.done_*), training resumes from ckpt_last.pt, rendering skips sentences already in meta/*.jsonl.
#
#   TEXTS=default,/data/texts HOURS=8 bash voice/student/run_vm.sh            # full run (~9-11 GPU-hours, see README)
#   SMOKE=1 bash voice/student/run_vm.sh                                       # tiny CPU rehearsal of every stage
#
# Env: K (repo, default /home/claude/krishi), W (work dir, default /opt/kv), TEXTS (prep_teacher --texts), HOURS per voice,
#      AM_BUDGET_H / VOC_BUDGET_H (run in parallel on the one GPU), FT_BUDGET_H, *_STEPS caps, PY (python with torch+cuda),
#      AM_PRESET / VOC_PRESET (base | small: ~40% less phone compute).
set -uo pipefail
K=${K:-/home/claude/krishi}; S=$K/voice/student; W=${W:-/opt/kv}
SMOKE=${SMOKE:-0}
DATA=$W/data; RUNS=$W/runs; OUT=$W/out; LOG=$W/logs
TEXTS=${TEXTS:-default}; HOURS=${HOURS:-8}; LANGS=${LANGS:-hi,ta,kn,en}
AM_STEPS=${AM_STEPS:-120000}; VOC_STEPS=${VOC_STEPS:-200000}; FT_STEPS=${FT_STEPS:-20000}
AM_BUDGET_H=${AM_BUDGET_H:-6}; VOC_BUDGET_H=${VOC_BUDGET_H:-6}; FT_BUDGET_H=${FT_BUDGET_H:-1}
export TTS_MODELS=${TTS_MODELS:-/home/claude/tts_models}
mkdir -p $DATA $RUNS $OUT $LOG
step() { echo "$(date -u '+%F %T') $*" | tee -a $W/progress.txt; }
die() { step "FAILED: $*"; exit 1; }
done_() { [ -f $W/.done_$1 ]; }
mark() { touch $W/.done_$1; step "stage $1 done"; }

if [ "$SMOKE" = 1 ]; then
  PY=${PY:-python3}; DEV=cpu; LANGS=en; HOURS=0.01; LIMIT="--limit 3"
  AMX="--preset tiny --cpu --steps 40 --max_frames 1500 --warmup 10 --workers 0 --log_every 10 --eval_every 40 --save_every 20"
  VOCX="--preset tiny --disc tiny --cpu --steps 30 --batch 4 --seg_frames 24 --warmup 5 --pretrain_mel_steps 10 --workers 0 --log_every 10 --eval_every 30 --save_every 10"
  FTX="--disc tiny --cpu --steps 10 --batch 4 --seg_frames 24 --warmup 2 --workers 0 --log_every 5 --eval_every 10 --ft_max_frames 1500"
  EXTRA_DATA=${EXTRA_DATA:-}     # e.g. the prep_local.py smoke corpus, so the tiny models see more than 6 sentences
else
  PY=${PY:-/opt/kvenv/bin/python3}; DEV=${VDEV:-cuda}; LIMIT=""; EXTRA_DATA=""
  if [ "$DEV" = cpu ]; then      # no GPU: the CPU threads are split between the acoustic model and the vocoder (they train at once)
    CA="--cpu --threads ${AM_THREADS:-4} --workers 1"; CV="--cpu --threads ${VOC_THREADS:-4} --workers 1"
  else CA="--workers 4"; CV="--workers 3"; fi
  AMX="--preset ${AM_PRESET:-base} --steps $AM_STEPS --budget_h $AM_BUDGET_H $CA"
  VOCX="--preset ${VOC_PRESET:-base} --steps $VOC_STEPS --budget_h $VOC_BUDGET_H --pretrain_mel_steps ${VOC_PRETRAIN:-5000} $CV"
  FTX="--steps $FT_STEPS --budget_h $FT_BUDGET_H --lr 1e-4 --warmup 200 $CV"
fi
step "start (smoke=$SMOKE) K=$K W=$W TEXTS=$TEXTS HOURS=$HOURS"

# ---------- 1. environment (GPU torch + coqui-tts 0.27.5 for the teacher)
if [ "$SMOKE" != 1 ] && ! done_ setup; then
  command -v nvidia-smi > /dev/null && nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv | tee -a $W/progress.txt
  nproc | sed 's/^/vCPUs: /' | tee -a $W/progress.txt; free -g | head -2 | tee -a $W/progress.txt; df -h $W | tail -1 | tee -a $W/progress.txt
  if ! python3 -m venv --help > /dev/null 2>&1 || ! command -v unzip > /dev/null || ! command -v javac > /dev/null; then   # best effort (root)
    (apt-get update -q && apt-get install -y -q python3-venv python3-pip unzip curl openjdk-17-jdk-headless libsndfile1) > $LOG/apt.log 2>&1 || step "apt-get failed (see $LOG/apt.log)"
  fi
  [ -x /opt/kvenv/bin/python3 ] || python3 -m venv /opt/kvenv || die "venv"
  /opt/kvenv/bin/pip install -q --upgrade pip > $LOG/pip.log 2>&1
  # torch from PyPI is the CUDA build on Linux; coqui-tts 0.27.5 is the teacher's runtime (as android/tools/job.sh)
  /opt/kvenv/bin/pip install -q torch torchaudio "coqui-tts==0.27.5" "transformers<5" torchcodec numba soundfile scipy librosa >> $LOG/pip.log 2>&1 || die "pip (see $LOG/pip.log)"
  $PY -c "import torch; assert torch.cuda.is_available(), 'CUDA not available'; print(torch.__version__, torch.cuda.get_device_name(0))" | tee -a $W/progress.txt || die "CUDA torch"
  mark setup
fi

# ---------- 2. teacher checkpoints (AI4Bharat Indic-TTS v1, MIT) - same download as android/tools/job.sh
if [ "$SMOKE" != 1 ] && ! done_ teacher; then
  mkdir -p $TTS_MODELS
  for L in ${LANGS//,/ }; do
    [ -f $TTS_MODELS/$L/fastpitch/best_model.pth ] && [ -f $TTS_MODELS/$L/hifigan/best_model.pth ] && continue
    ( cd $TTS_MODELS && curl -sSL --retry 5 -o $L.zip https://github.com/AI4Bharat/Indic-TTS/releases/download/v1-checkpoints-release/$L.zip \
      && unzip -q -o $L.zip && rm $L.zip ) || die "teacher download $L"
  done
  $PY - <<PY || die "patch teacher configs"
import glob, re
for f in glob.glob("$TTS_MODELS/*/fastpitch/config.json"):
    d = f.rsplit("/", 1)[0]; s = open(f).read()
    s = re.sub(r'"speakers_file": *"[^"]*"', f'"speakers_file": "{d}/speakers.pth"', s); open(f, "w").write(s)
print("teacher configs patched")
PY
  mark teacher
fi

# ---------- 3. render the corpus: one process per language on the one GPU (each loads one teacher, ~1-2 GB)
if ! done_ render; then
  pids=""
  for L in ${LANGS//,/ }; do
    OMP_NUM_THREADS=$( [ "$DEV" = cpu ] && echo $(( $(nproc) / 4 > 0 ? $(nproc) / 4 : 1 )) || echo 2 ) \
      $PY $S/prep_teacher.py --out $DATA --langs $L --texts $TEXTS --hours $HOURS --device $DEV $LIMIT > $LOG/render_$L.log 2>&1 &
    pids="$pids $!"
  done
  rc=0; for p in $pids; do wait $p || rc=1; done
  [ $rc = 0 ] || die "rendering (see $LOG/render_*.log)"
  $PY $S/prep_teacher.py --out $DATA --merge > $LOG/merge.log 2>&1 || die "merge"
  step "corpus: $(tr -d '\n ' < $DATA/report.json | cut -c1-400)"
  mark render
fi
DATAS=$DATA${EXTRA_DATA:+,$EXTRA_DATA}

# ---------- 4. acoustic model and vocoder (ground-truth mels) in parallel on the same GPU
if ! done_ train; then
  $PY $S/train_am.py --data $DATAS --out $RUNS/am $AMX > $LOG/train_am.log 2>&1 & PA=$!
  $PY $S/train_voc.py --data $DATAS --out $RUNS/voc $VOCX > $LOG/train_voc.log 2>&1 & PV=$!
  wait $PA; ra=$?; wait $PV; rv=$?
  [ $ra = 0 ] && [ -f $RUNS/am/final.pt ] || die "acoustic model (rc $ra, see $LOG/train_am.log)"
  [ $rv = 0 ] && [ -f $RUNS/voc/final.pt ] || die "vocoder (rc $rv, see $LOG/train_voc.log)"
  step "AM: $(grep EVAL $RUNS/am/train.log | tail -1 | cut -c1-200)"
  step "vocoder: $(grep EVAL $RUNS/voc/train.log | tail -1 | cut -c1-200)"
  mark train
fi

# ---------- 5. vocoder fine-tuning on AM-predicted (teacher-forced) mels
if ! done_ finetune; then
  $PY $S/train_voc.py --data $DATAS --out $RUNS/voc_ft --init $RUNS/voc/final.pt --am_ckpt $RUNS/am/final.pt $FTX > $LOG/train_voc_ft.log 2>&1 \
    && [ -f $RUNS/voc_ft/final.pt ] || die "vocoder fine-tuning (see $LOG/train_voc_ft.log)"
  mark finetune
fi

# ---------- 6. export for the phone (+ int8 check) and evaluation against the teacher
if ! done_ export; then
  $PY $S/export.py --am $RUNS/am/final.pt --voc $RUNS/voc_ft/final.pt --out $OUT/export --check > $LOG/export.log 2>&1 || die "export (see $LOG/export.log)"
  step "export: $(head -1 $LOG/export.log)"
  mark export
fi
if ! done_ eval; then
  $PY $S/eval.py --data $DATAS --am $RUNS/am/final.pt --voc $RUNS/voc_ft/final.pt --export $OUT/export --out $OUT/eval $([ "$SMOKE" = 1 ] && echo "--n 2 --wavs 1") > $LOG/eval.log 2>&1 || die "eval (see $LOG/eval.log)"
  step "eval: $(tail -1 $LOG/eval.log | cut -c1-400)"
  mark eval
fi

# ---------- 7. Java parity / speed on this machine (optional: needs a JDK)
if command -v javac > /dev/null && ! done_ java; then
  OUT_CASE=$OUT/javacase PY=$PY bash $K/android/test/voice/run.sh $RUNS/am/final.pt $RUNS/voc_ft/final.pt > $LOG/java.log 2>&1 \
    && step "java: $(grep -E 'PARITY|SPEED|ALL OK|FAIL' $LOG/java.log | tr '\n' ' ' | cut -c1-600)" || step "java test failed (see $LOG/java.log)"
  JAVA_CLS=$OUT/javacase/classes
  for L in ${LANGS//,/ }; do java -cp $JAVA_CLS in.krishi.doctor.Speak $OUT/export $L female $OUT/java_$L.wav "$(grep -m1 "\"lang\": \"$L\"" $DATA/metadata.jsonl | $PY -c 'import json,sys; print(json.loads(sys.stdin.read())["text"])')" >> $LOG/java.log 2>&1; done
  mark java
fi

tar czf $OUT/krishivoice_results.tgz -C $OUT export eval -C $W progress.txt logs 2>/dev/null
step "FINISHED: phone files in $OUT/export (voice.json, voice_am.bin, voice_voc.bin); results $OUT/krishivoice_results.tgz"
