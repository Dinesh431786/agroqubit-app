"""Python reference synthesis (what Speak.java does), from checkpoints or from an exported model directory.

  python3 infer.py --export export/ --lang hi --speaker female --text "दो सौ पचास ग्राम." --out x.wav
  python3 infer.py --am runs/am/final.pt --voc runs/voc/final.pt --lang ta --speaker male --text "..." --out y.wav
"""
import argparse, os, sys, time
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import text as T
from audio import SR, save_wav


def synth_ids(am, voc, ids, lang_i, voice_i, speed=1.0, dur=None):
    mel, dur, logd, pitch = am.infer(ids, lang_i, voice_i, speed=speed, dur=dur)
    return voc.infer(mel), mel, dur, logd, pitch


def synth(am, voc, text, lang, speaker, speed=1.0):
    """Raw text -> 16 kHz float32 waveform in the clips' format (render_segments.py): sentences joined with 0.28 s
    pauses, peak 0.85, 50 ms silence before and 100 ms after (Speak.synth does the same)."""
    li, vi = T.lang_id(lang), T.voice_id(lang, speaker); gap = np.zeros(int(round(T.GAP_SECONDS * SR)), np.float32); parts = []
    for ids in T.text_to_sentences(text, lang):
        if parts: parts.append(gap)
        parts.append(synth_ids(am, voc, ids, li, vi, speed)[0])
    if not parts: return np.zeros(0, np.float32)
    w = np.concatenate(parts); w = w * np.float32(0.85 / (np.abs(w).max() + 1e-6))
    return np.concatenate([np.zeros(SR // 20, np.float32), w, np.zeros(SR // 10, np.float32)]).astype(np.float32)


def load(args_export=None, am_path=None, voc_path=None, device="cpu"):
    from export import load_exported, load_checkpoints
    if args_export: am, voc, _ = load_exported(args_export, device); return am, voc
    am, voc, _, _ = load_checkpoints(am_path, voc_path, device); return am, voc


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--export"); ap.add_argument("--am"); ap.add_argument("--voc")
    ap.add_argument("--lang", required=True); ap.add_argument("--speaker", default="female"); ap.add_argument("--text", required=True)
    ap.add_argument("--speed", type=float, default=1.0); ap.add_argument("--out", required=True); ap.add_argument("--threads", type=int, default=1)
    a = ap.parse_args(); torch.set_num_threads(a.threads)
    am, voc = load(a.export, a.am, a.voc)
    t0 = time.time(); w = synth(am, voc, a.text, a.lang, a.speaker, a.speed); dt = time.time() - t0
    save_wav(a.out, w); print(f"{a.out}: {len(w) / SR:.2f} s audio in {dt:.2f} s (RTF {dt / max(1e-9, len(w) / SR):.3f})")


if __name__ == "__main__":
    main()
