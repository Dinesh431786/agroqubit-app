"""Export KrishiVoice for the phone (Speak.java): voice_am.bin + voice_voc.bin (KRW1, android/tools/krw.py) + voice.json.

Weights: every matrix that a GEMM reads (attention, FFN, predictor convs, vocoder embed / pointwise / head) is int8 with
one fp32 scale per output row (MSE-searched clipping, krw.quant_rows); the token table is fp16; norms, biases,
embeddings of language/voice, depthwise and pitch-embedding taps and the predictor output rows stay fp32 (tiny).
Conv1d weights [cout, cin, k] are stored tap-major as rows [cout, k*cin]: on row-major [T][cin] activations a k-tap
conv is then one dot product per output over k consecutive rows (SpeakOps.gemm with row stride cin).
voice.json carries the text tables (text.tables()), the mel/STFT definition, model dimensions and pitch stats.

  python3 export.py --am runs/am/final.pt --voc runs/voc_ft/final.pt --out export/ --check
--check reloads the exported (dequantised) weights into PyTorch and reports the int8 error against the float model.
"""
import argparse, json, os, sys
from collections import OrderedDict
from dataclasses import asdict
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(HERE)), "android", "tools"))
from krw import write_krw1, read_krw1, q8, f16, f32
import text as T
import audio as A
from model_am import AcousticModel, AMConfig
from model_voc import Vocoder, VocConfig

AM_LN_EPS, VOC_LN_EPS = 1e-5, 1e-6


def conv_rows(w):
    """torch Conv1d weight [cout, cin, k] -> [cout, k*cin] (tap-major)."""
    w = np.asarray(w, np.float32); return np.ascontiguousarray(w.transpose(0, 2, 1).reshape(w.shape[0], -1))


def unconv_rows(r, cin, k):
    return np.ascontiguousarray(np.asarray(r, np.float32).reshape(r.shape[0], k, cin).transpose(0, 2, 1))


def _np(sd): return {k: v.detach().cpu().float().numpy() for k, v in sd.items()}


def am_tensors(model, quant=True):
    c, sd = model.cfg, _np(model.state_dict()); Q = q8 if quant else f32; t = OrderedDict()
    t["tok"] = f16(sd["tok.weight"]); t["lang"] = f32(sd["lang.weight"])
    t["voice_enc"] = f32(sd["voice_enc.weight"]); t["voice_dec"] = f32(sd["voice_dec.weight"])
    for part, n in (("enc", c.enc_layers), ("dec", c.dec_layers)):
        for i in range(n):
            p = f"{part}.{i}."
            t[p + "qkv.w"] = Q(sd[p + "att.qkv.weight"]); t[p + "qkv.b"] = f32(sd[p + "att.qkv.bias"])
            t[p + "o.w"] = Q(sd[p + "att.o.weight"]); t[p + "o.b"] = f32(sd[p + "att.o.bias"])
            t[p + "ln1.g"] = f32(sd[p + "ln1.weight"]); t[p + "ln1.b"] = f32(sd[p + "ln1.bias"])
            t[p + "ff1.w"] = Q(conv_rows(sd[p + "ff1.weight"])); t[p + "ff1.b"] = f32(sd[p + "ff1.bias"])
            t[p + "ff2.w"] = Q(sd[p + "ff2.weight"][:, :, 0]); t[p + "ff2.b"] = f32(sd[p + "ff2.bias"])
            t[p + "ln2.g"] = f32(sd[p + "ln2.weight"]); t[p + "ln2.b"] = f32(sd[p + "ln2.bias"])
    for pr in ("dur", "pitch"):
        for i in range(2):
            t[f"{pr}.c{i}.w"] = Q(conv_rows(sd[f"{pr}.convs.{i}.weight"])); t[f"{pr}.c{i}.b"] = f32(sd[f"{pr}.convs.{i}.bias"])
            t[f"{pr}.ln{i}.g"] = f32(sd[f"{pr}.lns.{i}.weight"]); t[f"{pr}.ln{i}.b"] = f32(sd[f"{pr}.lns.{i}.bias"])
        t[f"{pr}.out.w"] = f32(sd[f"{pr}.out.weight"]); t[f"{pr}.out.b"] = f32(sd[f"{pr}.out.bias"])
    t["pitch_emb.w"] = f32(sd["pitch_emb.weight"][:, 0, :]); t["pitch_emb.b"] = f32(sd["pitch_emb.bias"])
    t["mel.w"] = Q(sd["mel.weight"]); t["mel.b"] = f32(sd["mel.bias"])
    return t


def voc_tensors(model, quant=True, head_f16=False):
    c, sd = model.cfg, _np(model.state_dict()); Q = q8 if quant else f32; t = OrderedDict()
    t["embed.w"] = Q(conv_rows(sd["embed.weight"])); t["embed.b"] = f32(sd["embed.bias"])
    t["norm.g"] = f32(sd["norm.weight"]); t["norm.b"] = f32(sd["norm.bias"])
    for i in range(c.layers):
        p = f"blocks.{i}."; q = f"b{i}."
        t[q + "dw.w"] = f32(sd[p + "dw.weight"][:, 0, :].T)          # [k][C] tap-major
        t[q + "dw.b"] = f32(sd[p + "dw.bias"])
        t[q + "ln.g"] = f32(sd[p + "norm.weight"]); t[q + "ln.b"] = f32(sd[p + "norm.bias"])
        t[q + "pw1.w"] = Q(sd[p + "pw1.weight"]); t[q + "pw1.b"] = f32(sd[p + "pw1.bias"])
        t[q + "pw2.w"] = Q(sd[p + "pw2.weight"]); t[q + "pw2.b"] = f32(sd[p + "pw2.bias"])
        t[q + "gamma"] = f32(sd[p + "gamma"])
    t["final.g"] = f32(sd["final_norm.weight"]); t["final.b"] = f32(sd["final_norm.bias"])
    t["head.w"] = (f16 if (head_f16 and quant) else Q)(sd["head.weight"]); t["head.b"] = f32(sd["head.bias"])
    return t


def load_am_krw(model, path):
    """Put the exported (dequantised) weights back into a PyTorch AM: the reference the Java port must match."""
    c, w = model.cfg, read_krw1(path); sd = {}
    sd["tok.weight"] = w["tok"]; sd["lang.weight"] = w["lang"]; sd["voice_enc.weight"] = w["voice_enc"]; sd["voice_dec.weight"] = w["voice_dec"]
    for part, n in (("enc", c.enc_layers), ("dec", c.dec_layers)):
        for i in range(n):
            p = f"{part}.{i}."
            sd[p + "att.qkv.weight"] = w[p + "qkv.w"]; sd[p + "att.qkv.bias"] = w[p + "qkv.b"]
            sd[p + "att.o.weight"] = w[p + "o.w"]; sd[p + "att.o.bias"] = w[p + "o.b"]
            sd[p + "ln1.weight"] = w[p + "ln1.g"]; sd[p + "ln1.bias"] = w[p + "ln1.b"]
            sd[p + "ff1.weight"] = unconv_rows(w[p + "ff1.w"], c.d, c.ff_kernel); sd[p + "ff1.bias"] = w[p + "ff1.b"]
            sd[p + "ff2.weight"] = w[p + "ff2.w"][:, :, None]; sd[p + "ff2.bias"] = w[p + "ff2.b"]
            sd[p + "ln2.weight"] = w[p + "ln2.g"]; sd[p + "ln2.bias"] = w[p + "ln2.b"]
    for pr in ("dur", "pitch"):
        for i in range(2):
            sd[f"{pr}.convs.{i}.weight"] = unconv_rows(w[f"{pr}.c{i}.w"], c.d if i == 0 else c.pred_filters, c.pred_kernel)
            sd[f"{pr}.convs.{i}.bias"] = w[f"{pr}.c{i}.b"]
            sd[f"{pr}.lns.{i}.weight"] = w[f"{pr}.ln{i}.g"]; sd[f"{pr}.lns.{i}.bias"] = w[f"{pr}.ln{i}.b"]
        sd[f"{pr}.out.weight"] = w[f"{pr}.out.w"]; sd[f"{pr}.out.bias"] = w[f"{pr}.out.b"]
    sd["pitch_emb.weight"] = w["pitch_emb.w"][:, None, :]; sd["pitch_emb.bias"] = w["pitch_emb.b"]
    sd["mel.weight"] = w["mel.w"]; sd["mel.bias"] = w["mel.b"]
    missing, unexpected = model.load_state_dict({k: torch.from_numpy(np.ascontiguousarray(v)) for k, v in sd.items()}, strict=False)
    assert not unexpected and all(k.startswith("aligner.") for k in missing), (missing, unexpected)
    return model


def load_voc_krw(model, path):
    c, w = model.cfg, read_krw1(path); sd = {}
    sd["embed.weight"] = unconv_rows(w["embed.w"], c.n_mels, c.kernel); sd["embed.bias"] = w["embed.b"]
    sd["norm.weight"] = w["norm.g"]; sd["norm.bias"] = w["norm.b"]
    for i in range(c.layers):
        p = f"blocks.{i}."; q = f"b{i}."
        sd[p + "dw.weight"] = np.ascontiguousarray(w[q + "dw.w"].T)[:, None, :]; sd[p + "dw.bias"] = w[q + "dw.b"]
        sd[p + "norm.weight"] = w[q + "ln.g"]; sd[p + "norm.bias"] = w[q + "ln.b"]
        sd[p + "pw1.weight"] = w[q + "pw1.w"]; sd[p + "pw1.bias"] = w[q + "pw1.b"]
        sd[p + "pw2.weight"] = w[q + "pw2.w"]; sd[p + "pw2.bias"] = w[q + "pw2.b"]; sd[p + "gamma"] = w[q + "gamma"]
    sd["final_norm.weight"] = w["final.g"]; sd["final_norm.bias"] = w["final.b"]; sd["head.weight"] = w["head.w"]; sd["head.bias"] = w["head.b"]
    model.load_state_dict({k: torch.from_numpy(np.ascontiguousarray(v)) for k, v in sd.items()}, strict=True)
    return model


def voice_json(am_cfg, voc_cfg, stats, extra=None):
    j = {"format": "krishivoice", "version": 1, **A.params(), "text": T.tables(),
         "am": {**{k: v for k, v in asdict(am_cfg).items() if not k.startswith("align")}, "ln_eps": AM_LN_EPS, "file": "voice_am.bin"},
         "voc": {**asdict(voc_cfg), "ln_eps": VOC_LN_EPS, "max_mag": 100.0, "file": "voice_voc.bin"},
         "voices": [{"id": T.voice_id(l, s), "lang": l, "speaker": s} for l in T.LANGS for s in T.SPEAKERS],
         "pitch_stats": {str(k): list(v) for k, v in sorted(stats.items())}}
    if extra: j.update(extra)
    return j


def export(am, voc, out, stats, quant=True, head_f16=False, extra=None):
    os.makedirs(out, exist_ok=True)
    write_krw1(os.path.join(out, "voice_am.bin"), am_tensors(am, quant))
    write_krw1(os.path.join(out, "voice_voc.bin"), voc_tensors(voc, quant, head_f16))
    sizes = {f: os.path.getsize(os.path.join(out, f)) for f in ("voice_am.bin", "voice_voc.bin")}
    j = voice_json(am.cfg, voc.cfg, stats, {"sizes_bytes": sizes, "quant": "int8" if quant else "fp32", **(extra or {})})
    json.dump(j, open(os.path.join(out, "voice.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return sizes


def load_checkpoints(am_path, voc_path, device="cpu"):
    ca = torch.load(am_path, map_location="cpu", weights_only=False); cv = torch.load(voc_path, map_location="cpu", weights_only=False)
    am = AcousticModel(AMConfig.from_dict(ca["cfg"])); am.load_state_dict(ca["model"]); am.eval().to(device)
    voc = Vocoder(VocConfig.from_dict(cv["cfg"])); voc.load_state_dict(cv["G"]); voc.eval().to(device)
    stats = {int(k): tuple(v) for k, v in ca["stats"].items()}
    return am, voc, stats, {"am_step": ca["step"], "voc_step": cv["step"]}


def load_exported(dirpath, device="cpu"):
    """PyTorch models holding exactly the phone's weights (int8/fp16 dequantised)."""
    j = json.load(open(os.path.join(dirpath, "voice.json"), encoding="utf-8"))
    am = load_am_krw(AcousticModel(AMConfig.from_dict(j["am"])), os.path.join(dirpath, "voice_am.bin")).eval().to(device)
    voc = load_voc_krw(Vocoder(VocConfig.from_dict(j["voc"])), os.path.join(dirpath, "voice_voc.bin")).eval().to(device)
    return am, voc, j


CHECK_SENTENCES = [("hi", "female", "मैंकोज़ेब पचहत्तर परसेंट डब्ल्यू जी, दो सौ लीटर पानी में मिलाइए."),
                   ("ta", "male", "ஒரு ஏக்கருக்கு இருநூறு லிட்டர் தண்ணீர் போதும்ங்க."),
                   ("kn", "female", "ಕಿಸಾನ್ ಕಾಲ್ ಸೆಂಟರ್ ಸಂಖ್ಯೆ ಒಂದು ಎಂಟು ಸೊನ್ನೆ ಸೊನ್ನೆ."),
                   ("en", "male", "Spray two grams per litre of water in the evening.")]


def check(am, voc, am_q, voc_q):
    """int8 vs float: same durations forced, mel max/mean abs error and copy-synthesis waveform SNR."""
    rows = []
    for lang, spk, s in CHECK_SENTENCES:
        ids = T.text_to_sentences(s, lang)[0]
        mel, dur, _, _ = am.infer(ids, T.lang_id(lang), T.voice_id(lang, spk))
        mq, _, _, _ = am_q.infer(ids, T.lang_id(lang), T.voice_id(lang, spk), dur=dur)
        w = voc.infer(mel); wq = voc_q.infer(mel)
        snr = 10 * np.log10((w ** 2).sum() / max(((w - wq) ** 2).sum(), 1e-12))
        rows.append({"lang": lang, "frames": int(dur.sum()), "mel_max_abs": float(np.abs(mel - mq).max()), "mel_mean_abs": float(np.abs(mel - mq).mean()),
                     "voc_snr_db": float(snr)})
    return rows


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--am", required=True); ap.add_argument("--voc", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--fp32", action="store_true", help="no int8 (debug)"); ap.add_argument("--head_f16", action="store_true")
    ap.add_argument("--check", action="store_true"); a = ap.parse_args()
    am, voc, stats, info = load_checkpoints(a.am, a.voc)
    sizes = export(am, voc, a.out, stats, not a.fp32, a.head_f16, {"source": info})
    print(f"AM {am.n_params() / 1e6:.2f}M params, vocoder {voc.n_params() / 1e6:.2f}M -> " + ", ".join(f"{k} {v / 1e6:.2f} MB" for k, v in sizes.items())
          + f" | total {sum(sizes.values()) / 1e6:.2f} MB -> {a.out}")
    if a.check:
        am_q, voc_q, _ = load_exported(a.out)
        res = check(am, voc, am_q, voc_q); print(json.dumps(res, indent=1))
        json.dump(res, open(os.path.join(a.out, "export_check.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
