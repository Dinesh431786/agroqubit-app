"""Corpus loading shared by train_am.py, train_voc.py and eval.py.

A data root (written by prep_teacher.py or prep_local.py) holds wavs (16 kHz mono PCM16), per-frame pitch (.npy, Hz,
0 = unvoiced, 1 + samples//256 values) and metadata rows {id, text, lang, speaker, path, pitch, seconds, samples} in
<root>/meta/*.jsonl (prep_teacher shards, preferred) or <root>/metadata.jsonl (paths relative to the root). Several roots
can be combined.
Held-out split: crc32(text) % 1000 < 10 * eval_pct (deterministic, the same in every script; by sentence text, so a
held-out sentence is unseen for every voice).
"""
import glob, json, os, random, zlib
import numpy as np
import torch

import text as T
from audio import HOP, SR, n_frames


def read_rows(root):
    files = sorted(glob.glob(os.path.join(root, "meta", "*.jsonl")))          # prep_teacher shards: the source of truth
    if not files and os.path.exists(os.path.join(root, "metadata.jsonl")): files = [os.path.join(root, "metadata.jsonl")]
    if not files: raise FileNotFoundError(f"no metadata.jsonl or meta/*.jsonl under {root!r} - run prep_teacher.py / prep_local.py first")
    rows = []
    for f in files:
        for ln, line in enumerate(open(f, encoding="utf-8")):
            line = line.strip()
            if not line: continue
            try: r = json.loads(line)
            except json.JSONDecodeError: print(f"warning: bad json at {f}:{ln + 1} (partial write?) - skipped"); continue
            r["path"] = os.path.join(root, r["path"]); r["pitch"] = os.path.join(root, r["pitch"]); rows.append(r)
    return rows


def is_eval(text, eval_pct): return zlib.crc32(" ".join(text.lower().split()).encode()) % 1000 < int(round(10 * eval_pct))


class Corpus:
    def __init__(self, roots, split="train", eval_pct=2.0, min_sec=0.4, max_sec=15.0, langs=None, voices=None, verbose=True):
        roots = [roots] if isinstance(roots, str) else list(roots)
        rows, dropped = [], {"split": 0, "length": 0, "short_text": 0, "too_fast": 0, "lang": 0, "missing_file": 0}
        for root in roots:
            for r in read_rows(root):
                if langs and r["lang"] not in langs: dropped["lang"] += 1; continue
                ev = is_eval(r["text"], eval_pct)
                if (split == "train" and ev) or (split == "eval" and not ev): dropped["split"] += 1; continue
                if not (min_sec <= r["seconds"] <= max_sec): dropped["length"] += 1; continue
                if not (os.path.exists(r["path"]) and os.path.exists(r["pitch"])): dropped["missing_file"] += 1; continue
                ids = T.encode(T.normalize(r["text"], r["lang"]))
                if len(ids) < 3: dropped["short_text"] += 1; continue
                r["frames"] = n_frames(int(r.get("samples", round(r["seconds"] * SR))))
                if r["frames"] < len(ids) + 2: dropped["too_fast"] += 1; continue   # MAS needs >= 1 frame per token
                r["ids"] = ids; r["lang_i"] = T.lang_id(r["lang"]); r["voice_i"] = T.voice_id(r["lang"], r["speaker"])
                if voices is not None and r["voice_i"] not in voices: continue
                rows.append(r)
        if not rows: raise RuntimeError(f"no usable utterances in {roots} (split={split}, dropped={dropped})")
        self.rows = rows
        if verbose:
            hours = {}
            for r in rows: k = f"{r['lang']}_{r['speaker']}"; hours[k] = hours.get(k, 0) + r["seconds"] / 3600
            print(f"corpus[{split}]: {len(rows)} utterances, {sum(hours.values()):.2f} h", {k: round(v, 2) for k, v in sorted(hours.items())},
                  "dropped", {k: v for k, v in dropped.items() if v}, flush=True)

    def __len__(self): return len(self.rows)


def pitch_stats(rows, cache=None):
    """Per-voice mean/std of log-f0 over voiced frames: {voice_i: (mean, std)} (cached as json)."""
    if cache and os.path.exists(cache):
        return {int(k): tuple(v) for k, v in json.load(open(cache)).items()}
    acc = {}
    for r in rows:
        f = np.load(r["pitch"]); f = f[f > 0]
        if len(f) == 0: continue
        a = acc.setdefault(r["voice_i"], [0.0, 0.0, 0]); lf = np.log(f.astype(np.float64)); a[0] += lf.sum(); a[1] += (lf ** 2).sum(); a[2] += len(lf)
    st = {}
    for v, (s, s2, n) in acc.items():
        m = s / n; st[v] = (float(m), float(max(np.sqrt(max(s2 / n - m * m, 0.0)), 1e-3)))
    for v in range(len(T.LANGS) * len(T.SPEAKERS)): st.setdefault(v, (float(np.log(150.0)), 0.25))
    if cache:
        os.makedirs(os.path.dirname(os.path.abspath(cache)), exist_ok=True); json.dump({str(k): v for k, v in st.items()}, open(cache, "w"), indent=1)
    return st


def load_wav16(path):
    import soundfile as sf
    w, fs = sf.read(path, dtype="float32", always_2d=True)
    if fs != SR: raise ValueError(f"{path}: {fs} Hz, expected {SR}")
    return w[:, 0]


class UttDataset(torch.utils.data.Dataset):
    """Whole utterances: tokens, ids, wav, per-frame pitch (Hz)."""
    def __init__(self, corpus): self.rows = corpus.rows

    def __len__(self): return len(self.rows)

    def __getitem__(self, i):
        r = self.rows[i]; w = load_wav16(r["path"]); p = np.load(r["pitch"]).astype(np.float32)
        n = n_frames(len(w))
        if len(p) != n: p = np.pad(p, (0, max(0, n - len(p))))[:n]
        return {"ids": np.asarray(r["ids"], np.int64), "lang": r["lang_i"], "voice": r["voice_i"], "wav": w, "pitch": p, "idx": i}


def collate_utts(items):
    B = len(items); N = max(len(x["ids"]) for x in items); L = max(len(x["wav"]) for x in items); Tm = 1 + L // HOP
    tok = torch.zeros(B, N, dtype=torch.long); wav = torch.zeros(B, L); pitch = torch.zeros(B, Tm)
    tl = torch.zeros(B, dtype=torch.long); wl = torch.zeros(B, dtype=torch.long)
    for b, x in enumerate(items):
        n = len(x["ids"]); tok[b, :n] = torch.from_numpy(x["ids"]); tl[b] = n
        w = len(x["wav"]); wav[b, :w] = torch.from_numpy(x["wav"]); wl[b] = w
        p = x["pitch"][:Tm]; pitch[b, :len(p)] = torch.from_numpy(p)
    return {"tokens": tok, "tlens": tl, "wav": wav, "wlens": wl, "mlens": 1 + wl // HOP, "pitch_hz": pitch,
            "lang": torch.tensor([x["lang"] for x in items]), "voice": torch.tensor([x["voice"] for x in items]),
            "idx": torch.tensor([x["idx"] for x in items])}


class BucketBatches(torch.utils.data.Sampler):
    """Batches of similar length, at most max_frames padded mel frames and max_batch items; reshuffled every epoch."""
    def __init__(self, frames, max_frames, max_batch=64, seed=0, epoch=0, shuffle=True):
        self.frames, self.max_frames, self.max_batch, self.seed, self.epoch, self.shuffle = list(frames), max_frames, max_batch, seed, epoch, shuffle
        self._batches = self._make()

    def _make(self):
        rng = random.Random(self.seed * 1000003 + self.epoch); idx = list(range(len(self.frames)))
        if self.shuffle: rng.shuffle(idx)
        chunk = max(1, 100 * self.max_batch); batches = []
        for c in range(0, len(idx), chunk):
            part = sorted(idx[c:c + chunk], key=lambda i: self.frames[i]); cur, mx = [], 0
            for i in part:
                f = self.frames[i]
                if cur and (max(mx, f) * (len(cur) + 1) > self.max_frames or len(cur) >= self.max_batch):
                    batches.append(cur); cur, mx = [], 0
                cur.append(i); mx = max(mx, f)
            if cur: batches.append(cur)
        if self.shuffle: rng.shuffle(batches)
        return batches

    def set_epoch(self, e): self.epoch = e; self._batches = self._make()

    def __iter__(self): return iter(self._batches)

    def __len__(self): return len(self._batches)


class SegmentDataset(torch.utils.data.Dataset):
    """Random fixed-length segments (K*256 samples) for vocoder training; length = utterances x repeats."""
    def __init__(self, corpus, seg_samples, repeats=1000):
        self.rows, self.seg, self.rep = corpus.rows, seg_samples, repeats

    def __len__(self): return len(self.rows) * self.rep

    def __getitem__(self, i):
        r = self.rows[i % len(self.rows)]; w = load_wav16(r["path"])
        if len(w) <= self.seg: w = np.pad(w, (0, self.seg - len(w) + 1))
        s = np.random.randint(0, (len(w) - self.seg) // HOP + 1) * HOP   # frame-aligned start
        return torch.from_numpy(w[s:s + self.seg].copy())


def normalise_pitch(pitch_hz, voice, stats):
    """[B,T] Hz -> (normalised log-f0 [B,T] (0 when unvoiced), voiced bool [B,T])."""
    mean = torch.tensor([stats[int(v)][0] for v in voice], device=pitch_hz.device)[:, None]
    std = torch.tensor([stats[int(v)][1] for v in voice], device=pitch_hz.device)[:, None]
    voiced = pitch_hz > 0
    return torch.where(voiced, (torch.log(pitch_hz.clamp(min=1.0)) - mean) / std, torch.zeros_like(pitch_hz)), voiced
