# Colloquial rewrite: notes

Source: `catalogue.json`. Output: `catalogue_colloquial.json`. Both have the same 77 ids and the same `hi/ta/kn/en` keys, in the same order.
Checks run: the phone number 1800-180-1551, every "KVK" and every digit in the source (4, 5, 6, 10) are still there in each cell.
17 cells were left as they were, because they are already plain spoken forms: some short English questions and fillers, and a few Tamil/Kannada disease names such as "தேமல் நோய்" and "ತುಕ್ಕು ರೋಗ".

Style choices:
- **Hindi:** uses "जी", "दीजिए/कीजिए" and "पत्ते" in place of "पत्तियाँ". "दवाई छिड़कना" replaces "छिड़काव". "जीवाणु" became "बैक्टीरिया वाला" and "अंडाकार" became "अंडे जैसे". "मौसम" became "सीज़न" in the advice lines.
- **Tamil:** uses spoken endings "-ங்க", "இருக்கா?", "தெரியுதா?", "மாறுதா?" and "-ல" in place of "-இல்". It says "இல்லன்னா" for "or", and "பூசணம்" for mould.
- **Kannada:** spoken Central/North-friendly, with "-ರಿ" imperatives (ಮಾಡ್ರಿ, ಕೇಳ್ರಿ, ಹಾಕ್ರಿ). Questions consistently end in "ಇದೆಯಾ?". I chose that over the more northern "ಐತಾ?" so speakers across the state follow it. Other words: "ಚುಕ್ಕಿ", "ದಂಟು" for stem, and "ಔಷಧಿ ಹೊಡೆಯೋದು" for spraying.
- **English:** short and plain. Each advice item is now 2–3 separate sentences rather than clauses joined by semicolons.

## Hindi: before → after
1. q_healthy: क्या पत्तियाँ पूरी तरह स्वस्थ दिखती हैं, कोई धब्बा, पाउडर या पीलापन नहीं? → क्या पत्ते एकदम ठीक-ठाक दिख रहे हैं — न कोई धब्बा, न पाउडर, न पीलापन?
2. q_round_brown_spots: …गोल या अंडाकार भूरे धब्बे हैं, लाल-भूरे किनारे के साथ? → क्या तिल के दाने जैसे गोल या अंडे जैसे भूरे धब्बे हैं, जिनका किनारा लाल-भूरा है?
3. q_sheath_grey_green_patches: …तने के आवरण पर… → पानी के पास, तने पर लिपटे पत्ते के खोल पर, क्या स्लेटी-हरे अंडे जैसे धब्बे हैं, भूरे किनारे वाले?
4. q_ctx_wet_cloudy: …अक्सर बारिश, बूंदाबांदी, बादल या बहुत नमी रही? → पिछले दो हफ़्ते में क्या बार-बार बारिश, फुहार, बादल या बहुत उमस रही है?
5. didnt_hear: माफ़ कीजिए, समझ नहीं आया। हाँ या ना बोलिए, या बटन दबाइए। → माफ़ कीजिए जी, समझ नहीं आया। हाँ या ना बोलिए, या बटन दबा दीजिए।
6. name_chilli_powdery_mildew: चूर्णिल आसिता (सफ़ेद चूर्ण रोग) → मिर्च का सफ़ेद चूर्ण रोग, यानी भभूतिया
7. adv_tomato_early_blight: संक्रमित निचली पत्तियाँ हटाएँ; हर मौसम नर्सरी की जगह बदलें; सहनशील किस्में लगाएँ। → बीमार निचले पत्ते तोड़कर हटा दीजिए। हर सीज़न नर्सरी की जगह बदलिए। ऐसी किस्म लगाइए जो ये रोग झेल सके।
8. adv_rice_blast: …स्यूडोमोनास से बीज/पौध उपचार — मात्रा KVK से पूछें। → …बीज या पौध का उपचार स्यूडोमोनास से कीजिए — कितना डालना है, ये KVK से पूछिए।

## Tamil: before → after
1. q_healthy: இலைகள் முழுமையாக ஆரோக்கியமாக உள்ளனவா? … இல்லையா? → இலையெல்லாம் நல்லா ஆரோக்கியமா இருக்கா? புள்ளியோ, தூளோ, மஞ்சளோ ஒண்ணுமே இல்லையா?
2. q_eye_shaped_grey_centre: இரு முனைகளும் கூர்மையான … கண் வடிவப் புள்ளிகள் உள்ளனவா? → கண்ணு மாதிரி புள்ளி இருக்கா? ரெண்டு முனையும் கூர்மையா, நடுவுல சாம்பல் கலர், ஓரம் பழுப்பு?
3. q_neck_black_panicle_breaks: …கதிர் உடைந்து தொங்குகிறதா? → கதிருக்குக் கீழ இருக்கிற கழுத்து கருப்பாகி, கதிர் ஒடிஞ்சு தொங்குதா?
4. q_ctx_whiteflies: …வெள்ளை ஈக்கள் இலைகளின் அடியில் தெரிகின்றனவா? → செடியை ஆட்டினா பறக்கிற சின்ன சின்ன வெள்ளை ஈ, இலை அடியில தெரியுதா?
5. q_orange_pustules_underside: …துரு நிறப் புள்ளிகள் உள்ளனவா? → இலை அடிப்பக்கம் ஆரஞ்சு இல்லன்னா துரு கலர்ல மேடா பொங்கின புள்ளி இருக்கா, தொட்டா விரல்ல தூள் ஒட்டுதா?
6. didnt_hear: மன்னிக்கவும், புரியவில்லை. ஆம் அல்லது இல்லை … பொத்தானை அழுத்துங்கள். → மன்னிச்சுக்கோங்க, புரியலை. ஆமா, இல்லைன்னு சொல்லுங்க, இல்லன்னா பட்டனை அமுக்குங்க.
7. adv_tomato_late_blight: …லேசான நீர்ப்பாசனம் மட்டும்; உடனே KVK-ஐ அணுகவும். → …தண்ணி லேசாத்தான் கட்டுங்க. உடனே KVK-ல பேசுங்க.
8. adv_chilli_powdery_mildew: …தாங்கும் ரகங்களைப் பயிரிடவும்; கந்தக தெளிப்பு அளவை KVK-யிடம் கேட்கவும். → அடுத்த பருவத்துல இந்த நோயைத் தாங்கற ரகத்தைப் போடுங்க. கந்தகம் எவ்வளவு தெளிக்கணும்னு KVK-ல கேளுங்க.

## Kannada: before → after
1. greet: …ಗಿಡದಲ್ಲಿ ಏನು ಕಾಣುತ್ತಿದೆ ಎಂದು ಹೇಳಿ. ಫೋಟೋ ಕೂಡ ತೆಗೆಯಬಹುದು. → ನಮಸ್ಕಾರ್ರಿ. ನಿಮ್ ಬೆಳೆ ಯಾವುದು, ಗಿಡದಲ್ಲಿ ಏನ್ ಕಾಣ್ತಿದೆ ಅಂತ ಹೇಳ್ರಿ. ಫೋಟೋನೂ ತೆಗೀಬಹುದು ರೀ.
2. q_part: ಸಮಸ್ಯೆ ಎಲ್ಲಿದೆ: ಎಲೆ, ಕಾಂಡ, ಕಾಳು/ಕಾಯಿ, ಅಥವಾ ಇಡೀ ಗಿಡ? → ತೊಂದರೆ ಎಲ್ಲಿದೆ ರೀ? ಎಲೆಗಾ, ದಂಟಿಗಾ, ಕಾಳು ಅಥವಾ ಕಾಯಿಗಾ, ಇಲ್ಲಾ ಇಡೀ ಗಿಡಕ್ಕಾ?
3. q_orange_yellow_from_tip: …ಗಿಡಗಳು ಕುಂಠಿತವಾಗಿವೆಯೇ? → ಹಳೇ ಎಲೆಗಳು ತುದಿಯಿಂದ ಕೆಳಗೆ ಹಳದಿ-ಕಿತ್ತಳೆ ಬಣ್ಣಕ್ಕೆ ತಿರುಗಿ, ಗಿಡ ಬೆಳೀದೆ ಗಿಡ್ಡ ಆಗಿದೆಯಾ?
4. q_ctx_high_urea: ಇತ್ತೀಚೆಗೆ ಹೆಚ್ಚು ಯೂರಿಯಾ ಹಾಕಿದ್ದೀರಾ? → ಇತ್ತೀಚೆಗೆ ಯೂರಿಯಾ ಜಾಸ್ತಿ ಹಾಕಿದ್ರೇನ್ರಿ?
5. q_ctx_wet_cloudy: ಕಳೆದ ಎರಡು ವಾರಗಳಲ್ಲಿ ಆಗಾಗ ಮಳೆ, ತುಂತುರು… ಇತ್ತೇ? → ಹೋದ ಎರಡು ವಾರದಲ್ಲಿ ಆಗಾಗ ಮಳೆ, ಜಿಟಿಜಿಟಿ ಮಳೆ, ಮೋಡ, ಇಲ್ಲಾ ತುಂಬಾ ತೇವ ಇತ್ತಾ?
6. generic_kvk: ಸರಿಯಾದ ಚಿಕಿತ್ಸೆಗೆ ಗಿಡವನ್ನು KVK ಗೆ ತೋರಿಸಿ… (ಉಚಿತ, …) → ಸರಿಯಾದ ಉಪಚಾರಕ್ಕೆ ಗಿಡಾನ KVK ಗೆ ತೋರಿಸ್ರಿ, ಇಲ್ಲಾಂದ್ರೆ … 1800-180-1551 ಗೆ ಫೋನ್ ಮಾಡ್ರಿ. ಫ್ರೀ ಇದೆ, ಬೆಳಿಗ್ಗೆ 6 ರಿಂದ ರಾತ್ರಿ 10 ರವರೆಗೆ.
7. adv_chilli_powdery_mildew: …ಸಹಿಷ್ಣು ತಳಿ ಬಳಸಿ; ಗಂಧಕ ಸಿಂಪಡಣೆ ಪ್ರಮಾಣ KVK ಬಳಿ ಕೇಳಿ. → ಮುಂದಿನ ಹಂಗಾಮಿಗೆ ಈ ರೋಗ ತಡಕೊಳ್ಳೋ ತಳಿ ಹಾಕ್ರಿ. ಗಂಧಕ ಎಷ್ಟು ಹೊಡೀಬೇಕು ಅಂತ KVK ನಲ್ಲಿ ಕೇಳ್ರಿ.
8. adv_chilli_anthracnose_dieback: …ನೀರು ನಿಲ್ಲಲು ಬಿಡಬೇಡಿ. → ರೋಗದ ಕಾಯಿ, ಒಣಗಿದ ಕೊಂಬೆ ತೆಗೆದುಹಾಕ್ರಿ. ನೀರು ನಿಲ್ಲೋಕೆ ಬಿಡಬೇಡ್ರಿ.

## English: before → after
1. didnt_hear: Sorry, I did not understand. Please say yes or no, or tap the button. → Sorry, I didn't catch that. Please say yes or no, or press the button.
2. q_sheath_grey_green_patches: On the stem sheath near the water… → Near the water, on the leaf cover around the stem, are there oval grey-green patches with a brown edge?
3. q_round_brown_spots: …round or oval brown spots… reddish-brown border? → Are there round or egg-shaped brown spots, like sesame seeds, with a reddish-brown edge?
4. q_orange_yellow_from_tip: …with plants stunted? → …from the tip downwards, with the plants short and stunted?
5. generic_kvk: …(free, 6 AM-10 PM) for the right treatment. → For the right treatment, show the plant at your KVK, or call … 1800-180-1551. It is free, from 6 in the morning to 10 at night.
6. adv_groundnut_rust: …remove volunteer plants… → …Pull out stray groundnut plants that came up on their own…
7. adv_groundnut_early_leaf_spot: Remove crop debris; next season rotate with sorghum/bajra/maize; … → Clear the old crop waste from the field. Next season, change the crop — grow sorghum, bajra or maize. If needed, use 5% neem seed kernel extract.
8. name_rice_healthy: rice healthy → Your rice is healthy

## Unsure about / please review
- **The source languages already disagree on some facts.** I kept each language's own facts and did not copy missing advice across from English, because rule 4 forbids adding advice. The Tamil/Kannada versions of these advice lines are shorter than the English/Hindi ones:
  - tomato_early_blight: ta/kn have no "tolerant varieties".
  - tomato_bacterial_leaf_spot: ta/kn have no "ask KVK before spraying".
  - tomato_mosaic: ta/kn have no "don't replant tomato/chilli/brinjal".
  - chilli_mosaic: ta/kn have no "cover nursery with net".
  - groundnut_early_leaf_spot: ta/kn have no "neem 5%".
  - groundnut_late_leaf_spot: neem 5% appears only in en.
  - groundnut_rust: "remove volunteer plants" appears only in en.
  
  These should probably be made the same in the source, after an agronomy check.
- **q_ctx_leafhoppers (kn):** the source said "ಹಾರುವ" (flying), but hi/ta/en say jumping. I wrote "ಹಾರಿ ಜಿಗಿಯೋ" (hop-jumping) to match the other languages.
- **Rice false smut (hi):** I used "हल्दी रोग" (already in the source) first, plus "आभासी कंड (फॉल्स स्मट)". In some areas it is called "लाई/हल्दिया". Ta/kn have a short added description: grains turning into balls.
- **Chilli powdery mildew (hi):** I added "भभूतिया", a common rural name in UP/MP. Please check that it fits your target districts.
- **Kannada BLB / sheath blight names:** I kept the source names ("ಎಲೆ ಮಚ್ಚೆ ರೋಗ", "ಎಲೆಪೊರೆ ಮಚ್ಚೆ ರೋಗ"). UAS extension material sometimes uses "ದುಂಡಾಣು ಎಲೆ ಮಚ್ಚೆ ರೋಗ" for BLB.
- **"Olive-green" mould:** Hindi says "मटमैली-हरी" (dull/muddy green) and Kannada says "ಮಸುಕು ಹಸಿರು". These are close to olive but not exact. Tamil keeps "ஆலிவ் பச்சை" with "மங்கலான" (dull) in front.
- **q_part:** this is still a choice between parts, not a yes/no question. I kept it that way because the app uses it that way.
- **"Sheath":** rewritten as "the leaf cover wrapped around the stem" in every language. Please check that this still separates it clearly from leaf symptoms.

## Advice alignment (follow-up)
The English line in `catalogue_colloquial.json` is now the reference for every `adv_*` id. The hi/ta/kn lines now give exactly the same facts, sentence by sentence (each has the same number of sentences as the English). Nothing was added that is not in the English line. This settles the advice gaps listed under "Unsure" above. The source `catalogue.json` itself is unchanged.

| id | What was added or changed |
|---|---|
| adv_tomato_early_blight | ta, kn: grow varieties that tolerate the disease |
| adv_tomato_late_blight | ta, kn: "it spreads fast"; kn: light watering **only** (ಮಾತ್ರ) |
| adv_tomato_bacterial_leaf_spot | ta, kn: ask KVK before spraying; hi: removed an extra "ही" (only), which the English does not have |
| adv_tomato_mosaic | ta, kn: don't plant tomato/chilli/brinjal there again; hi, ta, kn: "pull out **and** destroy" (was only "destroy") |
| adv_chilli_mosaic | ta, kn: cover the nursery with net |
| adv_groundnut_early_leaf_spot | ta, kn: 5% neem seed kernel extract if needed (ta வேப்பங்கொட்டைச் சாறு, kn ಬೇವಿನ ಬೀಜದ ಕಷಾಯ) |
| adv_groundnut_late_leaf_spot | hi, ta, kn: 5% neem seed kernel extract if needed |
| adv_groundnut_rust | hi, ta, kn: pull out stray groundnut plants that came up on their own (volunteer plants) |
| adv_rice_blast | hi, ta, kn: full product name "Pseudomonas fluorescens"; ta: seed **or seedlings** (was seed only); kn: ಬೀಜ ಅಥವಾ ಸಸಿ (was ಬೀಜೋಪಚಾರ only) |

These ids already matched the English and were not changed: tomato_leaf_curl, tomato_septoria_leaf_spot, chilli_anthracnose_dieback, chilli_powdery_mildew, chilli_cercospora_leaf_spot, chilli_bacterial_leaf_spot.
Checks: ids and keys still match `catalogue.json`. Every number/percentage in the English line, and "KVK" when the English has it, appears in hi/ta/kn.
