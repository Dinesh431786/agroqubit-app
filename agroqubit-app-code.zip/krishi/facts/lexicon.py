"""How to SAY the Latin-script words inside Hindi / Tamil / Kannada facts (pesticide, product, variety and pest names kept
in Latin letters by the translation step, e.g. "fipronil", "Kashi Aman"). The teacher writes each word the way an
Indian farmer says it, in Devanagari, Tamil and Kannada script. voice/verbalize.py reads voice/lex_auto.json, so the
pre-rendered human voice says "फिप्रोनिल" instead of spelling F-I-P-R-O-N-I-L. Screen text keeps the label spelling.
Acronyms / formulation codes in capitals (SC, WP, EC) are still spelled letter by letter, as people say them.
Usage: python3 facts/lexicon.py --facts facts/facts.jsonl --work facts/work [teacher args]"""
import argparse, asyncio, json, re, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import factlib as F  # noqa: E402
from teacher import InvalidOutput, add_teacher_args, run_jobs, teacher_from_args  # noqa: E402

SCRIPT = {"hi": r"^[ऀ-ॿ\s]+$", "ta": r"^[஀-௿\s]+$", "kn": r"^[ಀ-೿\s]+$"}
PROMPT = """TASK: lexicon
These words appear in Latin letters inside Hindi, Tamil and Kannada farm advice (pesticides, fertilisers, crop
varieties, pests, units, place names). For each word, write how an Indian farmer would SAY it, in Devanagari (hi),
Tamil script (ta) and Kannada script (kn). Keep the sound of the original word; do not translate the meaning.
Words: {words}
Return JSON only: {{"<word>": {{"hi": "...", "ta": "...", "kn": "..."}}, ...}} with every word above as a key."""


def make_validator(words):
    def clean(obj):
        if not isinstance(obj, dict):
            raise InvalidOutput("expected a JSON object {word: {hi, ta, kn}}")
        out = {}
        low = {k.lower(): v for k, v in obj.items() if isinstance(v, dict)}
        for w in words:
            r = low.get(w.lower())
            if not r:
                continue
            e = {}
            for L in ["hi", "ta", "kn"]:
                v = re.sub(r"\s+", " ", str(r.get(L, ""))).strip()
                if v and re.match(SCRIPT[L], v) and len(v) <= 60:
                    e[L] = v
            if len(e) == 3:
                out[w] = e
        if len(out) < max(1, len(words) // 2):
            raise InvalidOutput(f"only {len(out)} of {len(words)} words came back in the right scripts; give all of them")
        return out
    return clean


def latin_words(facts):
    from collections import Counter
    c = Counter()
    for f in facts:
        for L in ["hi", "ta", "kn"]:
            for w in re.findall(r"[A-Za-z]+", f["text"].get(L) or ""):
                if len(w) >= 2 and not (w.isupper() and len(w) <= 5):    # SC, WP, EC... are spelled out
                    c[w.lower()] += 1
    return c


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--facts", default=str(F.FACTS_DIR / "facts.jsonl"))
    ap.add_argument("--work", default=str(F.FACTS_DIR / "work"))
    ap.add_argument("--out", default=str(F.REPO_DIR / "voice" / "lex_auto.json"))
    ap.add_argument("--batch", type=int, default=40)
    add_teacher_args(ap)
    args = ap.parse_args(argv)
    log = F.get_logger("lexicon", args.work)
    sys.path.insert(0, str(F.REPO_DIR / "voice"))
    try:
        from verbalize import LEX
    except Exception:
        LEX = {}
    have = F.load_json(args.out, {}) or {}
    words = [w for w, _ in latin_words(F.read_jsonl(args.facts)).most_common() if w not in LEX and w not in have]
    log.info(f"{len(words)} Latin words need a reading ({len(have)} already known)")
    batches = [words[i:i + args.batch] for i in range(0, len(words), args.batch)]

    async def run():
        T = teacher_from_args(args, args.work, log)
        async with T:
            await T.wait_ready(args.wait)

            def job(b):
                msgs = [{"role": "user", "content": PROMPT.format(words=", ".join(b))}]
                return lambda: T.chat_json(msgs, tag="lexicon", validate=make_validator(b), temperature=0.1, max_tokens=60 * len(b) + 200)
            res = await run_jobs([job(b) for b in batches], log=log, label="lexicon")
            T.log_summary("lexicon")
        return res

    if batches:
        for r in asyncio.run(run()):
            if isinstance(r, Exception):
                log.warning(f"a batch failed: {str(r)[:200]} (those words will be spelled letter by letter)")
                continue
            have.update(r)
    F.write_json(args.out, have)
    log.info(f"wrote {len(have)} readings -> {args.out}; {sum(1 for w in words if w not in have)} words still without one")


if __name__ == "__main__":
    main()
