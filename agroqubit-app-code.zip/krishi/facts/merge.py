#!/usr/bin/env python3
"""merge.py: combine the seed facts (facts/seed_facts.jsonl, written by factlm/build_seed.py from the app's verified
knowledge base) with the pipeline's facts (work/facts_auto.jsonl, optional work/facts_human.jsonl) into facts.jsonl.

- Seed facts are copied unchanged; their ids are reserved and never assigned to another fact.
- Auto facts that repeat a seed fact (same crop + target/topic, text similarity >= --dup, same numbers) are dropped.
- An auto 'first' fact in a group whose seed already has a 'first' becomes 'action'.
- Ids stay stable across runs through work/id_registry.json; an auto id that collides with a seed id is re-keyed
  (old -> new written to work/id_remap.json).
- Order: seed facts keep their order; auto facts follow the seed facts of the same group in their own order.
- Human facts (review "human", same schema) replace the auto fact with the same id, or are added.
- If seed_facts.jsonl is missing, a stub is built from brain/advice.json + advice_i18n.json FOR TESTING ONLY
  (written to <work>/seed_facts.stub.jsonl, never to facts/seed_facts.jsonl).
Every output row is validated against SCHEMA.md; counts per crop/topic/kind/review are printed and saved.

Usage:
  python3 krishi/facts/merge.py [--work krishi/facts/work] [--out krishi/facts/facts.jsonl]
"""
from __future__ import annotations

import argparse
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import factlib as F  # noqa: E402


def stub_seed(log):
    """Seed-like facts from the app KB (same rules as factlm/build_seed.py). For tests when seed_facts.jsonl is absent."""
    adv = F.load_json(F.REPO_DIR / "brain" / "advice.json")["advice"]
    i18 = F.load_json(F.REPO_DIR / "brain" / "advice_i18n.json")
    rows = []
    for d, a in adv.items():
        crop = d.split("_")[0]
        src = a.get("source", "")
        doc, _, url = src.rpartition(" — ")
        doc, url = (doc or src).strip(), (url or "").strip() or None
        order = 0

        def add(cat, n, text, kind, req):
            nonlocal order
            rows.append({"id": f"{crop}.{d}.{cat}.{n}", "crop": crop, "topic": "disease", "target": d, "kind": kind,
                         "requires_confirmed": req, "text": text,
                         "source": {"doc": doc, "url": url, "page": None, "quote": text["en"]}, "order": order,
                         "review": "seed"})
            order += 1
        add("first", 1, dict(a["first"]), "first", False)
        for cat, kind, req in (("biological", "action", False), ("cultural", "action", False),
                               ("chemical_examples", "dose", True)):
            for i, en in enumerate(a.get(cat, [])):
                tr = {"en": en}
                for L in F.INDIC:
                    lst = i18.get(d, {}).get(cat, {}).get(L, [])
                    tr[L] = lst[i] if i < len(lst) else en
                add("chemical" if cat == "chemical_examples" else cat, i + 1, tr, kind, req)
    log.warning(f"seed_facts.jsonl not found: built a TEST STUB of {len(rows)} facts from brain/advice.json")
    return rows


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--work", default=str(F.DEFAULT_WORK))
    ap.add_argument("--seed", default=str(F.SEED_FACTS))
    ap.add_argument("--auto", default=None, help="default <work>/facts_auto.jsonl")
    ap.add_argument("--human", default=None, help="default <work>/facts_human.jsonl (optional)")
    ap.add_argument("--out", default=str(F.FACTS_OUT))
    ap.add_argument("--registry", default=None, help="default <work>/id_registry.json")
    ap.add_argument("--dup", type=float, default=0.85, help="similarity above which an auto fact repeats a seed fact")
    ap.add_argument("--no-stub", action="store_true", help="fail instead of building a stub when the seed file is missing")
    args = ap.parse_args(argv)
    work = Path(args.work)
    log = F.get_logger("merge", work)
    auto_p = Path(args.auto or work / "facts_auto.jsonl")
    human_p = Path(args.human or work / "facts_human.jsonl")

    if Path(args.seed).exists():
        seed = F.read_jsonl(args.seed)
        seed_src = str(args.seed)
    elif args.no_stub:
        log.error(f"no seed facts at {args.seed}")
        return 1
    else:
        seed = stub_seed(log)
        F.write_jsonl(work / "seed_facts.stub.jsonl", seed)
        seed_src = "stub"
    bad_seed = [(f.get("id"), F.fact_errors(f)) for f in seed if F.fact_errors(f)]
    if bad_seed:
        log.warning(f"{len(bad_seed)} seed facts violate the schema (copied anyway): {bad_seed[:3]}")
    seed_ids = {f["id"] for f in seed}
    auto = F.read_jsonl(auto_p) if auto_p.exists() else []
    if not auto_p.exists():
        log.warning(f"{auto_p} not found: output = seed facts only")
    human = F.read_jsonl(human_p) if human_p.exists() else []

    registry = F.IdRegistry(Path(args.registry or work / "id_registry.json"))
    registry.reserve(seed_ids)
    seed_groups = defaultdict(list)
    for f in seed:
        seed_groups[(f["crop"], F.group_of(f))].append(f)
    seed_first = {k for k, fs in seed_groups.items() if any(f["kind"] == "first" for f in fs)}

    kept, remap, drops = [], {}, Counter()
    dup_log = []
    for f in sorted(auto, key=lambda f: (f["crop"], F.group_of(f), f["order"], f["id"])):
        g = (f["crop"], F.group_of(f))
        nums = F.numbers_in(f["text"]["en"])
        dup = next((s for s in seed_groups.get(g, []) if F.numbers_in(s["text"]["en"]) == nums
                    and F.text_sim(s["text"]["en"], f["text"]["en"]) >= args.dup), None)
        if dup:
            drops["duplicate_of_seed"] += 1
            dup_log.append({"auto": f["id"], "seed": dup["id"], "en": f["text"]["en"], "seed_en": dup["text"]["en"]})
            continue
        f = dict(f)
        if f["kind"] == "first" and g in seed_first:
            f["kind"] = "action"
            drops["first_to_action"] += 1
        prefix = f"{f['crop']}.{F.group_of(f)}.{f['kind']}"
        need_new = f["id"] in seed_ids or not f["id"].startswith(prefix + ".")
        if need_new:
            new = registry.assign(F.fact_key("merge", f["source"]["quote"], f["crop"], F.group_of(f), f["kind"],
                                             f["text"]["en"]), prefix, f["text"]["en"])
            remap[f["id"]] = new
            f["id"] = new
        else:
            registry.used_now.add(f["id"])
        kept.append(f)
    if remap:
        F.write_json(work / "id_remap.json", remap)
        log.warning(f"{len(remap)} auto ids re-keyed (seed collision or kind change): see {work / 'id_remap.json'}")
    registry.save()

    by_id = {f["id"]: f for f in kept}
    n_human = 0
    for h in human:
        if F.fact_errors(h) or h.get("review") != "human":
            log.warning(f"skip invalid human fact {h.get('id')}: {F.fact_errors(h) or 'review must be human'}")
            continue
        if h["id"] in seed_ids:
            log.warning(f"human fact {h['id']} overrides a seed id: skipped (edit the seed via factlm/build_seed.py)")
            continue
        by_id[h["id"]] = h
        n_human += 1
    kept = list(by_id.values())
    # a machine fact that still fails the schema (or is too long) is left out and listed, instead of blocking the whole bank
    bad = [f for f in kept if F.fact_errors(f) or F.word_count(f["text"].get("en", "")) > F.MAX_WORDS]
    if bad:
        log.warning(f"{len(bad)} facts left out (schema / length): {[(f.get('id'), F.fact_errors(f)) for f in bad[:3]]}")
        F.write_jsonl(work / "rejects_merge.jsonl", [dict(f, _errors=F.fact_errors(f) or ["English text over 30 words"]) for f in bad])
        bad_ids = {id(f) for f in bad}; kept = [f for f in kept if id(f) not in bad_ids]

    groups = defaultdict(list)
    for f in kept:
        groups[(f["crop"], F.group_of(f))].append(f)
    for g, fs in groups.items():
        start = max((s["order"] for s in seed_groups.get(g, [])), default=-1) + 1
        for k, f in enumerate(sorted(fs, key=lambda f: (f["order"], f["id"]))):
            f["order"] = start + k
    out = seed + sorted(kept, key=lambda f: (f["crop"], F.group_of(f), f["order"]))

    errors = [(f.get("id"), F.fact_errors(f)) for f in out if F.fact_errors(f)]
    ids = [f["id"] for f in out]
    dups = [i for i, n in Counter(ids).items() if n > 1]
    if dups:
        errors.append(("duplicate ids", dups[:10]))
    ords = Counter((f["crop"], F.group_of(f), f["order"]) for f in out)
    clash = [k for k, n in ords.items() if n > 1]
    if clash:
        errors.append(("duplicate order inside a group", clash[:10]))
    long_en = [f["id"] for f in out if f["review"] != "seed" and F.word_count(f["text"]["en"]) > F.MAX_WORDS]
    if long_en:
        errors.append(("English text over 30 words", long_en[:10]))
    if errors:
        for e in errors[:20]:
            log.error(f"invalid: {e}")
        log.error(f"{len(errors)} problems: facts.jsonl NOT written")
        return 1
    F.write_jsonl(args.out, out)
    if dup_log:
        F.write_jsonl(work / "merge_duplicates.jsonl", dup_log)

    rep = {"seed_source": seed_src, "seed": len(seed), "auto_in": len(auto), "auto_kept": len(kept) - n_human,
           "human": n_human, "total": len(out), "dropped": dict(drops), "re_keyed": len(remap),
           "by_crop": dict(Counter(f["crop"] for f in out)), "by_topic": dict(Counter(f["topic"] for f in out)),
           "by_kind": dict(Counter(f["kind"] for f in out)), "by_review": dict(Counter(f["review"] for f in out)),
           "requires_confirmed": sum(f["requires_confirmed"] for f in out),
           "targets": len({f["target"] for f in out if f["target"]}),
           "by_crop_topic_kind": {f"{c}/{t}/{k}": n for (c, t, k), n in
                                  sorted(Counter((f["crop"], f["topic"], f["kind"]) for f in out).items())}}
    F.write_json(work / "merge_report.json", rep)
    crops = F.CROPS_ALL
    log.info(f"wrote {len(out)} facts -> {args.out} (seed {len(seed)}, auto {rep['auto_kept']}, human {n_human}; "
             f"dropped {dict(drops)})")
    table = Counter((f["topic"], f["crop"]) for f in out)
    head = f"{'topic':18s}" + "".join(f"{c:>10s}" for c in crops) + f"{'total':>8s}"
    lines = [head]
    for t in F.TOPICS:
        row = [table[(t, c)] for c in crops]
        if sum(row):
            lines.append(f"{t:18s}" + "".join(f"{n:>10d}" for n in row) + f"{sum(row):>8d}")
    lines.append(f"{'kind':18s}" + "  ".join(f"{k}={n}" for k, n in sorted(rep["by_kind"].items())))
    lines.append(f"{'review':18s}" + "  ".join(f"{k}={n}" for k, n in sorted(rep["by_review"].items())))
    log.info("counts per topic x crop:\n" + "\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())
