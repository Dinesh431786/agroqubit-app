"""Local farmer names for every disease / pest target in facts.jsonl that has no name yet (new pests from the fact
pipeline). The app shows and speaks the first name ("Stem borer." before the facts), and question generation uses all
of them. The teacher (Gemma 4 on the VM) gives 1-4 common names per language; checks: right script, short, no Latin
letters in hi/ta/kn. Names need native-speaker review like every other translation (review "auto").

Output: facts/target_names.json  {target: {"en": [...], "hi": [...], "ta": [...], "kn": [...], "review": "auto"}}
        and the same names merged into factlm/assets/disease_names.json (read by gen_questions.py).
Usage:  python3 facts/target_names.py --facts facts/facts.jsonl --work facts/work [teacher args]"""
import argparse, asyncio, json, re, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import factlib as F  # noqa: E402
from teacher import InvalidOutput, add_teacher_args, run_jobs, teacher_from_args  # noqa: E402

SCRIPT = {"hi": r"[ऀ-ॿ]", "ta": r"[஀-௿]", "kn": r"[ಀ-೿]"}
PROMPT = """TASK: target_names
You are an Indian agriculture extension expert. Give the names farmers commonly use for this {kind} of {crop}.
Target id: {tid}
What the verified facts say about it (English): {ctx}

Return JSON only: {{"en": [1-3 simple English names], "hi": [1-4 Hindi names in Devanagari], "ta": [1-4 Tamil names in Tamil script], "kn": [1-4 Kannada names in Kannada script]}}
Most common name first. Names only, at most 5 words each, no explanations, no Latin letters inside hi/ta/kn names."""


def clean(obj):
    out = {}
    for L in ["en", "hi", "ta", "kn"]:
        v = obj.get(L)
        if isinstance(v, str):
            v = [v]
        if not isinstance(v, list) or not v:
            raise InvalidOutput(f'"{L}" must be a non-empty list of names')
        names = []
        for n in v:
            n = re.sub(r"\s+", " ", str(n)).strip(" .,;:")
            if not n or len(n.split()) > 5:
                continue
            if L != "en" and (not re.search(SCRIPT[L], n) or re.search(r"[A-Za-z]", n)):
                continue
            if n not in names:
                names.append(n)
        if not names:
            raise InvalidOutput(f'no valid "{L}" name (wrong script or too long)')
        out[L] = names[:4]
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--facts", default=str(F.FACTS_DIR / "facts.jsonl"))
    ap.add_argument("--work", default=str(F.FACTS_DIR / "work"))
    ap.add_argument("--out", default=str(F.FACTS_DIR / "target_names.json"))
    ap.add_argument("--names", default=str(F.REPO_DIR / "factlm" / "assets" / "disease_names.json"))
    ap.add_argument("--extra-targets", default="/opt/v2data/meta.json", help="photo-model meta.json: its pest/disease labels also get names")
    add_teacher_args(ap)
    args = ap.parse_args(argv)
    log = F.get_logger("target_names", args.work)
    facts = F.read_jsonl(args.facts)
    known = F.load_json(args.names, {}) or {}
    have = F.load_json(args.out, {}) or {}
    todo = {}
    for f in facts:
        t = f.get("target")
        if not t or t in known or t in have:
            continue
        e = todo.setdefault(t, {"crop": f["crop"], "kind": "pest" if f.get("topic") == "pest" else "disease or problem", "ctx": []})
        if len(e["ctx"]) < 3:
            e["ctx"].append(f["text"]["en"])
    import os
    if args.extra_targets and os.path.exists(args.extra_targets):
        for lab, m in (F.load_json(args.extra_targets, {}) or {}).get("meta", {}).items():
            for t in dict.fromkeys([m.get("target")] + list(m.get("targets") or [])):
                if t and t not in known and t not in have and t not in todo:
                    todo[t] = {"crop": m.get("crop") or t.split("_")[0], "kind": "pest" if m.get("kind") == "pest" else "disease or problem",
                               "ctx": [f"photo class {lab} ({m.get('kind')})"]}
    log.info(f"{len(todo)} targets need names ({len(have)} already named, {len(known)} known app diseases)")

    async def run():
        T = teacher_from_args(args, args.work, log)
        async with T:
            await T.wait_ready(args.wait)

            def job(t, e):
                msgs = [{"role": "user", "content": PROMPT.format(kind=e["kind"], crop=e["crop"], tid=t, ctx=" | ".join(e["ctx"]))}]
                return lambda: T.chat_json(msgs, tag="target_names", validate=clean, temperature=0.1, max_tokens=400)
            keys = list(todo)
            res = await run_jobs([job(t, todo[t]) for t in keys], log=log, label="target names")
            T.log_summary("target names")
        return dict(zip(keys, res))

    if todo:
        for t, r in asyncio.run(run()).items():
            if isinstance(r, Exception):
                log.warning(f"{t}: no names ({str(r)[:200]}); the app falls back to the id")
                continue
            have[t] = dict(r, review="auto")
    F.write_json(args.out, have)
    merged = dict(known)
    for t, r in have.items():
        merged.setdefault(t, {L: r[L] for L in ["en", "hi", "ta", "kn"]})
    F.write_json(args.names, merged)
    log.info(f"wrote {len(have)} target names -> {args.out}; {len(merged)} names -> {args.names}")


if __name__ == "__main__":
    main()
