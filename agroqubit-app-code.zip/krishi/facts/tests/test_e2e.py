#!/usr/bin/env python3
"""End-to-end test of the fact pipeline on the fixtures (no internet, no GPU):

  local file server (fixtures: a 5-page PDF rendered from rice_ipm_fixture.txt + 3 HTML pages, one 404 with an HTML
  fallback, one dead URL)  ->  fetch_sources  ->  extract_facts  ->  extract again (ids stable, 100% cache)  ->
  translate_facts  ->  merge (real seed file read-only; and the stub)  ->  gen_questions  ->  factlm validators.
The mock teacher runs as an HTTP server with faults on (HTTP 500, slow reply > client timeout, truncated JSON,
JSON in prose, non-JSON, fabricated quote, wrong number, near-duplicate, dropped number in a translation, weak
back-translation, leaked / wrong-script / English-as-Hindi questions).

Usage: python3 krishi/facts/tests/test_e2e.py [--keep DIR] [--sample-out krishi/facts/tests/sample_output]
"""
import argparse
import functools
import json
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
from collections import Counter
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

FACTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(FACTS))
import factlib as F  # noqa: E402
import mock_teacher as M  # noqa: E402
import fetch_sources  # noqa: E402
import extract_facts  # noqa: E402
import translate_facts  # noqa: E402
import merge  # noqa: E402
import gen_questions  # noqa: E402

FIX = Path(__file__).resolve().parent / "fixtures"
CHECKS = []


def check(name, cond, detail=""):
    CHECKS.append((name, bool(cond), detail))
    print(("ok   " if cond else "FAIL ") + name + (f"  [{detail}]" if detail and not cond else ""))


def make_pdf(txt, pdf):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    pages, cur = [], None
    for line in txt.read_text(encoding="utf-8").splitlines():
        if line.startswith("#"):
            continue
        m = re.match(r"=== PAGE (\S+) ===", line)
        if m:
            cur = (m.group(1), [])
            pages.append(cur)
        elif cur is not None:
            cur[1].append(line)
    c = canvas.Canvas(str(pdf), pagesize=A4)
    W, H = A4
    for label, lines in pages:
        c.setFont("Helvetica", 8)
        c.drawString(40, H - 30, "Rice pest management fixture (test only)")
        y = H - 70
        for ln in lines:
            if re.match(r"^\d+(\.\d+)*\s", ln):
                y -= 16  # extra space before a heading -> separate text block
                c.setFont("Helvetica-Bold", 11)
            else:
                c.setFont("Helvetica", 10)
            for piece in textwrap.wrap(ln, 95) or [""]:
                c.drawString(50, y, piece)
                y -= 14
        if label != "cover":
            c.setFont("Helvetica", 9)
            c.drawCentredString(W / 2, 30, label)
        c.showPage()
    c.save()


class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass


def serve_dir(d):
    srv = ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Quiet, directory=str(d)))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}"


def sources_for(base):
    common = {"publisher": "Test fixture", "format": "html", "licence_note": "test fixture", "extract": True,
              "topics_covered": ["pest"], "year": 2026}
    return [
        dict(common, id="t_rice_pdf", crop="rice", title="Rice IPM fixture", url=f"{base}/rice_ipm.pdf", format="pdf",
             doc="Rice IPM fixture (test)", priority=1, region=None,
             select={"book_pages": [12, 14], "keywords": ["rice", "stem borer"], "min_hits": 1}),
        dict(common, id="t_tomato_html", crop="tomato", title="Tomato PoP fixture", url=f"{base}/tomato_pop_fixture.html",
             doc="Tomato PoP fixture (test)", priority=3, region="Tamil Nadu"),
        dict(common, id="t_chilli_fallback", crop="chilli", title="Chilli fixture", url=f"{base}/missing_chilli.pdf",
             format="pdf", doc="Chilli fixture (test)", priority=2, region=None,
             fallbacks=[{"url": f"{base}/chilli_fixture.html", "format": "html"}]),
        dict(common, id="t_groundnut_html", crop="groundnut", title="Groundnut fixture", url=f"{base}/groundnut_fixture.html",
             doc="Groundnut fixture (test)", priority=1, region=None),
        dict(common, id="t_dead", crop="rice", title="Dead link", url=f"{base}/dead.pdf", format="pdf", doc="dead", priority=9),
    ]


def run_validator(kind, *args):
    v = F.REPO_DIR / "factlm" / "facts_lib.py"
    if not v.exists():
        return None, "factlm/facts_lib.py not present"
    r = subprocess.run([sys.executable, str(v), kind, *args], capture_output=True, text=True, timeout=600)
    return r.returncode, (r.stdout + r.stderr).strip().splitlines()[-1:]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--keep", default="", help="run in this directory and keep it")
    ap.add_argument("--sample-out", default="", help="copy small samples of every output here")
    args = ap.parse_args(argv)
    t0 = time.time()
    tmp = Path(args.keep) if args.keep else Path(tempfile.mkdtemp(prefix="krishi_facts_e2e_"))
    if tmp.exists() and args.keep:
        shutil.rmtree(tmp)
    www, work, qdir = tmp / "www", tmp / "work", tmp / "questions"
    www.mkdir(parents=True)
    for p in FIX.glob("*.html"):
        shutil.copy(p, www / p.name)
    make_pdf(FIX / "rice_ipm_fixture.txt", www / "rice_ipm.pdf")
    fsrv, base = serve_dir(www)
    brain = M.MockBrain(faults=True, slow_s=1.6)
    msrv, url, _ = M.serve(brain)
    src_path = tmp / "sources_test.json"
    F.write_json(src_path, sources_for(base))
    T_ARGS = ["--teacher-url", url, "--timeout", "1.0", "--retries", "4", "--backoff", "0.05", "--wait", "20"]
    res = {"workdir": str(tmp)}

    # ---------------------------------------------------------------- 1. fetch
    rc = fetch_sources.main(["--sources", str(src_path), "--work", str(work)])
    pages = F.read_jsonl(work / "pages.jsonl")
    man = F.load_json(work / "fetch_manifest.json")
    by = Counter(p["source_id"] for p in pages)
    rice_pages = sorted(p["page"] for p in pages if p["source_id"] == "t_rice_pdf")
    check("fetch: exit 0 although one source is dead", rc == 0)
    check("fetch: book pages 12-14 -> PDF pages 3-5 (printed-number offset)", rice_pages == [3, 4, 5], rice_pages)
    check("fetch: 404 PDF fell back to the HTML page", man["t_chilli_fallback"].get("fallback") is True)
    check("fetch: dead source reported, others kept", man["t_dead"]["status"] == "failed" and len(by) == 4, dict(by))
    rice_lay = " ".join(p["text_layout"] for p in pages if p["source_id"] == "t_rice_pdf")
    qi = F.QuoteIndex([rice_lay])
    check("fetch: layout text keeps the line-break hyphenation, and the matcher still finds the joined quote",
          re.search(r"trans-\s*\n\s*planting", rice_lay) is not None
          and qi.match("Clip the tips of the seedlings before transplanting to remove the egg masses")[0] is not None)
    check("fetch: running page header and page numbers stripped from PDF pages",
          not any("pest management fixture" in p["text"] or re.search(r"^\s*1[1-4]\s*$", p["text"], re.M)
                  for p in pages if p["source_id"] == "t_rice_pdf"))
    html_txt = " ".join(p["text"] for p in pages if p["source_id"] == "t_tomato_html")
    check("fetch: HTML boilerplate (nav/footer/script) removed", "Visitor count" not in html_txt and "tracking" not in html_txt
          and "Login" not in html_txt)
    res["fetch"] = {"pages": len(pages), "by_source": dict(by), "rice_pdf_pages": rice_pages}

    # ---------------------------------------------------------------- 2. extract (+ rerun)
    ex_args = ["--work", str(work), "--sources", str(src_path), "--seed", str(F.SEED_FACTS)] + T_ARGS
    rc = extract_facts.main(ex_args)
    rep = F.load_json(work / "extract_report.json")
    facts = F.read_jsonl(work / "facts_en.jsonl")
    tstat = F.load_json(work / "stats" / "teacher_extract.json")["total"]
    check("extract: exit 0", rc == 0)
    for reason in ("quote_not_verbatim", "number_not_in_quote", "banned_pesticide", "restricted_pesticide", "duplicate"):
        check(f"extract: rejects '{reason}'", rep["rejected"].get(reason, 0) > 0, rep["rejected"])
    alltext = " ".join(f["text"]["en"] + " " + f["source"]["quote"] for f in facts).lower()
    for chem in ("phorate", "monocrotophos", "malathion", "carbofuran", "oxyfluorfen"):
        check(f"extract: no '{chem}' in kept facts", chem not in alltext)
    errs = [(f["id"], F.fact_errors(dict(f, text={L: f["text"]["en"] for L in F.LANGS}))) for f in facts]
    check("extract: all facts valid (schema, ids)", all(not e for _, e in errs), [e for e in errs if e[1]][:2])
    check("extract: every dose has requires_confirmed", all(f["requires_confirmed"] for f in facts if f["kind"] == "dose"))
    doses = {(f["crop"], f["target"]) for f in facts if f["kind"] == "dose"}
    want = {("rice", "rice_stem_borer"), ("rice", "rice_brown_planthopper"), ("rice", None), ("tomato", "tomato_early_blight"),
            ("groundnut", "groundnut_early_leaf_spot"), ("groundnut", "groundnut_late_leaf_spot"), ("chilli", "chilli_thrips")}
    check("extract: expected chemical doses kept (cartap, buprofezin, pretilachlor, mancozeb, hexaconazole x2, fipronil)",
          want <= doses, sorted(map(str, doses)))
    tn = [f["text"]["en"] for f in facts if f["crop"] == "tomato" and f["topic"] in ("variety", "season_sowing", "nutrient")]
    check("extract: Tamil Nadu prefix on state-specific advice", tn and all(t.startswith("In Tamil Nadu") for t in tn), tn[:3])
    check("extract: region prefix keeps proper nouns capitalised", any(t.startswith("In Tamil Nadu, Arka Rakshak") for t in tn), tn)
    check("extract: no HTML table separator '|' left in English text", not any("|" in f["text"]["en"] for f in facts))
    firsts = Counter((f["crop"], f["target"]) for f in facts if f["kind"] == "first")
    seed_first = {f["target"] for f in F.read_jsonl(F.SEED_FACTS) if f["kind"] == "first"} if F.SEED_FACTS.exists() else set()
    check("extract: at most one 'first' per target, none where the seed has one",
          all(n == 1 for n in firsts.values()) and not any(t in seed_first for _, t in firsts), dict(firsts))
    rice_p = {f["source"]["page"] for f in facts if f["source"]["doc"].startswith("Rice IPM")}
    check("extract: rice facts cite PDF pages 3-5 only", rice_p and rice_p <= {3, 4, 5}, rice_p)
    check("extract: HTML facts have page null", all(f["source"]["page"] is None for f in facts if "fixture (test)" in f["source"]["doc"]
                                                       and not f["source"]["doc"].startswith("Rice")))
    check("extract: survived HTTP 500 + timeout (retries), truncated/prose/non-JSON replies (re-asks, repair)",
          tstat.get("retries", 0) >= 2 and tstat.get("reasks", 0) >= 1 and tstat.get("repaired", 0) >= 1, tstat)
    res["extract"] = {k: rep[k] for k in ("chunks", "raw_facts", "kept_facts", "pass_rate", "rejected", "by_kind", "quote_match",
                                          "new_targets", "requires_confirmed")}
    res["extract"]["teacher"] = {k: tstat.get(k) for k in ("calls", "requests", "retries", "reasks", "repaired", "salvaged",
                                                            "cache_hits", "prompt_tokens", "completion_tokens")}
    ids1 = [f["id"] for f in facts]
    shutil.copy(work / "facts_en.jsonl", tmp / "facts_en.run1.jsonl")
    rc = extract_facts.main(ex_args)
    facts2 = F.read_jsonl(work / "facts_en.jsonl")
    t2 = F.load_json(work / "stats" / "teacher_extract.json")["total"]
    check("extract rerun: identical ids and texts (stable)", ids1 == [f["id"] for f in facts2] and facts == facts2)
    check("extract rerun: 100% teacher cache hits, 0 requests", t2.get("cache_hits") == t2.get("calls") and not t2.get("requests"), t2)

    # ---------------------------------------------------------------- 3. translate
    rc = translate_facts.main(["--work", str(work)] + T_ARGS)
    trep = F.load_json(work / "translate_report.json")
    auto = F.read_jsonl(work / "facts_auto.jsonl")
    check("translate: exit 0", rc == 0)
    check("translate: all facts translated", len(auto) == len(facts), f"{len(auto)}/{len(facts)} {trep['rejected']}")
    check("translate: a dropped number was caught and fixed by re-ask", trep["fixed_items"] >= 1, trep)
    check("translate: weak back-translation flagged", any(k.startswith("low_bt") for k in trep["flags"]), trep["flags"])
    ok_nums = all(F.numbers_in(f["text"]["en"], words=False) == F.numbers_in(f["text"][L], words=False)
                  for f in auto for L in F.INDIC)
    check("translate: numbers identical in all 4 languages", ok_nums)
    check("translate: review_queue.csv written", (work / "review_queue.csv").exists())
    res["translate"] = {k: trep[k] for k in ("facts_in", "facts_out", "rejected", "fixed_items", "bt_mean", "bt_below_threshold")}

    # ---------------------------------------------------------------- 4. merge
    out1 = tmp / "facts.jsonl"
    rc = merge.main(["--work", str(work), "--out", str(out1)])
    mrep = F.load_json(work / "merge_report.json")
    merged = F.read_jsonl(out1)
    check("merge: exit 0", rc == 0)
    seed = F.read_jsonl(F.SEED_FACTS) if F.SEED_FACTS.exists() else []
    check("merge: seed facts copied unchanged", all(any(m == s for m in merged) for s in seed) if seed else True)
    check("merge: unique ids, valid schema", len({f["id"] for f in merged}) == len(merged) and not any(F.fact_errors(f) for f in merged))
    rc2, msg = run_validator("validate-facts", str(out1))
    check("merge: factlm validate-facts passes", rc2 in (0, None), msg)
    rc = merge.main(["--work", str(work), "--out", str(tmp / "facts.again.jsonl")])
    check("merge: rerun gives the same file", (tmp / "facts.again.jsonl").read_text() == out1.read_text())
    rc = merge.main(["--work", str(work), "--out", str(tmp / "facts.stub.jsonl"), "--seed", str(tmp / "no_seed.jsonl")])
    stub = F.read_jsonl(tmp / "facts.stub.jsonl")
    check("merge: stub seed from brain/advice.json when seed_facts.jsonl is missing",
          rc == 0 and (work / "seed_facts.stub.jsonl").exists() and len(stub) > len(auto))
    res["merge"] = {k: mrep[k] for k in ("seed_source", "seed", "auto_kept", "total", "dropped", "re_keyed", "by_crop", "by_kind",
                                        "by_review")}

    # ---------------------------------------------------------------- 5. questions
    rc = gen_questions.main(["--facts", str(out1), "--work", str(work), "--out-dir", str(qdir), "--target-total", "500",
                             "--val-total", "60", "--zs-total", "60", "--holdout", "0.2"] + T_ARGS)
    qrep = F.load_json(qdir / "questions_report.json")
    tr = F.read_jsonl(qdir / "train.jsonl")
    va = F.read_jsonl(qdir / "val.jsonl")
    zs = F.read_jsonl(qdir / "zeroshot.jsonl")
    hold = set(F.load_json(qdir / "holdout_facts.json")["ids"])
    check("questions: exit 0", rc == 0)
    ys = Counter(r["y"][0] if r["y"][0] in F.CONTROLS else "facts" for r in tr)
    for tok in ("facts", F.CONFIRM, F.WHICH_CROP, F.ASK, F.NOT_SURE):
        check(f"questions: train has {tok} answers", ys.get(tok, 0) > 0, dict(ys))
    for why in ("leak_copied", "wrong_script", "roman_is_english"):
        check(f"questions: teacher output rejected for '{why}'", qrep["rejects"].get(why, 0) > 0, qrep["rejects"])
    check("questions: no held-out fact in train", not any(x in hold for r in tr for x in r["y"]))
    check("questions: zero-shot rows use held-out facts", zs and all(any(x in hold for x in r["y"]) for r in zs if r["y"][0] not in F.CONTROLS))
    langs = Counter(r["lang"] for r in tr)
    check("questions: languages balanced (each 15-35% of train)", all(0.15 <= langs[L] / len(tr) <= 0.35 for L in F.LANGS), dict(langs))
    check("questions: val and train share no question text",
          not ({gen_questions.norm_q(r["q"]) for r in va} & {gen_questions.norm_q(r["q"]) for r in tr}))
    check("questions: fact answers end with <END>", all(r["y"][-1] == F.END for r in tr + va + zs if r["y"][0] not in F.CONTROLS))
    check("questions: no meta.intent (rows are never relabelled by the seed oracle)",
          not any((r.get("meta") or {}).get("intent") for r in tr + va + zs))
    for name, path in (("train", qdir / "train.jsonl"), ("val", qdir / "val.jsonl"), ("zeroshot", qdir / "zeroshot.jsonl")):
        rc2, msg = run_validator("validate-questions", "--facts", str(out1), str(path))
        check(f"questions: factlm validate-questions passes on {name}", rc2 in (0, None), msg)
    res["questions"] = {"train": len(tr), "val": len(va), "zeroshot": len(zs), "train_by_y": dict(ys), "train_by_lang": dict(langs),
                        "train_by_script": qrep["splits"]["train"]["by_script"], "rejects": qrep["rejects"],
                        "holdout_facts": len(hold)}

    tot = Counter()
    for p in (work / "stats").glob("teacher_*.json"):
        for k, v in F.load_json(p)["total"].items():
            tot[k] += v
    check("all stages: every injected fault type occurred and every stage still finished",
          set(brain.faults_done) == {"http500", "slow", "truncated", "prose_json", "not_json"}, dict(brain.faults_done))
    res["teacher_all_stages"] = {k: tot[k] for k in ("calls", "requests", "cache_hits", "retries", "reasks", "repaired",
                                                     "salvaged", "invalid", "failures", "prompt_tokens", "completion_tokens")}
    res["mock_faults_injected"] = dict(brain.faults_done)
    res["mock_calls"] = dict(brain.calls)
    n_ok = sum(1 for _, ok, _ in CHECKS if ok)
    res["checks"] = {"total": len(CHECKS), "passed": n_ok, "failed": [n for n, ok, _ in CHECKS if not ok]}
    res["seconds"] = round(time.time() - t0, 1)
    F.write_json(Path(__file__).resolve().parent / "e2e_results.json", res)
    if args.sample_out:
        so = Path(args.sample_out)
        so.mkdir(parents=True, exist_ok=True)
        for old in so.glob("MOCK_*.jsonl"):
            old.unlink()
        for src, n, name in ((work / "pages.jsonl", 2, "pages"), (work / "facts_en.jsonl", 6, "facts_en"),
                             (work / "facts_auto.jsonl", 6, "facts_auto"), (work / "rejects_extract.jsonl", 8, "rejects_extract"),
                             (out1, 10, "facts_merged_auto_rows"), (qdir / "train.jsonl", 40, "questions_train"),
                             (qdir / "val.jsonl", 10, "questions_val"), (qdir / "zeroshot.jsonl", 10, "questions_zeroshot")):
            rows = F.read_jsonl(src)
            rows = [r for r in rows if r.get("review") == "auto"][:n] if src == out1 else rows[:n]
            F.write_jsonl(so / f"MOCK_{name}.jsonl", rows)
        (so / "README.txt").write_text("Outputs of tests/test_e2e.py with the MOCK teacher on hand-written FIXTURES. "
                                       "Not real facts, not agronomic advice. Formats only.\n", encoding="utf-8")
    msrv.shutdown()
    fsrv.shutdown()
    print(json.dumps({"e2e_checks": res["checks"], "seconds": res["seconds"], "workdir": str(tmp)}, indent=1))
    if not args.keep and not res["checks"]["failed"]:
        shutil.rmtree(tmp, ignore_errors=True)
    return 0 if not res["checks"]["failed"] else 1


if __name__ == "__main__":
    sys.exit(main())
