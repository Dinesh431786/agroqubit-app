Outputs of tests/test_e2e.py with the MOCK teacher on hand-written FIXTURES. Not real facts, not agronomic advice. Formats only.
