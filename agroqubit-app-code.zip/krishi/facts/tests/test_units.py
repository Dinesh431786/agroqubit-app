#!/usr/bin/env python3
"""Unit tests for the fact pipeline helpers (no network, no GPU). Run: python3 krishi/facts/tests/test_units.py
(pytest also works: every test is a plain test_* function)."""
import asyncio
import json
import random
import sys
import tempfile
import time
import traceback
from pathlib import Path

FACTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(FACTS))
import factlib as F  # noqa: E402
import teacher as TCH  # noqa: E402
import mock_teacher as M  # noqa: E402
import fetch_sources as FS  # noqa: E402
import extract_facts as EX  # noqa: E402
import translate_facts as TR  # noqa: E402
import gen_questions as GQ  # noqa: E402


# ------------------------------------------------------------------------------------------------ text / quotes
def test_quote_matching():
    page = ("Clip the tips of the seedlings before trans-\nplanting to remove the egg masses.\n"
            "Install  pheromone traps @ 8 per hectare\nfor monitoring.   Thiamethoxam 25 WG     80 g   200 l")
    qi = F.QuoteIndex([page])
    assert qi.match("Clip the tips of the seedlings before transplanting to remove the egg masses.")[0] in ("exact", "loose")
    assert qi.match("install pheromone traps @8 per hectare for monitoring")[0] == "loose"
    assert qi.match("Thiamethoxam 25 WG 80 g 200 l")[0] in ("exact", "loose")
    assert qi.match("Clip the tips of the seedlings ... pheromone traps @ 8 per hectare")[0] == "elided"
    assert qi.match("Neem oil must be sprayed every single day on every crop.")[0] is None
    assert qi.match("traps @ 9 per hectare")[0] is None  # a changed number is not verbatim


def test_numbers():
    assert F.numbers_in("Release 50,000 per ha; 1,00,000 later") == {"50000", "100000"}
    assert F.missing_numbers("Spray twice at 15 day interval with 1,500 ml", "Two sprays at 15-day interval @ 1500 ml") == []
    assert F.missing_numbers("Apply 25 t/ha FYM", "Apply FYM @ 12.5 t/ha") == ["25"]
    assert F.missing_numbers("Use 0.5 kg", "use 1/2 kg") == []
    assert F.numbers_in("10,20,30 DAT", quote_side=True) >= {"10", "20", "30"}
    assert F.numbers_in("२५ किलो") == {"25"}


def test_detect_script_matches_factlm():
    samples = [("धान में खाद कितना", "hi"), ("dhan me khad kitna", "hi"), ("टमाटर में fertilizer कितना डालें", "hi"),
               ("KVK से पूछिए", "hi"), ("தக்காளி leaf curl க்கு", "ta"), ("ಭತ್ತ ml ಹಾಕಿ", "kn"), ("what dose", "en")]
    try:
        sys.path.insert(0, str(F.REPO_DIR / "factlm"))
        import facts_lib as FL
    except Exception:
        FL = None
    for s, L in samples:
        if FL:
            assert F.detect_script(s, L) == FL.detect_script(s, L), s


# ------------------------------------------------------------------------------------------------ policy / targets
def test_pesticide_policy():
    P = F.PesticidePolicy()
    S = F.PesticidePolicy(strict=True)
    names = lambda v: [x["name"] for x in v]  # noqa: E731
    assert names(P.violations("Apply phorate 10 G @ 10 kg/ha", "rice")) == ["phorate"]
    assert names(P.violations("Spray Nuvacron 36 SL", "groundnut")) == ["monocrotophos"]
    assert P.violations("Apply carbofuran 3% CG @ 33 kg/ha", "rice") == []
    assert names(P.violations("Apply carbofuran 3G @ 33 kg/ha", "rice")) == ["carbofuran"]
    assert names(P.violations("Spray dimethoate 30 EC", "tomato")) == ["dimethoate"]
    assert P.violations("Spray dimethoate 30 EC", "groundnut") == [] and S.violations("Spray dimethoate 30 EC", "groundnut")
    assert names(P.violations("oxyfluorfen pre-emergence", "groundnut")) == ["oxyfluorfen"]
    assert P.violations("oxyfluorfen pre-emergence", "chilli") == []
    assert P.violations("Spray cypermethrin 25 EC", "tomato") == []
    assert names(P.violations("cypermethrin 3% smoke generator", "general")) == ["cypermethrin"]
    assert names(P.violations("Spray malathion 50 EC", "general")) == ["malathion"]  # general = any of our crops
    assert P.violations("Spray mancozeb 75 WP @ 2 g/l", "tomato") == []
    assert P.violations("Use Trichoderma viride 4 g/kg seed", "chilli") == []


def test_targets():
    T = F.Targets()
    assert T.normalize("Yellow stem borer", "rice") == (["rice_stem_borer"], "alias")
    assert T.normalize("BPH", "rice")[0] == ["rice_brown_planthopper"]
    assert T.normalize("Tikka disease", "groundnut")[0] == ["groundnut_early_leaf_spot", "groundnut_late_leaf_spot"]
    assert T.normalize("ToLCV", "tomato")[0] == ["tomato_leaf_curl"]
    assert T.normalize("sucking pests", "chilli")[0] == []
    assert T.normalize("rice blast", "tomato")[1].startswith("other_crop")
    assert T.normalize("Root knot nematodes", "tomato")[0] == ["tomato_root_knot_nematode"]
    assert T.normalize("new weird borer", "chilli")[0] == ["chilli_new_weird_borer"]
    for t in ["rice_blast", "tomato_leaf_mold", "rice_false_smut", "groundnut_rust"]:
        assert t in T.app_ids


def test_id_registry_stable():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "reg.json"
        R = F.IdRegistry(p)
        R.reserve(["rice.rice_stem_borer.action.1"])
        a = R.assign("k1", "rice.rice_stem_borer.action", "Collect and destroy egg masses.")
        b = R.assign("k2", "rice.rice_stem_borer.action", "Install pheromone traps @ 8 per hectare.")
        assert a == "rice.rice_stem_borer.action.2" and b == "rice.rice_stem_borer.action.3"
        R.save()
        R2 = F.IdRegistry(p)
        R2.reserve(["rice.rice_stem_borer.action.1"])
        assert R2.assign("k2", "rice.rice_stem_borer.action", "Install pheromone traps @ 8 per hectare.") == b
        # reworded fact (new key) reuses the old id through the fuzzy match
        assert R2.assign("k1-new", "rice.rice_stem_borer.action", "Collect and destroy the egg masses.") == a
        assert R2.assign("k3", "rice.rice_stem_borer.action", "Something else entirely.") == "rice.rice_stem_borer.action.4"


# ------------------------------------------------------------------------------------------------ teacher JSON
def test_json_repair():
    P = TCH.parse_reply
    assert P('{"a": 1}')[0][0] == {"a": 1}
    assert P('Sure!\n```json\n{"a": [1, 2,],}\n```\nbye')[0][0] == {"a": [1, 2]}
    assert P("<think>maybe {x}</think>{\"facts\": []}")[0][0] == {"facts": []}
    assert P("{'a': True, 'b': None}")[0][0] == {"a": True, "b": None}
    got = P('{"facts": [{"en": "a"}, {"en": "b"}, {"en": "c')
    assert got and got[-1][1] == "salvaged" and got[-1][0] == {"facts": [{"en": "a"}, {"en": "b"}]}
    assert P("I cannot help.") == []


def test_teacher_stub_retry_reask_cache():
    brain = M.MockBrain(faults=False)
    calls = {"n": 0}
    base = M.stub_transport(brain)

    async def flaky(body):  # 500, then timeout, then an unparseable reply, then fine
        calls["n"] += 1
        if calls["n"] == 1:
            return 500, {"error": "x"}
        if calls["n"] == 2:
            await asyncio.sleep(0.3)
        if calls["n"] == 3:
            return 200, brain._wrap("no json here", body)
        return await base(body)

    async def go(cache_dir):
        log = F.get_logger("unit_teacher")
        async with TCH.Teacher("http://stub/v1", transport=flaky, cache_dir=cache_dir, timeout=0.2, backoff=0.01,
                               log=log) as T:
            await T.wait_ready()
            msgs = [{"role": "user", "content": "TASK: ping"}]
            r1 = await T.chat_json(msgs, tag="t", validate=lambda o: o if o.get("ok") else (_ for _ in ()).throw(TCH.InvalidOutput("no ok")))
            r2 = await T.chat_json(msgs, tag="t")
            return r1, r2, T.summary()

    with tempfile.TemporaryDirectory() as d:
        r1, r2, s = asyncio.run(go(d))
        assert r1["ok"] and r2 == r1
        t = s["tags"]["t"]
        assert t["retries"] == 2 and t["reasks"] == 1 and t["cache_hits"] == 1, t


# ------------------------------------------------------------------------------------------------ stages
def test_fetch_helpers():
    pages = ["Cover\n\nno number", "Header text\nbody\n\n                 11", "Header\nbody\n 12 ", "x\ny\n- 13 -", "a\nb\n14"]
    assert [FS.printed_number(p) for p in pages] == [None, 11, 12, 13, 14]
    off, info = FS.detect_offset(pages)
    assert off == -9, info
    parts = FS.html_parts(b"<html><body><nav>menu</nav><main><p>Hello farmer.</p><table><tr><td>A</td><td>B</td></tr></table>"
                          b"</main><footer>foot</footer></body></html>")
    assert parts == ["Hello farmer.\n\nA | B"], parts


def test_running_lines():
    hdr = "AESA based IPM - Tomato"
    words = ["thrips", "aphids", "mites", "whitefly", "borer", "wilt"]
    pt = [f"{hdr}\nBody text about {w} on this page.\nMore text on {w} control.\n{i + 10}" for i, w in enumerate(words)]
    t, lay, running = FS.strip_running_lines(pt, list(pt))
    assert running and all(hdr not in x and str(i + 10) not in x for i, x in enumerate(t)), (running, t[:2])
    assert all("Body text" in x for x in t)


def test_region_prefix_case():
    src = {"id": "s", "crop": "tomato", "region": "Tamil Nadu", "priority": 3}
    assert EX.region_prefix(src) == "In Tamil Nadu"
    assert EX.clean_en("Season | December to January") == "Season: December to January."


def test_dedupe_keeps_different_chemicals():
    base = {"crop": "tomato", "topic": "disease", "target": "tomato_early_blight", "kind": "dose", "requires_confirmed": True,
            "priority": 1, "source_id": "s", "chunk": "s#1", "quote": "q", "flags": []}
    a = dict(base, en="Spray mancozeb 75 WP @ 2 g per litre of water.", chemicals=["mancozeb"], pos=0)
    b = dict(base, en="Spray zineb 75 WP @ 2 g per litre of water.", chemicals=["zineb"], pos=1)
    c = dict(base, en="Spray mancozeb 75 WP at 2 g per litre of water.", chemicals=["mancozeb"], pos=2)
    kept, dropped = EX.dedupe([a, b, c], 0.85, {"s": 0})
    assert [k["en"] for k in kept] == [a["en"], b["en"]] and len(dropped) == 1
    assert EX.table_text("  Stage      Pest        Practice\n  Nursery    Thrips      Nylon net") == \
        "Stage | Pest | Practice\nNursery | Thrips | Nylon net"


def test_heading_and_junk():
    assert EX.heading_level("3.2 Yellow stem borer") == 2
    assert EX.heading_level("NUTRIENT MANAGEMENT") == 1
    assert EX.heading_level("Apply 12.5 tonnes of farmyard manure per hectare before the last ploughing.") == 0
    toc = "\n".join(f"Chapter {i} ........ {i * 10}" for i in range(1, 12)) + "\n" + "x" * 200
    assert EX.junk_chunk(toc) == "table_of_contents"


def test_keep_terms_and_translation_checks():
    k = TR.keep_terms("Spray thiamethoxam 25 WG @ 80 g in 200 l of water per acre; grow Arka Rakshak or CO 51; ask KVK.")
    low = [x.lower() for x in k]
    assert "thiamethoxam" in low and "25 wg" in low and "arka rakshak" in low and "co 51" in low and "kvk" in low, k
    en = "Spray mancozeb 75 WP @ 2 g per litre of water."
    keep = TR.keep_terms(en)
    good = "mancozeb 75 WP हर 1 लीटर पानी में 2 ग्राम मिलाकर छिड़काव कीजिए।"
    assert TR.check_translation(en, keep, "hi", good) == [] or "numbers" in " ".join(TR.check_translation(en, keep, "hi", good))
    assert any("numbers" in e for e in TR.check_translation(en, keep, "hi", "mancozeb 75 WP पानी में छिड़काव कीजिए।"))
    assert any("English letters" in e for e in TR.check_translation(en, keep, "ta", "மான்கோசெப் 75 WP 2 கிராம் தெளிங்க"))
    assert any("script" in e for e in TR.check_translation(en, keep, "kn", "mancozeb 75 WP 2 grams spray maadi in water"))
    assert TR.check_translation(en, keep, "kn", "mancozeb 75 WP ಒಂದು ಲೀಟರ್ ನೀರಿಗೆ 2 ಗ್ರಾಂ ಸಿಂಪಡಿಸ್ರಿ.") == []


def test_question_checks_and_derivation():
    T = F.Targets()
    lex = GQ.Lex(T)
    unit = {"uid": "u", "type": "dose", "crop": "rice", "target": "rice_stem_borer", "topic": "pest", "req": True,
            "facts": [{"id": "rice.rice_stem_borer.dose.1", "crop": "rice", "target": "rice_stem_borer", "requires_confirmed": True,
                       "text": {"en": "Spray cartap hydrochloride 50 SP @ 1 kg per hectare when the borer crosses the threshold.",
                                "hi": "x", "ta": "x", "kn": "x"}}],
            "y": ["rice.rice_stem_borer.dose.1", "<END>"]}
    assert GQ.check_q({"q": "Spray cartap hydrochloride 50 SP @ 1 kg per hectare when the borer crosses"}, "en", unit) is not None
    assert GQ.check_q({"q": "is 1 kg enough for the borer"}, "en", unit) == "leak_number"
    assert GQ.check_q({"q": "is cartap 50 SP good for borer"}, "en", unit) is None  # 50 is part of a name
    assert GQ.check_q({"q": "నా పంట ఆకులు పసుపు"}, "kn") == "wrong_script"
    assert GQ.check_q({"q": "what is the best medicine for my crop please tell"}, "hi") == "roman_is_english"
    assert GQ.check_q({"q": "dhan me tana chhedak ki dawa kitni dalein"}, "hi", unit) is None
    fbid = {f["id"]: dict(f, crop="rice") for f in unit["facts"]}
    rng = random.Random(1)
    for names_t in (True, False):
        rows = GQ.derive({"q": "tana chhedak dawa kitna", "names_crop": False, "names_target": names_t}, unit, lex, rng,
                         {"rice": ["rice_stem_borer", "rice_blast"]})
        ys = [y for _, y, _ in rows]
        assert ["<CONFIRM>"] in ys and unit["y"] in ys
        for ctx, y, tag in rows:
            row = {"q": "x", "lang": "hi", "script": "roman", "ctx": ctx, "y": y, "src": tag}
            assert GQ.constraint_errors(row, fbid) == [], (ctx, y)


TESTS = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]


def main():
    t0 = time.time()
    ok, bad = 0, []
    for t in TESTS:
        try:
            t()
            ok += 1
            print(f"PASS {t.__name__}")
        except Exception:
            bad.append(t.__name__)
            print(f"FAIL {t.__name__}\n{traceback.format_exc()}")
    print(json.dumps({"unit_tests": len(TESTS), "passed": ok, "failed": bad, "seconds": round(time.time() - t0, 1)}))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
