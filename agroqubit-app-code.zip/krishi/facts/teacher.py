#!/usr/bin/env python3
"""teacher.py: async client for the teacher LLM behind an OpenAI-compatible chat API (llama.cpp `llama-server`).

- concurrency limit (default 8 = `llama-server --parallel 8`); the semaphore is held only during a request
- retries with exponential backoff + jitter on timeouts, connection errors, 408/429/5xx (503 = model still loading)
- strict JSON: `response_format` json_object (or a JSON schema, llama.cpp grammar), local repair (code fences,
  reasoning blocks, trailing commas, python literals, truncated arrays), then a re-ask with the exact error
- disk cache keyed by a SHA-256 of the whole request (+ model id), so every stage can be killed and resumed:
  finished prompts are never sent twice
- token accounting per tag (prompt/completion tokens, cache hits, retries, re-asks, llama.cpp timings)

CLI (on the GPU VM, after starting llama-server):
  python3 krishi/facts/teacher.py ping                 # health, model id, per-slot context, one JSON reply
  python3 krishi/facts/teacher.py bench --n 16         # aggregate generation tokens/s with parallel slots
"""
from __future__ import annotations

import argparse
import ast
import asyncio
import hashlib
import json
import os
import random
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import factlib as F  # noqa: E402

DEFAULT_URL = os.environ.get("TEACHER_URL", "http://127.0.0.1:8080/v1")
DEFAULT_MODEL = os.environ.get("TEACHER_MODEL") or None
CACHE_VERSION = "teacher-cache-v1"
REASK = ("Your previous reply could not be used: {err}\n"
         "Reply again with ONLY one JSON object in exactly the requested format. No explanation, no markdown.")


class TeacherError(RuntimeError):
    pass


class TeacherUnavailable(TeacherError):
    pass


class InvalidOutput(ValueError):
    """Raised by validators; the message is sent back to the teacher in the re-ask."""


# ------------------------------------------------------------------------------------------------ JSON repair
_FENCE = re.compile(r"```(?:json|JSON)?")
_REASONING = [re.compile(r"(?s)<think>.*?</think>"), re.compile(r"(?s)<thinking>.*?</thinking>"),
              re.compile(r"(?s)<\|channel\|>analysis.*?<\|end\|>"), re.compile(r"(?s)<unused\d+>.*?<unused\d+>")]


def strip_reasoning(text):
    t = text or ""
    for rx in _REASONING:
        t = rx.sub("", t)
    if "</think>" in t:
        t = t.split("</think>")[-1]
    return t


def _spans(text):
    """Top-level balanced {...}/[...] spans (string-aware once inside JSON) and the unclosed tail, if any."""
    out, stack, start, in_str, esc = [], [], None, False, False
    pairs = {"{": "}", "[": "]"}
    for i, ch in enumerate(text):
        if stack:
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch in pairs:
                stack.append(pairs[ch])
            elif ch in "}]":
                if ch == stack[-1]:
                    stack.pop()
                    if not stack:
                        out.append(text[start:i + 1])
                        start = None
                else:
                    stack, start, in_str = [], None, False
        elif ch in pairs:
            stack, start, in_str, esc = [pairs[ch]], i, False, False
    tail = text[start:] if (stack and start is not None) else None
    return out, tail


def loads_lenient(s):
    try:
        return json.loads(s)
    except Exception:
        pass
    t = re.sub(r",\s*([}\]])", r"\1", s).replace("“", '"').replace("”", '"')
    try:
        return json.loads(t)
    except Exception:
        pass
    try:  # python-style literal: single quotes, True/False/None
        t2 = re.sub(r"\bnull\b", "None", re.sub(r"\bfalse\b", "False", re.sub(r"\btrue\b", "True", t)))
        v = ast.literal_eval(t2)
        if isinstance(v, (dict, list)):
            return json.loads(json.dumps(v))
    except Exception:
        pass
    raise ValueError("not valid JSON")


def salvage(tail):
    """Close a truncated JSON value after its last complete element:
    '{"facts":[{..},{..},{"en":"ab'  ->  {"facts":[{..},{..}]}"""
    stack, in_str, esc, cuts = [], False, False, []
    pairs = {"{": "}", "[": "]"}
    for i, ch in enumerate(tail):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch in pairs:
            stack.append(pairs[ch])
        elif ch in "}]":
            if not stack or ch != stack[-1]:
                break
            stack.pop()
            if stack:
                cuts.append((i + 1, "".join(reversed(stack))))
        elif ch == "," and stack:
            cuts.append((i, "".join(reversed(stack))))
    for pos, closers in reversed(cuts[-300:]):
        cand = tail[:pos].rstrip().rstrip(",") + closers
        try:
            return json.loads(cand)
        except Exception:
            continue
    return None


def parse_reply(text):
    """All JSON readings of a reply, best first: [(obj, how)], how in clean/extracted/salvaged."""
    t = _FENCE.sub("", strip_reasoning(text)).strip()
    out = []
    try:
        out.append((json.loads(t), "clean"))
        return out
    except Exception:
        pass
    spans, tail = _spans(t)
    for s in reversed(spans):  # the answer usually comes last (after any reasoning)
        try:
            out.append((loads_lenient(s), "extracted"))
        except ValueError:
            pass
    if tail:
        obj = salvage(tail)
        if obj is not None:
            out.append((obj, "salvaged"))
    return out


# ------------------------------------------------------------------------------------------------ client
class Teacher:
    def __init__(self, url=DEFAULT_URL, model=DEFAULT_MODEL, *, concurrency=8, timeout=600.0, connect_timeout=20.0,
                 max_retries=6, backoff=2.0, cache_dir=None, cache_ns=None, json_mode="object", extra_body=None,
                 log=None, transport=None, max_tokens_cap=8192):
        self.url = url.rstrip("/")
        self.root = re.sub(r"/v1$", "", self.url)
        self.model = model
        self.concurrency = concurrency
        self.timeout = timeout
        self.connect_timeout = connect_timeout
        self.max_retries = max_retries
        self.backoff = backoff
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.cache_ns = cache_ns or os.environ.get("TEACHER_CACHE_NS")
        self.json_mode = json_mode
        self.extra_body = dict(extra_body or {})
        self.log = log or F.get_logger("teacher")
        self.transport = transport
        self.max_tokens_cap = max_tokens_cap
        self.stats = defaultdict(lambda: defaultdict(float))
        self.server_info = {}
        self._session = None
        self.sem = None
        self.t_start = time.monotonic()

    async def __aenter__(self):
        if self.transport is None:
            import aiohttp
            self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=None, sock_connect=self.connect_timeout))
        self.sem = asyncio.Semaphore(self.concurrency)
        return self

    async def __aexit__(self, *exc):
        if self._session is not None:
            await self._session.close()
            self._session = None

    # -------------------------------------------------------------------------------- HTTP
    async def _request(self, method, url, body=None, timeout=None):
        import aiohttp
        to = aiohttp.ClientTimeout(total=timeout or self.timeout, sock_connect=self.connect_timeout)
        async with self._session.request(method, url, json=body, timeout=to) as r:
            txt = await r.text()
            try:
                data = json.loads(txt)
            except Exception:
                data = txt
            return r.status, data

    async def wait_ready(self, max_wait=900, min_ctx=0):
        """Wait until the server answers /health and /v1/models; read the model id and per-slot context (/props)."""
        if self.transport is not None:
            self.model = self.model or "stub-teacher"
            self.cache_ns = self.cache_ns or self.model
            self.server_info = {"model": self.model, "transport": "stub"}
            return self.server_info
        t0, n, last = time.monotonic(), 0, "?"
        models = None
        while True:
            try:
                st, data = await self._request("GET", self.root + "/health", timeout=15)
                if st in (200, 404):
                    st2, models = await self._request("GET", self.url + "/models", timeout=15)
                    if st2 == 200 and isinstance(models, dict):
                        break
                    last = f"/models HTTP {st2}"
                else:
                    last = f"/health HTTP {st}: {str(data)[:120]}"
            except Exception as e:  # connection refused while the model loads
                last = f"{type(e).__name__}: {e}"
            if time.monotonic() - t0 > max_wait:
                raise TeacherUnavailable(f"teacher not reachable at {self.url} after {max_wait}s ({last}). "
                                         "Start llama-server first (see krishi/facts/README.md).")
            if n % 6 == 0:
                self.log.info(f"waiting for the teacher at {self.url} ({last})")
            n += 1
            await asyncio.sleep(5)
        ids = [m.get("id") for m in (models or {}).get("data", []) if isinstance(m, dict)]
        self.model = self.model or (ids[0] if ids else "teacher")
        self.cache_ns = self.cache_ns or self.model
        info = {"url": self.url, "model": self.model, "models": ids}
        try:
            st, props = await self._request("GET", self.root + "/props", timeout=15)
            if st == 200 and isinstance(props, dict):
                gs = props.get("default_generation_settings") or {}
                info["n_ctx_per_slot"] = gs.get("n_ctx") or props.get("n_ctx")
                info["total_slots"] = props.get("total_slots")
        except Exception:
            pass
        self.server_info = info
        self.log.info(f"teacher ready: {info}")
        if min_ctx and info.get("n_ctx_per_slot") and info["n_ctx_per_slot"] < min_ctx:
            self.log.warning(f"per-slot context {info['n_ctx_per_slot']} < {min_ctx} tokens needed by this stage: "
                             f"restart llama-server with a larger -c (n_ctx = slots x per-slot) or smaller chunks")
        if info.get("total_slots") and info["total_slots"] < self.concurrency:
            self.log.warning(f"server has {info['total_slots']} slots but concurrency is {self.concurrency}; "
                             "extra requests just queue on the server")
        return info

    def _body(self, messages, temperature, max_tokens, seed, schema, top_p):
        body = {"model": self.model or "teacher", "messages": messages, "temperature": temperature,
                "max_tokens": int(max_tokens), "stream": False}
        if top_p is not None:
            body["top_p"] = top_p
        if seed is not None:
            body["seed"] = int(seed)
        if self.json_mode == "schema" and schema:
            body["response_format"] = {"type": "json_object", "schema": schema}
        elif self.json_mode in ("object", "schema"):
            body["response_format"] = {"type": "json_object"}
        body.update(self.extra_body)
        return body

    async def _complete(self, messages, tag, temperature, max_tokens, seed, schema, top_p):
        st = self.stats[tag]
        attempt = 0
        while True:
            body = self._body(messages, temperature, max_tokens, seed, schema, top_p)
            status, data, err = None, None, None
            t0 = time.monotonic()
            async with self.sem:
                try:
                    if self.transport is not None:
                        status, data = await asyncio.wait_for(self.transport(body), self.timeout)
                    else:
                        status, data = await self._request("POST", self.url + "/chat/completions", body)
                except asyncio.TimeoutError:
                    err = "timeout"
                except Exception as e:
                    err = f"{type(e).__name__}: {e}"
            st["requests"] += 1
            st["request_seconds"] += time.monotonic() - t0
            if status == 200 and isinstance(data, dict) and data.get("choices"):
                ch = data["choices"][0]
                msg = ch.get("message") or {}
                content = msg.get("content") or ""
                if msg.get("reasoning_content") or "<think>" in content or "</think>" in content:
                    st["reasoning_replies"] += 1   # thinking mode is on: costs tokens (see --no-think)
                    if self.stats["_warn"]["reasoning"] == 0:
                        self.stats["_warn"]["reasoning"] = 1
                        self.log.warning("the teacher returns reasoning/thinking text: this multiplies generated tokens. "
                                         "Use --no-think (chat_template_kwargs.enable_thinking=false) or start llama-server "
                                         "with --reasoning-budget 0")
                if not content.strip() and msg.get("reasoning_content"):
                    content = msg["reasoning_content"]
                usage = data.get("usage") or {}
                pt, ct = usage.get("prompt_tokens"), usage.get("completion_tokens")
                if pt is None or ct is None:
                    st["usage_estimated"] += 1
                    pt = pt if pt is not None else sum(len(m.get("content", "")) for m in messages) // 4
                    ct = ct if ct is not None else len(content) // 4
                st["prompt_tokens"] += pt
                st["completion_tokens"] += ct
                tm = data.get("timings") or {}
                st["prompt_ms"] += float(tm.get("prompt_ms") or 0)
                st["predicted_ms"] += float(tm.get("predicted_ms") or 0)
                st["cached_prompt_tokens"] += float(tm.get("cache_n") or 0)
                fr = ch.get("finish_reason")
                if fr == "length":
                    st["truncated"] += 1
                return content, fr
            text = data if isinstance(data, str) else json.dumps(data)[:600] if data is not None else ""
            if status == 400 and "response_format" in body and re.search(r"response_format|grammar|schema|json", text, re.I) \
                    and self.json_mode != "none":
                self.json_mode = "object" if self.json_mode == "schema" else "none"
                self.log.warning(f"server rejected response_format ({text[:200]}); json_mode -> {self.json_mode}")
                continue
            if status == 400 and re.search(r"context|too long|exceed", text, re.I):
                st["failures"] += 1
                raise TeacherError(f"{tag}: prompt does not fit the slot context: {text[:200]}")
            retryable = err is not None or status in (408, 409, 425, 429, 500, 502, 503, 504)
            if not retryable:
                st["failures"] += 1
                raise TeacherError(f"{tag}: HTTP {status}: {text[:300]}")
            if attempt >= self.max_retries:
                st["failures"] += 1
                raise TeacherError(f"{tag}: gave up after {attempt + 1} attempts (last: {err or f'HTTP {status}'})")
            st["retries"] += 1
            delay = min(60.0, self.backoff * (2 ** attempt)) * (0.5 + random.random())
            if attempt >= 1:
                self.log.warning(f"{tag}: {err or f'HTTP {status}'}; retry {attempt + 1}/{self.max_retries} in {delay:.1f}s")
            attempt += 1
            await asyncio.sleep(delay)

    # -------------------------------------------------------------------------------- cache
    def cache_key(self, messages, temperature, max_tokens, seed, schema, top_p, extra):
        payload = json.dumps({"v": CACHE_VERSION, "ns": self.cache_ns, "m": messages, "t": temperature, "mt": max_tokens,
                              "s": seed, "sc": schema, "tp": top_p, "x": extra}, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _cache_path(self, key):
        return self.cache_dir / key[:2] / f"{key}.json"

    def _cache_read(self, key):
        p = self._cache_path(key)
        if not p.exists():
            return None
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None  # half-written / corrupt entry: recompute

    def _cache_write(self, key, obj):
        F.write_json(self._cache_path(key), obj)

    # -------------------------------------------------------------------------------- main entry
    async def chat_json(self, messages, *, tag, validate=None, temperature=0.2, max_tokens=2048, seed=None, schema=None,
                        top_p=None, reasks=2, use_cache=True, cache_extra=None):
        """Send a chat request and return the validated JSON object.
        validate(obj) -> cleaned obj, or raise InvalidOutput (its message is sent back in the re-ask)."""
        st = self.stats[tag]
        st["calls"] += 1
        key = self.cache_key(messages, temperature, max_tokens, seed, schema, top_p, cache_extra)
        if use_cache and self.cache_dir:
            hit = self._cache_read(key)
            if hit is not None:
                try:
                    res = validate(hit["result"]) if validate else hit["result"]
                    st["cache_hits"] += 1
                    return res
                except Exception:
                    pass  # validator changed since: ask again
        msgs, last_err, mt = list(messages), "?", max_tokens
        for attempt in range(reasks + 1):
            text, finish = await self._complete(msgs, tag, temperature, mt, seed, schema, top_p)
            errs = []
            for obj, how in parse_reply(text):
                if how == "salvaged" and finish == "length" and attempt < reasks:
                    errs.append("the reply was cut off (max_tokens reached); give fewer, shorter items")
                    continue  # ask again with a bigger budget before accepting a partial answer
                try:
                    res = validate(obj) if validate else obj
                except Exception as e:
                    errs.append(str(e) or type(e).__name__)
                    continue
                if how == "salvaged":
                    st["salvaged"] += 1
                if how == "extracted":
                    st["repaired"] += 1
                if use_cache and self.cache_dir:
                    self._cache_write(key, {"tag": tag, "result": res, "how": how, "finish": finish,
                                            "raw": text[-20000:], "attempt": attempt})
                st["ok"] += 1
                return res
            last_err = errs[0] if errs else ("the reply was cut off (max_tokens reached); give fewer, shorter items"
                                             if finish == "length" else "no JSON object found in the reply")
            if attempt < reasks:
                st["reasks"] += 1
                if finish == "length":
                    mt = min(int(mt * 1.5), self.max_tokens_cap)
                msgs = list(messages) + [{"role": "assistant", "content": text[-3000:]},
                                         {"role": "user", "content": REASK.format(err=last_err[:500])}]
        st["invalid"] += 1
        raise TeacherError(f"{tag}: unusable output after {reasks + 1} attempts: {last_err[:300]}")

    # -------------------------------------------------------------------------------- accounting
    def totals(self):
        tot = defaultdict(float)
        for t, s in self.stats.items():
            if t.startswith("_"):
                continue
            for k, v in s.items():
                tot[k] += v
        return tot

    def summary(self, wall_seconds=None):
        tags = {t: {k: (round(v, 1) if isinstance(v, float) and v % 1 else int(v)) for k, v in sorted(s.items())}
                for t, s in self.stats.items() if not t.startswith("_")}
        tot = self.totals()
        wall = wall_seconds if wall_seconds is not None else time.monotonic() - self.t_start
        out = {"server": self.server_info, "json_mode": self.json_mode, "tags": tags,
               "total": {k: int(v) for k, v in tot.items() if not k.endswith(("_ms", "_seconds"))},
               "wall_seconds": round(wall, 1)}
        net_calls = tot["calls"] - tot["cache_hits"]
        if wall > 0 and tot["completion_tokens"]:
            out["throughput"] = {
                "completion_tokens_per_s": round(tot["completion_tokens"] / wall, 1),
                "prompt_tokens_per_s": round(tot["prompt_tokens"] / wall, 1),
                "network_calls": int(net_calls),
                "avg_prompt_tokens": round(tot["prompt_tokens"] / max(1, tot["requests"]), 1),
                "avg_completion_tokens": round(tot["completion_tokens"] / max(1, tot["requests"]), 1)}
        return out

    def log_summary(self, label, wall_seconds=None):
        s = self.summary(wall_seconds)
        t = s["total"]
        self.log.info(f"[{label}] teacher calls {t.get('calls', 0)} (cache hits {t.get('cache_hits', 0)}, "
                      f"requests {t.get('requests', 0)}, retries {t.get('retries', 0)}, re-asks {t.get('reasks', 0)}, "
                      f"invalid {t.get('invalid', 0)}, failures {t.get('failures', 0)}); tokens prompt "
                      f"{t.get('prompt_tokens', 0)} + completion {t.get('completion_tokens', 0)}; "
                      f"wall {s['wall_seconds']} s; {s.get('throughput', {})}")
        return s

    def save_stats(self, path, label, extra=None, wall_seconds=None):
        s = self.summary(wall_seconds)
        s["stage"] = label
        if extra:
            s.update(extra)
        F.write_json(path, s)
        return s


async def run_jobs(factories, *, log, label, every_s=30.0):
    """Run coroutine factories concurrently (the Teacher semaphore limits the load); log progress + ETA.
    Returns results in order; a failed job's slot holds its exception (the stage decides what to do)."""
    n = len(factories)
    results = [None] * n
    state = {"done": 0, "fail": 0, "last": time.monotonic()}
    t0 = time.monotonic()

    async def one(i, fac):
        try:
            results[i] = await fac()
        except Exception as e:  # noqa: BLE001 - recorded per job
            results[i] = e
            state["fail"] += 1
            if state["fail"] <= 5 or state["fail"] % 100 == 0:
                log.warning(f"{label}: job {i} failed ({state['fail']} so far): {str(e)[:300]}")
        state["done"] += 1
        now = time.monotonic()
        if now - state["last"] >= every_s or state["done"] == n:
            state["last"] = now
            el = now - t0
            rate = state["done"] / el if el > 0 else 0.0
            eta = (n - state["done"]) / rate / 60 if rate else float("inf")
            log.info(f"{label}: {state['done']}/{n} done, {state['fail']} failed, {rate * 60:.1f}/min, ETA {eta:.1f} min")

    await asyncio.gather(*(one(i, f) for i, f in enumerate(factories)))
    return results


def add_teacher_args(ap):
    g = ap.add_argument_group("teacher")
    g.add_argument("--teacher-url", default=DEFAULT_URL)
    g.add_argument("--model", default=DEFAULT_MODEL, help="model name sent to the server (default: first id from /v1/models)")
    g.add_argument("--concurrency", type=int, default=int(os.environ.get("TEACHER_CONCURRENCY", 8)))
    g.add_argument("--timeout", type=float, default=600.0, help="seconds per request")
    g.add_argument("--retries", type=int, default=6)
    g.add_argument("--backoff", type=float, default=2.0, help="first retry delay in seconds (doubles each retry)")
    g.add_argument("--json-mode", choices=["schema", "object", "none"], default=os.environ.get("TEACHER_JSON_MODE", "object"))
    g.add_argument("--cache-dir", default=None, help="default <work>/cache/teacher")
    g.add_argument("--no-think", action="store_true",
                   help="send chat_template_kwargs.enable_thinking=false (for chat templates with a thinking mode)")
    g.add_argument("--wait", type=float, default=900, help="seconds to wait for the server to come up")
    return ap


def teacher_from_args(args, work, log, transport=None):
    extra = {"chat_template_kwargs": {"enable_thinking": False}} if getattr(args, "no_think", False) else None
    return Teacher(args.teacher_url, args.model, concurrency=args.concurrency, timeout=args.timeout, max_retries=args.retries,
                   backoff=args.backoff, cache_dir=args.cache_dir or (Path(work) / "cache" / "teacher"), json_mode=args.json_mode,
                   extra_body=extra, log=log, transport=transport)


# ------------------------------------------------------------------------------------------------ CLI
async def _ping(args):
    log = F.get_logger("teacher")
    async with teacher_from_args(args, F.DEFAULT_WORK, log) as T:
        info = await T.wait_ready(max_wait=args.wait)
        t0 = time.monotonic()
        res = await T.chat_json([{"role": "system", "content": "You answer with one JSON object only."},
                                 {"role": "user", "content": 'Return {"ok": true, "crop": "rice", "hindi": "<the Hindi word for rice>"}'}],
                                tag="ping", use_cache=False, max_tokens=128, temperature=0)
        print(json.dumps({"server": info, "reply": res, "seconds": round(time.monotonic() - t0, 2),
                          "json_mode": T.json_mode}, ensure_ascii=False, indent=1))


async def _bench(args):
    log = F.get_logger("teacher")
    async with teacher_from_args(args, F.DEFAULT_WORK, log) as T:
        await T.wait_ready(max_wait=args.wait)
        topics = ["rice nursery", "tomato staking", "chilli drying", "groundnut gypsum", "weeding", "drip irrigation",
                  "seed treatment", "harvest", "storage", "pheromone traps", "neem", "spraying safety"]

        def job(i):
            msgs = [{"role": "system", "content": "You answer with one JSON object only."},
                    {"role": "user", "content": f'Write about {args.max_tokens // 2} words of practical advice on '
                                                f'{topics[i % len(topics)]} for Indian farmers (variant {i}). '
                                                'Return {"text": "..."}'}]
            return lambda: T.chat_json(msgs, tag="bench", use_cache=False, max_tokens=args.max_tokens, temperature=0.7)

        t0 = time.monotonic()
        res = await run_jobs([job(i) for i in range(args.n)], log=log, label="bench", every_s=10)
        wall = time.monotonic() - t0
        ok = sum(1 for r in res if not isinstance(r, Exception))
        s = T.summary(wall)
        print(json.dumps({"requests": args.n, "ok": ok, "wall_s": round(wall, 1), "throughput": s.get("throughput"),
                          "server": T.server_info}, indent=1))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    add_teacher_args(sub.add_parser("ping"))
    b = add_teacher_args(sub.add_parser("bench"))
    b.add_argument("--n", type=int, default=16)
    b.add_argument("--max-tokens", type=int, default=256)
    args = ap.parse_args(argv)
    try:
        asyncio.run(_ping(args) if args.cmd == "ping" else _bench(args))
    except TeacherUnavailable as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
