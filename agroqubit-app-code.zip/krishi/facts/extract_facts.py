#!/usr/bin/env python3
"""extract_facts.py (GPU VM): cut <work>/pages.jsonl into chunks, ask the teacher for atomic facts with an exact
supporting quote, and keep only the facts that pass every check.

Checks (each rejected fact goes to <work>/rejects_extract.jsonl with its reason):
  schema      crop / topic / kind valid, crop matches the source, English text 1-30 words
  quote       the quote must appear verbatim in the chunk's page text (whitespace, line-break hyphenation,
              case and punctuation spacing are normalised; '...' gaps allowed between >=3-word segments)
  numbers     every number in the English text must appear in the quote
  ocr         sources marked ocr_suspect (garbled scans) give no facts with numbers
  pesticide   no banned pesticide, no pesticide restricted for that crop (banned_pesticides.json)
  duplicate   near-duplicates inside the same crop + target/topic (text similarity >= 0.85, same numbers)
Then it sets kind/requires_confirmed (synthetic chemical recommendation -> dose, requires_confirmed), keeps one
'first' fact per pest/disease, adds the region to state-specific advice, orders each group and assigns stable ids.

Usage:
  python3 krishi/facts/extract_facts.py [--work krishi/facts/work] [--limit 20] [--only niphm_rice_ipm_2014]
Outputs: <work>/facts_en.jsonl, facts_en_meta.jsonl, chunks.jsonl, rejects_extract.jsonl, extract_report.json,
         id_registry.json (shared with merge.py), stats/teacher_extract.json
"""
from __future__ import annotations

import argparse
import asyncio
import re
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import factlib as F  # noqa: E402
import teacher as TCH  # noqa: E402

PROMPT_VERSION = "extract-v1"
TOPIC_SYN = {"varieties": "variety", "cultivar": "variety", "cultivars": "variety", "hybrid": "variety",
             "season": "season_sowing", "sowing": "season_sowing", "sowing_time": "season_sowing", "planting": "season_sowing",
             "spacing": "season_sowing", "seed": "seed_nursery", "nursery": "seed_nursery", "seed_treatment": "seed_nursery",
             "seed_rate": "seed_nursery", "seeds": "seed_nursery", "land_preparation": "land_prep", "tillage": "land_prep",
             "soil": "land_prep", "fertilizer": "nutrient", "fertiliser": "nutrient", "nutrients": "nutrient",
             "manure": "nutrient", "manures": "nutrient", "nutrient_management": "nutrient", "fertilizers": "nutrient",
             "water": "irrigation", "water_management": "irrigation", "weeds": "weed", "weed_management": "weed",
             "weed_control": "weed", "insect": "pest", "insects": "pest", "pests": "pest", "insect_pest": "pest",
             "nematode": "pest", "rodent": "pest", "rodents": "pest", "diseases": "disease", "natural_enemies": "natural_enemy",
             "biocontrol": "natural_enemy", "biological_control": "natural_enemy", "beneficial_insects": "natural_enemy",
             "safety": "pesticide_safety", "pesticide": "pesticide_safety", "pesticides": "pesticide_safety",
             "harvest": "harvest_storage", "storage": "harvest_storage", "post_harvest": "harvest_storage",
             "harvesting": "harvest_storage", "ipm": "general", "other": "general"}
KIND_SYN = {"first_step": "first", "first_action": "first", "immediate": "first", "information": "info", "fact": "info",
            "description": "info", "practice": "action", "recommendation": "action", "cultural": "action",
            "mechanical": "action", "biological": "action", "chemical": "dose", "dosage": "dose", "chemical_dose": "dose"}
REGION_TOPICS = {"variety", "season_sowing", "nutrient"}
GENERAL_TOPICS = {"pesticide_safety", "general", "natural_enemy"}   # topics where crop "general" is accepted
MAX_QUOTE_WORDS = 120

SYSTEM = ("You are an agricultural extension scientist in India. You turn official crop guides into short, verified "
          "facts for an offline farmer helpline app. You never add knowledge that is not in the given text. "
          "You answer with one JSON object only.")

USER = """TASK: extract_facts
SOURCE: {doc}. Written for: {region}.
CROP: {crop}
SECTION: {heading}

TEXT (page {pages}):
<<<TEXT
{text}
TEXT>>>

Extract every distinct fact in TEXT that helps a farmer growing {crop_name}. One fact = one piece of advice or information that stands alone.

For each fact give:
- "crop": "{crop}", or "general" only for pesticide-safety and IPM rules that apply to every crop.
- "topic": one of variety | season_sowing | seed_nursery | land_prep | nutrient | irrigation | weed | pest | disease | natural_enemy | pesticide_safety | harvest_storage | general
- "target": for topic pest, disease or natural_enemy: the pest or disease id, else null. Use these ids when they match: {known}. For any other pest or disease write "{crop}_<name>" in lower_snake_case, singular (e.g. "{crop}_stem_borer"). For a natural enemy: the pest it attacks, or null.
- "kind": "first" = the first or most urgent thing to do against that pest/disease (only when TEXT says so or it is clearly the first step); "info" = description, symptom, cause, favourable condition, threshold, variety trait; "action" = something to do without a chemical pesticide (cultural, mechanical, fertiliser, bio-agent such as Trichoderma, Pseudomonas, neem, Trichogramma); "dose" = a chemical pesticide, herbicide, fungicide, bactericide or rodenticide recommendation (with its amount if given).
- "en": the fact in simple farmer English, at most 30 words, short everyday words ("spray", "pull out", "field"). Keep every number and unit exactly as in TEXT. Keep chemical names, formulations (e.g. 75% WP) and variety names exactly as in TEXT.{region_rule}
- "quote": the EXACT words from TEXT that support the fact, copied character for character (one sentence or one table row, at most 60 words). Do not fix spelling, do not join distant parts, do not paraphrase.
- "chemicals": the pesticide/herbicide/fungicide names in the fact ([] if none).

Rules:
- Only facts stated in TEXT. No outside knowledge. Nothing from contents pages, references, acknowledgements, page headers or statistics tables.
- Every number in "en" must appear in "quote".
- One chemical per dose fact: split lists into separate facts.
- Skip facts that need a figure or photo to understand. At most 15 facts.
- If TEXT has no useful facts, answer {{"facts": []}}.

Answer with JSON only:
{{"facts": [{{"crop": "...", "topic": "...", "target": null, "kind": "...", "en": "...", "quote": "...", "chemicals": []}}]}}"""

CROP_NAME = {"rice": "rice (paddy)", "tomato": "tomato", "chilli": "chilli", "groundnut": "groundnut (peanut)"}


# ------------------------------------------------------------------------------------------------ chunks
_HEAD_NUM = re.compile(r"^(?:(\d+(?:\.\d+){0,3})|([IVXLC]+)|([A-H]))[.)]?\s+\S")


def heading_level(line):
    """Return a heading depth (1..4) when a line looks like a section heading, else 0."""
    s = line.strip()
    if not s or len(s) > 90 or len(s.split()) > 12 or s.endswith((".", ",", ";", ":")) and not _HEAD_NUM.match(s):
        return 0
    if sum(ch.isalpha() for ch in s) < 3 or re.search(r"\s{3,}", s):
        return 0
    m = _HEAD_NUM.match(s)
    if m:
        if m.group(1):
            return min(4, m.group(1).count(".") + 1)
        return 1 if m.group(2) else 2
    letters = [ch for ch in s if ch.isalpha()]
    if letters and sum(ch.isupper() for ch in letters) / len(letters) > 0.8 and len(s.split()) <= 8:
        return 1
    return 0


def junk_chunk(text):
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if not lines:
        return "empty"
    if sum(ch.isalpha() for ch in text) < 150:
        return "too_little_text"
    toc = sum(1 for ln in lines if re.search(r"(\.{4,}|…{2,}|\s\.\s\.\s\.)\s*\d{1,4}\s*$", ln))
    if toc >= max(4, 0.3 * len(lines)):
        return "table_of_contents"
    refs = sum(1 for ln in lines if re.search(r"\b(19|20)\d{2}\b", ln) and re.search(r"\bet al\b|\bpp?\.\s*\d|journal|\bvol\b|proc\.", ln, re.I))
    if refs >= max(4, 0.4 * len(lines)):
        return "references"
    return None


def table_text(layout):
    """Layout text of a table page with column gaps made explicit: '  a     b' -> 'a | b'."""
    return "\n".join(re.sub(r"\s{3,}", " | ", ln.strip()) for ln in layout.splitlines())


def build_chunks(src, pages, max_chars, overlap, layout_tables=False):
    """Pages of one source -> chunks of whole paragraphs (<= max_chars) with a small overlap and the heading path.
    layout_tables: table-heavy pages use the -layout text (rows kept together) instead of reading order."""
    paras = []
    for p in pages:
        if p.get("empty"):
            continue
        body = table_text(p["text_layout"]) if (layout_tables and p.get("tabular")) else p["text"]
        for para in re.split(r"\n\s*\n", body):
            para = para.strip()
            if not para:
                continue
            while len(para) > max_chars:
                cut = para.rfind("\n", 0, max_chars)
                cut = cut if cut > max_chars // 3 else max_chars
                paras.append((p["page"], para[:cut].strip()))
                para = para[cut:].strip()
            if para:
                paras.append((p["page"], para))
    chunks, cur, cur_len, heads = [], [], 0, {}
    chunk_heads = None

    def emit():
        text = "\n\n".join(t for _, t in cur)
        pages_ = sorted({pg for pg, _ in cur})
        chunks.append({"id": f"{src['id']}#{len(chunks) + 1:04d}", "source_id": src["id"], "crop": src["crop"],
                       "pages": pages_, "text": text, "heading": chunk_heads or ""})

    for pg, para in paras:
        if cur and cur_len + len(para) + 2 > max_chars:
            emit()
            keep, k = [], 0
            for item in reversed(cur):
                if k + len(item[1]) > overlap:
                    break
                keep.insert(0, item)
                k += len(item[1]) + 2
            cur, cur_len = keep, k
            chunk_heads = " > ".join(heads[d] for d in sorted(heads))
        if not cur:
            chunk_heads = " > ".join(heads[d] for d in sorted(heads))
        cur.append((pg, para))
        cur_len += len(para) + 2
        first = para.splitlines()[0]
        lvl = heading_level(first)
        if lvl:
            heads = {d: h for d, h in heads.items() if d < lvl}
            heads[lvl] = re.sub(r"\s+", " ", first.strip())[:80]
    if cur:
        emit()
    return chunks


# ------------------------------------------------------------------------------------------------ teacher I/O
def validate_reply(obj):
    """Structural check only (content checks come later and are not re-asked)."""
    if isinstance(obj, list):
        obj = {"facts": obj}
    if not isinstance(obj, dict) or not isinstance(obj.get("facts"), list):
        raise TCH.InvalidOutput('expected {"facts": [...]}')
    out = []
    for f in obj["facts"]:
        if not isinstance(f, dict):
            continue
        en, quote = f.get("en") or f.get("text") or "", f.get("quote") or f.get("source_quote") or ""
        if not isinstance(en, str) or not isinstance(quote, str) or not en.strip():
            continue
        chems = f.get("chemicals") if isinstance(f.get("chemicals"), list) else []
        out.append({"crop": str(f.get("crop") or "").strip().lower(),
                    "topic": re.sub(r"[\s\-/]+", "_", str(f.get("topic") or "").strip().lower()),
                    "target": f.get("target") if isinstance(f.get("target"), str) else None,
                    "kind": re.sub(r"[\s\-]+", "_", str(f.get("kind") or "").strip().lower()),
                    "en": en.strip(), "quote": quote.strip(),
                    "chemicals": [c for c in chems if isinstance(c, str) and c.strip()][:6]})
    if obj["facts"] and not out:
        raise TCH.InvalidOutput("each fact must be an object with crop, topic, target, kind, en, quote, chemicals")
    return {"facts": out}


def build_prompt(chunk, src, targets):
    crop = src["crop"]
    region = src.get("region") or "all of India"
    prefix = region_prefix(src)
    if prefix:
        region_rule = (f" This source is written for {src['region']}: for varieties, sowing seasons and fertiliser doses "
                       f"start \"en\" with \"{prefix},\" unless TEXT names another place.")
    elif src.get("region"):
        region_rule = " Advice here is for specific states/districts: start \"en\" with the place named in TEXT (e.g. \"In Anantapur district, ...\")."
    else:
        region_rule = ""
    known = ", ".join(targets.known(crop)) if crop in F.CROPS else "none"
    pages = ", ".join(str(p) for p in chunk["pages"])
    user = USER.format(doc=src.get("doc") or src["title"], region=region, crop=crop, heading=chunk["heading"] or "-",
                       pages=pages, text=chunk["text"], crop_name=CROP_NAME.get(crop, crop), known=known,
                       region_rule=region_rule)
    return [{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}]


def region_prefix(src):
    if src.get("region_prefix"):
        return src["region_prefix"]
    r = src.get("region")
    if r and "(" not in r and "specific" not in r:
        return f"In {r}"
    return None


# ------------------------------------------------------------------------------------------------ checks
_LOWER_OK = {"apply", "use", "sow", "grow", "transplant", "raise", "plant", "give", "the", "a", "an", "for", "in", "during",
             "irrigate", "harvest", "select", "choose", "seed", "seeds", "sowing", "spacing", "adopt", "keep", "maintain",
             "do", "avoid", "treat", "mix", "add", "provide", "split", "basal", "top", "dress", "spray", "remove", "follow",
             "prefer", "take", "fertiliser", "fertilizer", "nitrogen", "medium", "short", "long", "early", "late", "this",
             "these", "varieties", "variety", "hybrids", "hybrid", "rice", "tomato", "chilli", "groundnut", "nursery"}


def clean_en(s):
    s = F.norm_text(s).strip().strip('"').strip()
    s = re.sub(r"\s*\|\s*", ": ", s)             # HTML table cells joined with ' | '
    s = re.sub(r"\s+([,.;:])", r"\1", s)
    if s and s[-1] not in ".!?":
        s += "."
    return s[:1].upper() + s[1:] if s else s


class Checker:
    def __init__(self, sources, targets, policy, seed_first_targets, log):
        self.src = {s["id"]: s for s in sources}
        self.T = targets
        self.P = policy
        self.seed_first = seed_first_targets
        self.log = log
        self.rejects = []
        self.reasons = Counter()

    def reject(self, g, chunk, reason, detail=None):
        self.reasons[reason] += 1
        self.rejects.append({"reason": reason, "detail": detail, "chunk": chunk["id"], "fact": g})
        return []

    def check(self, g, chunk, pos, qi, page_of):
        src = self.src[chunk["source_id"]]
        crop = g["crop"] if g["crop"] in F.CROPS_ALL else None
        if crop is None:
            return self.reject(g, chunk, "bad_crop", g["crop"])
        if src["crop"] in F.CROPS and crop not in (src["crop"], "general"):
            return self.reject(g, chunk, "crop_mismatch", crop)
        topic = TOPIC_SYN.get(g["topic"], g["topic"])
        if topic not in F.TOPICS:
            return self.reject(g, chunk, "bad_topic", g["topic"])
        coerced = False
        if crop == "general" and src["crop"] in F.CROPS and topic not in GENERAL_TOPICS:
            crop, coerced = src["crop"], True   # crop-specific agronomy stays with the source's crop
        kind = KIND_SYN.get(g["kind"], g["kind"])
        if kind not in F.KINDS:
            return self.reject(g, chunk, "bad_kind", g["kind"])
        en = clean_en(g["en"])
        if F.word_count(en) < 3:
            return self.reject(g, chunk, "en_too_short")
        if F.script_ratio(en, "latin") < 0.95:
            return self.reject(g, chunk, "en_not_latin")
        if F.word_count(en) > F.MAX_WORDS:
            return self.reject(g, chunk, "en_too_long", F.word_count(en))
        quote = F.clean_quote(g["quote"])
        level, idx = qi.match(quote)
        if level is None:
            return self.reject(g, chunk, "quote_not_verbatim")
        if F.word_count(quote) < 3:
            return self.reject(g, chunk, "quote_too_short")
        if F.word_count(quote) > MAX_QUOTE_WORDS:
            return self.reject(g, chunk, "quote_too_long", F.word_count(quote))
        miss = F.missing_numbers(en, quote)
        if miss:
            return self.reject(g, chunk, "number_not_in_quote", miss)
        if src.get("ocr_suspect") and F.numbers_in(en):
            return self.reject(g, chunk, "ocr_numbers")
        viol = self.P.violations(" ".join([en, quote, " ".join(g["chemicals"])]), crop)
        if viol:
            st = "banned_pesticide" if any(v["status"] == "banned" for v in viol) else "restricted_pesticide"
            return self.reject(g, chunk, st, [v["name"] for v in viol])
        targets, tnote = [], "none"
        if crop != "general" and topic in F.TARGET_TOPICS:
            targets, tnote = self.T.normalize(g["target"], crop)
            if tnote.startswith("other_crop"):
                return self.reject(g, chunk, "target_other_crop", tnote)
        chems = F.synthetic_chemicals(en, g["chemicals"])
        flags = []
        if chems:
            if kind in ("action", "first"):
                kind = "dose"
                flags.append("kind_to_dose")
        elif kind == "dose":
            kind = "action"
            flags.append("dose_without_chemical")
        if kind == "first" and not targets:
            kind = "action"
        req = kind == "dose" or bool(chems)
        if coerced:
            flags.append("crop_from_source")
        prefix = region_prefix(src)
        if prefix and topic in REGION_TOPICS and crop != "general":
            region_word = prefix.split(" ", 1)[1].lower()
            if region_word not in en.lower():
                first = en.split(" ", 1)[0].strip(",.:;").lower()
                en2 = f"{prefix}, {en[0].lower() + en[1:] if first in _LOWER_OK else en}"
                if F.word_count(en2) <= F.MAX_WORDS:
                    en = en2
                    flags.append("region_prefixed")
                else:
                    flags.append("region_missing")
        page = page_of(idx, quote)
        out = []
        for t in (targets or [None]):
            out.append({"crop": crop, "topic": topic, "target": t, "kind": kind, "requires_confirmed": req, "en": en,
                        "quote": quote, "page": page, "source_id": src["id"], "chunk": chunk["id"], "pos": pos,
                        "priority": src.get("priority", 5), "quote_match": level, "chemicals": chems,
                        "target_note": tnote, "flags": flags + (["expanded_target"] if len(targets) > 1 else [])})
        return out


def make_page_of(chunk, pages_by_key):
    texts, owners = [], []
    for kind in ("text", "text_layout"):
        for p in chunk["pages"]:
            texts.append(pages_by_key[(chunk["source_id"], p)][kind])
            owners.append(p)
    texts.append(chunk["text"])
    owners.append(None)
    qi = F.QuoteIndex(texts)
    page_kind = pages_by_key[(chunk["source_id"], chunk["pages"][0])].get("kind", "pdf")

    def page_of(idx, quote):
        if page_kind == "html":
            return None
        p = owners[idx] if 0 <= idx < len(owners) else None
        if p is None:  # spans two pages: the page where the quote starts
            head = F.loose(quote)[:40]
            for pg in chunk["pages"]:
                if head and head in F.loose(pages_by_key[(chunk["source_id"], pg)]["text"]):
                    return pg
            return chunk["pages"][0]
        return p
    return qi, page_of


# ------------------------------------------------------------------------------------------------ dedupe / order / ids
def dedupe(facts, threshold, src_order):
    """Keep the best copy (source priority, then document position) of near-duplicate facts in the same group."""
    facts = sorted(facts, key=lambda f: (f["priority"], src_order.get(f["source_id"], 99), f["chunk"], f["pos"]))
    kept, dropped = [], []
    by_group = defaultdict(list)
    for f in facts:
        key = (f["crop"], f["target"] or "#" + f["topic"])
        nums = F.numbers_in(f["en"])
        dup = None
        for g in by_group[key]:
            if g["kind"] != f["kind"] and not (g["requires_confirmed"] and f["requires_confirmed"]):
                continue
            if F.numbers_in(g["en"]) != nums or set(g["chemicals"]) != set(f["chemicals"]):
                continue
            same_quote = F.loose(g["quote"]) == F.loose(f["quote"])
            s = F.text_sim(g["en"], f["en"])
            if s >= threshold or (same_quote and s >= 0.6):
                dup = g
                break
        if dup:
            dup.setdefault("dups", []).append({"source_id": f["source_id"], "chunk": f["chunk"], "en": f["en"]})
            dropped.append((f, dup))
        else:
            by_group[key].append(f)
            kept.append(f)
    return kept, dropped


def fix_first(facts, seed_first, log):
    """One 'first' fact per pest/disease target. Seed targets keep their seed 'first'; else promote the earliest
    non-chemical action (flag first_promoted, for agronomist review)."""
    groups = defaultdict(list)
    for f in facts:
        if f["target"]:
            groups[(f["crop"], f["target"])].append(f)
    promoted = demoted = 0
    for (crop, t), fs in groups.items():
        fs.sort(key=lambda f: (f["priority"], f["chunk"], f["pos"]))
        firsts = [f for f in fs if f["kind"] == "first"]
        if t in seed_first:
            for f in firsts:
                f["kind"] = "action"
                f["flags"].append("first_demoted_seed_has_first")
                demoted += 1
            continue
        for f in firsts[1:]:
            f["kind"] = "action"
            f["flags"].append("first_demoted_extra")
            demoted += 1
        if not firsts:
            cand = [f for f in fs if f["kind"] == "action" and not f["requires_confirmed"]]
            if cand:
                cand[0]["kind"] = "first"
                cand[0]["flags"].append("first_promoted")
                promoted += 1
    log.info(f"'first' facts: {promoted} promoted, {demoted} demoted")


def order_and_ids(facts, registry, seed_orders, src_order):
    """Canonical order per (crop, target/topic) and stable ids. Pest/disease groups: first, info, action, dose;
    topic groups: non-chemical before chemical, then source priority and document position."""
    groups = defaultdict(list)
    for f in facts:
        groups[(f["crop"], F.group_of(f))].append(f)
    out = []
    for (crop, grp), fs in sorted(groups.items()):
        if fs[0]["target"]:
            key = lambda f: (F.KIND_RANK[f["kind"]], f["priority"], src_order.get(f["source_id"], 99), f["chunk"], f["pos"])  # noqa: E731
        else:
            key = lambda f: (f["requires_confirmed"], f["priority"], src_order.get(f["source_id"], 99), f["chunk"], f["pos"])  # noqa: E731
        fs.sort(key=key)
        start = seed_orders.get((crop, grp), -1) + 1
        for k, f in enumerate(fs):
            f["order"] = start + k
            prefix = f"{crop}.{grp}.{f['kind']}"
            f["id"] = registry.assign(F.fact_key(f["source_id"], f["quote"], crop, grp, f["kind"], f["en"]), prefix, f["en"])
            out.append(f)
    return out


def to_schema(f, src):
    return {"id": f["id"], "crop": f["crop"], "topic": f["topic"], "target": f["target"], "kind": f["kind"],
            "requires_confirmed": bool(f["requires_confirmed"]), "text": {"en": f["en"]},
            "source": {"doc": src.get("doc") or src["title"], "url": src["url"] if not f.get("url") else f["url"],
                       "page": f["page"], "quote": f["quote"]},
            "order": f["order"], "review": "auto"}


def load_seed(path, log):
    p = Path(path)
    if not p.exists():
        log.warning(f"no seed facts at {p}: seed ids cannot be reserved now (merge.py re-checks)")
        return [], set(), {}
    seed = F.read_jsonl(p)
    first = {f["target"] for f in seed if f.get("target") and f.get("kind") == "first"}
    orders = defaultdict(lambda: -1)
    for f in seed:
        k = (f["crop"], F.group_of(f))
        orders[k] = max(orders[k], int(f.get("order", 0)))
    return seed, first, dict(orders)


# ------------------------------------------------------------------------------------------------ main
async def run(args, log):
    work = Path(args.work)
    t0 = time.monotonic()
    sources = [s for s in F.load_sources(args.sources) if s.get("extract", True)]
    if args.only:
        keep = set(args.only.split(","))
        sources = [s for s in sources if s["id"] in keep]
    src_by_id = {s["id"]: s for s in sources}
    src_order = {s["id"]: i for i, s in enumerate(sources)}
    pages = [p for p in F.read_jsonl(args.pages) if p["source_id"] in src_by_id]
    if not pages:
        raise SystemExit(f"no pages for the selected sources in {args.pages}: run fetch_sources.py first")
    pages_by_key = {(p["source_id"], p["page"]): p for p in pages}
    by_src = defaultdict(list)
    for p in pages:
        by_src[p["source_id"]].append(p)
    chunks, skipped = [], Counter()
    for sid in sorted(by_src, key=lambda s: src_order[s]):
        for c in build_chunks(src_by_id[sid], sorted(by_src[sid], key=lambda p: p["page"]), args.chunk_chars, args.overlap,
                              args.layout_tables):
            why = junk_chunk(c["text"])
            if why:
                skipped[why] += 1
                continue
            chunks.append(c)
    if args.limit:
        rr = defaultdict(list)
        for c in chunks:
            rr[c["source_id"]].append(c)
        picked, i = [], 0
        while len(picked) < args.limit and any(rr.values()):
            sid = list(rr)[i % len(rr)]
            if rr[sid]:
                picked.append(rr[sid].pop(0))
            i += 1
        chunks = picked
    F.write_jsonl(work / "chunks.jsonl", chunks)
    log.info(f"{len(chunks)} chunks from {len(by_src)} sources (skipped {dict(skipped)}); "
             f"~{sum(len(c['text']) for c in chunks) // 4} source tokens")

    targets = F.Targets(args.targets)
    policy = F.PesticidePolicy(args.banned, strict=args.strict_restricted)
    seed, seed_first, seed_orders = load_seed(args.seed, log)
    checker = Checker(sources, targets, policy, seed_first, log)

    async with TCH.teacher_from_args(args, work, log) as T:
        await T.wait_ready(max_wait=args.wait, min_ctx=args.chunk_chars // 3 + 3500)

        def job(c):
            msgs = build_prompt(c, src_by_id[c["source_id"]], targets)
            return lambda: T.chat_json(msgs, tag="extract", validate=validate_reply, temperature=args.temperature,
                                       max_tokens=args.max_tokens, seed=args.seed_value, cache_extra=PROMPT_VERSION)
        results = await TCH.run_jobs([job(c) for c in chunks], log=log, label="extract")
        stats = T.log_summary("extract")
        T.save_stats(work / "stats" / "teacher_extract.json", "extract")

    raw_n, failed_chunks, kept = 0, [], []
    for c, res in zip(chunks, results):
        if isinstance(res, Exception):
            failed_chunks.append({"chunk": c["id"], "error": str(res)[:300]})
            continue
        qi, page_of = make_page_of(c, pages_by_key)
        for pos, g in enumerate(res["facts"]):
            raw_n += 1
            for f in checker.check(g, c, pos, qi, page_of):
                f["url"] = pages_by_key[(c["source_id"], c["pages"][0])].get("url")
                kept.append(f)
    kept, dropped = dedupe(kept, args.dedupe, src_order)
    for f, d in dropped:
        checker.reasons["duplicate"] += 1
        checker.rejects.append({"reason": "duplicate", "detail": {"kept_en": d["en"], "kept_chunk": d["chunk"]},
                                "chunk": f["chunk"], "fact": {k: f[k] for k in ("crop", "topic", "target", "kind", "en", "quote")}})
    fix_first(kept, seed_first, log)
    registry = F.IdRegistry(work / "id_registry.json")
    registry.reserve(f["id"] for f in seed)
    facts = order_and_ids(kept, registry, seed_orders, src_order)
    registry.save()

    rows = [to_schema(f, src_by_id[f["source_id"]]) for f in facts]
    bad = [(r["id"], e) for r in rows for e in [F.fact_errors(dict(r, text={L: r["text"]["en"] for L in F.LANGS}))] if e]
    if bad:
        raise RuntimeError(f"internal error: {len(bad)} facts violate the schema, e.g. {bad[:3]}")
    meta = [{"id": f["id"], "source_id": f["source_id"], "chunk": f["chunk"], "page": f["page"], "quote_match": f["quote_match"],
             "chemicals": f["chemicals"], "target_note": f["target_note"], "flags": f["flags"],
             "duplicates": f.get("dups", [])} for f in facts]
    F.write_jsonl(work / "facts_en.jsonl", rows)
    F.write_jsonl(work / "facts_en_meta.jsonl", meta)
    F.write_jsonl(work / "rejects_extract.jsonl", checker.rejects)
    if failed_chunks:
        F.write_jsonl(work / "failed_chunks_extract.jsonl", failed_chunks)

    by_src_kept = Counter(f["source_id"] for f in facts)
    by_src_raw = Counter()
    for r in checker.rejects:
        by_src_raw[r["chunk"].split("#")[0]] += 1
    report = {
        "prompt_version": PROMPT_VERSION, "chunks": len(chunks), "chunks_skipped": dict(skipped),
        "chunks_failed": len(failed_chunks), "raw_facts": raw_n, "kept_facts": len(facts),
        "rejected": dict(checker.reasons.most_common()),
        "pass_rate": round(len(facts) / raw_n, 3) if raw_n else None,
        "kept_by_source": dict(by_src_kept), "rejected_by_source": dict(by_src_raw),
        "by_crop_topic": dict(Counter(f"{f['crop']}/{f['topic']}" for f in facts).most_common()),
        "by_kind": dict(Counter(f["kind"] for f in facts)),
        "requires_confirmed": sum(f["requires_confirmed"] for f in facts),
        "targets": dict(Counter(f["target"] for f in facts if f["target"]).most_common()),
        "new_targets": sorted({f["target"] for f in facts if f["target"] and f["target_note"] == "new"}),
        "quote_match": dict(Counter(f["quote_match"] for f in facts)),
        "flags": dict(Counter(x for f in facts for x in f["flags"])),
        "ids": dict(registry.stats), "teacher": stats.get("total"), "wall_seconds": round(time.monotonic() - t0, 1)}
    F.write_json(work / "extract_report.json", report)
    log.info(f"facts: {raw_n} proposed -> {len(facts)} kept ({report['pass_rate']}); rejected {report['rejected']}")
    log.info(f"by kind {report['by_kind']}; new targets {len(report['new_targets'])}; ids {report['ids']}")
    return 0 if facts or not chunks else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--work", default=str(F.DEFAULT_WORK))
    ap.add_argument("--sources", default=str(F.SOURCES_JSON))
    ap.add_argument("--pages", default=None, help="default <work>/pages.jsonl")
    ap.add_argument("--targets", default=str(F.TARGETS_JSON))
    ap.add_argument("--banned", default=str(F.BANNED_JSON))
    ap.add_argument("--seed", default=str(F.SEED_FACTS), help="seed facts (their ids are reserved)")
    ap.add_argument("--only", default="", help="comma-separated source ids")
    ap.add_argument("--limit", type=int, default=0, help="only the first N chunks (round-robin over sources): dry run")
    ap.add_argument("--chunk-chars", type=int, default=3500)
    ap.add_argument("--overlap", type=int, default=300)
    ap.add_argument("--dedupe", type=float, default=0.85, help="text similarity threshold for near-duplicates")
    ap.add_argument("--layout-tables", action="store_true",
                    help="give the teacher the -layout text of table-heavy pages (rows together) instead of reading order")
    ap.add_argument("--strict-restricted", action="store_true", help="drop every restricted pesticide, whatever the crop")
    ap.add_argument("--temperature", type=float, default=0.1)
    ap.add_argument("--max-tokens", type=int, default=3000)
    ap.add_argument("--seed-value", type=int, default=7, help="sampling seed sent to the server")
    TCH.add_teacher_args(ap)
    args = ap.parse_args(argv)
    args.pages = args.pages or str(Path(args.work) / "pages.jsonl")
    log = F.get_logger("extract_facts", args.work)
    try:
        return asyncio.run(run(args, log))
    except TCH.TeacherUnavailable as e:
        log.error(str(e))
        return 3


if __name__ == "__main__":
    sys.exit(main())
