#!/usr/bin/env python3
"""factlib: shared helpers for the Krishi Doctor fact pipeline (krishi/facts/).

Standard library only, so every stage, the mock teacher and the tests can import it.

- paths and enums from facts/SCHEMA.md (the contract with factlm/)
- JSONL/JSON IO with atomic writes, logging to <work>/logs/<stage>.log
- text normalisation and verbatim quote matching (whitespace / hyphenation / punctuation-spacing tolerant)
- number extraction (every number of a fact must appear in its quote, and in every translation)
- script detection (same rule as factlm/facts_lib.detect_script) and similarity scores
- target ids (targets.json + the app's disease ids), pesticide policy (banned_pesticides.json),
  chemical / bio-agent / fertiliser lexicon, and the stable fact-id registry
"""
from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

FACTS_DIR = Path(__file__).resolve().parent
REPO_DIR = FACTS_DIR.parent
DEFAULT_WORK = FACTS_DIR / "work"
QUESTIONS_DIR = FACTS_DIR / "questions"
SOURCES_JSON = FACTS_DIR / "sources.json"
BANNED_JSON = FACTS_DIR / "banned_pesticides.json"
TARGETS_JSON = FACTS_DIR / "targets.json"
SEED_FACTS = FACTS_DIR / "seed_facts.jsonl"
FACTS_OUT = FACTS_DIR / "facts.jsonl"

CROPS = ["rice", "tomato", "chilli", "groundnut"]
CROPS_ALL = CROPS + ["general"]
TOPICS = ["variety", "season_sowing", "seed_nursery", "land_prep", "nutrient", "irrigation", "weed", "pest", "disease",
          "natural_enemy", "pesticide_safety", "harvest_storage", "general"]
TARGET_TOPICS = {"pest", "disease", "natural_enemy"}
KINDS = ["first", "info", "action", "dose"]
KIND_RANK = {k: i for i, k in enumerate(KINDS)}
SEED_CATS = ["first", "cultural", "biological", "chemical"]
LANGS = ["en", "hi", "ta", "kn"]
INDIC = ["hi", "ta", "kn"]
LANG_NAME = {"en": "English", "hi": "Hindi", "ta": "Tamil", "kn": "Kannada"}
SCRIPTS = ["native", "roman", "mixed"]
REVIEW = ["seed", "auto", "human"]
END, ASK, NOT_SURE, WHICH_CROP, CONFIRM = "<END>", "<ASK>", "<NOT_SURE>", "<WHICH_CROP>", "<CONFIRM>"
CONTROLS = [END, ASK, NOT_SURE, WHICH_CROP, CONFIRM]
MAX_FACTS = 6            # SCHEMA.md: an answer has at most 6 facts
MAX_WORDS = 30           # screen text limit (English words)
ID_RE = re.compile(r"^[a-z0-9_]+\.[a-z0-9_]+\.[a-z0-9_]+\.[0-9]+$")
TARGET_RE = re.compile(r"^(rice|tomato|chilli|groundnut)_[a-z0-9]+(?:_[a-z0-9]+)*$")


# ------------------------------------------------------------------------------------------------ IO
def read_jsonl(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        for n, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}:{n}: bad JSON: {e}") from e
    return rows


def _atomic_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp{os.getpid()}")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def write_jsonl(path, rows):
    _atomic_write(path, "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows))


def write_json(path, obj):
    _atomic_write(path, json.dumps(obj, ensure_ascii=False, indent=1) + "\n")


def load_json(path, default=None):
    path = Path(path)
    if not path.exists():
        if default is not None:
            return default
        raise FileNotFoundError(path)
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def get_logger(name, work=None, verbose=False):
    """Logger that writes to stderr and <work>/logs/<name>.log (appending, so resumed runs keep history)."""
    log = logging.getLogger(f"krishi.{name}")
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    log.propagate = False
    for h in list(log.handlers):
        log.removeHandler(h)
        h.close()
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s | %(message)s", "%Y-%m-%d %H:%M:%S")
    sh = logging.StreamHandler(sys.stderr)
    sh.setFormatter(fmt)
    log.addHandler(sh)
    if work:
        d = Path(work) / "logs"
        d.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(d / f"{name}.log", encoding="utf-8")
        fh.setFormatter(fmt)
        log.addHandler(fh)
    return log


def sha1(s):
    return hashlib.sha1(s.encode("utf-8")).hexdigest()


def stable_frac(s):
    """Deterministic number in [0, 1) from a string (for hash-based splits that survive reruns)."""
    return int(sha1(s)[:12], 16) / float(16 ** 12)


# ------------------------------------------------------------------------------------------------ text
_TRANS = {ord(c): "-" for c in "‐‑‒–—―−⁃﹘﹣－"}
_TRANS.update({ord(c): "'" for c in "‘’‚‛′´`"})
_TRANS.update({ord(c): '"' for c in "“”„″«»"})
_TRANS.update({ord(c): " " for c in "     •●▪■➢‣⁃"})
_TRANS.update({ord("­"): None, ord("​"): None, ord("﻿"): None, ord("⁄"): "/"})
_DEHYPH = re.compile(r"([A-Za-z])-[ \t]*\r?\n[ \t]*([a-z])")


def norm_text(s):
    """NFKC, unified dashes/quotes/bullets, line-break hyphenation joined, whitespace collapsed."""
    s = unicodedata.normalize("NFKC", s or "").translate(_TRANS)
    s = _DEHYPH.sub(r"\1\2", s)
    return re.sub(r"\s+", " ", s).strip()


def loose(s):
    """Case-, hyphen-, quote- and punctuation-spacing-insensitive form used for verbatim matching."""
    s = norm_text(s).casefold().replace("-", "").replace('"', "").replace("'", "").replace("|", " ")
    s = re.sub(r"\s*([,;:.()\[\]/%@+=*&])\s*", r"\1", s)
    s = re.sub(r"(\d)\s+(?=[a-z%])", r"\1", s)
    s = re.sub(r"([a-z])\s+(?=\d)", r"\1", s)
    return re.sub(r"\s+", " ", s).strip()


def nospace(s):
    return re.sub(r"\s+", "", loose(s))


def clean_quote(q):
    q = norm_text(q)
    q = q.strip().strip('"').strip("'").strip()
    q = re.sub(r"^(\.\.\.|…)\s*", "", q)
    q = re.sub(r"\s*(\.\.\.|…)$", "", q)
    return q.strip()


class QuoteIndex:
    """Precomputed normalised forms of a list of texts (e.g. the pages of one chunk, both pdftotext modes)."""

    def __init__(self, texts):
        self.texts = [t or "" for t in texts]
        self.norm = [norm_text(t) for t in self.texts]
        self.loose = [loose(t) for t in self.texts]
        self.nosp = [re.sub(r"\s+", "", t) for t in self.loose]

    def match(self, quote, window=600):
        """-> (level, text index) or (None, -1). Levels: exact > loose > nospace > elided ('...' gaps)."""
        q = clean_quote(quote)
        if len(q) < 8:
            return None, -1
        for i, t in enumerate(self.norm):
            if q in t:
                return "exact", i
        lq = loose(q)
        for i, t in enumerate(self.loose):
            if lq in t:
                return "loose", i
        nq = re.sub(r"\s+", "", lq)
        for i, t in enumerate(self.nosp):
            if nq in t:
                return "nospace", i
        segs = [s for s in re.split(r"\s*(?:\.\.\.|…)\s*", q) if s.strip()]
        if len(segs) > 1 and all(len(s.split()) >= 3 for s in segs):
            for i, t in enumerate(self.nosp):
                pos, start, ok = 0, None, True
                for s in segs:
                    ns = re.sub(r"\s+", "", loose(s))
                    j = t.find(ns, pos)
                    if j < 0 or (start is not None and j - pos > window):
                        ok = False
                        break
                    start = j if start is None else start
                    pos = j + len(ns)
                if ok:
                    return "elided", i
        return None, -1


# ------------------------------------------------------------------------------------------------ numbers
_NUMWORDS = {"two": "2", "three": "3", "four": "4", "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9",
             "ten": "10", "eleven": "11", "twelve": "12", "fifteen": "15", "twenty": "20", "thirty": "30",
             "forty": "40", "fifty": "50", "hundred": "100", "thousand": "1000", "twice": "2", "thrice": "3",
             "half": "0.5", "double": "2"}
_THOUS = re.compile(r"(?<![\d.,])\d{1,3}(?:,\d{2})*,\d{3}(?!\d)")
_NUM = re.compile(r"\d+(?:\.\d+)?")


def ascii_digits(s):
    return "".join(str(unicodedata.digit(c)) if (not c.isascii() and unicodedata.category(c) == "Nd") else c for c in s)


def canon_num(x):
    if "." in x:
        a, b = x.split(".", 1)
        a, b = a.lstrip("0") or "0", b.rstrip("0")
        return f"{a}.{b}" if b else a
    return x.lstrip("0") or "0"


def numbers_in(text, quote_side=False, words=True):
    """Set of canonical numbers in text. '1,500' -> 1500, '.5' -> 0.5, number words (two..hundred) -> digits.
    quote_side=True also adds the comma-split reading and simple fractions, so the check is lenient on the source side."""
    t = ascii_digits(norm_text(text))
    t = re.sub(r"(?<![\d])\.(\d)", r"0.\1", t)
    joined = _THOUS.sub(lambda m: m.group(0).replace(",", ""), t)
    out = set()
    for v in ([joined, t] if quote_side else [joined]):
        out.update(canon_num(m) for m in _NUM.findall(v))
    if words:
        low = t.lower()
        for w, d in _NUMWORDS.items():
            if re.search(rf"\b{w}\b", low):
                out.add(d)
    if quote_side:
        for a, b in re.findall(r"\b(\d+)\s*/\s*(\d+)\b", t):
            a, b = int(a), int(b)
            if 0 < a < b and b in (2, 3, 4, 5, 8, 10):
                out.add(canon_num(f"{a / b:.3f}"))
    return out


def missing_numbers(en, quote):
    """Numbers of the English fact text that do not appear in the quote."""
    return sorted(numbers_in(en) - numbers_in(quote, quote_side=True), key=lambda x: float(x))


# ------------------------------------------------------------------------------------------------ scripts
_BLOCKS = [("devanagari", 0x0900, 0x097F), ("bengali", 0x0980, 0x09FF), ("gurmukhi", 0x0A00, 0x0A7F),
           ("gujarati", 0x0A80, 0x0AFF), ("oriya", 0x0B00, 0x0B7F), ("tamil", 0x0B80, 0x0BFF),
           ("telugu", 0x0C00, 0x0C7F), ("kannada", 0x0C80, 0x0CFF), ("malayalam", 0x0D00, 0x0D7F),
           ("devanagari", 0xA8E0, 0xA8FF)]
LANG_SCRIPT = {"hi": "devanagari", "ta": "tamil", "kn": "kannada", "en": "latin"}
_LATIN_RE = re.compile(r"[a-zA-Z]")


def char_script(c):
    o = ord(c)
    if c.isascii():
        return "latin" if c.isalpha() else None
    cat = unicodedata.category(c)
    if not (cat.startswith("L") or cat.startswith("M")):
        return None
    if 0x00C0 <= o <= 0x024F:
        return "latin"
    for name, a, b in _BLOCKS:
        if a <= o <= b:
            return name
    return "other"


def script_profile(text):
    c = Counter()
    for ch in text or "":
        s = char_script(ch)
        if s:
            c[s] += 1
    return c


def script_ratio(text, script):
    p = script_profile(text)
    n = sum(p.values())
    return (p.get(script, 0) / n) if n else 0.0


def detect_script(text, lang):
    """Same rule as factlm/facts_lib.detect_script (SCHEMA.md): native / roman / mixed; English is always native."""
    if lang == "en":
        return "native"
    has_latin = bool(_LATIN_RE.search(text))
    has_native = any(ord(c) > 0x2FF and unicodedata.category(c)[0] in "LM" for c in text)
    if has_latin and has_native:
        latin_words = [w for w in text.split() if _LATIN_RE.search(w)]
        if len(latin_words) <= 1 and all(w.isupper() or len(w) <= 3 for w in latin_words):
            return "native"
        return "mixed"
    if has_latin:
        return "roman"
    return "native"


def word_count(s):
    return len([w for w in re.split(r"\s+", (s or "").strip()) if w])


# ------------------------------------------------------------------------------------------------ similarity
_STOP = frozenset((
    "a an the of to in on at for and or with by from is are was were be been as it its this that these those into per "
    "each your you their them they he she his her than then also only use using used do does can may should will shall "
    "about after before during over under up out if when where which who what how not no all any some more most such "
    "other there here so very".split()))
_TOKEN = re.compile(r"[a-z0-9]+(?:\.[0-9]+)?")


def _stem(w):
    if w.isdigit() or len(w) <= 3:
        return w
    if w.endswith("ies") and len(w) > 4:
        return w[:-3] + "y"
    if w.endswith("s") and not w.endswith(("ss", "us", "is", "ps")):
        return w[:-1]
    return w


def content_tokens(s):
    t = norm_text(s).casefold().replace("-", " ")
    return [_stem(w) for w in _TOKEN.findall(t) if w not in _STOP]


def char_ngrams(s, n=3):
    t = " " + re.sub(r"\s+", " ", norm_text(s).casefold()) + " "
    return Counter(t[i:i + n] for i in range(max(0, len(t) - n + 1)))


def cosine(a, b):
    if not a or not b:
        return 0.0
    dot = sum(v * b.get(k, 0) for k, v in a.items())
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    return dot / (na * nb) if na and nb else 0.0


def jaccard(a, b):
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if (a or b) else 1.0


def text_sim(a, b):
    """0..1: mean of content-word Jaccard and character-trigram cosine."""
    return 0.5 * jaccard(content_tokens(a), content_tokens(b)) + 0.5 * cosine(char_ngrams(a), char_ngrams(b))


def token_f1(ref, hyp):
    r, h = Counter(content_tokens(ref)), Counter(content_tokens(hyp))
    if not r or not h:
        return 0.0
    common = sum((r & h).values())
    if not common:
        return 0.0
    p, rc = common / sum(h.values()), common / sum(r.values())
    return 2 * p * rc / (p + rc)


# ------------------------------------------------------------------------------------------------ chemicals
def pnorm(s):
    """Normalisation for chemical-name matching: lowercase, only [a-z0-9%] words."""
    s = norm_text(s).casefold()
    s = re.sub(r"[^a-z0-9%]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


_PEST_MULTI = """
mancozeb|carbendazim|tricyclazole|hexaconazole|propiconazole|tebuconazole|difenoconazole|azoxystrobin|trifloxystrobin|
kresoxim methyl|metalaxyl|metalaxyl m|cymoxanil|copper oxychloride|copper oxy chloride|copper hydroxide|chlorothalonil|
captan|thiram|thiophanate methyl|iprobenfos|edifenphos|isoprothiolane|validamycin|pencycuron|propineb|zineb|ziram|
wettable sulphur|wettable sulfur|dinocap|myclobutanil|flusilazole|kasugamycin|carpropamid|picoxystrobin|pyraclostrobin|
thifluzamide|streptocycline|streptomycin|streptomycin sulphate|streptomycin sulfate|tetracycline|plantomycin|
copper sulphate|copper sulfate|bordeaux mixture|metiram|famoxadone|dimethomorph|fosetyl al|fosetyl|ametoctradin|
mandipropamid|fenamidone|iprodione|procymidone|tolclofos methyl|fluopicolide|fluxapyroxad|penflufen|carboxin|
bitertanol|triadimefon|triadimenol|fenarimol|benomyl|tridemorph|imidacloprid|thiamethoxam|clothianidin|acetamiprid|
dinotefuran|flonicamid|pymetrozine|buprofezin|triflumezopyrim|spinosad|spinetoram|emamectin benzoate|emamectin|
chlorantraniliprole|flubendiamide|cyantraniliprole|indoxacarb|novaluron|lufenuron|chlorfenapyr|fipronil|
cartap hydrochloride|cartap|thiocyclam|chlorpyrifos|chlorpyriphos|quinalphos|profenofos|acephate|dimethoate|
malathion|monocrotophos|triazophos|phorate|carbofuran|cypermethrin|alpha cypermethrin|lambda cyhalothrin|
lambdacyhalothrin|deltamethrin|fenvalerate|bifenthrin|beta cyfluthrin|cyfluthrin|fenpropathrin|ethion|spiromesifen|
diafenthiuron|fenpyroximate|hexythiazox|propargite|abamectin|milbemectin|etoxazole|sulfoxaflor|pyriproxyfen|
tolfenpyrad|fluxametamide|broflanilide|dichlorvos|ddvp|methyl parathion|parathion|carbaryl|endosulfan|phosphamidon|
fenthion|diazinon|oxydemeton methyl|thiodicarb|methomyl|dicofol|oxyfluorfen|pretilachlor|butachlor|pendimethalin|
bispyribac sodium|bispyribac|penoxsulam|pyrazosulfuron ethyl|pyrazosulfuron|bensulfuron methyl|bensulfuron|
metsulfuron methyl|metsulfuron|chlorimuron ethyl|chlorimuron|almix|cyhalofop butyl|cyhalofop|fenoxaprop|
fenoxaprop p ethyl|quizalofop ethyl|quizalofop|imazethapyr|fluchloralin|metribuzin|alachlor|anilofos|oxadiargyl|
propanil|ethoxysulfuron|triafamone|florpyrauxifen|glyphosate|paraquat|paraquat dichloride|2 4 d|atrazine|diuron|
bromadiolone|zinc phosphide|aluminium phosphide|aluminum phosphide|celphos|methyl bromide|ethylene dibromide|dazomet|
fluensulfone|cadusafos|ethoprophos|thiacloprid|chlorantranilipole|novaluron|flufenoxuron|teflubenzuron|
pyridalyl|metaflumizone|chromafenozide|methoxyfenozide|tebufenozide|fenobucarb|bpmc|isoprocarb|etofenprox|
ethiprole|thiodicarb|hexaconazol|validamycin a|kitazin|hinosan|bavistin|dithane|indofil|blitox|contaf|tilt|
nativo|amistar|score|ridomil|curzate|kavach|antracol|ekalux|confidor|actara|coragen|fame|tracer|rynaxypyr|takumi
"""
PESTICIDES = frozenset(pnorm(x) for x in _PEST_MULTI.replace("\n", "").split("|") if x.strip())
# trade names that are also common English words are not included (e.g. 'score', 'fame' removed below)
PESTICIDES = frozenset(x for x in PESTICIDES if x not in {"score", "fame", "tilt", "contaf", "nativo"})

BIOAGENTS = frozenset(pnorm(x) for x in """trichoderma|trichoderma viride|trichoderma harzianum|pseudomonas|
pseudomonas fluorescens|bacillus subtilis|bacillus thuringiensis|bt|beauveria|beauveria bassiana|metarhizium|
metarhizium anisopliae|verticillium|verticillium lecanii|lecanicillium|npv|ha npv|hanpv|sl npv|slnpv|nuclear polyhedrosis
virus|granulosis virus|azospirillum|rhizobium|phosphobacteria|phosphobacterium|azotobacter|vam|mycorrhiza|neem|neem oil|
nske|neem seed kernel extract|azadirachtin|neem cake|pongamia|pongamia oil|garlic|trichogramma|trichogramma japonicum|
trichogramma chilonis|chrysoperla|chrysoperla carnea|cryptolaemus|panchagavya|cow urine|pheromone|ha lure|sl lure|
paecilomyces|purpureocillium|pochonia|ampelomyces|nomuraea""".replace("\n", "").split("|") if x.strip())

FERTILIZERS = frozenset(pnorm(x) for x in """urea|dap|diammonium phosphate|mop|muriate of potash|potash|ssp|
single super phosphate|super phosphate|gypsum|zinc sulphate|zinc sulfate|znso4|ferrous sulphate|feso4|borax|boron|
fym|farm yard manure|farmyard manure|compost|vermicompost|npk|ammonium sulphate|ammonium sulfate|lime|manure|
green manure|magnesium sulphate|calcium nitrate|potassium nitrate|potassium sulphate|sulphate of potash|
micronutrient mixture|ammonium chloride|rock phosphate|press mud|coir pith|19 19 19|13 0 45|12 61 0|mono ammonium phosphate|
water soluble fertilizer|calcium ammonium nitrate|can|biofertilizer|biofertiliser|dhaincha|sunhemp""".replace("\n", "").split("|")
                         if x.strip())

FORMULATION_RE = re.compile(r"\b\d+(?:\.\d+)?\s?%?\s?(?:EC|WP|WG|WDG|SC|SL|SP|GR|CG|CS|DS|FS|WS|OD|ME|EW|ZC|DP|G)\b")
QUANTITY_RE = re.compile(r"\d\s*(?:%|ppm|g\b|gm\b|gram|kg\b|ml\b|l\b|lit|litre|liter|t\b|tonne|ton|q\b|quintal|"
                         r"/\s*(?:ha|acre|kg|l|lit|litre|plant|m))", re.I)


def _contains(norm_text_padded, term):
    return f" {term} " in norm_text_padded


def pesticide_hits(text):
    """Synthetic pesticide names (lexicon) found in text, plus 'formulation' when a code like '75% WP' or '4G' is present."""
    t = f" {pnorm(text)} "
    hits = sorted({p for p in PESTICIDES if _contains(t, p)})
    if FORMULATION_RE.search(norm_text(text)):
        hits.append("formulation")
    return hits


def is_bio_or_fertilizer(name):
    n = pnorm(name)
    if not n:
        return True
    if n in BIOAGENTS or n in FERTILIZERS:
        return True
    return any(f" {b} " in f" {n} " for b in BIOAGENTS | FERTILIZERS if len(b) >= 4)


def synthetic_chemicals(text, teacher_chems=()):
    """Synthetic (non-bio, non-fertiliser) pesticide names: lexicon hits in text + teacher-listed names."""
    out = set(h for h in pesticide_hits(text) if h != "formulation")
    for c in teacher_chems or ():
        if isinstance(c, str) and c.strip() and not is_bio_or_fertilizer(c):
            out.add(pnorm(c))
    if not out and "formulation" in pesticide_hits(text):
        out.add("formulation")
    return sorted(out)


def has_quantity(text):
    return bool(QUANTITY_RE.search(norm_text(text)))


# ------------------------------------------------------------------------------------------------ pesticide policy
class PesticidePolicy:
    """banned_pesticides.json: 'banned' entries always block; 'restricted' entries block for their crops
    (or everywhere with strict=True). 'allow_if' / 'block_if' regexes refine a restriction (e.g. carbofuran 3% CG)."""

    def __init__(self, path=BANNED_JSON, strict=False):
        data = load_json(path)
        self.strict = strict
        self.version = data.get("version")
        self.entries = []
        for status in ("banned", "restricted"):
            for e in data.get(status, []):
                for a in [e["name"]] + list(e.get("aliases", [])):
                    a2 = pnorm(a)
                    if a2:
                        self.entries.append((status, e["name"], a2, e))
        # longest alias first so 'methyl parathion' is reported before 'parathion'
        self.entries.sort(key=lambda x: -len(x[2]))

    def violations(self, text, crop):
        t = f" {pnorm(text)} "
        out, seen = [], set()
        for status, name, alias, e in self.entries:
            if name in seen or not _contains(t, alias):
                continue
            if status == "restricted":
                if e.get("allow_if") and re.search(e["allow_if"], t):
                    continue
                if e.get("block_if") and not re.search(e["block_if"], t):
                    continue
                crops = e.get("blocked_crops", "all")
                if not self.strict and crops != "all":
                    blocked = bool(set(crops) & set(CROPS)) if crop == "general" else crop in crops
                    if not blocked:
                        continue
            seen.add(name)
            out.append({"name": name, "status": status, "matched": alias, "rule": e.get("rule") or e.get("list", "")})
        return out


# ------------------------------------------------------------------------------------------------ targets
_SING_KEEP = ("ss", "us", "is", "ps", "sis")


def singular(w):
    if w in ("thrips", "virus", "series", "species", "bakanae", "rabies"):
        return w
    if w.endswith("ies") and len(w) > 4:
        return w[:-3] + "y"
    if w.endswith("s") and len(w) > 3 and not w.endswith(_SING_KEEP):
        return w[:-1]
    return w


def app_disease_ids(repo=REPO_DIR):
    """Disease ids the app already uses: brain/advice.json keys + android/doctor_kb.json names (minus *_healthy)."""
    ids = set()
    adv = Path(repo) / "brain" / "advice.json"
    if adv.exists():
        ids.update(load_json(adv).get("advice", {}).keys())
    kb = Path(repo) / "android" / "doctor_kb.json"
    if kb.exists():
        ids.update(n for n in load_json(kb).get("names", []) if not n.endswith("_healthy"))
    return ids


class Targets:
    def __init__(self, path=TARGETS_JSON, repo=REPO_DIR):
        data = load_json(path)
        self.app_ids = set(data.get("app_disease_ids", [])) | app_disease_ids(repo)
        self.canonical = {c: set(v.get("pests", [])) | set(v.get("diseases", [])) for c, v in data["canonical"].items()}
        for t in self.app_ids:
            self.canonical.setdefault(t.split("_")[0], set()).add(t)
        self.aliases = {k: v for k, v in data.get("aliases", {}).items()}
        self.expand_map = data.get("expand", {})
        self.generic = set(data.get("generic", []))
        self.names = data.get("names", {})

    def known(self, crop):
        return sorted(self.canonical.get(crop, ()))

    def display(self, target):
        if target in self.names:
            return self.names[target]
        return target.split("_", 1)[1].replace("_", " ") if "_" in target else target

    def _candidates(self, s, crop):
        out = [s]
        t = s
        changed = True
        while changed:
            changed = False
            for suf in ("_disease", "_diseases", "_pest", "_pests", "_infestation", "_attack", "_damage", "_management",
                        "_control", "_incidence", "_problem", "_complex_disease"):
                if t.endswith(suf) and len(t) > len(crop) + 1 + len(suf):
                    t = t[: -len(suf)]
                    changed = True
        out.append(t)
        parts = t.split("_")
        sing = singular(parts[-1])
        if sing != parts[-1]:
            out.append("_".join(parts[:-1] + [sing]))
        seen, res = set(), []
        for x in out:
            if x not in seen:
                seen.add(x)
                res.append(x)
        return res

    def normalize(self, raw, crop):
        """Teacher target string -> ([canonical ids], note). [] = no target (null / generic / other crop / invalid)."""
        if raw is None or crop not in CROPS:
            return [], "none"
        s = str(raw).strip().lower()
        if s in ("", "null", "none", "n/a", "na", "-", "general", "all"):
            return [], "none"
        s = re.sub(r"[^a-z0-9]+", "_", s).strip("_")
        for a, b in (("chili_", "chilli_"), ("chillies_", "chilli_"), ("chilies_", "chilli_"), ("paddy_", "rice_"),
                     ("peanut_", "groundnut_"), ("tomatoes_", "tomato_"), ("groundnuts_", "groundnut_")):
            if s.startswith(a):
                s = b + s[len(a):]
        first = s.split("_", 1)[0]
        if first in CROPS and first != crop:
            return [], f"other_crop:{s}"
        if first not in CROPS:
            s = f"{crop}_{s}"
        cands = self._candidates(s, crop)
        for c in cands:
            if c in self.expand_map:
                return list(self.expand_map[c]), "expanded"
            if c in self.aliases:
                return [self.aliases[c]], "alias"
            if c in self.canonical.get(crop, ()):
                return [c], "known"
        s2 = cands[-1]
        rest = s2[len(crop) + 1:]
        if not rest or any(c[len(crop) + 1:] in self.generic for c in cands):
            return [], f"generic:{s}"
        if not TARGET_RE.match(s2) or len(rest) > 40:
            return [], f"bad:{s}"
        return [s2], "new"


# ------------------------------------------------------------------------------------------------ sources
def load_sources(path=SOURCES_JSON):
    data = load_json(path)
    rows = data["sources"] if isinstance(data, dict) else data
    ids = [r["id"] for r in rows]
    if len(set(ids)) != len(ids):
        raise ValueError(f"{path}: duplicate source ids")
    for r in rows:
        for k in ("id", "crop", "title", "publisher", "url", "format", "topics_covered", "licence_note"):
            if k not in r:
                raise ValueError(f"{path}: source {r.get('id')} misses {k}")
    return rows


# ------------------------------------------------------------------------------------------------ facts
def group_of(f):
    return f["target"] if f.get("target") else f["topic"]


def fact_errors(f):
    """Same checks as factlm/facts_lib.fact_errors (SCHEMA.md) plus the 30-word limit on English."""
    e = []
    for k in ["id", "crop", "topic", "target", "kind", "requires_confirmed", "text", "source", "order", "review"]:
        if k not in f:
            e.append(f"missing field {k}")
    if e:
        return e
    fid = f["id"]
    if not isinstance(fid, str) or not ID_RE.match(fid):
        e.append(f"bad id {fid!r}")
    else:
        p = fid.split(".")
        if p[0] != f["crop"]:
            e.append("id crop part != crop")
        if p[1] != (f["target"] if f["target"] is not None else f["topic"]):
            e.append("id second part != target/topic")
        if p[2] not in KINDS + SEED_CATS:
            e.append("bad id kind part")
    if f["crop"] not in CROPS_ALL:
        e.append(f"crop {f['crop']!r}")
    if f["topic"] not in TOPICS:
        e.append(f"topic {f['topic']!r}")
    if f["target"] is not None and not (isinstance(f["target"], str) and re.match(r"^[a-z0-9_]+$", f["target"])):
        e.append(f"bad target {f['target']!r}")
    if f["kind"] not in KINDS:
        e.append(f"kind {f['kind']!r}")
    if not isinstance(f["requires_confirmed"], bool):
        e.append("requires_confirmed not bool")
    elif f["kind"] == "dose" and not f["requires_confirmed"]:
        e.append("dose without requires_confirmed")
    t = f["text"]
    if not isinstance(t, dict):
        e.append("text not an object")
    else:
        for L in LANGS:
            if not isinstance(t.get(L), str) or not t[L].strip():
                e.append(f"text.{L} missing")
    s = f["source"]
    if not isinstance(s, dict):
        e.append("source not an object")
    else:
        for k in ["doc", "url", "page", "quote"]:
            if k not in s:
                e.append(f"source.{k} missing")
        if not isinstance(s.get("quote"), str) or not s.get("quote", "").strip():
            e.append("source.quote empty")
    if not isinstance(f["order"], int) or isinstance(f["order"], bool):
        e.append("order not int")
    if f["review"] not in REVIEW:
        e.append(f"review {f['review']!r}")
    return e


class IdRegistry:
    """Persistent content-key -> fact id map (work/id_registry.json).

    - the same fact (same source, quote, crop, group, kind and English text) always gets the same id;
    - a reworded fact (text similarity >= fuzzy) in the same crop/group/kind reuses its old id;
    - ids are never renumbered or reused for a different fact; ids in `reserved` (seed facts) are never assigned.
    """

    def __init__(self, path, fuzzy=0.9):
        self.path = Path(path)
        data = load_json(self.path, {"version": 1, "entries": {}})
        self.entries = data.get("entries", {})
        self.fuzzy = fuzzy
        self.reserved = set()
        self.used_now = set()
        self.max_n = defaultdict(int)
        self.by_prefix = defaultdict(list)
        for k, e in self.entries.items():
            self._index(k, e)
        self.stats = Counter()

    def _index(self, k, e):
        pre, n = e["id"].rsplit(".", 1)
        self.max_n[pre] = max(self.max_n[pre], int(n))
        self.by_prefix[pre].append(k)

    def reserve(self, ids):
        for i in ids:
            self.reserved.add(i)
            pre, n = i.rsplit(".", 1)
            if n.isdigit():
                self.max_n[pre] = max(self.max_n[pre], int(n))

    def assign(self, key, prefix, en):
        e = self.entries.get(key)
        if e and e["id"].rsplit(".", 1)[0] == prefix and e["id"] not in self.used_now and e["id"] not in self.reserved:
            fid = e["id"]
            self.stats["kept"] += 1
        else:
            best = None
            for k2 in self.by_prefix.get(prefix, ()):
                e2 = self.entries[k2]
                if e2["id"] in self.used_now or e2["id"] in self.reserved:
                    continue
                s = text_sim(en, e2.get("en", ""))
                if s >= self.fuzzy and (best is None or s > best[0]):
                    best = (s, e2["id"])
            if best:
                fid = best[1]
                self.stats["fuzzy"] += 1
            else:
                self.max_n[prefix] += 1
                fid = f"{prefix}.{self.max_n[prefix]}"
                self.stats["new"] += 1
            self.entries[key] = {"id": fid, "en": en}
            self._index(key, self.entries[key])
        self.entries[key]["en"] = en
        self.used_now.add(fid)
        return fid

    def save(self):
        write_json(self.path, {"version": 1, "note": "content key -> fact id; never delete entries (ids must stay stable)",
                               "entries": self.entries})


def fact_key(source_id, quote, crop, group, kind, en):
    return sha1("|".join([source_id or "", loose(quote or ""), crop, group, kind, loose(en or "")]))[:20]
