#!/usr/bin/env bash
# Run the Krishi Doctor fact pipeline on the GPU VM.
# The teacher must already be served by llama-server (OpenAI-compatible) at $TEACHER_URL (default http://127.0.0.1:8080/v1);
# see krishi/facts/README.md for the llama-server command.
#
#   bash krishi/facts/run_vm.sh setup       # apt/pip dependencies (poppler-utils, aiohttp, pdfplumber, bs4, lxml)
#   bash krishi/facts/run_vm.sh check       # teacher health + one JSON call + throughput bench (16 requests)
#   bash krishi/facts/run_vm.sh dry         # small end-to-end run (~10-20 min) into work/dry, to check outputs + speed
#   bash krishi/facts/run_vm.sh all         # fetch -> extract -> translate -> merge -> questions (+ validation)
#   bash krishi/facts/run_vm.sh <stage>     # fetch | extract | translate | merge | names | lexicon | questions | validate
#
# Every stage is resumable: re-running it re-uses the teacher cache (work/cache/teacher), so finished prompts are
# never sent twice. Environment overrides: TEACHER_URL, WORK, PYTHON, TARGET_TOTAL, SOURCES, TEACHER_FLAGS (e.g. "--no-think").
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(dirname "$HERE")"
PY="${PYTHON:-python3}"
URL="${TEACHER_URL:-http://127.0.0.1:8080/v1}"
WORK="${WORK:-$HERE/work}"
TARGET_TOTAL="${TARGET_TOTAL:-60000}"
SOURCES="${SOURCES:-$HERE/sources.json}"
TFLAGS=(--teacher-url "$URL" ${TEACHER_FLAGS:-})
mkdir -p "$WORK/logs"
LOG="$WORK/logs/run_vm.log"

say() { echo "=== $* ($(date '+%F %T'))" | tee -a "$LOG"; }
run() { say "$*"; "$@" 2>&1 | tee -a "$LOG"; return "${PIPESTATUS[0]}"; }

validate() {
  local facts="$1" qdir="$2"
  if [[ -f "$REPO/factlm/facts_lib.py" ]]; then
    run "$PY" "$REPO/factlm/facts_lib.py" validate-facts "$facts"
    for f in "$qdir"/train.jsonl "$qdir"/val.jsonl "$qdir"/zeroshot.jsonl; do
      if [[ -f "$f" ]]; then run "$PY" "$REPO/factlm/facts_lib.py" validate-questions --facts "$facts" "$f"; fi
    done
  else
    say "factlm/facts_lib.py not found: skipping the factlm validators"
  fi
}

stage="${1:-all}"
case "$stage" in
  setup)
    if command -v apt-get >/dev/null; then sudo apt-get update -y && sudo apt-get install -y poppler-utils; fi
    run "$PY" -m pip install --upgrade -r "$HERE/requirements.txt"
    ;;
  check)
    run "$PY" "$HERE/teacher.py" ping "${TFLAGS[@]}"
    run "$PY" "$HERE/teacher.py" bench --n 16 --max-tokens 256 "${TFLAGS[@]}"
    ;;
  fetch)     run "$PY" "$HERE/fetch_sources.py" --work "$WORK" --sources "$SOURCES" ;;
  extract)   run "$PY" "$HERE/extract_facts.py" --work "$WORK" --sources "$SOURCES" "${TFLAGS[@]}" ;;
  translate) run "$PY" "$HERE/translate_facts.py" --work "$WORK" "${TFLAGS[@]}" ;;
  merge)     run "$PY" "$HERE/merge.py" --work "$WORK" --out "$HERE/facts.jsonl" --no-stub ;;
  names)     run "$PY" "$HERE/target_names.py" --facts "$HERE/facts.jsonl" --work "$WORK" "${TFLAGS[@]}" ;;
  lexicon)   run "$PY" "$HERE/lexicon.py" --facts "$HERE/facts.jsonl" --work "$WORK" "${TFLAGS[@]}" ;;
  questions) run "$PY" "$HERE/gen_questions.py" --facts "$HERE/facts.jsonl" --work "$WORK" --out-dir "$HERE/questions" \
                 --target-total "$TARGET_TOTAL" --val-total "${VAL_TOTAL:-4000}" --zs-total "${ZS_TOTAL:-4000}" "${TFLAGS[@]}" ;;
  validate)  validate "$HERE/facts.jsonl" "$HERE/questions" ;;
  dry)
    D="$WORK/dry"; mkdir -p "$D"
    run "$PY" "$HERE/fetch_sources.py" --work "$D" --sources "$SOURCES"
    run "$PY" "$HERE/extract_facts.py" --work "$D" --sources "$SOURCES" --limit 16 "${TFLAGS[@]}"
    run "$PY" "$HERE/translate_facts.py" --work "$D" --limit 40 "${TFLAGS[@]}"
    run "$PY" "$HERE/merge.py" --work "$D" --out "$D/facts.jsonl" --no-stub
    run "$PY" "$HERE/gen_questions.py" --facts "$D/facts.jsonl" --work "$D" --out-dir "$D/questions" --limit-calls 60 "${TFLAGS[@]}"
    validate "$D/facts.jsonl" "$D/questions"
    say "dry run done: inspect $D/facts.jsonl, $D/review_queue.csv, $D/questions/*.jsonl and $D/stats/*.json"
    ;;
  all)
    for s in fetch extract translate merge names lexicon questions validate; do bash "$0" "$s" || say "stage $s FAILED (continuing with the next stage)"; done
    say "all stages done: $HERE/facts.jsonl and $HERE/questions/{train,val,zeroshot}.jsonl"
    ;;
  *) echo "unknown stage: $stage"; exit 2 ;;
esac
