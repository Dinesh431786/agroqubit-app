#!/usr/bin/env python3
"""gen_questions.py (GPU VM): generate realistic farmer questions in Hindi, Tamil, Kannada and English, each
labelled with its answer y (fact ids in canonical order + a control token), for training the fact model (factlm/).

Answer units, built from facts.jsonl (SCHEMA.md answer policy; target units mirror factlm's seed oracle):
  pest/disease target   treat   -> its 'first' fact           organic -> its non-chemical actions (<= 6)
                        prevent -> its cultural actions        info    -> its info facts (<= 3)
                        dose    -> its dose facts (<= 6)       single  -> any one fact
  topic group           single, set (2-3 facts from the same source page), overview (first 4 non-chemical facts)
Negatives: out-of-scope -> ["<NOT_SURE>"]; symptom statements -> ["<ASK>"]; crop-less questions -> ["<WHICH_CROP>"].
Context variants are derived from each generated question so that y is consistent with ctx (factlm inference
constraints): a dose question without the confirmed target -> ["<CONFIRM>"]; a crop-specific question with no crop
in the text or ctx -> ["<WHICH_CROP>"]; a named crop that conflicts with ctx.crop -> ["<WHICH_CROP>"]; a pest/disease
question that does not name it while nothing is confirmed -> ["<ASK>"].

Splits (written to <out-dir>, default krishi/facts/questions/):
  train.jsonl     train prompt (styles: native / casual roman / code-mixed / short / misspelled / dialect / personas)
  val.jsonl       different prompt (phone-call openings, other personas) on the same seen facts
  zeroshot.jsonl  ~10% of the non-seed facts are held out entirely (hash of the id): every unit that touches them is
                  generated only here (train-style prompt); holdout_facts.json lists them
Teacher output checks: language/script, other-crop mentions, answer leakage (copied text or answer numbers),
length 1-40 words, de-duplication. Rows are finally validated with the same rules as factlm/facts_lib.question_errors.

Usage:
  python3 krishi/facts/gen_questions.py [--facts krishi/facts/facts.jsonl] [--target-total 60000] [--limit-calls 200]
"""
from __future__ import annotations

import argparse
import asyncio
import difflib
import functools
import random
import re
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import factlib as F  # noqa: E402
import teacher as TCH  # noqa: E402
from translate_facts import keep_terms  # noqa: E402

PROMPT_VERSION = "questions-v1"
END, ASK, NOT_SURE, WHICH_CROP, CONFIRM = F.END, F.ASK, F.NOT_SURE, F.WHICH_CROP, F.CONFIRM
CONFIRM_RATE = 0.7   # share of dose questions that also get the "not confirmed -> <CONFIRM>" ctx variant (--confirm-rate)

PERSONAS = [
    "an old farmer (about 65) who uses traditional words",
    "a young farmer (about 22) who types fast on WhatsApp and mixes in English words",
    "a woman farmer who runs the farm herself",
    "a small farmer with 1 acre who worries about cost",
    "a first-time grower of this crop",
    "an experienced farmer in a hurry",
    "a farmer's son typing for his father who is standing next to him",
    "a worried farmer whose crop looks bad",
]
VAL_PERSONAS = [
    "a farmer's daughter calling for her father",
    "a self-help-group woman leader asking for her group",
    "a tenant farmer who leases 2 acres",
    "a large farmer with 25 acres and hired labour",
    "a member of a farmer producer organisation",
    "a farmer calling from the field with noise around",
    "a retired soldier who started farming recently",
]
DIALECTS = {
    "hi": ["Bhojpuri-influenced Hindi (Bihar / East UP)", "Awadhi-influenced Hindi (central UP)", "Haryanvi-influenced Hindi",
           "Rajasthani/Marwari-influenced Hindi", "Bundeli (Bundelkhand)", "Chhattisgarhi-influenced Hindi", "Malwi (western MP)",
           "plain rural Hindi"],
    "ta": ["Kongu Tamil (Coimbatore / Erode)", "Madurai Tamil", "Tirunelveli Tamil", "Thanjavur delta Tamil", "Chennai Tamil",
           "plain rural Tamil"],
    "kn": ["North Karnataka Kannada (Dharwad / Belagavi)", "Kalyana Karnataka Kannada (Kalaburagi / Raichur)",
           "Mysuru / Mandya Kannada", "coastal Kannada (Udupi / Mangaluru)", "plain rural Kannada"],
    "en": ["Indian English", "simple English of a farmer with little schooling", "Indian English with a few Hindi/Tamil/Kannada farm words"],
}
SCRIPT_HOW = {
    "hi": {"native": "in Devanagari script",
           "roman": 'in Roman-script Hindi as typed on WhatsApp (e.g. "dhan me khad kab dalna hai")',
           "mixed": 'in Devanagari with some English words in English letters (e.g. "टमाटर में fertilizer कितना डालें")'},
    "ta": {"native": "in Tamil script",
           "roman": 'in Roman-script Tamil as typed on WhatsApp (e.g. "thakkali ilai surul aagudhu enna pannanum")',
           "mixed": 'in Tamil script with some English words in English letters (e.g. "தக்காளி leaf curl க்கு என்ன spray பண்ணணும்")'},
    "kn": {"native": "in Kannada script",
           "roman": 'in Roman-script Kannada as typed on WhatsApp (e.g. "tomato gida ele muduri hogide enu madbeku")',
           "mixed": 'in Kannada script with some English words in English letters (e.g. "ಟೊಮೆಟೊ leaf curl ಗೆ ಯಾವ spray ಹಾಕಬೇಕು")'},
}
PLANS = [(3, 3, 2), (4, 2, 2), (2, 4, 2), (3, 4, 1)]
TOPIC_LABEL = {"variety": "which variety to grow", "season_sowing": "sowing time, season and spacing",
               "seed_nursery": "seed, seed treatment and nursery", "land_prep": "land preparation",
               "nutrient": "manure and fertiliser", "irrigation": "irrigation and watering", "weed": "weeds and weed control",
               "pest": "insect pests", "disease": "diseases", "natural_enemy": "friendly insects and natural enemies",
               "pesticide_safety": "safe use of pesticides", "harvest_storage": "harvest, drying and storage",
               "general": "general crop care"}
NOT_SURE_CATS = ["today's mandi price of their produce", "the weather forecast for the next days", "PM-KISAN money not received",
                 "a crop loan or Kisan Credit Card", "crop insurance claim", "a sick cow, buffalo or goat", "poultry disease",
                 "wheat sowing", "cotton pink bollworm", "sugarcane", "onion storage price", "mango flowering", "banana",
                 "coconut", "fish pond", "tractor repair", "electricity for the pump", "land records / patta",
                 "MSP for paddy", "selling chilli in the market", "making tomato ketchup at home", "a government subsidy for drip",
                 "the farmer's own health", "a cricket score or film (off-topic)"]
WHICH_CROP_TOPICS = ["which variety to grow", "when to sow", "seed rate", "spacing", "fertiliser dose", "how often to irrigate",
                     "weed control", "when to harvest", "seed treatment", "nursery raising", "how to store the produce"]
SYMPTOMS = ["spots on leaves", "yellowing leaves", "curling or crinkled leaves", "holes in leaves or fruits", "small insects under leaves",
            "white powder on leaves", "wilting plants", "rotting fruits or pods", "drying tips", "stunted plants", "dead heart / white ear",
            "webbing or rolled leaves", "black or brown patches", "fruit dropping"]
EN_COMMON = set("""what how when which where why should can could would will my your you we they it this that these those are was
were does did have has having of for with from about into on in at by and or but not no yes please tell give use apply spray sprayed
fertilizer fertiliser crop crops plant plants leaf leaves disease diseases medicine seed seeds water field insect insects pest pests best
good much many time days after before sowing harvest variety varieties dose quantity per acre kg litre liter control treatment problem
help need want know also there some any more very now today i am getting got coming come small big new old sir madam brother our
yellow white black brown spots spot dry drying rot rotting the a an thing things make take get put all every should must right
correct proper method way kind sort tell me him her them its their then than so too here going doing""".split())
# tokens that are also everyday words in romanised Hindi / Tamil / Kannada never count as English
EN_AMBIGUOUS = {"me", "to", "do", "is", "hi", "us", "pe", "par", "na", "ho", "he", "ye", "so", "man", "pan", "bin", "mat", "kal",
                "dal", "tab", "jab", "ab", "sab", "kar", "lag", "a", "i", "ok", "the", "an", "am", "ka", "ki", "ke", "le", "de"}
SAFE_CROP_WORDS = {
    "rice": ["rice", "paddy", "धान", "चावल", "dhan", "dhaan", "chawal", "நெல்", "nel", "nellu", "ಭತ್ತ", "bhatta", "batta"],
    "tomato": ["tomato", "tomatoes", "टमाटर", "tamatar", "தக்காளி", "thakkali", "takkali", "ಟೊಮೆಟೊ", "tometo"],
    "chilli": ["chilli", "chili", "chillies", "मिर्च", "mirch", "mirchi", "மிளகாய்", "milagai", "ಮೆಣಸಿನಕಾಯಿ", "menasinakayi", "menasu"],
    "groundnut": ["groundnut", "peanut", "मूंगफली", "moongfali", "mungfali", "நிலக்கடலை", "nilakadalai", "verkadalai",
                  "ಶೇಂಗಾ", "shenga", "kadalekai", "ಕಡಲೆಕಾಯಿ"],
}


# ------------------------------------------------------------------------------------------------ lexicons
class Lex:
    def __init__(self, targets):
        self.crop_words = {L: {c: list(SAFE_CROP_WORDS[c]) for c in F.CROPS} for L in F.LANGS}
        p = F.REPO_DIR / "data" / "dialect_lexicon.json"
        self.prompt_names = {L: {c: [] for c in F.CROPS} for L in F.LANGS}
        if p.exists():
            lex = F.load_json(p)
            for L in F.LANGS:
                for c in F.CROPS:
                    e = lex.get(L, {}).get(f"crop_{c}", {})
                    self.prompt_names[L][c] = (e.get("standard", []) + e.get("variants", []))[:7]
                    self.crop_words[L][c] += [w for w in e.get("standard", []) if len(w) >= 3]
        for L in F.LANGS:
            for c in F.CROPS:
                if not self.prompt_names[L][c]:
                    self.prompt_names[L][c] = SAFE_CROP_WORDS[c][:4]
        dn = F.REPO_DIR / "factlm" / "assets" / "disease_names.json"
        self.target_names = F.load_json(dn) if dn.exists() else {}
        self.T = targets

    def crops_named(self, text):
        low = F.norm_text(text).lower()
        out = set()
        for c in F.CROPS:
            for L in F.LANGS:
                for w in self.crop_words[L][c]:
                    w2 = w.lower()
                    if w2.isascii():
                        if re.search(r"(?<![a-z])" + re.escape(w2), low):
                            out.add(c)
                            break
                    elif w2 in low:
                        out.add(c)
                        break
        return out

    def target_named(self, text, target):
        low = F.norm_text(text).lower()
        names = [self.T.display(target).split("(")[0].strip().lower(), target.split("_", 1)[1].replace("_", " ")]
        for L, vs in self.target_names.get(target, {}).items():
            names += [v.lower() for v in vs if len(v) >= 4]
        return any(n and n in low for n in names)


# ------------------------------------------------------------------------------------------------ units
def seed_cat(fid):
    return fid.split(".")[2]


def y_of(facts):
    ids = [f["id"] for f in facts][:F.MAX_FACTS]
    return ids + ([END] if len(ids) < F.MAX_FACTS else [])


def build_units(facts, holdout):
    groups = defaultdict(list)
    for f in facts:
        groups[(f["crop"], F.group_of(f))].append(f)
    units = []

    def add(typ, crop, target, topic, fs):
        if not fs:
            return
        fs = sorted(fs, key=lambda f: (f["order"], f["id"]))[:F.MAX_FACTS]
        ids = [f["id"] for f in fs]
        units.append({"uid": f"{crop}.{target or topic}.{typ}.{len(units)}", "type": typ, "crop": crop, "target": target,
                      "topic": topic, "facts": fs, "y": y_of(fs), "req": any(f["requires_confirmed"] for f in fs),
                      "split": "zs" if any(i in holdout for i in ids) else "seen"})

    for (crop, grp), fs in sorted(groups.items()):
        fs = sorted(fs, key=lambda f: (f["order"], f["id"]))
        tgt = fs[0]["target"]
        topic = fs[0]["topic"]
        if tgt:
            firsts = [f for f in fs if f["kind"] == "first"]
            acts = [f for f in fs if f["kind"] == "action" and not f["requires_confirmed"]]
            prev = [f for f in acts if seed_cat(f["id"]) in ("cultural", "action")]
            infos = [f for f in fs if f["kind"] == "info" and not f["requires_confirmed"]]
            doses = [f for f in fs if f["kind"] == "dose"]
            add("treat", crop, tgt, topic, firsts[:1])
            add("organic", crop, tgt, topic, acts)
            add("prevent", crop, tgt, topic, prev)
            add("info", crop, tgt, topic, infos[:3])
            add("dose", crop, tgt, topic, doses)
            for f in fs:
                if not (f["kind"] == "first" and firsts and f is firsts[0]):
                    add("single", crop, tgt, topic, [f])
        else:
            for f in fs:
                add("single", crop, None, grp, [f])
            run = []
            for f in fs + [None]:
                same = run and f is not None and f["requires_confirmed"] == run[-1]["requires_confirmed"] \
                    and f["source"]["doc"] == run[-1]["source"]["doc"] and f["source"].get("page") == run[-1]["source"].get("page")
                if same and len(run) < 3:
                    run.append(f)
                    continue
                if len(run) >= 2:
                    add("set", crop, None, grp, run)
                run = [f] if f is not None else []
            nonreq = [f for f in fs if not f["requires_confirmed"]]
            if len(nonreq) >= 3:
                add("overview", crop, None, grp, nonreq[:4])
    return units


UNIT_WEIGHT = {"treat": 2, "dose": 2, "organic": 1, "prevent": 1, "info": 1, "single": 1, "set": 1, "overview": 2}


def about_text(u, T):
    tn = T.display(u["target"]) if u["target"] else None
    label = TOPIC_LABEL.get(u["topic"], u["topic"])
    crop = "any crop" if u["crop"] == "general" else u["crop"]
    return {"treat": f"what to do about {tn} / how to control it",
            "organic": f"a natural, organic or non-chemical way to manage {tn}",
            "prevent": f"how to prevent {tn} next time or next season",
            "info": f"what {tn} is, why it comes, how to recognise it or what damage it does",
            "dose": f"which chemical medicine to spray or apply for {tn} and how much",
            "single": f"exactly the point in the answer below (about {tn})" if tn else f"exactly the point in the answer below ({label})",
            "set": f"the points in the answer below ({label})",
            "overview": f"general guidance on {label} for {crop}"}[u["type"]]


# ------------------------------------------------------------------------------------------------ prompts
def plan_for(lang, rng, n):
    if lang == "en":
        return {"native": n, "roman": 0, "mixed": 0}
    a, b, c = rng.choice(PLANS)
    scale = n / 8
    na, nb = round(a * scale), round(b * scale)
    return {"native": na, "roman": nb, "mixed": max(0, n - na - nb)}


def write_line(lang, plan):
    if lang == "en":
        return (f"{plan['native']} messages in English: most plain, 2 very short (2-4 words), 2 with the broken spelling "
                f"and grammar of a farmer with little schooling.")
    parts = [f"{plan[s]} {SCRIPT_HOW[lang][s]}" for s in ("native", "roman", "mixed") if plan[s]]
    return "; ".join(parts) + "."


def crop_line(u, lex, lang):
    if u["crop"] == "general":
        return "CROP: any crop (do not name a crop)"
    return f"CROP: {u['crop']} | farmers say: {', '.join(lex.prompt_names[lang][u['crop']])}"


def target_line(u, lex, T, lang):
    if not u["target"]:
        return ""
    names = lex.target_names.get(u["target"], {}).get(lang, []) if lang != "en" else []
    extra = f" | local names: {', '.join(names[:3])}" if names else ""
    return f"\nPEST/DISEASE: {T.display(u['target'])}{extra}"


Q_SYSTEM = ("You write realistic messages that Indian farmers type or say to a crop-advice app on their phone. "
            "You answer with one JSON object only.")

# Static rules first, job details last: llama-server reuses each slot's cached prompt prefix (system + rules), so
# most of the prompt is not recomputed for every call.
Q_USER = """TASK: questions
Write {n} different messages that Indian farmers send to a crop-advice app on their phone. THE APP'S ANSWER (at the end) must fully answer every message.
Rules:
- Use exactly the language and scripts in PLAN and WRITE. native = the language's own script; roman = the language typed in English letters as on WhatsApp; mixed = the language's own script with a few English words in English letters.
- Vary the length: a few only 2-4 words, some long and chatty. Two of them with the spelling mistakes of fast phone typing.
- If CROP names a crop: about half must NOT name it (the app already knows it); the others name it the way farmers do. If CROP says "any crop", do not name a crop.
- If a PEST/DISEASE is given: about half must NOT name it (the app already knows it from the diagnosis); the others name it with a local farmer word.
- Ask in your own words, as the FARMER described would. Do not copy the answer and do not put its numbers or doses in the message.
- At most 25 words each.
- For each message say whether it names the crop (names_crop) and whether it names the pest/disease (names_target).
Answer with JSON only: {{"questions": [{{"q": "...", "names_crop": true, "names_target": false}}]}}

LANGUAGE: {lang_name} ({lang})
PLAN: native={pn} roman={pr} mixed={pm}
WRITE: {write}
{crop_line}{target_line}
FARMER: {persona}; dialect flavour: {dialect}
ASKS ABOUT: {about}
VARIANT: {variant}
THE APP'S ANSWER (do not copy):
<<<ANSWER
{answer}
ANSWER>>>"""

VAL_USER = """TASK: questions_val
Write {n} different first sentences of a phone call to the Kisan Call Centre. In each, the CALLER asks about the topic below, and THE ANSWER at the end must fully answer it.
Rules:
- Use exactly the language and scripts in PLAN and WRITE (native = own script; roman = typed in English letters; mixed = own script with a few English words).
- Start like real callers: a greeting or filler word, then a little context (village, acres, days since sowing), then the question. Some roundabout or unsure, some direct.
- If CROP names a crop: about half must NOT name it; if CROP says "any crop", do not name a crop. If a PEST/DISEASE is given: about half must NOT name it.
- Do not copy the answer and do not put its numbers or doses in the sentence. At most 35 words each.
- For each sentence say whether it names the crop (names_crop) and the pest/disease (names_target).
Answer with JSON only: {{"questions": [{{"q": "...", "names_crop": true, "names_target": false}}]}}

LANGUAGE: {lang_name} ({lang})
PLAN: native={pn} roman={pr} mixed={pm}
WRITE: {write}
{crop_line}{target_line}
CALLER: {persona}; dialect flavour: {dialect}
ASKS ABOUT: {about}
VARIANT: {variant}
THE ANSWER (do not copy):
<<<ANSWER
{answer}
ANSWER>>>"""

NEG_USER = """TASK: negatives
Write {n} different messages that Indian farmers send to a crop-advice app on their phone, following KIND and the instruction at the end.
Rules:
- Use exactly the language and scripts in PLAN and WRITE (native = own script; roman = typed in English letters as on WhatsApp; mixed = own script with a few English words).
- Vary the length and spelling; sound like the FARMER described. At most 25 words each.
Answer with JSON only: {{"questions": [{{"q": "...", "names_crop": false, "names_target": false}}]}}

KIND: {kind}
LANGUAGE: {lang_name} ({lang})
PLAN: native={pn} roman={pr} mixed={pm}
WRITE: {write}
{crop_line}
FARMER: {persona}; dialect flavour: {dialect}
VARIANT: {variant}
INSTRUCTION: {instruction}"""


def answer_block(u):
    return "\n".join(f"- {f['text']['en']}" for f in u["facts"])


def unit_prompt(u, job, lex, T, val=False):
    lang, rng = job["lang"], random.Random(job["seed"])
    n = job["n"]
    plan = plan_for(lang, rng, n)
    persona = rng.choice(VAL_PERSONAS if val else PERSONAS)
    dialect = rng.choice(DIALECTS[lang])
    tpl = VAL_USER if val else Q_USER
    user = tpl.format(lang_name=F.LANG_NAME[lang], lang=lang, write=write_line(lang, plan), pn=plan["native"],
                      pr=plan["roman"], pm=plan["mixed"], crop_line=crop_line(u, lex, lang),
                      target_line=target_line(u, lex, T, lang), persona=persona, dialect=dialect,
                      about=about_text(u, T), answer=answer_block(u), variant=job["variant"], n=n)
    return [{"role": "system", "content": Q_SYSTEM}, {"role": "user", "content": user}], plan


def neg_prompt(job, lex):
    lang, rng = job["lang"], random.Random(job["seed"])
    n = job["n"]
    plan = plan_for(lang, rng, n)
    kind = job["neg"]
    crop = job.get("crop")
    if kind == "not_sure":
        cats = rng.sample(NOT_SURE_CATS, 4)
        instr = (f"messages that are NOT about growing rice, tomato, chilli or groundnut, or are about things the app "
                 f"cannot know offline. Topics for this batch: {'; '.join(cats)}.")
        cl = "CROP: none"
    elif kind == "ask":
        sy = rng.sample(SYMPTOMS, 4)
        instr = (f"the farmer only DESCRIBES what they see on their {crop} plants or field ({'; '.join(sy)}), without "
                 f"asking any question and without naming any disease or pest. About half name the crop, the others do not.")
        cl = f"CROP: {crop} | farmers say: {', '.join(lex.prompt_names[lang][crop])}"
    else:
        tops = rng.sample(WHICH_CROP_TOPICS, 4)
        instr = (f"farming questions that cannot be answered without knowing the crop, about: {'; '.join(tops)}. "
                 f"Do NOT name any crop, plant, vegetable or fruit.")
        cl = "CROP: none (do not name one)"
    user = NEG_USER.format(n=n, kind=kind, lang_name=F.LANG_NAME[lang], lang=lang, write=write_line(lang, plan),
                           pn=plan["native"], pr=plan["roman"], pm=plan["mixed"], crop_line=cl,
                           persona=rng.choice(PERSONAS), dialect=rng.choice(DIALECTS[lang]), variant=job["variant"],
                           instruction=instr)
    return [{"role": "system", "content": Q_SYSTEM}, {"role": "user", "content": user}], plan


def _tobool(v):
    if isinstance(v, str):
        return v.strip().lower() in ("true", "yes", "1", "y")
    return bool(v)


def validate_qs(obj):
    if isinstance(obj, list):
        obj = {"questions": obj}
    qs = obj.get("questions") if isinstance(obj, dict) else None
    if not isinstance(qs, list) or not qs:
        raise TCH.InvalidOutput('expected {"questions": [{"q": "...", ...}]}')
    out = []
    for x in qs:
        if isinstance(x, str):
            x = {"q": x}
        if not isinstance(x, dict) or not isinstance(x.get("q"), str) or not x["q"].strip():
            continue
        out.append({"q": x["q"].strip(), "script": str(x.get("script") or ""), "names_crop": _tobool(x.get("names_crop")),
                    "names_target": _tobool(x.get("names_target"))})
    if not out:
        raise TCH.InvalidOutput("no usable questions")
    return {"questions": out}


# ------------------------------------------------------------------------------------------------ checks
def norm_q(s):
    s = F.norm_text(s).casefold()
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


@functools.lru_cache(maxsize=100000)
def name_numbers(text):
    """Numbers that are part of names (variety 'CO 51', formulation '75% WP'): not a leak when a farmer types them."""
    return frozenset(n for t in keep_terms(text) for n in F.numbers_in(t, words=False))


def check_q(q, lang, unit=None):
    """-> rejection reason or None."""
    text = q["q"]
    if len(text) < 2:
        return "too_short"
    if F.word_count(text) > 40 or len(text) > 280:
        return "too_long"
    prof = F.script_profile(text)
    if not sum(prof.values()):
        return "no_letters"
    if lang == "en":
        if set(prof) - {"latin"}:
            return "wrong_script"
    else:
        native = F.LANG_SCRIPT[lang]
        if set(prof) - {native, "latin"}:
            return "wrong_script"
        if F.detect_script(text, lang) == "roman":
            toks = [t for t in re.findall(r"[a-z']+", text.lower()) if t not in EN_AMBIGUOUS]
            if len(toks) >= 3 and sum(t in EN_COMMON for t in toks) / len(toks) >= 0.6:
                return "roman_is_english"
    if unit is not None:
        qn = F.numbers_in(F.ascii_digits(text), words=False)
        for f in unit["facts"]:
            en = f["text"]["en"]
            if qn & (F.numbers_in(en, words=False) - name_numbers(en)):
                return "leak_number"
            nq = norm_q(text)
            for t in [en] + ([f["text"].get(lang, "")] if lang != "en" else []):
                nt = norm_q(t)
                if nt and len(nq) >= 20:
                    m = difflib.SequenceMatcher(None, nq, nt, autojunk=False).find_longest_match(0, len(nq), 0, len(nt))
                    if m.size >= 25:
                        return "leak_copied"
            ct = set(F.content_tokens(en))
            if len(ct) >= 4 and len(ct & set(F.content_tokens(text))) / len(ct) >= 0.6:
                return "leak_overlap"
    return None


def constraint_errors(row, facts_by_id):
    """Same rules as factlm/facts_lib.question_errors (+ Items.allowed) for one row."""
    y, c = row["y"], row["ctx"]
    e = []
    if not y or len(set(y)) != len(y):
        return ["empty or repeated y"]
    ctrl = [k for k, x in enumerate(y) if x in F.CONTROLS]
    facts_part = [x for x in y if x not in F.CONTROLS]
    if ctrl and ctrl[0] != len(y) - 1:
        e.append("control token not last")
    if y == [END]:
        e.append("END alone")
    if len(facts_part) > F.MAX_FACTS:
        e.append("too many facts")
    if not ctrl and len(facts_part) < F.MAX_FACTS:
        e.append("missing END")
    for x in facts_part:
        f = facts_by_id.get(x)
        if f is None:
            e.append(f"unknown fact {x}")
            continue
        if c.get("crop") and f["crop"] != "general" and f["crop"] != c["crop"]:
            e.append(f"{x} masked by ctx.crop")
        elif f["requires_confirmed"] and f["target"] != c.get("target"):
            e.append(f"{x} needs confirmed target")
    if row["script"] not in F.SCRIPTS or row["lang"] not in F.LANGS:
        e.append("bad lang/script")
    return e


# ------------------------------------------------------------------------------------------------ derivation
def other_targets(units, crop, target):
    return sorted({u["target"] for u in units if u["crop"] == crop and u["target"] and u["target"] != target})


def derive(q, u, lex, rng, tgts_by_crop):
    """One validated question of unit u -> [(ctx, y, tag)] consistent with SCHEMA.md and the inference constraints."""
    named = lex.crops_named(q["q"])
    names_crop = (u["crop"] in named) or (q["names_crop"] and not named)
    names_target = bool(u["target"]) and (q["names_target"] or lex.target_named(q["q"], u["target"]))
    crop, T, y = u["crop"], u["target"], u["y"]
    out = []
    if crop == "general":   # general facts are allowed whatever the crop
        out.append(({"crop": None, "target": None}, y, "teacher"))
        c2 = next(iter(named)) if len(named) == 1 else (rng.choice(F.CROPS) if rng.random() < 0.5 else None)
        if c2:
            out.append(({"crop": c2, "target": None}, y, "teacher+ctx"))
        return out
    others = [c for c in F.CROPS if c != crop]
    if T is None:
        out.append(({"crop": crop, "target": None}, y, "teacher"))
        if names_crop:
            if rng.random() < 0.5:
                out.append(({"crop": None, "target": None}, y, "teacher+ctx"))
            if rng.random() < 0.15:
                out.append(({"crop": rng.choice(others), "target": None}, [WHICH_CROP], "teacher+ctx"))
        elif rng.random() < 0.6:
            out.append(({"crop": None, "target": None}, [WHICH_CROP], "teacher+ctx"))
        if not u["req"] and tgts_by_crop.get(crop) and rng.random() < 0.15:
            out.append(({"crop": crop, "target": rng.choice(tgts_by_crop[crop])}, y, "teacher+ctx"))
        return out
    if u["req"]:
        out.append(({"crop": crop, "target": T}, y, "teacher"))
        if rng.random() < CONFIRM_RATE:
            out.append(({"crop": crop, "target": None}, [CONFIRM], "teacher+ctx"))
        if names_target:
            if rng.random() < 0.3:
                out.append(({"crop": None, "target": None}, [CONFIRM], "teacher+ctx"))
            alt = [t for t in tgts_by_crop.get(crop, []) if t != T]
            if alt and rng.random() < 0.3:
                out.append(({"crop": crop, "target": rng.choice(alt)}, [CONFIRM], "teacher+ctx"))
        return out
    if names_target:
        out.append(({"crop": crop, "target": None}, y, "teacher"))
        if rng.random() < 0.5:
            out.append(({"crop": crop, "target": T}, y, "teacher+ctx"))
        if rng.random() < 0.3:
            out.append(({"crop": None, "target": None}, y, "teacher+ctx"))
        if names_crop and rng.random() < 0.1:
            out.append(({"crop": rng.choice(others), "target": None}, [WHICH_CROP], "teacher+ctx"))
    else:
        out.append(({"crop": crop, "target": T}, y, "teacher"))
        if rng.random() < 0.4:
            out.append(({"crop": crop, "target": None}, [ASK], "teacher+ctx"))
    return out


def derive_neg(q, job, lex, rng):
    kind = job["neg"]
    named = lex.crops_named(q["q"])
    if kind == "not_sure":
        ctx = {"crop": rng.choice(F.CROPS) if rng.random() < 0.3 else None, "target": None}
        return [(ctx, [NOT_SURE], "teacher")]
    if kind == "ask":
        crop = job["crop"]
        if named - {crop}:
            return []
        out = [({"crop": crop if rng.random() < 0.6 else None, "target": None}, [ASK], "teacher")]
        return out
    if named:
        return []
    return [({"crop": None, "target": None}, [WHICH_CROP], "teacher")]


# ------------------------------------------------------------------------------------------------ jobs
def make_jobs(units, split, n_calls, langs, per_call, round_no, seed, val=False):
    """Weighted round-robin over units; languages rotate so that each language gets the same number of calls."""
    rng = random.Random(f"{seed}:{split}:{round_no}:{val}")
    pool = []
    for u in units:
        pool += [u] * UNIT_WEIGHT.get(u["type"], 1)
    rng.shuffle(pool)
    jobs = []
    k = 0
    while len(jobs) < n_calls and pool:
        u = pool[k % len(pool)]
        rep = k // len(pool)
        lang = langs[(k + round_no) % len(langs)]
        jid = f"{split}:{'val' if val else 'q'}:{u['uid']}:{lang}:r{round_no}.{rep}"
        jobs.append({"jid": jid, "unit": u["uid"], "lang": lang, "n": per_call, "variant": f"{round_no}.{rep}",
                     "seed": int(F.sha1(jid)[:8], 16), "val": val, "split": split})
        k += 1
        if rep >= 6:
            break
    return jobs


def make_neg_jobs(n_calls, langs, per_call, round_no, seed, split="train"):
    rng = random.Random(f"{seed}:neg:{split}:{round_no}")
    kinds = ["not_sure"] * 4 + ["ask"] * 4 + ["which_crop"] * 3   # ~36% / 36% / 27% of negative calls
    jobs = []
    for k in range(n_calls):
        lang = langs[(k + round_no) % len(langs)]
        kind = kinds[k % len(kinds)]
        crop = rng.choice(F.CROPS) if kind == "ask" else None
        jid = f"{split}:neg:{kind}:{crop}:{lang}:r{round_no}.{k}"
        jobs.append({"jid": jid, "neg": kind, "crop": crop, "lang": lang, "n": per_call, "variant": f"{round_no}.{k}",
                     "seed": int(F.sha1(jid)[:8], 16), "split": split})
    return jobs


# ------------------------------------------------------------------------------------------------ main
class Collector:
    def __init__(self, facts_by_id):
        self.rows = {"train": [], "val": [], "zs": []}
        self.seen = {}
        self.rejects = Counter()
        self.reject_samples = []
        self.fbid = facts_by_id
        self.bad_constraints = 0

    def add(self, split, q, lang, ctx, y, src, meta):
        row = {"q": q, "lang": lang, "script": F.detect_script(q, lang), "ctx": ctx, "y": list(y), "src": src, "meta": meta}
        err = constraint_errors(row, self.fbid)
        if err:
            self.bad_constraints += 1
            self.rejects["constraint:" + err[0].split(" ")[-1]] += 1
            return
        key = (norm_q(q), ctx.get("crop"), ctx.get("target"), tuple(y))
        if key in self.seen:
            self.rejects["duplicate"] += 1
            return
        self.seen[key] = split
        self.rows[split].append(row)

    def reject(self, reason, q, job):
        self.rejects[reason] += 1
        if len(self.reject_samples) < 20000:
            self.reject_samples.append({"reason": reason, "q": q, "lang": job["lang"], "job": job["jid"]})


def process(results, jobs, units_by_id, lex, col, tgts_by_crop):
    for job, res in zip(jobs, results):
        if isinstance(res, Exception):
            col.rejects["teacher_failed"] += 1
            continue
        rng = random.Random(job["seed"])
        split = {"seen": "train", "zs": "zs"}.get(job["split"], job["split"])
        if job.get("val"):
            split = "val"
        for q in res["questions"]:
            if "neg" in job:
                why = check_q(q, job["lang"])
                if why:
                    col.reject(why, q["q"], job)
                    continue
                for ctx, y, tag in derive_neg(q, job, lex, rng):
                    col.add(split, q["q"], job["lang"], ctx, y, tag, {"unit": f"neg_{job['neg']}", "crop": job.get("crop")})
                continue
            u = units_by_id[job["unit"]]
            why = check_q(q, job["lang"], u)
            if not why and u["crop"] != "general" and lex.crops_named(q["q"]) - {u["crop"]}:
                why = "other_crop_named"
            if why:
                col.reject(why, q["q"], job)
                continue
            tag_val = "teacher_val" if job.get("val") else None
            for ctx, y, tag in derive(q, u, lex, rng, tgts_by_crop):
                col.add(split, q["q"], job["lang"], ctx, y, tag_val or tag,
                        {"unit": u["type"], "crop": None if u["crop"] == "general" else u["crop"], "target": u["target"]})


async def run(args, log):
    work, out_dir = Path(args.work), Path(args.out_dir)
    t0 = time.monotonic()
    facts = F.read_jsonl(args.facts)
    bad = [(f.get("id"), F.fact_errors(f)) for f in facts if F.fact_errors(f)]
    if bad:
        raise SystemExit(f"{len(bad)} invalid facts in {args.facts}, e.g. {bad[:2]}: run merge.py first")
    fbid = {f["id"]: f for f in facts}
    holdout = {f["id"] for f in facts if f["review"] != "seed" and F.stable_frac("holdout:" + f["id"]) < args.holdout}
    targets = F.Targets(args.targets)
    lex = Lex(targets)
    units = build_units(facts, holdout)
    units_by_id = {u["uid"]: u for u in units}
    seen_units = [u for u in units if u["split"] == "seen"]
    zs_units = [u for u in units if u["split"] == "zs"]
    tgts_by_crop = defaultdict(list)
    for f in facts:
        if f["target"] and f["target"] not in tgts_by_crop[f["crop"]]:
            tgts_by_crop[f["crop"]].append(f["target"])
    langs = [L for L in args.langs.split(",") if L in F.LANGS]
    log.info(f"{len(facts)} facts ({len(holdout)} held out), {len(units)} units ({len(seen_units)} seen, {len(zs_units)} "
             f"zero-shot): {dict(Counter(u['type'] for u in units))}")
    F.write_json(out_dir / "holdout_facts.json", {"fraction": args.holdout, "ids": sorted(holdout)})

    col = Collector(fbid)
    est = args.per_call * args.accept_est * args.variants_est
    neg_frac = args.neg_frac
    n_train = int(args.target_total * (1 - neg_frac) / est) + 1
    n_neg = int(args.target_total * neg_frac / (args.per_call * args.accept_est)) + 1
    n_val = int(args.val_total / est) + 1
    n_zs = int(args.zs_total / est) + 1
    if args.limit_calls:
        tot = n_train + n_neg + n_val + n_zs
        f_ = min(1.0, args.limit_calls / tot)
        n_train, n_neg, n_val, n_zs = (max(1, int(x * f_)) for x in (n_train, n_neg, n_val, n_zs))
    log.info(f"planned teacher calls: train {n_train}, negatives {n_neg}, val {n_val}, zero-shot {n_zs} "
             f"(~{est:.1f} rows per call assumed)")

    async with TCH.teacher_from_args(args, work, log) as T:
        await T.wait_ready(max_wait=args.wait, min_ctx=3000)

        def factory(job):
            if "neg" in job:
                msgs, _ = neg_prompt(job, lex)
            else:
                msgs, _ = unit_prompt(units_by_id[job["unit"]], job, lex, targets, val=job.get("val", False))
            tag = "neg" if "neg" in job else ("val" if job.get("val") else "questions")
            return lambda: T.chat_json(msgs, tag=tag, validate=validate_qs, temperature=args.temperature,
                                       max_tokens=args.max_tokens, seed=job["seed"], top_p=0.95,
                                       cache_extra=PROMPT_VERSION)

        async def run_round(jobs, label):
            res = await TCH.run_jobs([factory(j) for j in jobs], log=log, label=label)
            process(res, jobs, units_by_id, lex, col, tgts_by_crop)

        # zero-shot and val first, so that a question text that appears twice stays in the evaluation split
        if zs_units and n_zs:
            await run_round(make_jobs(zs_units, "zs", n_zs, langs, args.per_call, 0, args.seed), "zeroshot")
        if n_val:
            await run_round(make_jobs(seen_units, "seen", n_val, langs, args.per_call, 0, args.seed, val=True), "val")
        await run_round(make_neg_jobs(n_neg, langs, args.per_call, 0, args.seed), "negatives")
        rnd = 0
        jobs = make_jobs(seen_units, "seen", n_train, langs, args.per_call, rnd, args.seed)
        await run_round(jobs, f"train r{rnd}")
        while len(col.rows["train"]) < 0.9 * args.target_total and rnd < args.max_rounds - 1 and not args.limit_calls:
            rnd += 1
            have = len(col.rows["train"])
            per = max(1.0, have / max(1, len(jobs) + n_neg))
            more = int((args.target_total - have) / per) + 1
            log.info(f"train rows {have} < target {args.target_total}: round {rnd} with {more} more calls")
            jobs = make_jobs(seen_units, "seen", more, langs, args.per_call, rnd, args.seed)
            await run_round(jobs, f"train r{rnd}")
        T.log_summary("questions")
        tstats = T.save_stats(work / "stats" / "teacher_questions.json", "questions")

    # a question text used in val/zero-shot is not also used in train
    eval_q = {norm_q(r["q"]) for s in ("val", "zs") for r in col.rows[s]}
    before = len(col.rows["train"])
    col.rows["train"] = [r for r in col.rows["train"] if norm_q(r["q"]) not in eval_q]
    col.rejects["train_overlaps_eval"] += before - len(col.rows["train"])
    leak = [r for r in col.rows["train"] if any(x in holdout for x in r["y"])]
    if leak:
        raise RuntimeError(f"internal error: {len(leak)} train rows use held-out facts")
    names = {"train": "train.jsonl", "val": "val.jsonl", "zs": "zeroshot.jsonl"}
    for s, fn in names.items():
        F.write_jsonl(out_dir / fn, col.rows[s])
    F.write_jsonl(work / "rejects_questions.jsonl", col.reject_samples)

    def stats(rows):
        ytype = Counter(r["y"][0] if r["y"][0] in F.CONTROLS else ("facts_%d" % len([x for x in r["y"] if x not in F.CONTROLS]))
                        for r in rows)
        return {"rows": len(rows), "by_lang": dict(Counter(r["lang"] for r in rows)),
                "by_script": dict(Counter(f"{r['lang']}-{r['script']}" for r in rows)), "by_y": dict(ytype),
                "by_src": dict(Counter(r["src"] for r in rows)),
                "by_unit": dict(Counter((r.get("meta") or {}).get("unit") for r in rows)),
                "by_crop": dict(Counter((r.get("meta") or {}).get("crop") for r in rows)),
                "ctx_crop_null": sum(1 for r in rows if not r["ctx"]["crop"]),
                "ctx_target_set": sum(1 for r in rows if r["ctx"]["target"]),
                "facts_covered": len({x for r in rows for x in r["y"] if x not in F.CONTROLS})}
    report = {"prompt_version": PROMPT_VERSION, "facts": len(facts), "holdout_facts": len(holdout), "units": len(units),
              "splits": {s: stats(col.rows[s]) for s in names}, "rejects": dict(col.rejects.most_common()),
              "constraint_errors": col.bad_constraints, "teacher": tstats.get("total"),
              "wall_seconds": round(time.monotonic() - t0, 1)}
    F.write_json(work / "questions_report.json", report)
    F.write_json(out_dir / "questions_report.json", report)
    log.info(f"questions: train {len(col.rows['train'])}, val {len(col.rows['val'])}, zero-shot {len(col.rows['zs'])}; "
             f"rejects {dict(col.rejects.most_common(8))}")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--facts", default=str(F.FACTS_OUT))
    ap.add_argument("--work", default=str(F.DEFAULT_WORK))
    ap.add_argument("--out-dir", default=str(F.QUESTIONS_DIR))
    ap.add_argument("--targets", default=str(F.TARGETS_JSON))
    ap.add_argument("--langs", default="hi,ta,kn,en")
    ap.add_argument("--target-total", type=int, default=60000, help="train rows wanted (incl. negatives and ctx variants)")
    ap.add_argument("--val-total", type=int, default=4000)
    ap.add_argument("--zs-total", type=int, default=4000)
    ap.add_argument("--holdout", type=float, default=0.10, help="fraction of non-seed facts held out (zero-shot)")
    ap.add_argument("--neg-frac", type=float, default=0.15, help="share of train rows from negative prompts")
    ap.add_argument("--per-call", type=int, default=8, help="questions asked per teacher call")
    ap.add_argument("--accept-est", type=float, default=0.85, help="expected share of questions passing the checks")
    ap.add_argument("--variants-est", type=float, default=1.5, help="expected rows (ctx variants) per accepted question")
    ap.add_argument("--max-rounds", type=int, default=3)
    ap.add_argument("--limit-calls", type=int, default=0, help="cap the total number of teacher calls (dry run)")
    ap.add_argument("--temperature", type=float, default=0.9)
    ap.add_argument("--max-tokens", type=int, default=1200)
    ap.add_argument("--seed", type=int, default=13)
    ap.add_argument("--confirm-rate", type=float, default=0.7, help="share of dose questions that get a <CONFIRM> variant")
    TCH.add_teacher_args(ap)
    args = ap.parse_args(argv)
    global CONFIRM_RATE
    CONFIRM_RATE = args.confirm_rate
    log = F.get_logger("gen_questions", args.work)
    try:
        return asyncio.run(run(args, log))
    except TCH.TeacherUnavailable as e:
        log.error(str(e))
        return 3


if __name__ == "__main__":
    sys.exit(main())
