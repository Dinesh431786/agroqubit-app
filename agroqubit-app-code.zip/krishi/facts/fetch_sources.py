#!/usr/bin/env python3
"""fetch_sources.py (GPU VM or any machine with internet): download every source in sources.json and extract the
text of each page into <work>/pages.jsonl.

- Downloads are cached in <work>/raw/ (named by URL hash; two sources with the same URL share one download).
  A file placed at <work>/raw/manual/<source_id>.pdf (or .html) is used instead of downloading: use it for sites
  that block scripts or have broken TLS chains (open the URL in a browser, save the file there, re-run).
- PDF: poppler `pdftotext` per page in two modes, reading order ('text') and `-layout` ('text_layout'). The
  verbatim-quote check later accepts a quote found in either. pdfplumber is the fallback if pdftotext fails.
- Page selection (sources.json "select"): {"book_pages": [a, b]} uses printed page numbers (the PDF offset is
  detected from page headers/footers), {"pdf_pages": "3-40,45"} uses PDF page indexes, {"keywords": [...]} keeps
  pages with enough keyword hits (also the fallback when printed numbers cannot be detected).
- HTML: scripts/styles/navigation removed, table rows joined with ' | ', split into parts of ~4000 characters.
- If a source fails, its "fallbacks" (another URL/format) are tried; failures are logged and the others continue.

Usage:
  python3 krishi/facts/fetch_sources.py [--work krishi/facts/work] [--only id1,id2] [--force]
Outputs: <work>/pages.jsonl, <work>/fetch_manifest.json, <work>/logs/fetch_sources.log
"""
from __future__ import annotations

import argparse
import hashlib
import os
import re
import shutil
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import factlib as F  # noqa: E402

UA = "Mozilla/5.0 (X11; Linux x86_64) KrishiDoctor-fact-pipeline/1.0 (offline farmer helpline; contact via KVK)"


# ------------------------------------------------------------------------------------------------ download
def download(url, dest, log, timeout=180, max_mb=150, ca_bundle=None, retries=4):
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
    s = requests.Session()
    s.headers.update({"User-Agent": UA, "Accept": "application/pdf,text/html;q=0.9,*/*;q=0.8"})
    retry = Retry(total=retries, connect=retries, read=retries, backoff_factor=2,
                  status_forcelist=[429, 500, 502, 503, 504], allowed_methods=["GET"])
    s.mount("https://", HTTPAdapter(max_retries=retry))
    s.mount("http://", HTTPAdapter(max_retries=retry))
    t0 = time.monotonic()
    with s.get(url, stream=True, timeout=(30, timeout), verify=ca_bundle or True, allow_redirects=True) as r:
        r.raise_for_status()
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name + ".part")
        n = 0
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                n += len(chunk)
                if n > max_mb * 1_000_000:
                    raise RuntimeError(f"larger than {max_mb} MB")
                f.write(chunk)
        os.replace(tmp, dest)
        log.info(f"downloaded {url} -> {dest.name} ({n / 1e6:.2f} MB, {time.monotonic() - t0:.1f}s)")
        return {"bytes": n, "content_type": r.headers.get("content-type", ""), "final_url": r.url}


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def sniff(path):
    with open(path, "rb") as f:
        head = f.read(2048)
    if head.startswith(b"%PDF") or b"%PDF-" in head[:1024]:
        return "pdf"
    low = head.lower()
    if b"<html" in low or b"<!doctype html" in low or b"<head" in low or b"<body" in low:
        return "html"
    return "unknown"


# ------------------------------------------------------------------------------------------------ PDF
def pdf_pages(path, log):
    """-> (pages_text, pages_layout, tool). pdftotext splits pages with form feeds."""
    if shutil.which("pdftotext"):
        try:
            outs = []
            for layout in (False, True):
                cmd = ["pdftotext", "-enc", "UTF-8"] + (["-layout"] if layout else []) + [str(path), "-"]
                res = subprocess.run(cmd, capture_output=True, timeout=900, check=True)
                pages = res.stdout.decode("utf-8", "replace").split("\f")
                if pages and not pages[-1].strip():
                    pages = pages[:-1]
                outs.append(pages)
            if len(outs[0]) == len(outs[1]) and len(outs[0]) > 0:
                return outs[0], outs[1], "pdftotext"
            log.warning(f"{path.name}: pdftotext page counts differ ({len(outs[0])} vs {len(outs[1])}); using pdfplumber")
        except Exception as e:
            log.warning(f"{path.name}: pdftotext failed ({e}); using pdfplumber")
    import pdfplumber
    t, lay = [], []
    with pdfplumber.open(str(path)) as pdf:
        for p in pdf.pages:
            t.append(p.extract_text() or "")
            try:
                lay.append(p.extract_text(layout=True) or "")
            except Exception:
                lay.append(t[-1])
    return t, lay, "pdfplumber"


_PNUM = [re.compile(r"^(?:page\s*)?[-–—(\[|]?\s*(\d{1,4})\s*[-–—)\]|]?$", re.I),
         re.compile(r"^(\d{1,4})\s{2,}\S"), re.compile(r"\S\s{2,}(\d{1,4})$")]


def printed_number(page_text):
    """Printed page number from the first/last lines of a page (layout text), or None."""
    lines = [ln.strip() for ln in page_text.splitlines() if ln.strip()]
    for ln in lines[:2] + lines[-2:]:
        for rx in _PNUM:
            m = rx.search(ln)
            if m:
                n = int(m.group(1))
                if 0 < n < 2000:
                    return n
    return None


def detect_offset(pages_layout):
    """pdf_index - printed_number, by majority vote over pages with a detectable number."""
    diffs = Counter()
    found = 0
    for i, t in enumerate(pages_layout, 1):
        n = printed_number(t)
        if n is not None:
            found += 1
            diffs[i - n] += 1
    if not diffs:
        return None, {"detected": 0}
    off, votes = diffs.most_common(1)[0]
    ok = votes >= 3 and votes >= 0.3 * found
    return (off if ok else None), {"detected": found, "votes": votes, "offset": off, "pages": len(pages_layout)}


def strip_running_lines(pages_text, pages_layout, min_pages=3):
    """Remove running headers/footers (a short line among the first/last 2 lines of >= 40% of the pages, digits
    ignored) and bare page-number lines, from both text versions. Saves teacher tokens and avoids facts made of page
    headers."""
    def key(ln):
        return re.sub(r"\d+", "#", re.sub(r"\s+", " ", ln.strip().lower()))

    def edges(t):
        lines = [ln for ln in t.splitlines() if ln.strip()]
        return lines[:2] + lines[-2:]
    n = len(pages_text)
    cnt = Counter()
    for t in pages_layout:
        cnt.update({key(ln) for ln in edges(t) if len(ln.split()) <= 12})
    running = {k for k, c in cnt.items() if c >= max(min_pages, 0.4 * n) and len(k) > 2}

    def clean(t):
        lines = t.splitlines()
        idx = [i for i, ln in enumerate(lines) if ln.strip()]
        edge = set(idx[:2] + idx[-2:])
        keep = [ln for i, ln in enumerate(lines)
                if not (i in edge and (key(ln) in running or re.fullmatch(r"\s*[-–(\[]?\s*\d{1,4}\s*[-–)\]]?\s*", ln)))]
        return "\n".join(keep)
    if n < min_pages:
        running = set()
    return [clean(t) for t in pages_text], [clean(t) for t in pages_layout], sorted(running)


def parse_ranges(spec, n):
    out = []
    for part in str(spec).split(","):
        part = part.strip()
        if not part:
            continue
        a, _, b = part.partition("-")
        a = int(a)
        b = int(b) if b else a
        out.extend(range(max(1, a), min(n, b) + 1))
    return sorted(set(out))


def keyword_hits(text, kws):
    low = text.lower()
    return sum(len(re.findall(r"\b" + re.escape(k.lower()), low)) for k in kws)


def select_pages(pages_text, pages_layout, sel, log, sid):
    n = len(pages_text)
    allp = list(range(1, n + 1))
    if not sel:
        return allp, {"method": "all"}
    if sel.get("pdf_pages"):
        return parse_ranges(sel["pdf_pages"], n), {"method": "pdf_pages", "spec": sel["pdf_pages"]}
    kws = sel.get("keywords") or []
    if sel.get("book_pages"):
        a, b = sel["book_pages"]
        if sel.get("book_page_offset") is not None:
            off, info = int(sel["book_page_offset"]), {"configured": True}
        else:
            off, info = detect_offset(pages_layout)
        if off is not None:
            chosen = [i for i in allp if a + off <= i <= b + off]
            info.update({"method": "book_pages", "book_pages": [a, b], "offset": off})
            if kws and chosen:
                hit = sum(1 for i in chosen if keyword_hits(pages_text[i - 1], kws) > 0)
                info["keyword_pages"] = hit
                if hit < 0.3 * len(chosen):
                    log.warning(f"{sid}: only {hit}/{len(chosen)} selected pages mention {kws}: check the page offset "
                                f"(set select.book_page_offset or select.pdf_pages in sources.json)")
            if chosen:
                return chosen, info
        log.warning(f"{sid}: printed page numbers not detected ({info}); falling back to keyword selection")
    if kws:
        mh = int(sel.get("min_hits", 2))
        chosen = [i for i in allp if keyword_hits(pages_text[i - 1], kws) >= mh]
        return chosen, {"method": "keywords", "keywords": kws, "min_hits": mh}
    return allp, {"method": "all"}


# ------------------------------------------------------------------------------------------------ HTML
def html_parts(data, max_chars=4000):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(data, "lxml")
    for t in soup(["script", "style", "noscript", "header", "footer", "nav", "aside", "form", "iframe", "svg", "button"]):
        t.decompose()
    main = soup.find("main") or soup.find("article") or soup.find(id=re.compile("content", re.I)) or soup.body or soup
    for tr in list(main.find_all("tr")):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
        tr.replace_with(soup.new_string("\n" + " | ".join(c for c in cells if c) + "\n"))
    for br in main.find_all("br"):
        br.replace_with("\n")
    text = main.get_text("\n")
    paras, cur = [], []
    for ln in text.splitlines():
        ln = re.sub(r"[ \t ]+", " ", ln).strip()
        if ln:
            cur.append(ln)
        elif cur:
            paras.append("\n".join(cur))
            cur = []
    if cur:
        paras.append("\n".join(cur))
    parts, buf = [], ""
    for p in paras:
        if buf and len(buf) + len(p) + 2 > max_chars:
            parts.append(buf)
            buf = ""
        while len(p) > max_chars:  # very long paragraph: split at a line break
            cut = p.rfind("\n", 0, max_chars)
            cut = cut if cut > max_chars // 2 else max_chars
            parts.append(p[:cut])
            p = p[cut:].lstrip()
        buf = f"{buf}\n\n{p}" if buf else p
    if buf:
        parts.append(buf)
    return parts


# ------------------------------------------------------------------------------------------------ main
def fetch_one(src, fmt, url, work, args, log):
    raw = Path(work) / "raw"
    manual = None
    for ext in ("pdf", "html", "htm"):
        p = raw / "manual" / f"{src['id']}.{ext}"
        if p.exists():
            manual = p
    if manual:
        log.info(f"{src['id']}: using manual file {manual}")
        path, meta = manual, {"manual": True}
    else:
        path = raw / f"{F.sha1(url)[:12]}.{'pdf' if fmt == 'pdf' else 'html'}"
        meta = {}
        if args.force or not path.exists() or path.stat().st_size == 0:
            meta = download(url, path, log, timeout=args.timeout, max_mb=args.max_mb, ca_bundle=args.ca_bundle)
        else:
            log.info(f"{src['id']}: cached {path.name}")
    kind = sniff(path)
    if fmt == "pdf" and kind != "pdf":
        raise RuntimeError(f"expected a PDF but got {kind} (an error page?): {path}")
    meta.update({"file": str(path), "sha256": sha256_file(path), "format": kind})
    rows = []
    if kind == "pdf":
        pt, pl, tool = pdf_pages(path, log)
        chosen, sel = select_pages(pt, pl, src.get("select"), log, src["id"])
        printed = [printed_number(t) for t in pl]
        pt, pl, running = strip_running_lines(pt, pl)
        meta.update({"tool": tool, "pages_total": len(pt), "selection": sel, "running_lines_removed": running[:10]})
        for i in chosen:
            t, lay = pt[i - 1], pl[i - 1]
            letters = sum(ch.isalpha() for ch in t)
            lines = [ln for ln in lay.splitlines() if ln.strip()]
            tab = sum(1 for ln in lines if len(re.findall(r"\S\s{3,}\S", ln)) >= 2)
            rows.append({"source_id": src["id"], "crop": src["crop"], "page": i, "book_page": printed[i - 1],
                         "kind": "pdf", "text": t, "text_layout": lay, "chars": len(t), "empty": letters < 40,
                         "tabular": tab >= max(5, 0.3 * len(lines))})
    else:
        data = open(path, "rb").read()
        parts = html_parts(data, args.html_chars)
        meta.update({"tool": "bs4", "pages_total": len(parts), "selection": {"method": "all"}})
        for i, t in enumerate(parts, 1):
            rows.append({"source_id": src["id"], "crop": src["crop"], "page": i, "book_page": None, "kind": "html",
                         "text": t, "text_layout": t, "chars": len(t), "empty": sum(ch.isalpha() for ch in t) < 40,
                         "tabular": False})
    empty = sum(r["empty"] for r in rows)
    meta.update({"pages_selected": len(rows), "pages_empty": empty, "chars": sum(r["chars"] for r in rows)})
    if rows and empty > 0.5 * len(rows):
        log.warning(f"{src['id']}: {empty}/{len(rows)} pages have almost no text (scanned PDF?). OCR is not done here; "
                    "put an OCRed PDF in raw/manual/ or drop the source")
    return rows, meta


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sources", default=str(F.SOURCES_JSON))
    ap.add_argument("--work", default=str(F.DEFAULT_WORK))
    ap.add_argument("--only", default="", help="comma-separated source ids")
    ap.add_argument("--force", action="store_true", help="download again even if cached")
    ap.add_argument("--timeout", type=float, default=180)
    ap.add_argument("--max-mb", type=float, default=150)
    ap.add_argument("--html-chars", type=int, default=4000)
    ap.add_argument("--ca-bundle", default=None, help="CA bundle for sites with incomplete certificate chains")
    ap.add_argument("--strict", action="store_true", help="exit 1 if any source fails")
    args = ap.parse_args(argv)
    work = Path(args.work)
    log = F.get_logger("fetch_sources", work)
    sources = [s for s in F.load_sources(args.sources) if s.get("extract", True)]
    if args.only:
        keep = set(args.only.split(","))
        sources = [s for s in sources if s["id"] in keep]
    out_rows, manifest, failed = [], {}, []
    for src in sources:
        tries = [(src.get("format", "pdf"), src["url"], None)] + \
                [(fb.get("format", "html"), fb["url"], fb.get("select")) for fb in src.get("fallbacks", [])]
        last = None
        for k, (fmt, url, fsel) in enumerate(tries):
            s2 = dict(src)
            if k > 0:
                s2["select"] = fsel
            try:
                rows, meta = fetch_one(s2, fmt, url, work, args, log)
                if not rows:
                    raise RuntimeError("no pages selected")
                meta.update({"url": url, "fallback": k > 0, "status": "ok"})
                for r in rows:
                    r["url"] = url
                out_rows.extend(rows)
                manifest[src["id"]] = meta
                log.info(f"{src['id']}: {meta['pages_selected']} pages/parts from {url} "
                         f"({meta['chars']} chars, selection {meta.get('selection', {}).get('method')})")
                last = None
                break
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
                log.error(f"{src['id']}: {url} failed: {last}")
        if last:
            failed.append(src["id"])
            manifest[src["id"]] = {"status": "failed", "error": last, "url": src["url"]}
    F.write_jsonl(work / "pages.jsonl", out_rows)
    F.write_json(work / "fetch_manifest.json", manifest)
    ok = len(sources) - len(failed)
    log.info(f"done: {ok}/{len(sources)} sources, {len(out_rows)} pages -> {work / 'pages.jsonl'}"
             + (f"; FAILED: {', '.join(failed)} (see README: manual download)" if failed else ""))
    if failed and (args.strict or ok == 0):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
