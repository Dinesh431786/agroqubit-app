#!/usr/bin/env python3
"""mock_teacher.py: deterministic stand-in for the teacher LLM, used by the local tests of every stage.

MockBrain answers the pipeline prompts (TASK: extract_facts / translate / translate_fix / back_translate / questions /
questions_val / negatives) with plausible JSON built from the prompt itself, and injects the faults the real run must
survive:
  transport  HTTP 500, a reply slower than the client timeout, invalid / truncated JSON, JSON wrapped in prose
  extract    a fabricated quote, a number that is not in the quote, a near-duplicate (banned pesticides come from the
             test text itself)
  translate  a translation that drops a number (fixed on re-ask), a weak back-translation (low similarity flag)
  questions  an answer copied into the question, wrong-script Kannada (Telugu letters), English typed as 'roman Hindi'
Faults happen only on the first attempt of a prompt, so retries/re-asks succeed and runs stay deterministic.

serve(): OpenAI-compatible HTTP server (/health, /v1/models, /props, /v1/chat/completions) in a thread.
stub_transport(): in-process transport for teacher.Teacher(transport=...).
CLI: python3 krishi/facts/mock_teacher.py --port 8099 [--no-faults]
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import re
import sys
import threading
import time
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import factlib as F  # noqa: E402

TOPIC_RULES = [
    ("pesticide_safety", r"\b(gloves?|mask|protective|empty containers?|wash (?:hands|face)|poison|label|safety)\b"),
    ("natural_enemy", r"\b(parasitoids?|predators?|trichogramma|natural enem|spiders?|coccinellid|lady bird)\b"),
    ("variety", r"\b(variet|hybrids?|cultivars?)\w*"),
    ("weed", r"\b(weeds?|weeding|herbicide|pretilachlor|pendimethalin)\b"),
    ("pest", r"\b(borers?|hoppers?|planthopper|aphids?|whitefl|thrips|mites?|caterpillars?|insects?|midge|bugs?|hispa|nematodes?|egg masses)\b"),
    ("disease", r"\b(blight|blast|spots?|rot|wilt|mosaic|curl|mildew|diseases?|virus)\b"),
    ("seed_nursery", r"\b(seeds?|nursery|seedlings?)\b"),
    ("land_prep", r"\b(plough|ploughing|puddl\w*|land preparation|field preparation)\b"),
    ("nutrient", r"\b(fertili[sz]\w*|manure|fym|urea|nitrogen|npk|zinc|gypsum|potash)\b"),
    ("irrigation", r"\b(irrigat\w*|water level|drain\w*)\b"),
    ("season_sowing", r"\b(sow\w*|season|spacing|transplant\w*)\b"),
    ("harvest_storage", r"\b(harvest\w*|storage|store|dry(?:ing)?|moisture)\b"),
]
TARGET_RULES = [  # how a teacher might name a target (aliases are resolved by factlib.Targets)
    (r"stem borer", "Yellow stem borer"), (r"brown planthopper|\bbph\b", "BPH"), (r"leaf folder", "rice_leaf_folder"),
    (r"blast", "rice_blast"), (r"fruit borer", "tomato_fruit_borer"), (r"whitefl", "whiteflies"),
    (r"early blight", "early blight"), (r"leaf curl", "Tomato leaf curl virus"), (r"tikka|leaf spot", "Tikka disease"),
    (r"thrips", "thrips"), (r"aphid", "aphids"), (r"sucking", "sucking pests"),
]
VERBS = ("apply", "spray", "use", "remove", "release", "install", "keep", "avoid", "sow", "transplant", "irrigate",
         "harvest", "dry", "store", "grow", "collect", "destroy", "plough", "maintain", "drain", "treat", "wear", "wash",
         "give", "raise", "set", "pull", "do not", "don't")
CROP_WORDS = {
    "hi": {"rice": ("धान", "dhan"), "tomato": ("टमाटर", "tamatar"), "chilli": ("मिर्च", "mirch"), "groundnut": ("मूंगफली", "moongfali")},
    "ta": {"rice": ("நெல்", "nel"), "tomato": ("தக்காளி", "thakkali"), "chilli": ("மிளகாய்", "milagai"), "groundnut": ("நிலக்கடலை", "nilakadalai")},
    "kn": {"rice": ("ಭತ್ತ", "bhatta"), "tomato": ("ಟೊಮೆಟೊ", "tometo"), "chilli": ("ಮೆಣಸಿನಕಾಯಿ", "menasinakayi"), "groundnut": ("ಶೇಂಗಾ", "shenga")},
    "en": {"rice": ("paddy", "paddy"), "tomato": ("tomato", "tomato"), "chilli": ("chilli", "chilli"), "groundnut": ("groundnut", "groundnut")},
}
FILL = {
    "hi": ["भाई", "जी", "साहब", "जल्दी", "अभी", "इस बार", "हमारे खेत में", "पिछले साल भी", "बताइए", "कृपया", "यार", "सुनिए"],
    "ta": ["அண்ணா", "சார்", "இப்போ", "இந்த தடவை", "எங்க வயல்ல", "போன வருஷமும்", "சொல்லுங்க", "கொஞ்சம்", "ஐயா", "அம்மா"],
    "kn": ["ಅಣ್ಣಾ", "ಸಾರ್", "ಈಗ", "ಈ ಸಲ", "ನಮ್ಮ ಹೊಲದಾಗ", "ಹೋದ ವರ್ಷನೂ", "ಹೇಳ್ರಿ", "ಸ್ವಲ್ಪ", "ಯಪ್ಪಾ", "ರೀ"],
    "en": ["sir", "please", "urgent", "this time", "in my field", "last year also", "brother", "kindly", "now", "help"],
}
ROMAN_FILL = {"hi": ["bhai", "ji", "sahab", "jaldi", "abhi", "is baar", "batao", "yaar", "suniye", "kripya"],
              "ta": ["anna", "sir", "ippo", "indha thadavai", "sollunga", "konjam", "ayya", "amma", "vayal la", "sekiram"],
              "kn": ["anna", "sir", "iga", "ee sala", "helri", "swalpa", "yappa", "ri", "holadaga", "bega"]}
TOPIC_WORDS = {
    "hi": ("खाद", "दवा", "किस्म", "बुवाई", "पानी", "कीड़ा", "रोग"), "ta": ("உரம்", "மருந்து", "ரகம்", "விதைப்பு", "தண்ணீர்", "பூச்சி", "நோய்"),
    "kn": ("ಗೊಬ್ಬರ", "ಔಷಧಿ", "ತಳಿ", "ಬಿತ್ತನೆ", "ನೀರು", "ಕೀಟ", "ರೋಗ"), "en": ("fertilizer", "medicine", "variety", "sowing", "water", "insect", "disease"),
}
ROMAN_TOPIC = {"hi": ("khad", "dawa", "kism", "buvai", "pani", "keeda", "rog"), "ta": ("uram", "marundhu", "ragam", "vidhaippu", "thanni", "poochi", "noi"),
               "kn": ("gobbara", "aushadhi", "tali", "bittane", "neeru", "keeta", "roga")}


def _h(s):
    return int(hashlib.sha1(s.encode("utf-8")).hexdigest()[:8], 16)


def _between(text, a, b):
    i = text.find(a)
    if i < 0:
        return ""
    j = text.find(b, i + len(a))
    return text[i + len(a): j if j >= 0 else len(text)].strip("\n")


class MockBrain:
    # fault schedule by the order in which distinct prompts of one task arrive: prompts 1-5 of every task get one
    # fault each (so every stage meets every fault), later prompts every 7th
    SCHEDULE = {1: "http500", 2: "slow", 3: "truncated", 4: "prose_json", 5: "not_json"}

    def __init__(self, faults=True, slow_s=0.0):
        self.faults = faults
        self.slow_s = slow_s
        self.attempts = Counter()
        self.seq = Counter()
        self.memory = {}
        self.calls = Counter()
        self.faults_done = Counter()
        self.lock = threading.Lock()

    def _fault_for(self, n):
        if n in self.SCHEDULE:
            return self.SCHEDULE[n]
        if n % 7 == 0:
            return self.SCHEDULE[1 + (n // 7) % 5]
        return None

    # ------------------------------------------------------------------ transport-level faults
    def respond(self, body):
        """-> (status, payload, delay_seconds)"""
        msgs = body.get("messages") or []
        task_text = next((m.get("content", "") for m in msgs if m.get("role") == "user" and "TASK:" in m.get("content", "")), "")
        m = re.search(r"TASK:\s*(\w+)", task_text)
        task = m.group(1) if m else "unknown"
        key = hashlib.sha1(json.dumps(msgs[:2], ensure_ascii=False, sort_keys=True).encode()).hexdigest()
        with self.lock:
            self.attempts[key] += 1
            attempt = self.attempts[key]
            self.calls[task] += 1
            if attempt == 1:
                self.seq[task] += 1
            fault = self._fault_for(self.seq[task]) if (self.faults and attempt == 1) else None
            if fault == "slow" and self.slow_s <= 0:
                fault = None
            if fault:
                self.faults_done[fault] += 1
        if fault == "http500":
            return 500, {"error": "mock: internal error"}, 0.0
        content = self._answer(task, task_text)
        if fault == "slow":
            return 200, self._wrap(content, body), self.slow_s
        if fault == "truncated":
            return 200, self._wrap(content[: max(10, len(content) // 3)], body, finish="length"), 0.0
        if fault == "prose_json":
            content = "Sure! Here is the JSON you asked for:\n```json\n" + content + "\n```\nHope this helps."
        elif fault == "not_json":
            content = "I am sorry, I cannot help with that."
        return 200, self._wrap(content, body), 0.0

    def _wrap(self, content, body, finish="stop"):
        pt = sum(len(m.get("content", "")) for m in body.get("messages", [])) // 4
        ct = max(1, len(content) // 4)
        return {"id": "mock", "object": "chat.completion", "model": "mock-teacher",
                "choices": [{"index": 0, "message": {"role": "assistant", "content": content}, "finish_reason": finish}],
                "usage": {"prompt_tokens": pt, "completion_tokens": ct, "total_tokens": pt + ct},
                "timings": {"prompt_ms": pt / 3.0, "predicted_ms": ct * 5.0, "cache_n": 0}}

    def _answer(self, task, text):
        fn = {"extract_facts": self.extract, "translate": self.translate, "translate_fix": self.translate_fix,
              "back_translate": self.back, "questions": self.questions, "questions_val": self.questions,
              "negatives": self.negatives, "target_names": self.target_names, "lexicon": self.lexicon}.get(task)
        if fn is None:
            return json.dumps({"ok": True, "crop": "rice", "hindi": "धान"}, ensure_ascii=False)
        return fn(text)

    def lexicon(self, text):
        words = [w.strip() for w in (re.search(r"Words:\s*(.*)", text) or [None, ""])[1].split(",") if w.strip()]
        return json.dumps({w: {"hi": "फिप्रोनिल", "ta": "ஃபிப்ரோனில்", "kn": "ಫಿಪ್ರೊನಿಲ್"} for w in words}, ensure_ascii=False)

    def target_names(self, text):
        return json.dumps({"en": ["stem borer"], "hi": ["तना छेदक", "Tana chhedak"], "ta": ["தண்டுத் துளைப்பான்"], "kn": ["ಕಾಂಡ ಕೊರಕ"]},
                          ensure_ascii=False)

    # ------------------------------------------------------------------ extraction
    def extract(self, text):
        crop = (re.search(r"^CROP:\s*(\S+)", text, re.M) or [None, "general"])[1]
        head = (re.search(r"^SECTION:\s*(.*)$", text, re.M) or [None, ""])[1]
        chunk = _between(text, "<<<TEXT\n", "\nTEXT>>>")
        sents = []   # (sentence, heading in force), the way a reader keeps the section in mind
        for para in re.split(r"\n\s*\n", chunk):
            lines = para.splitlines()
            while lines and re.match(r"^\s*\d+(\.\d+)*\s+[A-Z][A-Za-z ]+$", lines[0]):
                head = lines.pop(0).strip()
            flat = re.sub(r"-\n(?=[a-z])", "", "\n".join(lines))   # line-break hyphenation, as a teacher reads it
            flat = re.sub(r"\s*\n\s*", " ", flat)
            for s in re.split(r"(?<=[.;])\s+", flat):
                s = s.strip()
                if 5 <= len(s.split()) <= 60:
                    sents.append((s, head))
        facts = []
        for s, head in sents:
            low = s.lower()
            topic = next((t for t, rx in TOPIC_RULES if re.search(rx, low)), "general")
            target = None
            if topic in ("pest", "disease", "natural_enemy"):
                target = next((t for rx, t in TARGET_RULES if re.search(rx, low)), None) or \
                    next((t for rx, t in TARGET_RULES if re.search(rx, head.lower())), None)
            chems = [p for p in sorted(F.PESTICIDES) if f" {p} " in f" {F.pnorm(s)} "]
            chems += [b for b in ("phorate", "monocrotophos", "carbofuran", "malathion") if b in low and b not in chems]
            has_num = bool(re.search(r"\d", s))
            if chems and has_num:
                kind = "dose"
            elif low.startswith(VERBS):
                kind = "action"
            else:
                kind = "info"
            if "first" in low or "immediately" in low:
                kind = "first"
            en = " ".join(s.split()[:30]).rstrip(";,")
            fact_crop = "general" if topic == "pesticide_safety" else crop
            facts.append({"crop": fact_crop, "topic": topic, "target": target, "kind": kind, "en": en, "quote": s,
                          "chemicals": chems})
        if self.faults and facts:
            facts.append({"crop": crop, "topic": "pest", "target": None, "kind": "action",
                          "en": "Spray neem oil every day on all crops.",
                          "quote": "Neem oil must be sprayed every single day on every crop.", "chemicals": []})
            with_num = next((f for f in facts if re.search(r"\d+", f["en"])), None)
            if with_num:
                bumped = re.sub(r"\d+", lambda m: str(int(m.group(0)) + 1), with_num["en"], count=1)
                facts.append(dict(with_num, en=bumped))
            f0 = next((f for f in facts if f["kind"] == "action"), facts[0])
            facts.append(dict(f0, en="Please " + f0["en"][0].lower() + f0["en"][1:]))
        return json.dumps({"facts": facts}, ensure_ascii=False)

    # ------------------------------------------------------------------ translation
    WORDS = {"hi": ["ध्यान", "जल्दी", "सही", "पूरा", "हमेशा", "समय", "खेत", "फसल", "बराबर", "सावधानी"],
             "ta": ["கவனமா", "சீக்கிரம்", "சரியா", "முழுசா", "எப்பவும்", "நேரத்துல", "வயல்ல", "பயிருக்கு", "சமமா", "ஜாக்கிரதையா"],
             "kn": ["ಗಮನವಿಟ್ಟು", "ಬೇಗ", "ಸರಿಯಾಗಿ", "ಪೂರ್ತಿ", "ಯಾವಾಗಲೂ", "ಸಮಯಕ್ಕೆ", "ಹೊಲದಲ್ಲಿ", "ಬೆಳೆಗೆ", "ಸಮವಾಗಿ", "ಜೋಪಾನವಾಗಿ"]}

    def _render(self, en, keep, lang, drop_number=False):
        nums = sorted(F.numbers_in(en, words=False) - {n for t in keep for n in F.numbers_in(t, words=False)},
                      key=float)
        if drop_number and nums:
            nums = nums[1:]
        names = " ".join(keep)
        n = " ".join(nums)
        h = _h(en)
        w = self.WORDS[lang]
        uniq = f"{w[h % 10]} {w[(h // 10) % 10]} {w[(h // 100) % 10]}"
        body = {"hi": f"{names} {n} यह सलाह {uniq} मानिए जी, खेत में ऐसा ही कीजिए।",
                "ta": f"{names} {n} இந்த ஆலோசனையை {uniq} பின்பற்றுங்க, வயல்ல இப்படியே செய்யுங்க.",
                "kn": f"{names} {n} ಈ ಸಲಹೆಯನ್ನು {uniq} ಪಾಲಿಸ್ರಿ, ಹೊಲದಲ್ಲಿ ಹೀಗೆ ಮಾಡ್ರಿ."}[lang]
        body = re.sub(r"\s+", " ", body).strip()
        with self.lock:
            self.memory[body] = en
        return body

    def translate(self, text, fix=False):
        items = json.loads(_between(text, "<<<FACTS\n", "\nFACTS>>>") or "[]")
        victim = None
        if self.faults and not fix:   # drop a number in Tamil for the first item that has one (caught + fixed by re-ask)
            victim = next((it["id"] for it in items if F.numbers_in(it["en"], words=False)
                           - {n for t in it.get("keep", []) for n in F.numbers_in(t, words=False)}), None)
        out = []
        for it in items:
            row = {"id": it["id"]}
            for L in ("hi", "ta", "kn"):
                row[L] = self._render(it["en"], it.get("keep", []), L, drop_number=(it["id"] == victim and L == "ta"))
            out.append(row)
        return json.dumps({"items": out}, ensure_ascii=False)

    def translate_fix(self, text):
        return self.translate(text, fix=True)

    def back(self, text):
        items = json.loads(_between(text, "<<<ITEMS\n", "\nITEMS>>>") or "[]")
        out = []
        for it in items:
            en = self.memory.get(re.sub(r"\s+", " ", it["text"]).strip(), "Something about the farm.")
            if self.faults and _h(it["id"]) % 17 == 0:
                en = "Do some work in the garden."
            out.append({"id": it["id"], "en": en})
        return json.dumps({"items": out}, ensure_ascii=False)

    # ------------------------------------------------------------------ questions
    def _plan(self, text):
        m = re.search(r"^PLAN:\s*native=(\d+)\s+roman=(\d+)\s+mixed=(\d+)", text, re.M)
        return (int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else (8, 0, 0)

    def questions(self, text):
        lang = (re.search(r"^LANGUAGE:.*\((\w\w)\)", text, re.M) or [None, "en"])[1]
        crop_m = re.search(r"^CROP:\s*(\w+)", text, re.M)
        crop = crop_m.group(1) if crop_m and crop_m.group(1) in F.CROPS else None
        tgt_m = re.search(r"^PEST/DISEASE:\s*([^|\n(]+)", text, re.M)
        tname = tgt_m.group(1).strip() if tgt_m else None
        answer = [ln[2:] for ln in _between(text, "<<<ANSWER\n", "\nANSWER>>>").splitlines() if ln.startswith("- ")]
        variant = (re.search(r"^VARIANT:\s*(\S+)", text, re.M) or [None, "0"])[1]
        pn, pr, pm = self._plan(text)
        hh = _h(text)
        val = "TASK: questions_val" in text
        qs = []
        for k in range(pn + pr + pm):
            script = "native" if k < pn else ("roman" if k < pn + pr else "mixed")
            names_crop = (k % 2 == 0) and crop is not None
            names_target = bool(tname) and (k % 3 == 0)
            qs.append(self._q(lang, script, crop, tname, names_crop, names_target, hh + k * 7 + int(_h(variant) % 97), val))
        if self.faults and qs:
            if answer and hh % 2 == 0:
                qs[0] = {"q": answer[0], "script": "native", "names_crop": True, "names_target": False}
            if lang == "kn" and len(qs) > 1:
                qs[1] = {"q": "నా పంట ఆకులు పసుపు రంగులో ఉన్నాయి ఏమి చేయాలి", "script": "native", "names_crop": False, "names_target": False}
            if lang == "hi" and pr and len(qs) > pn:
                qs[pn] = {"q": "what is the best thing to do for this crop please tell me", "script": "roman",
                          "names_crop": False, "names_target": False}
        return json.dumps({"questions": qs}, ensure_ascii=False)

    def _q(self, lang, script, crop, tname, names_crop, names_target, seed, val):
        tw = TOPIC_WORDS[lang][seed % 7]
        f1 = FILL[lang][seed % len(FILL[lang])]
        f2 = FILL[lang][(seed // 7) % len(FILL[lang])]
        cn, cr = CROP_WORDS[lang].get(crop, ("", "")) if crop else ("", "")
        t = f" {tname}" if names_target and tname else ""
        if lang == "en":
            c = f" in my {cn}" if names_crop else ""
            q = f"{f1} what to do about {tw}{t}{c} {f2}" if not val else f"hello sir, {f1}, I have 2 acres{c}, what about {tw}{t} {f2}"
        elif script == "native":
            c = f"{cn} " if names_crop else ""
            q = {"hi": f"{f1} {c}{tw}{t} के लिए क्या करें {f2}", "ta": f"{f1} {c}{tw}{t} க்கு என்ன பண்ணணும் {f2}",
                 "kn": f"{f1} {c}{tw}{t} ಗೆ ಏನು ಮಾಡಬೇಕು {f2}"}[lang]
            if val:
                q = {"hi": "हाँ जी नमस्ते, ", "ta": "வணக்கம் சார், ", "kn": "ನಮಸ್ಕಾರ ಸಾರ್, "}[lang] + q
        elif script == "roman":
            rf1 = ROMAN_FILL[lang][seed % len(ROMAN_FILL[lang])]
            rf2 = ROMAN_FILL[lang][(seed // 5) % len(ROMAN_FILL[lang])]
            rt = ROMAN_TOPIC[lang][seed % 7]
            c = f"{cr} " if names_crop else ""
            q = {"hi": f"{rf1} {c}{rt}{t} ke liye kya karein {rf2}", "ta": f"{rf1} {c}{rt}{t} ku enna pannanum {rf2}",
                 "kn": f"{rf1} {c}{rt}{t} ge enu madbeku {rf2}"}[lang]
        else:
            c = f"{cn} " if names_crop else ""
            q = {"hi": f"{f1} {c}fertilizer spray dose{t} के लिए क्या करें", "ta": f"{f1} {c}spray medicine dose{t} க்கு என்ன பண்ணணும்",
                 "kn": f"{f1} {c}spray medicine dose{t} ಗೆ ಏನು ಮಾಡಬೇಕು"}[lang]
        return {"q": re.sub(r"\s+", " ", q).strip(), "script": script, "names_crop": names_crop, "names_target": bool(t)}

    def negatives(self, text):
        lang = (re.search(r"^LANGUAGE:.*\((\w\w)\)", text, re.M) or [None, "en"])[1]
        kind = (re.search(r"^KIND:\s*(\w+)", text, re.M) or [None, "not_sure"])[1]
        crop_m = re.search(r"^CROP:\s*(\w+)", text, re.M)
        crop = crop_m.group(1) if crop_m and crop_m.group(1) in F.CROPS else None
        pn, pr, pm = self._plan(text)
        hh = _h(text)
        qs = []
        for k in range(pn + pr + pm):
            s = hh + k * 11
            f1 = FILL[lang][s % len(FILL[lang])]
            roman = pn <= k < pn + pr and lang != "en"
            rf = ROMAN_FILL.get(lang, ["sir"])[s % len(ROMAN_FILL.get(lang, ["sir"]))]
            if kind == "not_sure":
                q = {"hi": (f"{rf} aaj mandi bhav kya chal raha hai" if roman else f"{f1} आज मंडी में भाव क्या है"),
                     "ta": (f"{rf} indru mandi vilai enna" if roman else f"{f1} இன்னிக்கு மண்டி விலை என்ன"),
                     "kn": (f"{rf} ivattu mandi bele estu" if roman else f"{f1} ಇವತ್ತು ಮಂಡಿ ಬೆಲೆ ಎಷ್ಟು"),
                     "en": f"{f1} what is the mandi price today"}[lang]
            elif kind == "ask":
                cn, cr = CROP_WORDS[lang][crop]
                c = (cr if roman else cn) + " " if k % 2 == 0 else ""
                q = {"hi": (f"{rf} {c}patte peele ho rahe hain" if roman else f"{f1} {c}के पत्ते पीले हो रहे हैं"),
                     "ta": (f"{rf} {c}ilai manjala aagudhu" if roman else f"{f1} {c}இலை மஞ்சளா ஆகுது"),
                     "kn": (f"{rf} {c}ele haladi aagtide" if roman else f"{f1} {c}ಎಲೆ ಹಳದಿ ಆಗ್ತಿದೆ"),
                     "en": f"{f1} the leaves of my {CROP_WORDS['en'][crop][0] if k % 2 == 0 else 'plants'} are turning yellow"}[lang]
            else:
                q = {"hi": (f"{rf} kaun si kism lagayein" if roman else f"{f1} कौन सी किस्म लगाएँ"),
                     "ta": (f"{rf} endha ragam podanum" if roman else f"{f1} எந்த ரகம் போடணும்"),
                     "kn": (f"{rf} yav tali haakbeku" if roman else f"{f1} ಯಾವ ತಳಿ ಹಾಕಬೇಕು"),
                     "en": f"{f1} which variety should I sow"}[lang]
            qs.append({"q": re.sub(r"\s+", " ", q).strip(), "script": "roman" if roman else "native", "names_crop": False,
                       "names_target": False})
        return json.dumps({"questions": qs}, ensure_ascii=False)



# ------------------------------------------------------------------------------------------------ servers
def make_handler(brain):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):  # quiet
            pass

        def _send(self, status, obj):
            data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self):
            if self.path.rstrip("/") in ("/health", "/v1/health"):
                return self._send(200, {"status": "ok"})
            if self.path.rstrip("/") in ("/v1/models", "/models"):
                return self._send(200, {"object": "list", "data": [{"id": "mock-teacher", "object": "model"}]})
            if self.path.rstrip("/") == "/props":
                return self._send(200, {"default_generation_settings": {"n_ctx": 8192}, "total_slots": 8})
            return self._send(404, {"error": "not found"})

        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0)
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                return self._send(400, {"error": "bad json"})
            if not self.path.rstrip("/").endswith("/chat/completions"):
                return self._send(404, {"error": "not found"})
            status, payload, delay = brain.respond(body)
            if delay:
                time.sleep(delay)
            return self._send(status, payload)
    return Handler


def serve(brain=None, host="127.0.0.1", port=0):
    """Start the mock server in a daemon thread. Returns (server, base_url, brain)."""
    brain = brain or MockBrain()
    srv = ThreadingHTTPServer((host, port), make_handler(brain))
    srv.daemon_threads = True
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    return srv, f"http://{host}:{srv.server_address[1]}/v1", brain


def stub_transport(brain=None):
    brain = brain or MockBrain()

    async def transport(body):
        status, payload, delay = brain.respond(body)
        if delay:
            await asyncio.sleep(delay)
        return status, payload
    transport.brain = brain
    return transport


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8099)
    ap.add_argument("--no-faults", action="store_true")
    ap.add_argument("--slow", type=float, default=0.0, help="seconds of delay for the 'slow reply' fault")
    args = ap.parse_args(argv)
    srv, url, _ = serve(MockBrain(faults=not args.no_faults, slow_s=args.slow), args.host, args.port)
    print(f"mock teacher at {url} (Ctrl-C to stop)", flush=True)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        srv.shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
