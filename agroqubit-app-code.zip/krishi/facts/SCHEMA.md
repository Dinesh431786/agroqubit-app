# Krishi Doctor fact schema (v1)

The fact-token model (FactLM, `factlm/`) answers a farmer's question with a short sequence of **verified fact ids** plus
control tokens. It can only ever output ids from these tables, so every fact must be checked against its source before it
is added. This file is the contract between the fact pipeline (`facts/`) and the model.

Validate any file before handing it over:

```
python3 factlm/facts_lib.py validate-facts facts/*.jsonl
python3 factlm/facts_lib.py validate-questions --facts 'facts/*.jsonl' path/to/questions.jsonl
```

## 1. `facts.jsonl`

One JSON object per line, UTF-8, no trailing commas. All fields are required (`target` and `source.page` may be `null`).

| field | type | rule |
|---|---|---|
| `id` | string | Stable, lowercase, dotted: `<crop>.<target-or-topic>.<kind>.<n>`, `n` = 1, 2, ... Regex `^[a-z0-9_]+\.[a-z0-9_]+\.[a-z0-9_]+\.[0-9]+$`. The first part equals `crop`, the second equals `target` (or `topic` when `target` is null). Never reuse or renumber an id: trained models refer to ids. |
| `crop` | string | `"rice"`, `"tomato"`, `"chilli"`, `"groundnut"` or `"general"` (applies to every crop). |
| `topic` | string | `"variety"`, `"season_sowing"`, `"seed_nursery"`, `"land_prep"`, `"nutrient"`, `"irrigation"`, `"weed"`, `"pest"`, `"disease"`, `"natural_enemy"`, `"pesticide_safety"`, `"harvest_storage"` or `"general"`. |
| `target` | string or null | A disease or pest id. Disease ids are the app's ids (keys of `brain/advice.json["advice"]`, plus the other app diseases such as `rice_bacterial_leaf_blight`, `rice_brown_spot`, `rice_sheath_blight`, `rice_tungro`, `rice_false_smut`, `tomato_leaf_mold`). A new pest is `"<crop>_<pest>"`, e.g. `"rice_stem_borer"`. `null` for topic facts (variety, nutrient, ...). |
| `kind` | string | `"first"`: the first thing to do. `"info"`: background (what it is, why it comes). `"action"`: a non-chemical practice (cultural, mechanical, biological, bio-pesticide). `"dose"`: any chemical with a quantity (product + amount + water/area). |
| `requires_confirmed` | bool | `true` for every `"dose"` fact and for every chemical recommendation tied to a target, even without a quantity. The model can output such a fact only when the app passes the same confirmed `target` (see constraints). |
| `text` | object | `{"en","hi","ta","kn"}`: the short screen text, one or two sentences, all four required and non-empty. Keep numbers, units and product names identical across languages. |
| `source` | object | `{"doc","url","page","quote"}`. `doc`: document title and publisher. `url`: where it can be downloaded. `page`: page number or null. `quote`: **verbatim English** source text that supports the fact. |
| `order` | int | Canonical position inside its group (same `crop` and same `target`, or same `topic` when `target` is null). Answers always list facts in increasing `order`. |
| `review` | string | `"seed"` (converted from the app's verified KB), `"auto"` (extracted automatically, not yet checked) or `"human"` (checked by an agronomist). |

Example:

```json
{"id": "tomato.tomato_leaf_curl.chemical.1", "crop": "tomato", "topic": "disease", "target": "tomato_leaf_curl",
 "kind": "dose", "requires_confirmed": true,
 "text": {"en": "thiamethoxam 25 WG @ 80 g in 200 l of water/acre", "hi": "...", "ta": "...", "kn": "..."},
 "source": {"doc": "AESA based IPM – Tomato (Package No. 18), DPPQS/NIPHM, Govt. of India",
            "url": "https://niphm.gov.in/IPMPackages/Tomato.pdf", "page": null,
            "quote": "thiamethoxam 25 WG @ 80 g in 200 l of water/acre"},
 "order": 7, "review": "seed"}
```

### Seed facts (`facts/seed_facts.jsonl`)

Built by `python3 factlm/build_seed.py` from `brain/advice.json` and `brain/advice_i18n.json`, text copied exactly.

- The kind part of a seed id is the KB category: `first`, `cultural`, `biological`, `chemical`.
- `kind` is `first` for the first-step line, `action` for cultural and biological items, `dose` for `chemical_examples`.
- `requires_confirmed` is true for all `chemical_examples` and false for the rest.
  Biological items (neem extract, Pseudomonas) stay `action`, as in the old app, where organic answers did not need a confirmed disease.
- `order`: `first` = 0, then biological, cultural, chemical. This is the order the old free chat used in its answers.
- `source.quote` is the KB's English item text. For the `first` line it is the KB's own English summary of the source.
  `page` is null.
- Rice diseases other than blast and `tomato_leaf_mold` have no seed facts yet.

### Merging several fact files

The model's item list is the union of all fact files given to `factlm/train.py` (`--facts` accepts globs). When the same
`id` appears twice, the later file wins and a warning is printed, so a `human` file listed last overrides `auto`.
A model trained on one table can only answer with that table's ids. After adding facts, retrain (cheap), or append them
zero-shot with `factlm/export.py --add-facts`.

## 2. Control tokens

| token | meaning (what the app does) |
|---|---|
| `<END>` | End of the answer. It follows the last fact and is never the first item. |
| `<ASK>` | The farmer is describing symptoms, or asks about a disease that is not yet known or has no facts. Start the Bayesian diagnosis questions. |
| `<NOT_SURE>` | Not covered offline (out of scope, off-topic, helpline request, or no verified fact for that part of the card). Refer to KVK / Kisan Call Centre 1800-180-1551. |
| `<WHICH_CROP>` | A crop is needed first (crop-specific topic with no crop known, or the named crop conflicts with the app's crop). Ask which crop. |
| `<CONFIRM>` | The farmer asks for a dose or chemical before the disease is confirmed. Confirm the diagnosis first. The model's target head says which disease to confirm. |

Every control token stops decoding. An answer has at most 6 items.

## 3. `questions.jsonl` (training and test questions)

```json
{"q": "tamatar ke patte mud rahe hai kya spray kare", "lang": "hi", "script": "roman",
 "ctx": {"crop": "tomato", "target": null}, "y": ["<ASK>"], "src": "teacher"}
```

| field | rule |
|---|---|
| `q` | The farmer's text as typed or recognized: any script, casual romanization, code-mixed, typos are fine. May be empty. |
| `lang` | `"hi"`, `"ta"`, `"kn"` or `"en"`: the language spoken, whatever the script. |
| `script` | `"native"` (Devanagari/Tamil/Kannada, or Latin for English), `"roman"` (hi/ta/kn written in Latin letters) or `"mixed"` (both). |
| `ctx` | `{"crop": crop or null, "target": target or null}`: what the app already knows when the question is asked. `target` means a **confirmed** diagnosis. |
| `y` | The answer: fact ids in canonical `order`, then one control token. Rules: no repeats; at most 6 facts; `<END>` after facts (it may be dropped when there are exactly 6 facts); a control token alone for control answers (`["<ASK>"]`); never `["<END>"]` alone. |
| `src` | `"seed"` (from `data/free_questions_*.jsonl`), `"teacher"` (generated), `"test_human"` (held-out human test), or another short tag. |
| `meta` | Optional: `{"intent", "target", "crop"}`, the labels the question was written for (seed questions). Lets the trainer recompute `y` when the fact table or `ctx` changes. |

`y` must be consistent with `ctx` under the inference constraints below. The trainer drops inconsistent rows and reports them.

### Answer policy (what `y` should be)

- Answer with the facts that answer the question, in `order`, and nothing else. One fact is fine.
- Dose or chemical requested, and `ctx.target` is not the disease asked about: `["<CONFIRM>"]`.
- Dose requested for the confirmed `ctx.target`: its `dose` facts, then `<END>`.
- Symptom description, or a disease-specific question when no disease is named or known: `["<ASK>"]`.
- Crop-specific topic question (variety, sowing, nutrients) when no crop is in the text or `ctx`: `["<WHICH_CROP>"]`.
- Out of scope, off-topic, helpline, or nothing verified covers it: `["<NOT_SURE>"]`.
- Seed questions follow the old free chat (`freechat/freechat.py`) with perfect understanding:
  - treatment: the `first` fact; disease info: the `info` facts if the table has them, else the `first` fact;
  - organic: biological + cultural facts;
  - prevention: cultural facts;
  - dose: chemical facts (`<CONFIRM>` unless confirmed);
  - an empty section: `<NOT_SURE>`;
  - diagnose, no disease, or a disease without facts: `<ASK>`;
  - helpline / out of scope / off-topic: `<NOT_SURE>`.

## 4. Inference constraints (identical in Python `factlm/model.py` and Java `FactLM.java`)

1. No item is output twice.
2. If `ctx.crop` is known, facts of other crops are masked (`general` facts stay allowed).
3. A `requires_confirmed` fact is masked unless `fact.target == ctx.target`. A target-less one (e.g. a herbicide
   dose) is therefore allowed only when no disease is confirmed.
4. `<END>` cannot be the first item.
5. Decoding stops at any control token or after 6 items. Decoding is greedy.

Rules 1–5 depend only on the tables, and `facts_lib.question_errors` checks `y` against them. Three extra safety rules
use the model's own heads, and rule 9 uses a name list. Each can be switched off in `factlm.json`.

6. **Dose gate** (`dose_gate`). If the target head (the disease the text names) points to a real target other than
   `ctx.target`, every `requires_confirmed` fact is masked.
7. **Text crop** (`text_crop_min`, default 0.5). If the app gives no crop and the slot head finds `crop_X` with
   probability ≥ 0.5, rule 2 applies as if `ctx.crop = X`.
8. **Unsure first fact** (`min_first_prob`, default 0.3). If the first item is a fact with probability < 0.3, the model
   answers `<ASK>` instead.
9. **Name guard** (`name_lexicon`, written by `factlm/export.py`; no model involved). If a disease is confirmed and the
   normalised question contains, as whole words, a local name of another target but none of the confirmed one, every
   `requires_confirmed` fact is masked. Only names of at least 4 characters that belong to exactly one target are used.
