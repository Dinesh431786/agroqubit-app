# Krishi Doctor fact pipeline (`krishi/facts/`)

This pipeline grows the verified fact bank from the 75 disease seed facts (`seed_facts.jsonl`, owned by the factlm
agent) to all farmer topics for rice, tomato, chilli and groundnut: varieties, season and sowing, seed and nursery,
land preparation, nutrients, irrigation, weeds, pests, diseases, natural enemies, pesticide safety, and harvest and
storage. It then generates farmer questions with answers for training the fact model (`factlm/`). Every fact keeps a
verbatim English quote from an official Indian source. The output follows `SCHEMA.md`.

```
sources.json ─► fetch_sources.py ─► work/pages.jsonl
                      ─► extract_facts.py (teacher) ─► work/facts_en.jsonl       quote, number, pesticide, duplicate checks
                      ─► translate_facts.py (teacher) ─► work/facts_auto.jsonl   hi/ta/kn + back-translation, review "auto"
                      ─► merge.py ─► facts.jsonl                                  seed + auto (+ human), stable ids
                      ─► gen_questions.py (teacher) ─► questions/{train,val,zeroshot}.jsonl
```

## Files

| file | what it is |
|---|---|
| `sources.json` | 13 extractable sources + the pesticide list: url, publisher, topics, page selection, region, priority, licence note, how it was checked |
| `banned_pesticides.json` | Banned, withdrawn, refused and restricted pesticides (CIB&RC list as on 01.06.2023 + S.O. 4294(E) of 03.10.2023 + glyphosate 2022), with crop-specific rules and trade-name aliases |
| `targets.json` | Canonical pest/disease ids per crop, teacher-spelling aliases (`BPH` → `rice_brown_planthopper`), the groundnut "tikka" expansion to both leaf spots, and generic names that are not targets |
| `factlib.py` | Shared helpers: schema enums, verbatim matching, numbers, scripts, similarity, target normaliser, pesticide policy, id registry |
| `teacher.py` | Async OpenAI-compatible client: 8 concurrent requests, retries, timeouts, JSON repair/salvage + re-ask, disk cache, token accounting. CLI: `ping`, `bench` |
| `fetch_sources.py` | Download (cached, with fallbacks and manual override) → text per page (pdftotext reading-order + `-layout`, pdfplumber fallback; HTML → text) |
| `extract_facts.py` | Chunks → teacher facts → checks → kinds, `first` facts, region prefix, order, stable ids |
| `translate_facts.py` | Teacher translation in the app register, hard checks + fix rounds, back-translation scores, `review_queue.csv` |
| `merge.py` | Seed + auto (+ `work/facts_human.jsonl`) → `facts.jsonl`, counts per crop/topic/kind/review |
| `gen_questions.py` | Answer units, train/val/zero-shot prompts, negatives, context variants, output validation |
| `mock_teacher.py` | Deterministic fake teacher (HTTP server or in-process) with fault injection, used by the tests |
| `run_vm.sh` | VM driver: `setup`, `check`, `dry`, `all`, or a single stage |
| `tests/` | `test_units.py` (15 tests), `test_e2e.py` (61 checks), fixtures, `sample_output/` (MOCK outputs, formats only) |

Work files go to `work/` and questions to `questions/`. The trainer's default glob `facts/*.jsonl` would load any
JSONL in this folder as facts, so only `seed_facts.jsonl` and `facts.jsonl` live at this level.

## Sources (all opened with WebFetch on 2026-10-12)

| crop | source | covers | licence note (short) |
|---|---|---|---|
| rice | DPPQS/NCIPM *IPM Package for Rice* (2014), niphm.gov.in | pests, diseases, weeds, natural enemies, nursery, nutrients, water, safety | © 2014 DPPQ&S |
| rice | DPPQS *Advisory on blast disease* (2022) | blast | govt advisory; OCR garbled, so no numbers are taken from it |
| rice | TNAU + TN Dept. of Agriculture *Crop Production Guide – Agriculture 2020*, book pp. 1–64 | varieties, seasons, nursery, nutrients, irrigation, weeds, harvest | no notice; Tamil Nadu advice |
| rice | ICAR-CRRI *Agro-Advisory Service*, June 2026 (I) | varieties by land type, seed rate and treatment, nursery, harvest, drying, grain storage | no notice; Odisha advice |
| tomato | NIPHM *AESA based IPM – Tomato* (Package 18) | pests, diseases, weeds, natural enemies, nutrition disorders, safety, harvest | "For internal circulation only. Not for sale." |
| tomato | TNAU *CPG – Horticulture 2020*, book pp. 59–64 (fallback: TNAU Agritech page) | varieties, season, nursery, fertiliser, irrigation, weeds, pests | no notice; Tamil Nadu advice |
| tomato | ICAR-IIVR Varanasi tomato page | Kashi varieties, sowing, nursery, nutrients, irrigation, harvest, storage | "© 2026 All Rights Reserved" |
| chilli | NIPHM *AESA based IPM – Chillies/Capsicum* (Package 24) | pests, diseases, weeds, natural enemies, nutrients, nursery, safety | "For internal circulation only. Not for sale." |
| chilli | TNAU *CPG – Horticulture 2020*, book pp. 75–79 (fallback: Agritech page) | varieties, seasons, nursery, fertiliser, irrigation, harvest | no notice; Tamil Nadu advice |
| chilli | ICAR-IIVR Varanasi chilli page | varieties, sowing, nursery, nutrients, weeds, harvest, drying, storage | "© 2026 All Rights Reserved" |
| groundnut | DPPQS/NCIPM *IPM Package for Groundnut* (2014) | pests, diseases, weeds, natural enemies, sowing, seed treatment, nutrients, harvest, storage | © 2014 DPPQ&S |
| groundnut | TNAU *CPG – Agriculture 2020*, book pp. 181–197 (fallback: Agritech page) | varieties, seasons, gypsum, irrigation, weeds, harvest | no notice; Tamil Nadu advice |
| groundnut | ICAR-CRIDA *Districtwise Promising Technologies for Rainfed Groundnut* (2004), book pp. 1–42 | district advice for Andhra Pradesh, Gujarat, Karnataka | no notice; dated |

Excluded: the PAU *Package of Practices* ("No part of it should be reproduced without the prior permission"), and
sites that WebFetch could not open (the ppqs.gov.in banned-list page; the copies used instead are named in
`banned_pesticides.json`).

**Licence position.** Indian government works are under Crown-style copyright (Copyright Act 1957, s.17(dd)), and
none of these documents carries an open licence. Data published on data.gov.in comes under GODL; these PDFs and
pages do not. The pipeline stores facts rewritten in our own words, which are not protected as such, plus a short
verbatim quote that is used only for verification. Before commercial release:

- get written permission, NIPHM/DPPQS first (two packages say "internal circulation only");
- do not ship the `source.quote` strings in the APK;
- show attribution;
- have a lawyer confirm.

## Checks (what makes a fact "verified")

1. **Verbatim quote.** The quote must occur in the chunk's page text. Whitespace, line-break hyphenation, case,
   quotes and punctuation spacing are normalised; `...` gaps are allowed between segments of 3+ words. The text is
   checked in both pdftotext modes.
2. **Numbers.** Every number in the English text must appear in the quote (`1,500` = `1500`, `two` = `2`, `½` = `0.5`).
3. **OCR.** Sources marked `ocr_suspect` give no facts with numbers.
4. **Pesticides.** Banned, withdrawn and refused names are always dropped, in the text, the quote or the chemical
   list, including trade names (Thimet, Nuvacron, Sevin...). Restricted ones are dropped for their crops:
   - monocrotophos, captafol, aluminium phosphide, methyl bromide, DDT, fenitrothion, trifluralin and glyphosate: dropped for all crops;
   - carbofuran: dropped unless the product is "3% CG";
   - dimethoate: dropped on tomato and chilli;
   - malathion: dropped on tomato;
   - oxyfluorfen: dropped on groundnut.

   `--strict-restricted` drops every restricted name, whatever the crop.
5. **Near-duplicates.** Facts in the same crop and target/topic with similarity ≥ 0.85, the same numbers and the
   same chemicals are merged. The higher-priority source wins: national IPM packages, then ICAR, then TNAU, then CRIDA.
6. **Schema.** Every fact is checked against `SCHEMA.md`:
   - a synthetic pesticide recommendation becomes `dose` with `requires_confirmed`; so does a `first`/`action` that names one, so chemicals never slip into a "first step";
   - bio-agents and fertilisers stay `action`;
   - any fact that names a synthetic pesticide gets `requires_confirmed`;
   - each pest/disease gets one `first` fact. Seed diseases keep their seed `first`. Elsewhere the earliest non-chemical action is promoted and flagged `first_promoted` for review.
7. **Region.** Varieties, seasons and fertiliser doses from TNAU or CRRI get "In Tamil Nadu," or "In Odisha,"
   prepended. The app cannot know the farmer's state, so the advice says where it applies.
8. **Translation** (hard checks: re-ask, then drop):
   - the same numbers as the English;
   - chemical, formulation, bio-agent and variety names kept in Latin script;
   - the rest written in the target script;
   - at most 45 words.

   Soft flags (kept, reviewed first): back-translation similarity < 0.5, and a missing polite imperative (Hindi -इए, Tamil -ங்க, Kannada -ರಿ).
9. **Questions.** The teacher's questions are checked for:
   - script and language (for example, English typed as "roman Hindi" is rejected);
   - another crop named;
   - leaks: answer numbers or long copied spans of the answer;
   - length 1–40 words;
   - duplicates;
   - every row passes the same rules as `factlm/facts_lib.question_errors`.

## Questions: answers and splits

- Pest and disease answers mirror the seed oracle in `factlm/facts_lib.oracle`:
  - treat → the `first` fact;
  - organic → non-chemical actions;
  - prevent → cultural actions;
  - dose → dose facts;
  - info → info facts, which is new: the oracle maps "disease info" to `first`;
  - single → one fact.
- Topic answers are single facts, small sets (2–3 facts from the same source page) and overviews (the first 4
  non-chemical facts in `order`).
- Fact answers end with `<END>`.
- Each question becomes 1–3 rows with different `ctx`, following the answer policy and inference constraints in
  `SCHEMA.md`:
  - a dose question without the confirmed target → `<CONFIRM>` (`--confirm-rate` 0.7);
  - a topic question with no crop in the text or `ctx` → `<WHICH_CROP>`;
  - a named crop that conflicts with `ctx.crop` → `<WHICH_CROP>`;
  - a pest/disease question that does not name it, with nothing confirmed → `<ASK>`.
- Negatives (15% of calls) cover out-of-scope topics → `<NOT_SURE>` (prices, weather, loans and schemes,
  livestock, other crops), symptom statements → `<ASK>`, and crop-less questions → `<WHICH_CROP>`.
- Teacher rows carry `meta = {unit, crop, target}` without `intent`, so `factlm/train.py` never relabels them
  with the seed-only oracle.
- Splits:
  - `train.jsonl`, about 60k rows, generated with the train prompt in every style: native script, casual roman,
    code-mixed, short, misspelled, dialect flavour, and personas (old, young, woman, small farmer...);
  - `val.jsonl`, about 4k rows, uses a different prompt (phone-call openings) and different personas on the same facts;
  - `zeroshot.jsonl`, about 4k rows, covers the 10% of non-seed facts held out by a hash of their id; these facts
    never appear in train. `holdout_facts.json` lists them.
- Languages rotate per call, so hi/ta/kn/en are balanced.

## Commands

Local tests (CPU, no internet, about 15 s):

```
python3 krishi/facts/tests/test_units.py      # 15 unit tests
python3 krishi/facts/tests/test_e2e.py        # 61 end-to-end checks with the mock teacher (writes tests/e2e_results.json)
```

On the GPU VM (one L4, Ubuntu, CUDA, internet):

```
# 1. teacher: 8 slots x 8k context each (extraction needs ~5k: 1.8k prompt + 3k output). Flags are for a recent
#    llama.cpp build (older builds: plain -fa). If 64k of KV cache does not fit next to the ~16 GB weights, use
#    -c 49152 and extract_facts.py --chunk-chars 3000 --max-tokens 2500.
./llama-server -hfr unsloth/gemma-4-26B-A4B-it-GGUF -hff gemma-4-26B-A4B-it-UD-Q4_K_M.gguf --host 127.0.0.1 --port 8080 \
    -ngl 99 -np 8 -c 65536 --jinja -fa on --cache-reuse 256 --reasoning-budget 0
# (the repo has no plain Q4_K_M file, only UD-Q4_K_M; android/tools/job_gpu.sh runs this in the llama.cpp CUDA image)
# 2. pipeline
bash krishi/facts/run_vm.sh setup     # poppler-utils + pip requirements
bash krishi/facts/run_vm.sh check     # ping + throughput bench: note completion_tokens_per_s
bash krishi/facts/run_vm.sh dry       # ~16 chunks, 40 facts, 60 question calls -> work/dry/ (10-20 min): read it!
bash krishi/facts/run_vm.sh all       # fetch, extract, translate, merge, questions, validate
```

- Each stage can also be run alone: `bash run_vm.sh extract`. Environment overrides: `TEACHER_URL`, `WORK`,
  `SOURCES`, `TARGET_TOTAL`, `TEACHER_FLAGS`. The `dry` path was tested locally against the fixtures and the mock
  teacher over HTTP.
- If a download fails (TLS chain, blocking), save the file in a browser to `work/raw/manual/<source_id>.pdf` and
  re-run `fetch`.
- A killed stage resumes from the teacher cache (`work/cache/teacher/`): re-run the same command.
- If replies contain thinking text, the client warns. Then use `TEACHER_FLAGS=--no-think` or `--reasoning-budget 0`.
- If the per-slot context is too small, the client also warns.
- For table-heavy PDFs, `extract_facts.py --layout-tables` gives the teacher the layout text, which keeps rows together.

Hand-off to factlm:

```
python3 factlm/train.py --facts facts/facts.jsonl --questions factlm/data/seed_train.jsonl \
    --questions 'facts/questions/train.jsonl' --test facts/questions/val.jsonl --test facts/questions/zeroshot.jsonl ...
```

Pass `facts/facts.jsonl` alone: it already contains the seed facts. Passing `facts/*.jsonl` would load the seed twice
and print warnings.

## Estimated teacher cost (one L4, llama.cpp, Gemma 4 26B-A4B Q4_K_M, 8 slots)

These are estimates from the measured prompt sizes:

- extraction: 7.0k chars ≈ 1.8k tokens;
- translation: 3.1k chars ≈ 1.0k tokens;
- questions: 2.2k chars ≈ 0.6k tokens, of which 0.35k is a static prefix that llama.cpp keeps cached per slot.

The volume assumptions are about 400 source pages → about 350 chunks → about 2,300 facts.

| stage | calls | prompt tokens | generated tokens | time |
|---|---|---|---|---|
| extract | ~370 | ~0.7M | ~0.4M | 30–60 min |
| translate + fixes + back-translation | ~830 | ~0.9M | ~0.6M | 45–80 min |
| questions (60k train + 4k val + 4k zero-shot) | ~7,100 | ~4.3M (~2.5M cached prefix) | ~2.3M | 2.5–4.5 h |
| **total** | ~8,300 | **~5.9M** | **~3.3M** | **~4–7 h** (central ~5 h) |

The assumptions are 150–250 generated tokens/s across 8 slots and 1.5–3k prompt tokens/s. Measure with
`run_vm.sh check` and rescale: hours ≈ 3.3M / (measured completion_tokens_per_s) / 3600 + 0.5. Every stage writes
its real usage to `work/stats/teacher_<stage>.json`. `TARGET_TOTAL=40000` cuts the question stage by about a third.

## Honest limits

- **Machine-extracted facts need agronomist review.** A verbatim quote proves the text exists. It does not prove:
  - that the teacher understood it (wrong target, a unit per acre vs per hectare when the number matches, a row
    association lost in a table);
  - that it is still current: the IPM packages are from about 2014 and the CRIDA book from 2004;
  - that it fits the farmer's state.

  All new facts are `review: "auto"`. Review `work/extract_report.json` (`new_targets`, flags such as
  `first_promoted` and `crop_from_source`) and correct by writing `work/facts_human.jsonl` (review `"human"`).
- **Translations need native-speaker review.** Number and name checks and back-translation catch gross errors,
  not wrong words, register or dialect. `work/review_queue.csv` lists the worst back-translations first.
- **Recall is traded for precision.** Facts whose quote the teacher paraphrased are dropped, and so are facts with
  numbers from garbled scans. OCR is not done; the 2022 blast advisory gives no doses.
- **The pesticide list is a snapshot.** It is the CIB&RC list of 01.06.2023 plus the 2023 order, read from copies:
  the official ppqs.gov.in page did not open, and the glyphosate S.O. number was not verified. Re-check it before
  each release; label claims (crop, dose) are not checked against the CIB&RC registration database.
- **Tested with a mock teacher only.** Every script ran end to end on hand-written fixtures with a fake LLM and
  injected faults (HTTP 500, timeouts, truncated, prose or non-JSON replies, fabricated quotes, wrong numbers,
  dropped numbers, leaked or wrong-script questions). Real Gemma output quality, pass rates and speed are unknown
  until `run_vm.sh dry`.
- **Synthetic questions.** They are written by one model, so they will be more regular than real farmers. Validate
  on real KCC or field questions before trusting accuracy numbers. The zero-shot split tests unseen facts, not
  unseen phrasing.
- **Policy choices for the factlm owner to confirm:**
  - "info" questions answer with info facts, while the seed oracle answers with `first`;
  - target-less dose facts (herbicides) can be output only when no disease is confirmed (SCHEMA constraint 3);
  - every fact that names a synthetic pesticide requires confirmation.
