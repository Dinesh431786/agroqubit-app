#!/usr/bin/env python3
"""translate_facts.py (GPU VM): the teacher translates every English fact into Hindi, Tamil and Kannada in the
app's farmer register (brain/advice_i18n.json: Hindi '-इए', Tamil '-ங்க', Kannada '-ರಿ'), then translates each
translation back to English for a similarity check.

Checks per language:
  hard  numbers   same set of numbers as the English text (digits in any script are read as 0-9)
  hard  names     chemical, formulation, bio-agent and variety names (the KEEP list) stay in Latin script, unchanged
  hard  script    everything else is in Devanagari / Tamil / Kannada script; 1-45 words
        -> failing items are sent back once or twice with the exact errors (translate_fix); still failing -> dropped
  soft  back-translation similarity to the English text < --bt-threshold -> flag low_bt_<lang> (kept, review first)
  soft  register  no polite imperative on an action/first/dose fact -> flag register_<lang>
All kept facts get review "auto".

Usage:
  python3 krishi/facts/translate_facts.py [--work krishi/facts/work] [--limit 50]
Outputs: <work>/facts_auto.jsonl, facts_auto_meta.jsonl, rejects_translate.jsonl, review_queue.csv,
         translate_report.json, stats/teacher_translate.json
"""
from __future__ import annotations

import argparse
import asyncio
import csv
import json
import re
import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import factlib as F  # noqa: E402
import teacher as TCH  # noqa: E402

PROMPT_VERSION = "translate-v1"
MAX_WORDS_L = 45
REGISTER = {"hi": re.compile(r"(िए|इए|ीजिए|ें|एँ|ाएँ|ो\b)"), "ta": re.compile(r"(ங்க|ுங்கள்|ுங்க)"), "kn": re.compile(r"(ರಿ|್ರಿ|ಿರಿ)")}

SYSTEM = ("You translate short farm advice from English into Hindi, Tamil and Kannada the way an experienced village "
          "extension worker talks to farmers. You answer with one JSON object only.")

USER = """TASK: translate
Translate each English fact into Hindi (hi), Tamil (ta) and Kannada (kn).

Follow the style of these lines from our app:
{examples}

Rules:
- Hindi: simple rural Hindi with polite "-इए/-िए" verbs (रखिए, लगाइए, कीजिए). Tamil: spoken style with "-ங்க" (போடுங்க, வைங்க). Kannada: spoken style with "-ರಿ" (ಹಾಕ್ರಿ, ಇಡ್ರಿ).
- Write every number with the same digits 0-9 as in the English. Never change, drop or add a number.
- Copy every term in "keep" exactly, in English letters (do not transliterate or translate it).
- Units may be local words (किलो, ग्राम, लीटर, एकड़, हेक्टेयर / கிலோ, கிராம், லிட்டர், ஏக்கர், ஹெக்டேர் / ಕೆಜಿ, ಗ್ರಾಂ, ಲೀಟರ್, ಎಕರೆ, ಹೆಕ್ಟೇರ್).
- Same meaning only: no extra advice, no warnings. At most 30 words each.

FACTS:
<<<FACTS
{facts}
FACTS>>>

Answer with JSON only:
{{"items": [{{"id": "...", "hi": "...", "ta": "...", "kn": "..."}}]}}"""

FIX = """TASK: translate_fix
These translations broke the rules. Correct them. Keep every number with digits 0-9 exactly as in the English, copy every "keep" term exactly in English letters, write the rest in the target language script, at most 30 words. Use the same farmer style (Hindi "-इए", Tamil "-ங்க", Kannada "-ರಿ").

<<<FACTS
{facts}
FACTS>>>

Answer with JSON only:
{{"items": [{{"id": "...", "hi": "...", "ta": "...", "kn": "..."}}]}}"""

BACK = """TASK: back_translate
Translate each line into plain English, literally. Keep every number. Do not add or explain anything.

<<<ITEMS
{items}
ITEMS>>>

Answer with JSON only:
{{"items": [{{"id": "...", "en": "..."}}]}}"""

_BUILTIN_EXAMPLES = [
    {"en": "Yellow sticky traps @ 10/acre", "hi": "पीले चिपचिपे ट्रैप लगाइए, हर एकड़ में 10।",
     "ta": "மஞ்சள் ஒட்டும் பொறி ஏக்கருக்கு 10 வைங்க.", "kn": "ಹಳದಿ ಅಂಟು ಬಲೆ ಎಕರೆಗೆ 10 ಇಡ್ರಿ."},
    {"en": "thiamethoxam 25 WG @ 80 g in 200 l of water/acre", "hi": "thiamethoxam 25 WG। हर एकड़ के लिए 200 लीटर पानी में 80 ग्राम।",
     "ta": "thiamethoxam 25 WG. ஏக்கருக்கு 200 லிட்டர் தண்ணீர்ல 80 கிராம்.", "kn": "thiamethoxam 25 WG. ಎಕರೆಗೆ 200 ಲೀಟರ್ ನೀರಿನಲ್ಲಿ 80 ಗ್ರಾಂ."},
]


def load_examples(log):
    """Parallel en/hi/ta/kn lines from brain/advice.json + brain/advice_i18n.json (the app's reviewed register)."""
    try:
        adv = F.load_json(F.REPO_DIR / "brain" / "advice.json")["advice"]
        i18 = F.load_json(F.REPO_DIR / "brain" / "advice_i18n.json")
        picks = [("tomato_leaf_curl", "cultural", 2), ("tomato_leaf_curl", "chemical_examples", 0),
                 ("rice_blast", "cultural", 2), ("groundnut_late_leaf_spot", "cultural", 0),
                 ("groundnut_early_leaf_spot", "biological", 0)]
        out = []
        for d, cat, i in picks:
            ex = {"en": adv[d][cat][i]}
            for L in F.INDIC:
                ex[L] = i18[d][cat][L][i]
            out.append(ex)
        return out
    except Exception as e:  # pragma: no cover - repo files missing
        log.warning(f"could not load app register examples ({e}); using built-in examples")
        return _BUILTIN_EXAMPLES


def format_examples(exs):
    lines = []
    for ex in exs:
        lines += [f"EN: {ex['en']}", f"HI: {ex['hi']}", f"TA: {ex['ta']}", f"KN: {ex['kn']}", ""]
    return "\n".join(lines).strip()


# ------------------------------------------------------------------------------------------------ KEEP terms
_VARIETY_RES = [
    re.compile(r"\b[A-Z]{1,6}(?:\s?\([A-Za-z]{1,4}\))?[\s-]?\d{1,5}[A-Za-z]?\b"),
    re.compile(r"\b(?:Arka|Kashi|Pusa|Hisar|Phule|Kadiri|Pant|Punjab|Swarna|Samba|Sambha|Improved|Kalinga|Naveen|Sahbhagi|"
               r"Lalat|Tapaswini|Pooja|Varsha|Jaya|Vijetha|Shatabdi|Abhishek|Dhanlaxmi|Girnar|Dharani|Tirupati|Abhaya|"
               r"Konkan|Utkal|Jawahar|Rajendra|Narendra|Indira|Birsa|Sabour|CR\s?Dhan|DRR\s?Dhan|Kashi\s?\w+)"
               r"(?:\s+[A-Z][A-Za-z]+){1,2}(?:\s\d+)?\b"),
]
_FORMULATION = re.compile(r"\b\d+(?:\.\d+)?\s?%?\s?(?:EC|WP|WG|WDG|SC|SL|SP|GR|CG|CS|DS|FS|WS|OD|ME|EW|ZC|DP|G)\b")
_STOP_CAPS = {"KVK", "IPM", "ETL", "DAS", "DAT", "FYM", "NPK", "DAP", "MOP", "SSP", "ETLS", "AESA", "PH", "LT", "HA"}


def keep_terms(en, chems=()):
    """Names that must stay in Latin script: chemicals (+ formulation codes), bio-agent binomials, variety names."""
    text = F.norm_text(en)
    terms = []
    low = text.lower()
    lex = sorted(F.PESTICIDES | {b for b in F.BIOAGENTS if len(b) > 4 and " " in b}, key=len, reverse=True)
    taken = []
    for name in lex:
        for m in re.finditer(r"(?<![a-z])" + re.escape(name).replace(r"\ ", r"[\s\-]+") + r"(?![a-z])", low):
            if any(a <= m.start() < b for a, b in taken):
                continue
            taken.append((m.start(), m.end()))
            terms.append(text[m.start():m.end()])
    for m in _FORMULATION.finditer(text):
        terms.append(m.group(0))
    for rx in _VARIETY_RES:
        for m in rx.finditer(text):
            t = m.group(0).strip()
            if t.split()[0].upper() in _STOP_CAPS or re.fullmatch(r"[A-Z]{1,3}\s?\d+(?:\.\d+)?", t) and t.split()[0] in ("I", "A"):
                continue
            if re.fullmatch(r"\d.*", t):
                continue
            terms.append(t)
    if re.search(r"\bKVK\b", text):
        terms.append("KVK")
    out, seen = [], set()
    for t in sorted(terms, key=len, reverse=True):  # drop terms contained in a longer term
        k = t.lower()
        if k in seen or any(k in s for s in seen):
            continue
        seen.add(k)
        out.append(t)
    return out


# ------------------------------------------------------------------------------------------------ checks
def term_present(term, text):
    pat = re.escape(F.norm_text(term).lower()).replace(r"\ ", r"[\s\-]*")
    return re.search(pat, F.norm_text(text).lower()) is not None


def check_translation(en, keep, L, tr):
    """Hard errors for one translation (empty list = ok)."""
    errs = []
    if not isinstance(tr, str) or not tr.strip():
        return ["empty"]
    tr = F.norm_text(tr)
    n_en = F.numbers_in(en, words=False)
    n_tr = F.numbers_in(F.ascii_digits(tr), words=False)
    if n_en != n_tr:
        miss, extra = sorted(n_en - n_tr), sorted(n_tr - n_en)
        errs.append("numbers differ" + (f": missing {miss}" if miss else "") + (f": extra {extra}" if extra else ""))
    for t in keep:
        if not term_present(t, tr):
            errs.append(f"'{t}' must appear exactly in English letters")
    rest = tr
    for t in keep:
        rest = re.sub(re.escape(F.norm_text(t)).replace(r"\ ", r"[\s\-]*"), " ", rest, flags=re.I)
    prof = F.script_profile(rest)
    tot = sum(prof.values())
    want = F.LANG_SCRIPT[L]
    if tot == 0 or prof.get(want, 0) / tot < 0.85:
        errs.append(f"write it in {F.LANG_NAME[L]} script (only the keep terms in English letters)")
    other = [s for s in prof if s not in (want, "latin")]
    if other:
        errs.append(f"contains {other} script letters")
    if F.word_count(tr) > MAX_WORDS_L:
        errs.append(f"too long ({F.word_count(tr)} words)")
    return errs


def bt_score(en, bt):
    if not isinstance(bt, str) or not bt.strip():
        return 0.0
    s = 0.5 * F.token_f1(en, bt) + 0.5 * F.cosine(F.char_ngrams(en), F.char_ngrams(bt))
    if F.numbers_in(en, words=False) != F.numbers_in(bt, words=False):
        s *= 0.8
    return round(s, 3)


def validate_items(ids, langs=("hi", "ta", "kn")):
    def v(obj):
        if isinstance(obj, list):
            obj = {"items": obj}
        items = obj.get("items") if isinstance(obj, dict) else None
        if not isinstance(items, list):
            raise TCH.InvalidOutput('expected {"items": [...]}')
        got = {}
        for it in items:
            if isinstance(it, dict) and str(it.get("id")) in ids:
                got[str(it["id"])] = {L: it.get(L) if isinstance(it.get(L), str) else "" for L in langs}
        missing = [i for i in ids if i not in got]
        if len(missing) == len(ids):
            raise TCH.InvalidOutput(f"no item ids matched; use exactly these ids: {sorted(ids)[:10]}")
        if missing:
            raise TCH.InvalidOutput(f"missing items for ids {missing[:10]}")
        return {"items": [dict(id=i, **got[i]) for i in ids]}
    return v


def validate_back(ids):
    def v(obj):
        if isinstance(obj, list):
            obj = {"items": obj}
        items = obj.get("items") if isinstance(obj, dict) else None
        if not isinstance(items, list):
            raise TCH.InvalidOutput('expected {"items": [...]}')
        got = {str(it.get("id")): it.get("en") for it in items if isinstance(it, dict) and isinstance(it.get("en"), str)}
        missing = [i for i in ids if i not in got]
        if len(missing) > len(ids) // 2:
            raise TCH.InvalidOutput(f"missing ids {missing[:10]}")
        return {"items": [{"id": i, "en": got.get(i, "")} for i in ids]}
    return v


# ------------------------------------------------------------------------------------------------ main
async def translate_batch(T, batch, keep, examples, args):
    """-> {fid: {"hi","ta","kn","errors": {L: [...]}, "fixes": n}}  (fixes = fix requests this item needed)"""
    ids = [f["id"] for f in batch]
    payload = json.dumps([{"id": f["id"], "en": f["text"]["en"], "keep": keep[f["id"]]} for f in batch], ensure_ascii=False, indent=0)
    msgs = [{"role": "system", "content": SYSTEM},
            {"role": "user", "content": USER.format(examples=format_examples(examples), facts=payload)}]
    res = await T.chat_json(msgs, tag="translate", validate=validate_items(ids), temperature=args.temperature,
                            max_tokens=args.max_tokens, cache_extra=PROMPT_VERSION)
    out = {it["id"]: {L: it[L] for L in F.INDIC} for it in res["items"]}
    by_id = {f["id"]: f for f in batch}
    for rnd in range(args.fix_rounds + 1):
        bad = {}
        for fid, tr in out.items():
            errs = {L: check_translation(by_id[fid]["text"]["en"], keep[fid], L, tr[L]) for L in F.INDIC}
            errs = {L: e for L, e in errs.items() if e}
            tr["errors"] = errs
            tr.setdefault("fixes", 0)
            if errs:
                bad[fid] = errs
        if not bad or rnd == args.fix_rounds:
            break
        for fid in bad:
            out[fid]["fixes"] += 1
        fix_payload = json.dumps([{"id": fid, "en": by_id[fid]["text"]["en"], "keep": keep[fid],
                                   "previous": {L: out[fid][L] for L in F.INDIC},
                                   "errors": {L: "; ".join(e) for L, e in bad[fid].items()}} for fid in bad],
                                 ensure_ascii=False, indent=0)
        msgs = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": FIX.format(facts=fix_payload)}]
        try:
            fixed = await T.chat_json(msgs, tag="translate_fix", validate=validate_items(list(bad)), temperature=0.1,
                                      max_tokens=args.max_tokens, cache_extra=f"{PROMPT_VERSION}:fix{rnd}")
        except TCH.TeacherError:
            break
        for it in fixed["items"]:
            for L in F.INDIC:
                if L in bad[it["id"]]:
                    out[it["id"]][L] = it[L]
    return out


async def back_batch(T, items):
    ids = [i["id"] for i in items]
    payload = json.dumps(items, ensure_ascii=False, indent=0)
    msgs = [{"role": "system", "content": "You translate into plain literal English. You answer with one JSON object only."},
            {"role": "user", "content": BACK.format(items=payload)}]
    res = await T.chat_json(msgs, tag="back_translate", validate=validate_back(ids), temperature=0.0, max_tokens=2000,
                            cache_extra=PROMPT_VERSION)
    return {it["id"]: it["en"] for it in res["items"]}


async def run(args, log):
    work = Path(args.work)
    t0 = time.monotonic()
    facts = F.read_jsonl(args.inp)
    meta_in = {m["id"]: m for m in F.read_jsonl(Path(args.inp).with_name(Path(args.inp).stem + "_meta.jsonl"))} \
        if Path(args.inp).with_name(Path(args.inp).stem + "_meta.jsonl").exists() else {}
    if args.limit:
        facts = facts[:args.limit]
    examples = load_examples(log)
    keep = {f["id"]: keep_terms(f["text"]["en"], (meta_in.get(f["id"]) or {}).get("chemicals", ())) for f in facts}
    batches = [facts[i:i + args.batch] for i in range(0, len(facts), args.batch)]
    log.info(f"{len(facts)} facts in {len(batches)} batches")
    async with TCH.teacher_from_args(args, work, log) as T:
        await T.wait_ready(max_wait=args.wait, min_ctx=4000)
        res = await TCH.run_jobs([(lambda b=b: translate_batch(T, b, keep, examples, args)) for b in batches],
                                 log=log, label="translate")
        trans, failed = {}, []
        for b, r in zip(batches, res):
            if isinstance(r, Exception):
                failed.extend(f["id"] for f in b)
            else:
                trans.update(r)
        ok_ids = [f["id"] for f in facts if f["id"] in trans and not trans[f["id"]]["errors"]]
        bt_items = [{"id": f"{fid}|{L}", "text": trans[fid][L]} for fid in ok_ids for L in F.INDIC]
        bt_batches = [bt_items[i:i + args.batch * 3] for i in range(0, len(bt_items), args.batch * 3)]
        bres = await TCH.run_jobs([(lambda b=b: back_batch(T, b)) for b in bt_batches], log=log, label="back_translate")
        back = {}
        for r in bres:
            if not isinstance(r, Exception):
                back.update(r)
        T.log_summary("translate")
        tstats = T.save_stats(work / "stats" / "teacher_translate.json", "translate")

    rows, metas, rejects = [], [], []
    reasons, flags_c = Counter(), Counter()
    for f in facts:
        fid = f["id"]
        if fid in failed or fid not in trans:
            reasons["teacher_failed"] += 1
            rejects.append({"id": fid, "reason": "teacher_failed", "en": f["text"]["en"]})
            continue
        tr = trans[fid]
        if tr["errors"]:
            reasons["hard_check_failed"] += 1
            rejects.append({"id": fid, "reason": "hard_check_failed", "errors": tr["errors"], "en": f["text"]["en"],
                            "translation": {L: tr[L] for L in F.INDIC}})
            continue
        flags, scores, bts = [], {}, {}
        for L in F.INDIC:
            bt = back.get(f"{fid}|{L}", "")
            bts[L] = bt
            scores[L] = bt_score(f["text"]["en"], bt) if bt else None
            if scores[L] is None:
                flags.append(f"no_bt_{L}")
            elif scores[L] < args.bt_threshold:
                flags.append(f"low_bt_{L}")
            if f["kind"] in ("action", "first", "dose") and not REGISTER[L].search(tr[L]):
                flags.append(f"register_{L}")
        if tr.get("fixes"):
            flags.append(f"fixed_after_{tr['fixes']}_rounds")
        flags_c.update(flags)
        row = dict(f)
        row["text"] = {"en": f["text"]["en"], **{L: F.norm_text(F.ascii_digits(tr[L])) for L in F.INDIC}}
        row["review"] = "auto"
        errs = F.fact_errors(row)
        if errs:
            reasons["schema"] += 1
            rejects.append({"id": fid, "reason": "schema", "errors": errs})
            continue
        rows.append(row)
        vals = [s for s in scores.values() if s is not None]
        metas.append({"id": fid, "keep": keep[fid], "bt": bts, "bt_score": scores, "bt_min": min(vals) if vals else None,
                      "flags": flags, **({"extract_flags": meta_in[fid].get("flags")} if fid in meta_in else {})})
    F.write_jsonl(work / "facts_auto.jsonl", rows)
    F.write_jsonl(work / "facts_auto_meta.jsonl", metas)
    F.write_jsonl(work / "rejects_translate.jsonl", rejects)
    by = {r["id"]: r for r in rows}
    with open(work / "review_queue.csv", "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "crop", "topic", "kind", "bt_min", "flags", "en", "hi", "ta", "kn", "bt_hi", "bt_ta", "bt_kn", "quote", "doc", "page"])
        for m in sorted(metas, key=lambda m: (m["bt_min"] if m["bt_min"] is not None else -1)):
            r = by[m["id"]]
            w.writerow([r["id"], r["crop"], r["topic"], r["kind"], m["bt_min"], " ".join(m["flags"]), r["text"]["en"],
                        r["text"]["hi"], r["text"]["ta"], r["text"]["kn"], m["bt"].get("hi", ""), m["bt"].get("ta", ""),
                        m["bt"].get("kn", ""), r["source"]["quote"], r["source"]["doc"], r["source"]["page"]])
    allbt = [s for m in metas for s in m["bt_score"].values() if s is not None]
    report = {"prompt_version": PROMPT_VERSION, "facts_in": len(facts), "facts_out": len(rows), "rejected": dict(reasons),
              "flags": dict(flags_c.most_common()),
              "bt_mean": round(sum(allbt) / len(allbt), 3) if allbt else None,
              "bt_below_threshold": sum(1 for s in allbt if s < args.bt_threshold), "bt_threshold": args.bt_threshold,
              "fixed_items": sum(1 for t in trans.values() if t.get("fixes") and not t["errors"]),
              "teacher": tstats.get("total"),
              "wall_seconds": round(time.monotonic() - t0, 1)}
    F.write_json(work / "translate_report.json", report)
    log.info(f"translated {len(rows)}/{len(facts)} facts; rejected {dict(reasons)}; back-translation mean "
             f"{report['bt_mean']}, {report['bt_below_threshold']} below {args.bt_threshold}; flags {dict(flags_c.most_common(6))}")
    return 0 if rows or not facts else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--work", default=str(F.DEFAULT_WORK))
    ap.add_argument("--inp", default=None, help="default <work>/facts_en.jsonl")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--batch", type=int, default=6, help="facts per teacher call")
    ap.add_argument("--fix-rounds", type=int, default=2)
    ap.add_argument("--bt-threshold", type=float, default=0.5)
    ap.add_argument("--temperature", type=float, default=0.2)
    ap.add_argument("--max-tokens", type=int, default=2500)
    TCH.add_teacher_args(ap)
    args = ap.parse_args(argv)
    args.inp = args.inp or str(Path(args.work) / "facts_en.jsonl")
    log = F.get_logger("translate_facts", args.work)
    try:
        return asyncio.run(run(args, log))
    except TCH.TeacherUnavailable as e:
        log.error(str(e))
        return 3


if __name__ == "__main__":
    sys.exit(main())
