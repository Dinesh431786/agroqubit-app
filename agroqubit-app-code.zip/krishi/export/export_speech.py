"""Export the speech encoder (meaning vector + phoneme logits) to ONNX; measure size, single-thread latency and RAM."""
import sys, time, json, os, resource, numpy as np, torch
sys.path.insert(0, "/home/claude/krishi/speech"); from speechenc import SpeechEncoder, logmel
K = "/home/claude/krishi"; torch.set_num_threads(1)
protos = torch.load(f"{K}/text/enc_A_0.pt")["state"]["slots"]; sd = torch.load(f"{K}/speech/speech_enc_v2.pt")["state"]
net = SpeechEncoder(protos, n_phon=sd["ctc.weight"].shape[0] - 1); net.load_state_dict(sd); net.eval()
class Wrap(torch.nn.Module):
    def __init__(s, n): super().__init__(); s.n = n
    def forward(s, mel):
        z, h = s.n(mel, None, return_frames=True); return torch.sigmoid(s.n.slot_logits(z)), s.n.ctc(h).log_softmax(1)
mel = logmel(torch.randn(1, 16000 * 3) * 0.1)
torch.onnx.export(Wrap(net), mel, "speech_v2.onnx", input_names=["mel"], output_names=["slot_probs", "phoneme_logprobs"],
                  dynamic_axes={"mel": {2: "T"}, "phoneme_logprobs": {2: "T2"}}, opset_version=17, dynamo=False)
from onnxruntime.transformers.float16 import convert_float_to_float16
import onnx; onnx.save(convert_float_to_float16(onnx.load("speech_v2.onnx"), keep_io_types=True), "speech_v2_fp16.onnx")
import onnxruntime as ort
so = ort.SessionOptions(); so.intra_op_num_threads = 1
for f in ["speech_v2.onnx", "speech_v2_fp16.onnx"]:
    s = ort.InferenceSession(f, so, providers=["CPUExecutionProvider"]); x = mel.numpy()
    a = s.run(None, {"mel": x}); b = Wrap(net)(mel)
    for _ in range(3): s.run(None, {"mel": x})
    t = time.time(); [s.run(None, {"mel": x}) for _ in range(20)]
    print(f, f"{os.path.getsize(f)/1e6:.2f} MB", f"{(time.time()-t)/20*1000:.1f} ms per 3 s of audio (1 thread)", "max diff", float(np.abs(a[0] - b[0].detach().numpy()).max()))
print("peak RSS MB", resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024)
