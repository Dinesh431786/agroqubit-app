"""Personal phonetic memory: after a farmer confirms a meaning (button tap), keep (their phoneme string -> meaning).
New utterance = model probabilities fused with a nearest-neighbour vote over THAT farmer's own confirmed utterances.
Test: 13 unseen voices; per voice, N confirmed utterances are enrolled, evaluation on the voice's OTHER (different) sentences."""
import json, sys, re, zlib, random, numpy as np, torch
sys.path.insert(0, "/home/claude/krishi/speech"); sys.path.insert(0, "/home/claude/krishi/text")
import train_phon2meaning_lib as P; from textenc import TextEncoder
K = "/home/claude/krishi"; SL = list(json.load(open(f"{K}/slots.json"))); S = {s: i for i, s in enumerate(SL)}
meta = json.load(open(f"{K}/speech/test_meta.json"))
net = TextEncoder(len(SL)); net.load_state_dict(torch.load(f"{K}/speech/phon2meaning_v2.pt")["state"]); net.eval()
def ngr(s, n=(2, 3, 4)):
    s = "#" + re.sub(r"\s", "", s) + "#"; v = {}
    for k in n:
        for i in range(len(s) - k + 1): h = zlib.crc32(s[i:i+k].encode()) % 4096; v[h] = v.get(h, 0) + 1
    x = np.zeros(4096, np.float32); x[list(v)] = list(v.values()); return x / (np.linalg.norm(x) + 1e-9)
R = {}
for cond in ["clean", "pink10"]:
    hyp = json.load(open(f"{K}/speech/test_decoded_v2_{cond}.json"))
    with torch.no_grad(): i, o = P.pk(hyp); Pm = torch.sigmoid(net.slot_logits(net.embed(i, o))).numpy()
    V = np.stack([ngr(h) for h in hyp]); single = [k for k, m in enumerate(meta) if len(m["slots"]) == 1]
    by_voice = {}
    for k in single: by_voice.setdefault(meta[k]["voice"], []).append(k)
    for N in [0, 10, 20, 40]:
        accs = []
        for seed in range(5):
            rng = random.Random(seed); hit = tot = 0
            for v, ks in by_voice.items():
                ks = ks[:]; rng.shuffle(ks); enr, ev = ks[:N], ks[N:]
                if not ev: continue
                for k in [x for x in ev if meta[x]["slots"][0].startswith("ans_")]:
                    p = Pm[k].copy()
                    if enr:
                        sims = V[enr] @ V[k]; top = np.argsort(-sims)[:3]
                        mem = np.zeros(len(SL))
                        for j in top: mem[S[meta[enr[j]]["slots"][0]]] += max(sims[j], 0)
                        if mem.sum() > 0:
                            a = min(0.6, float(sims[top[0]]))          # trust memory more when the match is close
                            p = (1 - a) * p / (p.sum() + 1e-9) + a * mem / mem.sum()
                    hit += p.argmax() == S[meta[k]["slots"][0]]; tot += 1
            accs.append(hit / tot)
        R[f"{cond}/enrolled_{N}"] = dict(top1=round(float(np.mean(accs)), 3), sd=round(float(np.std(accs)), 3))
        print(cond, N, R[f"{cond}/enrolled_{N}"], flush=True)
json.dump(R, open("results_personal_answers.json", "w"), indent=1)
