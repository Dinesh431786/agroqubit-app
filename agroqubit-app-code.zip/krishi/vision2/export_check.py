"""Export the field-photo model for the phone and check it honestly (GPU VM, after train.py).
 1) student.pt -> ONNX -> vision.bin/.json (same int8 op-list format the pure-Java Vision.java runs)
 2) one fingerprint per label from the PHONE (int8) weights, single view - exactly what the app computes
 3) held-out test photos: top-1 / top-3 per crop, phone int8 vs fp32; 'not sure' threshold calibrated on validation
 4) 6 test photos per crop (JPEG) + the Python reference answer, to compare with the app on the emulator
Usage: python3 export_check.py <data_dir> <student.pt> <vision_out_dir> <results_dir>"""
import json, os, subprocess, sys
import numpy as np, onnx, onnxruntime as ort, torch
from onnx import numpy_helper
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__)); TOOLS = os.path.join(os.path.dirname(HERE), "android", "tools")
sys.path.insert(0, TOOLS); sys.path.insert(0, HERE)
from phone_model import Embedder
import export_vision as EV
import labels as LB

D, CK, VIS, RES = sys.argv[1:5]; os.makedirs(VIS, exist_ok=True); os.makedirs(f"{RES}/test_photos", exist_ok=True)
meta = json.load(open(f"{D}/meta.json")); names = meta["labels"]; NC = len(names)
ck = torch.load(CK, map_location="cpu"); net = Embedder(); net.load_state_dict(ck["net"]); net.eval()
onx = f"{VIS}/leaf_fp32.onnx"
torch.onnx.export(net, torch.rand(1, 3, 224, 224) * 255, onx, input_names=["image"], output_names=["embedding"], opset_version=17, dynamo=False)
_, _, _, deq = EV.convert(onx, "int8"); m8 = onnx.load(onx)
for ini in m8.graph.initializer:
    if ini.name in deq: ini.CopyFrom(numpy_helper.from_array(deq[ini.name].astype(np.float32), ini.name))
def sess(m): so = ort.SessionOptions(); so.intra_op_num_threads = 4; return ort.InferenceSession(m.SerializeToString(), so, providers=["CPUExecutionProvider"])
s32, s8 = sess(onnx.load(onx)), sess(m8)
def emb(s, X, bs=32):
    out = []
    for i in range(0, len(X), bs):
        x = np.ascontiguousarray(X[i:i + bs][:, 16:240, 16:240].transpose(0, 3, 1, 2)).astype(np.float32)
        out.append(np.concatenate([s.run(None, {"image": x[j:j + 1]})[0] for j in range(len(x))]))
    return np.concatenate(out) if out else np.zeros((0, 256), np.float32)
def norm(v): return v / np.linalg.norm(v, axis=-1, keepdims=True)

Xtr = np.load(f"{D}/train_X.npy", mmap_mode="r"); ytr = np.load(f"{D}/train_y.npy")
Xva = np.load(f"{D}/val_X.npy", mmap_mode="r"); yva = np.load(f"{D}/val_y.npy")
Xte = np.load(f"{D}/test_X.npy", mmap_mode="r"); yte = np.load(f"{D}/test_y.npy")
rng = np.random.default_rng(0); P = []
for c in range(NC):                                   # fingerprints: mean phone embedding of up to 300 training photos per label
    ii = np.where(ytr == c)[0]; ii = np.sort(rng.permutation(ii)[:300]); P.append(norm(emb(s8, Xtr[ii]).mean(0)))
P = np.stack(P)
np.savez(f"{VIS}/protos.npz", P=P, cls=np.arange(NC), names=np.array(names))
mapping = {"app": {l: LB.meta(l)["app"][0] for l in names if len(LB.meta(l)["app"]) == 1}, "meta": {l: LB.meta(l) for l in names}}
json.dump(mapping, open(f"{VIS}/mapping.json", "w"), indent=1)
subprocess.run([sys.executable, os.path.join(TOOLS, "export_vision.py"), onx, f"{VIS}/protos.npz", VIS, "int8", f"{VIS}/mapping.json"], check=True)

# ---- held-out test: per crop, phone int8 vs fp32 (single view, one fingerprint per label - what the app runs)
crop_of = [LB.meta(l)["crop"] or "other" for l in names]
def metrics(Z, y):
    S = Z @ P.T; R = {}
    for cr in ["rice", "tomato", "chilli", "groundnut", "other"]:
        m = np.array([crop_of[l] == cr for l in y])
        if not m.any(): continue
        cols = [j for j in range(NC) if crop_of[j] == cr]                      # within-crop ranking (the app knows or asks the crop)
        Sc = S[m][:, cols]; yc = np.array([cols.index(l) for l in y[m]]); o = np.argsort(-Sc, 1)
        R[cr] = {"n": int(m.sum()), "labels": len(cols), "top1": round(float((o[:, 0] == yc).mean()), 4),
                 "top3": round(float(np.mean([yc[i] in o[i, :3] for i in range(len(yc))])), 4),
                 "top1_any_crop": round(float((S[m].argmax(1) == y[m]).mean()), 4)}
    return R
Zte8, Zte32 = emb(s8, Xte), emb(s32, Xte)
R = {"labels": names, "n_test": int(len(yte)), "phone_int8": metrics(Zte8, yte), "fp32": metrics(Zte32, yte),
     "cos_phone_vs_fp32": round(float((Zte8 * Zte32).sum(1).mean()), 5), "vision_bin_MB": round(os.path.getsize(f"{VIS}/vision.bin") / 1e6, 2)}
sv = (emb(s8, Xva) @ P.T).max(1); t80 = float(np.quantile(sv, 0.20))
V = json.load(open(f"{VIS}/vision.json")); V["not_sure"] = round(t80, 3); json.dump(V, open(f"{VIS}/vision.json", "w"), ensure_ascii=False)
S = Zte8 @ P.T; ans = S.max(1) >= t80
R["not_sure_gate"] = {"threshold": round(t80, 3), "answered": round(float(ans.mean()), 3), "accuracy_when_answered": round(float((S.argmax(1)[ans] == yte[ans]).mean()), 3)}

# ---- test photos for the phone: 6 per crop, reference = the same JPEG decoded the same way, phone weights
ref = []; k = 0
for cr in ["rice", "tomato", "chilli", "groundnut"]:
    ii = [i for i in range(len(yte)) if crop_of[yte[i]] == cr]
    for i in sorted(rng.permutation(ii)[:6].tolist()):
        dst = f"{RES}/test_photos/p{k:02d}.jpg"; Image.fromarray(np.asarray(Xte[i])).save(dst, quality=92); k += 1
        x = np.asarray(Image.open(dst).convert("RGB"), np.uint8)[None]; sc = (emb(s8, x) @ P.T)[0]; b = int(sc.argmax())
        ref.append({"file": os.path.basename(dst), "true": names[int(yte[i])], "ref_label": names[b], "ref_score": round(float(sc[b]), 4),
                    "ref_correct": b == int(yte[i]), "crop": cr})
json.dump(ref, open(f"{RES}/test_photos/reference.json", "w"), indent=1)
R["test_photos"] = {"n": len(ref), "python_correct": sum(r["ref_correct"] for r in ref)}
json.dump(R, open(f"{RES}/vision2_check.json", "w"), indent=1); print(json.dumps(R))
