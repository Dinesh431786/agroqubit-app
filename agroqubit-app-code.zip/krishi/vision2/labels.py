"""One label set for the Indian field-photo model, shared by data building, training, export and the app.

Each dataset keeps its own class names; RULES map a class name (lower-case, punctuation removed) of a given crop to one
unified label, first match wins. A rule mapping to None drops that class (a disease the app has no knowledge of).
Labels are app ids: '<crop>_<disease or pest>' or '<crop>_healthy', plus 'other_crop' (photos of crops the app
does not cover, so the app can say "this does not look like rice, tomato, chilli or groundnut").

meta(label) -> {"crop", "kind": disease | pest | healthy | other, "app": [doctor-KB disease ids the photo is evidence
for], "target": fact-bank target id (pests and diseases outside the doctor KB) or None, and for a class that shows two
pests together "targets": [both ids]}"""
import json, os, re

HERE = os.path.dirname(os.path.abspath(__file__)); REPO = os.path.dirname(HERE)
CROPS = ["rice", "tomato", "chilli", "groundnut"]

RULES = {
    "rice": [(r"panicle|leaf ?smut|downy|streak|neck", None),
             (r"bacterial.*blight|^blb$|bacterial ?blight", "rice_bacterial_leaf_blight"), (r"blast", "rice_blast"),
             (r"narrow ?brown", "rice_narrow_brown_leaf_spot"), (r"brow?o?n ?spot|brownspot", "rice_brown_spot"), (r"tu[nr]gro", "rice_tungro"),
             (r"sh?e?ath ?blight", "rice_sheath_blight"), (r"false ?smut", "rice_false_smut"), (r"leaf ?scal?e?d", "rice_leaf_scald"),
             (r"hispa", "rice_hispa"), (r"dead ?heart|stem ?borer", "rice_stem_borer"), (r"brown ?plant ?hopper|\bbph\b", "rice_brown_planthopper"),
             (r"leaf ?folder|leaf ?roller", "rice_leaf_folder"), (r"green ?leaf ?hopper|\bglh\b", "rice_green_leafhopper"),
             (r"rice ?bug|gundhi", "rice_gundhi_bug"), (r"whorl ?maggot", "rice_whorl_maggot"), (r"healthy|normal", "rice_healthy")],
    "groundnut": [(r"early ?leaf ?spot", "groundnut_early_leaf_spot"), (r"late ?leaf ?spot", "groundnut_late_leaf_spot"),
                  (r"alternaria", "groundnut_alternaria_blight"), (r"leaf ?spot|tikka", "groundnut_leaf_spot"), (r"rust", "groundnut_rust"),
                  (r"rosette", "groundnut_rosette"), (r"healthy", "groundnut_healthy"), (r"nutri|deficien", None)],
    "chilli": [(r"mite.*t(h)?rip|t(h)?rip.*mite", "chilli_mites_thrips"), (r"leaf ?curl|curl", "chilli_leaf_curl"), (r"cercospora|frog ?eye", "chilli_cercospora_leaf_spot"),
               (r"bacterial", "chilli_bacterial_leaf_spot"), (r"powdery", "chilli_powdery_mildew"), (r"anthracnose|die ?back", "chilli_anthracnose_dieback"),
               (r"mosaic|virus", "chilli_mosaic"), (r"white ?fly", "chilli_whitefly"), (r"thrips", "chilli_thrips"), (r"mite", "chilli_yellow_mite"),
               (r"aphid", "chilli_aphid"), (r"healthy", "chilli_healthy"), (r"nutri|deficien", None)],
    "tomato": [(r"early ?blight", "tomato_early_blight"), (r"late ?blight", "tomato_late_blight"), (r"septoria", "tomato_septoria_leaf_spot"),
               (r"bacterial", "tomato_bacterial_leaf_spot"), (r"yellow ?(leaf)? ?curl|leaf ?curl|yellow ?virus", "tomato_leaf_curl"),
               (r"mosaic", "tomato_mosaic"), (r"mold|mould", "tomato_leaf_mold"), (r"spider ?mite", "tomato_spider_mite"),
               (r"healthy|^tomato ?leaf$|^leaf$", "tomato_healthy")],
}
COMBINED = {"groundnut_leaf_spot": ["groundnut_early_leaf_spot", "groundnut_late_leaf_spot"]}   # one photo class, two app diseases
COMBINED_TARGETS = {"chilli_mites_thrips": ["chilli_thrips", "chilli_yellow_mite"]}            # one photo class, two pests (leaf-curl 'murda' complex)


def norm(name):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", str(name).lower().replace("_", " "))).strip()


def map_class(crop, name):
    """Unified label for a dataset class of this crop, or None (dropped)."""
    n = norm(name)
    for c in CROPS:                       # dataset class names often start with the crop ("Tomato leaf late blight")
        for w in {"rice": ["rice", "paddy"], "tomato": ["tomato"], "chilli": ["chilli", "chili", "pepper"], "groundnut": ["groundnut", "peanut"]}[c]:
            if n.startswith(w + " ") and c == crop: n = n[len(w) + 1:]
    for pat, lab in RULES[crop]:
        if re.search(pat, n): return lab
    return None


_KB = None
def kb_diseases():
    global _KB
    if _KB is None:
        p = os.path.join(REPO, "android", "doctor_kb.json")
        _KB = set(json.load(open(p))["names"]) if os.path.exists(p) else set()
    return _KB


_PESTS = None
def pest_ids():
    global _PESTS
    if _PESTS is None:
        p = os.path.join(REPO, "facts", "targets.json"); _PESTS = set()
        if os.path.exists(p):
            for c, v in json.load(open(p)).get("canonical", {}).items(): _PESTS.update(v.get("pests", []))
    return _PESTS


def meta(label):
    if label == "other_crop": return {"crop": None, "kind": "other", "app": [], "target": None}
    crop = label.split("_")[0]
    if label.endswith("_healthy"): return {"crop": crop, "kind": "healthy", "app": [], "target": None}
    if label in COMBINED_TARGETS:
        ts = COMBINED_TARGETS[label]; return {"crop": crop, "kind": "pest", "app": [], "target": ts[0], "targets": ts}
    app = COMBINED.get(label) or ([label] if label in kb_diseases() else [])
    kind = "pest" if label in pest_ids() else "disease"
    return {"crop": crop, "kind": kind, "app": app, "target": None if app else label}
