"""Build the Indian field-photo training set (runs on the GPU VM; needs internet).

Sources (licence read from each dataset card at run time; only open licences are used, every one is recorded):
  Hugging Face Project-AgML mirrors (parquet): Odisha rice (Sethy et al.), Tamil Nadu 'Paddy Doctor', UCI rice (Gujarat),
  West Bengal groundnut (Sasmal et al.), a second groundnut set, a chilli set, Bangladesh rice sets (same field conditions)
  PlantDoc (GitHub, CC BY 4.0): tomato field/web photos + other crops ('other_crop', so the app can say 'not my crops')
Every class name goes through labels.map_class (unknown diseases are dropped). Near-duplicate photos across datasets
(16x16 average hash within 12 of 256 bits, also against flipped / rotated copies) are removed so the same photo can never
be in train and test. Photos on a white background (Dhan-Shomadhan's 'background' column) are not field photos and are left out.
Output (<out>/): {train,val,test}_X.u8 (memmap N x 256 x 256 x 3), {split}_y.npy, {split}_src.npy, meta.json, report.json
Usage: python3 build_data.py <out_dir> [--max-per-label 3000] [--plantdoc <dir>]"""
import argparse, io, json, os, re, subprocess, sys, time
import numpy as np
from PIL import Image, ImageOps

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import labels as LB

HF = [("Project-AgML/rice_leaf_disease_classification_india", "rice"), ("Project-AgML/paddy_disease_classification", "rice"),
      ("Project-AgML/uci_rice_leaf_diseases_classification", "rice"), ("Project-AgML/rice_leaf_disease_classification_bd", "rice"),
      ("Project-AgML/Dhan-Shomadhan_rice_leaf_disease_classification", "rice"),
      ("Project-AgML/groundnut_leaf_disease_classification", "groundnut"), ("Project-AgML/groundnut_leaf_disease_classification_2", "groundnut"),
      ("Project-AgML/COLD_chili_leaf_disease_classification", "chilli")]
# not used: Project-AgML/pepper_disease_pest_classification (classes such as 'Brown_Spot' suggest black pepper, a different crop)
OPEN = ("cc-by-4.0", "cc-by-3.0", "cc-by-2.0", "cc0-1.0", "cc0", "apache-2.0", "mit", "odc-by", "cdla-permissive-2.0", "pddl", "unlicense", "bsd-3-clause")
SIZE = 256


def log(*a): print(time.strftime("[%H:%M:%S]"), *a, flush=True)


def square(im):
    im = ImageOps.exif_transpose(im).convert("RGB"); w, h = im.size; s = min(w, h)
    im = im.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s))
    return np.asarray(im.resize((SIZE, SIZE), Image.BICUBIC), np.uint8)


class Dedup:
    """Near-duplicate filter: 16x16 average hash (block means of the 256 px grey image, no resampling) compared by Hamming
    distance, against all 8 flips / 90-degree rotations of every photo kept so far (some datasets ship rotated or mirrored
    copies; those must not end up in both train and test). Multi-index lookup: 16 chunks of 16 bits, so every hash within
    MAXD < 16 bits is found exactly."""
    MAXD = 12

    def __init__(self):
        self.tab = [dict() for _ in range(16)]; self.codes = []

    @staticmethod
    def bits(x):
        g = (x.astype(np.float32) @ np.array([0.299, 0.587, 0.114], np.float32)).reshape(16, 16, 16, 16).mean((1, 3))
        return g > g.mean()

    def seen(self, b):                    # any flip / rotation of this photo within MAXD bits of a kept photo
        for v in (b, b[:, ::-1]):
            for k in range(4):
                q = np.packbits(np.ascontiguousarray(np.rot90(v, k)).ravel()); cand = set()
                for i in range(16): cand.update(self.tab[i].get(q[2 * i:2 * i + 2].tobytes(), ()))
                if any(int(np.unpackbits(q ^ self.codes[j]).sum()) <= self.MAXD for j in cand): return True
        return False

    def add(self, b):
        q = np.packbits(b.ravel()); j = len(self.codes); self.codes.append(q)
        for i in range(16): self.tab[i].setdefault(q[2 * i:2 * i + 2].tobytes(), []).append(j)


def licence_of(repo):
    try:
        from huggingface_hub import HfApi
        cd = HfApi().dataset_info(repo).card_data
        lic = (cd.get("license") if cd else None) or "unknown"
        return lic if isinstance(lic, str) else ",".join(lic)
    except Exception as e:
        return f"error: {e}"[:120]


def hf_rows(repo, crop, report):
    """Yield (label, uint8 image, split) for one AgML dataset; split from the dataset if it has test/validation."""
    from datasets import load_dataset, ClassLabel, Image as HImage
    lic = licence_of(repo); report["sources"][repo] = {"crop": crop, "licence": lic}
    if lic.lower() not in OPEN:
        report["sources"][repo]["skipped"] = "licence not open or unknown"; log(repo, "skipped: licence", lic); return
    try:                                        # prefer a 'raw'/'original' config; never an augmented one (copies would leak into test)
        try:
            from datasets import get_dataset_config_names
            cfgs = get_dataset_config_names(repo) or [None]
        except Exception:
            cfgs = [None]
        pick = [c for c in cfgs if c and re.search(r"raw|orig", c, re.I)] or [c for c in cfgs if not (c and re.search(r"aug", c, re.I))] or cfgs
        ds = load_dataset(repo, pick[0]) if pick[0] else load_dataset(repo)
        report["sources"][repo]["config"] = pick[0]
    except Exception as e:
        report["sources"][repo]["skipped"] = f"load failed: {str(e)[:200]}"; log(repo, "load failed", e); return
    for split, d in ds.items():
        feats = d.features
        icol = next((k for k, v in feats.items() if isinstance(v, HImage)), None)
        lcol = next((k for k, v in feats.items() if isinstance(v, ClassLabel)), None)
        if icol is None or lcol is None:
            report["sources"][repo]["skipped"] = f"no image/class columns in {split}: {list(feats)}"; return
        names = feats[lcol].names; mapping = {i: LB.map_class(crop, n) for i, n in enumerate(names)}
        bcol = next((k for k, v in feats.items() if "background" in k.lower() and getattr(v, "dtype", "") == "string"), None)   # Dhan-Shomadhan
        report["sources"][repo].setdefault("classes", {}).update({n: mapping[i] for i, n in enumerate(names)})
        if "aug" in split.lower(): continue                    # augmented copies: never (they would leak into test)
        sp = "test" if split.lower().startswith("test") else "val" if split.lower().startswith(("val", "dev")) else None
        for r in d:
            lab = mapping.get(r[lcol])
            if lab is None: continue
            if bcol and re.search(r"white|plain|lab", str(r[bcol]), re.I):         # studio photos on white paper: not field photos
                report["sources"][repo]["white_background_dropped"] = report["sources"][repo].get("white_background_dropped", 0) + 1; continue
            try:
                im = r[icol]; im = im if isinstance(im, Image.Image) else Image.open(io.BytesIO(im["bytes"]))
                yield lab, square(im), sp
            except Exception:
                continue


def plantdoc_rows(root, report):
    if not os.path.isdir(root):
        subprocess.run(["git", "clone", "-q", "--depth", "1", "https://github.com/pratikkayal/PlantDoc-Dataset", root], check=False)
    report["sources"]["PlantDoc"] = {"licence": "cc-by-4.0", "url": "https://github.com/pratikkayal/PlantDoc-Dataset"}
    for split in ["train", "test"]:
        for c in sorted(os.listdir(f"{root}/{split}")) if os.path.isdir(f"{root}/{split}") else []:
            lab = LB.map_class("tomato", c) if c.lower().startswith("tomato") else "other_crop"
            if c.lower().startswith("tomato two spotted"): lab = None
            if lab is None: continue
            for f in sorted(os.listdir(f"{root}/{split}/{c}")):
                try: yield lab, square(Image.open(f"{root}/{split}/{c}/{f}")), ("test" if split == "test" else None)
                except Exception: continue


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("out"); ap.add_argument("--max-per-label", type=int, default=3000)
    ap.add_argument("--plantdoc", default="/home/claude/data/PlantDoc-Dataset"); ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True); rng = np.random.default_rng(a.seed)
    report = {"sources": {}}; seen = Dedup(); rows = {"train": [], "val": [], "test": []}; srcs = []
    tmp = os.path.join(a.out, "all_X.u8"); cap = 120000
    X = np.lib.format.open_memmap(tmp + ".npy", mode="w+", dtype=np.uint8, shape=(cap, SIZE, SIZE, 3)); n = 0; meta_rows = []
    gens = [(repo, hf_rows(repo, crop, report)) for repo, crop in HF] + [("PlantDoc", plantdoc_rows(a.plantdoc, report))]
    for si, (name, g) in enumerate(gens):
        srcs.append(name); t0 = time.time(); k = dup = 0
        for lab, x, sp in g:
            b = Dedup.bits(x)
            if seen.seen(b): dup += 1; continue
            seen.add(b)
            if n >= cap: break
            X[n] = x; meta_rows.append((lab, si, sp)); n += 1; k += 1
        report["sources"].setdefault(name, {})["images"] = k; report["sources"][name]["duplicates_dropped"] = dup
        log(f"{name}: {k} images ({dup} duplicates dropped) in {time.time() - t0:.0f}s")
    labels = sorted({m[0] for m in meta_rows}); L = {l: i for i, l in enumerate(labels)}
    # splits: dataset test/val splits kept; the rest stratified 80/10/10 per (source, label); training capped per label
    by = {}
    for i, (lab, si, sp) in enumerate(meta_rows):
        if sp: rows[sp].append(i)
        else: by.setdefault((si, lab), []).append(i)
    for (si, lab), idx in by.items():
        idx = rng.permutation(idx); nv = max(1, len(idx) // 10) if len(idx) >= 10 else 0
        rows["val"] += idx[:nv].tolist(); rows["test"] += idx[nv:2 * nv].tolist(); rows["train"] += idx[2 * nv:].tolist()
    tr = np.array(rows["train"]); ytr = np.array([L[meta_rows[i][0]] for i in tr]); keep = []
    for c in range(len(labels)):
        ii = tr[ytr == c]; keep += rng.permutation(ii)[:a.max_per_label].tolist()
    rows["train"] = sorted(keep)
    for sp, idx in rows.items():
        idx = np.array(sorted(idx), dtype=np.int64)
        Y = np.lib.format.open_memmap(os.path.join(a.out, f"{sp}_X.npy"), mode="w+", dtype=np.uint8, shape=(len(idx), SIZE, SIZE, 3))
        for j in range(0, len(idx), 512): Y[j:j + 512] = X[idx[j:j + 512]]
        Y.flush(); del Y
        np.save(os.path.join(a.out, f"{sp}_y.npy"), np.array([L[meta_rows[i][0]] for i in idx], np.int64))
        np.save(os.path.join(a.out, f"{sp}_src.npy"), np.array([meta_rows[i][1] for i in idx], np.int64))
    del X; os.remove(tmp + ".npy")
    counts = {sp: {l: int(c) for l, c in zip(labels, np.bincount(np.load(os.path.join(a.out, f"{sp}_y.npy")), minlength=len(labels)))} for sp in rows}
    json.dump({"labels": labels, "meta": {l: LB.meta(l) for l in labels}, "sources": srcs}, open(os.path.join(a.out, "meta.json"), "w"), indent=1)
    report["counts"] = counts; report["labels"] = labels
    json.dump(report, open(os.path.join(a.out, "report.json"), "w"), indent=1)
    log("labels", len(labels), {sp: sum(c.values()) for sp, c in counts.items()})


if __name__ == "__main__":
    main()
