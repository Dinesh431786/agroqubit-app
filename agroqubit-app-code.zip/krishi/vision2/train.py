"""Train the photo fingerprint model on the Indian field-photo set (GPU, ~15-30 min on one L4).
Same phone architecture as before (MobileNetV3-Large -> 256-d unit vector, cosine head), so the pure-Java runtime and
the export are unchanged. Class-balanced sampling (rare diseases are seen as often as common ones), phone-camera
augmentations on the GPU, bf16 autocast, best checkpoint by balanced validation accuracy.
Usage: python3 train.py <data_dir> <out.pt> [--epochs 18] [--weights mnv3.pth]"""
import argparse, json, math, os, sys, time
import numpy as np, torch, torch.nn.functional as F
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from phone_model import Embedder, CosineHead    # the phone model (same as agri_vision/model.py)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("data"); ap.add_argument("out")
    ap.add_argument("--epochs", type=int, default=18); ap.add_argument("--batch", type=int, default=96)
    ap.add_argument("--weights", default="/home/claude/weights/mnv3.pth"); ap.add_argument("--workers", type=int, default=4)
    a = ap.parse_args(); torch.manual_seed(0); np.random.seed(0); dev = "cuda" if torch.cuda.is_available() else "cpu"
    meta = json.load(open(f"{a.data}/meta.json")); labels = meta["labels"]; C = len(labels)
    Xtr = np.load(f"{a.data}/train_X.npy", mmap_mode="r"); ytr = np.load(f"{a.data}/train_y.npy")
    Xva = np.load(f"{a.data}/val_X.npy", mmap_mode="r"); yva = np.load(f"{a.data}/val_y.npy")
    cnt = np.bincount(ytr, minlength=C).astype(np.float64); w = 1.0 / np.maximum(cnt, 1) ** 0.75; p = w[ytr]; p /= p.sum()
    print("train", len(ytr), "val", len(yva), "labels", C, "min/max per label", int(cnt.min()), int(cnt.max()), flush=True)
    net = Embedder(a.weights if os.path.exists(a.weights) else None).to(dev).to(memory_format=torch.channels_last); head = CosineHead(C).to(dev)
    opt = torch.optim.AdamW([{"params": net.backbone.parameters(), "lr": 6e-4}, {"params": list(net.proj.parameters()) + list(head.parameters()), "lr": 3e-3}], weight_decay=0.02)
    steps_per = math.ceil(len(ytr) / a.batch); total = a.epochs * steps_per; base = [g["lr"] for g in opt.param_groups]; step = 0

    def load(idx):  # memmap -> uint8 tensor (sorted reads are faster)
        o = np.argsort(idx); x = torch.from_numpy(np.ascontiguousarray(Xtr[np.sort(idx)]))[torch.from_numpy(np.argsort(o))]
        return x
    def aug(x):     # x uint8 N,256,256,3 on GPU -> float N,3,224,224 (0..255), phone-like variation
        x = x.permute(0, 3, 1, 2).float(); N = x.shape[0]; out = torch.empty(N, 3, 224, 224, device=x.device)
        for i in range(N):
            s = max(120, int(256 * math.sqrt(np.random.uniform(0.40, 1.0)))); t, l = np.random.randint(0, 257 - s, 2)
            im = F.interpolate(x[i:i + 1, :, t:t + s, l:l + s], size=224, mode="bilinear", align_corners=False)[0]
            if np.random.rand() < .5: im = im.flip(2)
            if np.random.rand() < .5: im = im.flip(1)
            im = torch.rot90(im, np.random.randint(4), (1, 2))
            m = im.mean(); im = (im - m) * np.random.uniform(.7, 1.3) + m * np.random.uniform(.7, 1.3)
            im = im * torch.tensor(np.random.uniform(.88, 1.12, 3), dtype=torch.float32, device=x.device).view(3, 1, 1)
            if np.random.rand() < .2: im = F.avg_pool2d(im[None], 3, 1, 1)[0]                       # slight blur (shaky hands)
            out[i] = im.clamp(0, 255)
        return out.contiguous(memory_format=torch.channels_last)
    def evaluate():
        net.eval(); Z = []
        with torch.no_grad(), torch.autocast(dev, dtype=torch.bfloat16, enabled=dev == "cuda"):
            for i in range(0, len(yva), 256):
                x = torch.from_numpy(np.ascontiguousarray(Xva[i:i + 256])).to(dev).permute(0, 3, 1, 2).float()[:, :, 16:240, 16:240]
                Z.append(net(x.contiguous(memory_format=torch.channels_last)).float())
        pred = head(torch.cat(Z)).argmax(1).cpu().numpy(); net.train()
        acc = [(pred[yva == c] == c).mean() for c in range(C) if (yva == c).any()]
        return float(np.mean(acc)), float((pred == yva).mean())
    best = -1; t0 = time.time()
    for ep in range(a.epochs):
        tot = 0.0
        for it in range(steps_per):
            idx = np.random.choice(len(ytr), a.batch, p=p); xb = aug(load(idx).to(dev, non_blocking=True)); yb = torch.from_numpy(ytr[idx]).to(dev)
            warm = min(1, (step + 1) / 200); cos = 0.5 * (1 + math.cos(math.pi * step / total))
            for g, b in zip(opt.param_groups, base): g["lr"] = b * warm * cos
            with torch.autocast(dev, dtype=torch.bfloat16, enabled=dev == "cuda"):
                loss = F.cross_entropy(head(net(xb).float(), yb), yb, label_smoothing=0.1)
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step(); step += 1; tot += loss.item()
        bal, acc = evaluate()
        print(f"ep {ep + 1}/{a.epochs} loss {tot / steps_per:.3f} val balanced {bal:.3f} plain {acc:.3f} t {time.time() - t0:.0f}s", flush=True)
        if bal >= best:
            best = bal; torch.save({"net": net.state_dict(), "head": head.state_dict(), "labels": labels}, a.out)
    print("best val balanced", round(best, 4), flush=True)


if __name__ == "__main__":
    main()
