package in.krishi.doctor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.Deflater;

/**
 * Offline speech recogniser: Whisper (tiny dims, one checkpoint per language) in plain Java. No ML runtime, no native
 * code, no android.* imports. Weights: whisper_&lt;lang&gt;.bin (KRW1, written by speech/whisper/export_whisper.py);
 * everything else (dims, special tokens, forced prompt, suppress lists, mel filters, vocab bytes): whisper_&lt;lang&gt;.json.
 *
 * <p>Pipeline: 16 kHz float PCM -> log-mel exactly as WhisperFeatureExtractor (hann 400, hop 160, centred STFT with
 * reflect padding, power, 80 slaney mel filters, log10, max-8 dynamic range, (x+4)/4) -> encoder (conv k3 + GELU,
 * conv k3 s2 + GELU, + positions, 4 pre-LN blocks, ln_post) -> greedy decoder with KV cache and a forced prefix
 * [sot, lang, transcribe, notimestamps], suppress_tokens at every step and begin_suppress_tokens at the first step.
 *
 * <p>Two encoder modes. FULL: the audio is zero-padded to 30 s (3000 frames, 1500 positions) exactly like Hugging Face,
 * so outputs match transformers. SHORT (what the phone uses): only the frames whose centre lies inside the audio
 * (rounded up to even, + short_pad_frames from the json) go through the encoder; the per-utterance cost scales with the
 * audio length. The frames themselves are identical to FULL mode (same global max), only the context is shorter, which
 * is why our checkpoints are fine-tuned in SHORT mode.
 *
 * <p>All matmuls keep int8 weights (one fp32 scale per row) and float activations: WhisperMath.linear, a register-blocked
 * version of Nn.linear with the same per-output summation order (bit-identical results); the conv stem runs as
 * im2col + the same kernel. Set {@link #nnKernels} to run on Nn.linear / Nn.attention / Nn.conv1d instead.
 * The conv stem and positional tables are fp16 on disk (float in memory).
 *
 * <p>Optional restricted vocabulary (json "vocab_ids", export_whisper.py --keep-text): the token embedding / output
 * projection then hold only the tokens of the language (plus the 256 byte tokens and the specials), which halves the
 * file (about 20 MB instead of 40 MB) and makes each decoder step 2-3x cheaper; ids outside it are never produced.
 *
 * <p>Memory: about 37 MB of weights with the full vocabulary (20 MB of it the int8 token embedding), about 18 MB
 * restricted; activations in SHORT mode for 12 s about 10 MB. Not thread-safe: one transcription at a time per
 * instance (the public methods are synchronized).
 */
@SuppressWarnings("unchecked")
public final class Whisper {
    // ------------------------------------------------------------------ model description
    public final String lang;
    public final int nMels, d, encLayers, decLayers, encHeads, decHeads, vocab, nAudioCtx, nTextCtx;
    public final int sot, eot, langToken, transcribe, noTimestamps, noSpeech;
    public final int maxNewTokens, shortPadFrames;
    final int[] prompt; final int sotIndex; final boolean[] suppress; final int[] beginSuppress;
    /** Output rows (= vocab, or the size of a restricted vocabulary) and the id <-> row maps (null = identity). */
    public final int rows; final int[] idOfRow, rowOfId;
    final float eps;
    // audio front end
    final int sr, nFft, hop, nFrames, chunkSamples; final int nFreq;
    final float[] melFb; final int[] melLo, melHi; final double[] window;
    final int[] fftFactors; final int maxFactor; final double[] fftCos, fftSin;
    // vocab
    final byte[] vocabBytes; final int[] vocabOff; final int textBelow; final boolean[] nontext;

    // ------------------------------------------------------------------ weights
    static final class Lin {
        final Krw.T w; final float[] b;
        Lin(Krw.T w, float[] b) { this.w = w; this.b = b; }
        float[] apply(float[] x, int T) { return mm(w, b, x, T); }
    }
    static final class EncLayer { float[] ln1g, ln1b, ln2g, ln2b; Lin q, k, v, o, fc1, fc2; }
    static final class DecLayer { float[] ln1g, ln1b, lnxg, lnxb, ln2g, ln2b; Lin qkv, o, xq, xk, xv, xo, fc1, fc2; }

    final Krw.T conv1W, conv2W; final float[] conv1b, conv2b, encPos, lnPostG, lnPostB;
    final EncLayer[] enc; final DecLayer[] dec;
    final Krw.T tokEmb, outW; final float[] decPos, lnDecG, lnDecB;

    /** true = run on the shared Nn kernels (Nn.linear / Nn.attention / Nn.conv1d) instead of WhisperMath's blocked
     *  versions. Same results (bit-identical sums), 2-4x slower; kept for checks and benchmarks. */
    public static volatile boolean nnKernels = false;

    static float[] mm(Krw.T w, float[] b, float[] x, int T) { return nnKernels ? Nn.linear(w, b, x, T) : WhisperMath.linear(w, b, x, T); }
    static float[] attn(float[] q, float[] k, float[] v, int Tq, int Tk, int d, int heads, boolean causal) {
        return nnKernels ? Nn.attention(q, k, v, Tq, Tk, d, heads, causal, null) : WhisperMath.attention(q, k, v, Tq, Tk, d, heads, causal);
    }

    // decoder state (preallocated KV caches, cross K/V of the current utterance)
    float[][] kCache, vCache; int cacheRows;
    float[][] xK, xV; int xT;

    // ------------------------------------------------------------------ result
    public static final class Result {
        /** Decoded text (UTF-8 bytes of the text tokens, trimmed). */
        public String text = "";
        /** Generated text tokens (without the prompt and without eot). */
        public int[] tokens = new int[0];
        /** Mean log-probability of the generated tokens incl. eot (OpenAI's avg_logprob). */
        public double avgLogProb = Double.NEGATIVE_INFINITY;
        /** P(&lt;|nocaptions|&gt;) at the start-of-transcript position, from the raw logits. */
        public double noSpeechProb;
        /** len(utf8) / len(deflate(utf8)); &gt; 2.4 means a repetition loop (OpenAI's rule). */
        public double compressionRatio;
        public boolean hitMaxTokens, fullWindow;
        public int samples, melFrames, encPositions, steps;
        public long melMs, encMs, decMs;

        /** OpenAI's no-speech rule. */
        public boolean noSpeech() { return noSpeechProb > 0.6 && avgLogProb < -1.0; }
        /** Probably garbage: repetition loop, ran out of tokens or very unsure. */
        public boolean unreliable() { return text.isEmpty() || compressionRatio > 2.4 || hitMaxTokens || avgLogProb < -1.0; }
        /** 0..1 for the UI: exp(avg log-prob) * (1 - no-speech prob). */
        public double confidence() {
            if (tokens.length == 0) return 0;
            double c = Math.exp(Math.max(-20, avgLogProb)) * (1 - noSpeechProb);
            return Math.max(0, Math.min(1, c));
        }
        public long totalMs() { return melMs + encMs + decMs; }
        @Override public String toString() {
            return String.format(Locale.ROOT, "\"%s\" avg_logprob %.3f no_speech %.3f cr %.2f tokens %d (%s, %d frames; mel %d ms, enc %d ms, dec %d ms)",
                    text, avgLogProb, noSpeechProb, compressionRatio, tokens.length, fullWindow ? "full" : "short", melFrames, melMs, encMs, decMs);
        }
    }

    // ------------------------------------------------------------------ loading
    /** Opens a model file by name (Android assets, a folder, ...); same shape as Krishi.Res, so res::open fits. */
    public interface Opener { InputStream open(String name) throws IOException; }

    public static String assetStem(String lang) { return "whisper_" + lang; }

    /** Loads whisper_&lt;lang&gt;.bin + .json through the app's resource opener (Android assets or a folder). */
    public static Whisper fromRes(Opener res, String lang) throws IOException {
        String json;
        try (InputStream in = res.open(assetStem(lang) + ".json")) { json = readText(in); }
        try (InputStream in = res.open(assetStem(lang) + ".bin")) { return new Whisper(in, json); }
    }

    public static Whisper load(File bin, File json) throws IOException {
        String js;
        try (InputStream in = new FileInputStream(json)) { js = readText(in); }
        try (InputStream in = new FileInputStream(bin)) { return new Whisper(in, js); }
    }

    static String readText(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[1 << 16]; int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        return new String(b.toByteArray(), StandardCharsets.UTF_8);
    }

    public Whisper(InputStream bin, String json) throws IOException {
        Map<String, Object> m = (Map<String, Object>) Json.parse(json);
        if (!"krishi-whisper-1".equals(m.get("format"))) throw new IOException("not a krishi-whisper-1 model description");
        lang = (String) m.get("lang");
        Map<String, Object> dm = (Map<String, Object>) m.get("dims");
        nMels = num(dm, "n_mels"); d = num(dm, "d_model"); encLayers = num(dm, "enc_layers"); decLayers = num(dm, "dec_layers");
        encHeads = num(dm, "enc_heads"); decHeads = num(dm, "dec_heads"); vocab = num(dm, "vocab");
        nAudioCtx = num(dm, "n_audio_ctx"); nTextCtx = num(dm, "n_text_ctx");
        eps = m.get("layer_norm_eps") != null ? (float) ((Number) m.get("layer_norm_eps")).doubleValue() : 1e-5f;
        Map<String, Object> tk = (Map<String, Object>) m.get("tokens");
        sot = num(tk, "sot"); eot = num(tk, "eot"); langToken = num(tk, "lang"); transcribe = num(tk, "transcribe");
        noTimestamps = num(tk, "notimestamps"); noSpeech = tk.get("no_speech") != null ? num(tk, "no_speech") : -1;
        prompt = ints((List<Object>) m.get("prompt"));
        sotIndex = m.get("sot_index") != null ? num(m, "sot_index") : 0;
        // restricted vocabulary (export_whisper.py keep ids): the embedding / output rows are those ids, in order
        Map<String, Object> vi = (Map<String, Object>) m.get("vocab_ids");
        if (vi != null) {
            byte[] b = b64((String) vi.get("b64")); int k = num(vi, "n");
            idOfRow = new int[k]; rowOfId = new int[vocab]; Arrays.fill(rowOfId, -1);
            for (int r = 0; r < k; r++) {
                int id = ((b[4 * r] & 0xff) << 24) | ((b[4 * r + 1] & 0xff) << 16) | ((b[4 * r + 2] & 0xff) << 8) | (b[4 * r + 3] & 0xff);
                if (id < 0 || id >= vocab) throw new IOException("vocab id " + id);
                idOfRow[r] = id; rowOfId[id] = r;
            }
            rows = k;
        } else { idOfRow = null; rowOfId = null; rows = vocab; }
        suppress = new boolean[rows];   // indexed by output row
        for (int t : ints((List<Object>) m.get("suppress_tokens"))) { int r = rowOf(t); if (r >= 0) suppress[r] = true; }
        int[] bs = ints((List<Object>) m.get("begin_suppress_tokens")); int nb = 0;
        for (int t : bs) if (rowOf(t) >= 0) bs[nb++] = rowOf(t);
        beginSuppress = Arrays.copyOf(bs, nb);
        maxNewTokens = m.get("max_new_tokens") != null ? num(m, "max_new_tokens") : 96;

        Map<String, Object> au = (Map<String, Object>) m.get("audio");
        sr = num(au, "sr"); nFft = num(au, "n_fft"); hop = num(au, "hop"); chunkSamples = num(au, "chunk_samples"); nFrames = num(au, "n_frames");
        shortPadFrames = au.get("short_pad_frames") != null ? num(au, "short_pad_frames") : 0;
        nFreq = nFft / 2 + 1;
        Map<String, Object> mf = (Map<String, Object>) m.get("mel_filters");
        List<Object> msh = (List<Object>) mf.get("shape");
        if (((Number) msh.get(0)).intValue() != nMels || ((Number) msh.get(1)).intValue() != nFreq) throw new IOException("mel filter shape " + msh);
        melFb = floatsBE(b64((String) mf.get("b64")), nMels * nFreq);
        melLo = new int[nMels]; melHi = new int[nMels];
        for (int i = 0; i < nMels; i++) {
            int lo = nFreq, hi = 0;
            for (int k = 0; k < nFreq; k++) if (melFb[i * nFreq + k] != 0f) { lo = Math.min(lo, k); hi = k + 1; }
            melLo[i] = Math.min(lo, hi); melHi[i] = hi;
        }
        window = new double[nFft];
        for (int i = 0; i < nFft; i++) window[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / nFft);   // torch.hann_window (periodic)
        fftFactors = factor(nFft);
        int mf0 = 1; for (int f : fftFactors) mf0 = Math.max(mf0, f); maxFactor = mf0;
        fftCos = new double[nFft]; fftSin = new double[nFft];
        for (int i = 0; i < nFft; i++) { fftCos[i] = Math.cos(2 * Math.PI * i / nFft); fftSin[i] = Math.sin(2 * Math.PI * i / nFft); }

        Map<String, Object> vm = (Map<String, Object>) m.get("vocab");
        textBelow = num(vm, "text_below");
        byte[] lens = b64((String) vm.get("lens_b64")); vocabBytes = b64((String) vm.get("bytes_b64"));
        int nv = num(vm, "n"); vocabOff = new int[nv + 1];
        for (int i = 0; i < nv; i++) vocabOff[i + 1] = vocabOff[i] + (((lens[2 * i] & 0xff) << 8) | (lens[2 * i + 1] & 0xff));
        if (vocabOff[nv] != vocabBytes.length) throw new IOException("vocab blob size mismatch");
        nontext = new boolean[nv];
        for (int t : ints((List<Object>) vm.get("nontext_ids"))) if (t >= 0 && t < nv) nontext[t] = true;

        // weights
        Map<String, Krw.T> w = Krw.read(bin);
        conv1W = need(w, "encoder.conv1.weight"); conv1b = vec(w, "encoder.conv1.bias");
        conv2W = need(w, "encoder.conv2.weight"); conv2b = vec(w, "encoder.conv2.bias");
        encPos = need(w, "encoder.embed_positions.weight").floats();
        lnPostG = vec(w, "encoder.layer_norm.weight"); lnPostB = vec(w, "encoder.layer_norm.bias");
        enc = new EncLayer[encLayers];
        for (int l = 0; l < encLayers; l++) {
            String p = "encoder.layers." + l + ".";
            EncLayer L = new EncLayer(); enc[l] = L;
            L.ln1g = vec(w, p + "self_attn_layer_norm.weight"); L.ln1b = vec(w, p + "self_attn_layer_norm.bias");
            L.q = lin(w, p + "self_attn.q_proj"); L.k = lin(w, p + "self_attn.k_proj"); L.v = lin(w, p + "self_attn.v_proj"); L.o = lin(w, p + "self_attn.out_proj");
            L.ln2g = vec(w, p + "final_layer_norm.weight"); L.ln2b = vec(w, p + "final_layer_norm.bias");
            L.fc1 = lin(w, p + "fc1"); L.fc2 = lin(w, p + "fc2");
        }
        tokEmb = need(w, "decoder.embed_tokens.weight");
        outW = w.containsKey("proj_out.weight") ? w.get("proj_out.weight") : tokEmb;
        decPos = need(w, "decoder.embed_positions.weight").floats();
        lnDecG = vec(w, "decoder.layer_norm.weight"); lnDecB = vec(w, "decoder.layer_norm.bias");
        dec = new DecLayer[decLayers];
        for (int l = 0; l < decLayers; l++) {
            String p = "decoder.layers." + l + ".";
            DecLayer L = new DecLayer(); dec[l] = L;
            L.ln1g = vec(w, p + "self_attn_layer_norm.weight"); L.ln1b = vec(w, p + "self_attn_layer_norm.bias");
            L.qkv = fuse(lin(w, p + "self_attn.q_proj"), lin(w, p + "self_attn.k_proj"), lin(w, p + "self_attn.v_proj"));
            L.o = lin(w, p + "self_attn.out_proj");
            L.lnxg = vec(w, p + "encoder_attn_layer_norm.weight"); L.lnxb = vec(w, p + "encoder_attn_layer_norm.bias");
            L.xq = lin(w, p + "encoder_attn.q_proj"); L.xk = lin(w, p + "encoder_attn.k_proj"); L.xv = lin(w, p + "encoder_attn.v_proj");
            L.xo = lin(w, p + "encoder_attn.out_proj");
            L.ln2g = vec(w, p + "final_layer_norm.weight"); L.ln2b = vec(w, p + "final_layer_norm.bias");
            L.fc1 = lin(w, p + "fc1"); L.fc2 = lin(w, p + "fc2");
        }
        if (tokEmb.rows != rows || tokEmb.cols != d || outW.rows != rows) throw new IOException("token embedding " + tokEmb.rows + "x" + tokEmb.cols);
        for (int t : prompt) if (rowOf(t) < 0) throw new IOException("prompt token " + t + " not in the vocabulary");
        if (rowOf(eot) < 0) throw new IOException("eot not in the vocabulary");
        if (encPos.length < nAudioCtx * d || decPos.length < nTextCtx * d) throw new IOException("positional tables too small");
        if (prompt.length < 1 || prompt.length >= nTextCtx) throw new IOException("bad prompt");
    }

    /** Output row of a token id (-1 if the restricted vocabulary lacks it). */
    public int rowOf(int id) { return id < 0 || id >= vocab ? -1 : rowOfId == null ? id : rowOfId[id]; }
    /** Token id of an output row. */
    public int idOf(int row) { return idOfRow == null ? row : idOfRow[row]; }

    static int num(Map<String, Object> m, String k) {
        Object v = m.get(k); if (v == null) throw new IllegalArgumentException("missing " + k);
        return ((Number) v).intValue();
    }
    static int[] ints(List<Object> l) {
        if (l == null) return new int[0];
        int[] a = new int[l.size()]; for (int i = 0; i < a.length; i++) a[i] = ((Number) l.get(i)).intValue(); return a;
    }
    static Krw.T need(Map<String, Krw.T> w, String n) throws IOException {
        Krw.T t = w.get(n); if (t == null) throw new IOException("weight missing: " + n); return t;
    }
    static float[] vec(Map<String, Krw.T> w, String n) throws IOException { return need(w, n).floats(); }
    static Lin lin(Map<String, Krw.T> w, String p) throws IOException {
        Krw.T b = w.get(p + ".bias"); return new Lin(need(w, p + ".weight"), b == null ? null : b.floats());
    }
    /** One [3d][d] weight for q|k|v (k has no bias): one matmul per decoder step instead of three. */
    static Lin fuse(Lin q, Lin k, Lin v) {
        Krw.T t = new Krw.T(); int r = q.w.rows, c = q.w.cols;
        t.rows = 3 * r; t.cols = c; t.shape = new int[]{3 * r, c};
        if (q.w.isQ8() && k.w.isQ8() && v.w.isQ8()) {
            t.q = new byte[3 * r * c]; t.sc = new float[3 * r];
            System.arraycopy(q.w.q, 0, t.q, 0, r * c); System.arraycopy(k.w.q, 0, t.q, r * c, r * c); System.arraycopy(v.w.q, 0, t.q, 2 * r * c, r * c);
            System.arraycopy(q.w.sc, 0, t.sc, 0, r); System.arraycopy(k.w.sc, 0, t.sc, r, r); System.arraycopy(v.w.sc, 0, t.sc, 2 * r, r);
        } else {
            t.f = new float[3 * r * c];
            System.arraycopy(q.w.floats(), 0, t.f, 0, r * c); System.arraycopy(k.w.floats(), 0, t.f, r * c, r * c); System.arraycopy(v.w.floats(), 0, t.f, 2 * r * c, r * c);
        }
        float[] b = new float[3 * r];
        if (q.b != null) System.arraycopy(q.b, 0, b, 0, r);
        if (k.b != null) System.arraycopy(k.b, 0, b, r, r);
        if (v.b != null) System.arraycopy(v.b, 0, b, 2 * r, r);
        return new Lin(t, b);
    }

    // ------------------------------------------------------------------ base64 (java.util.Base64 needs API 26)
    static byte[] b64(String s) {
        int[] val = new int[128]; Arrays.fill(val, -1);
        String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        for (int i = 0; i < 64; i++) val[alpha.charAt(i)] = i;
        val['-'] = 62; val['_'] = 63;
        ByteArrayOutputStream out = new ByteArrayOutputStream(s.length() * 3 / 4 + 3);
        int acc = 0, bits = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '=') break;
            if (c >= 128 || val[c] < 0) continue;   // whitespace / line breaks
            acc = (acc << 6) | val[c]; bits += 6;
            if (bits >= 8) { bits -= 8; out.write((acc >> bits) & 0xff); }
        }
        return out.toByteArray();
    }
    static float[] floatsBE(byte[] b, int n) {
        if (b.length < 4 * n) throw new IllegalArgumentException("need " + n + " floats, got " + b.length + " bytes");
        float[] f = new float[n];
        for (int i = 0; i < n; i++) {
            int o = 4 * i; f[i] = Float.intBitsToFloat(((b[o] & 0xff) << 24) | ((b[o + 1] & 0xff) << 16) | ((b[o + 2] & 0xff) << 8) | (b[o + 3] & 0xff));
        }
        return f;
    }

    // ------------------------------------------------------------------ log-mel front end
    /** Mel frames for SHORT mode: frames whose centre lies inside the audio + short_pad_frames, rounded up to even. */
    public int shortFrames(int nSamples) {
        int f = (Math.min(nSamples, chunkSamples) + hop - 1) / hop + shortPadFrames;
        f += f & 1;
        return Math.max(2, Math.min(nFrames, f));
    }

    /**
     * Log-mel [nMels][frames] (channel-major) of pcm[0..n), identical to WhisperFeatureExtractor on the audio zero-padded
     * to 30 s: frames = 3000 gives the FULL window, shortFrames(n) the SHORT one (same values, fewer frames).
     */
    public float[] logMel(final float[] pcm, int nIn, final int frames) {
        final int n = Math.max(0, Math.min(nIn, Math.min(pcm.length, chunkSamples)));
        if (frames < 1 || frames > nFrames) throw new IllegalArgumentException("frames " + frames);
        // frames touching the audio decide the global max; the rest of the 30 s window is log10(1e-10) = -10
        int seen = n == 0 ? 0 : Math.min(nFrames, (n + nFft / 2 + hop - 1) / hop);
        final int count = Math.max(frames, seen);
        final float[] lg = new float[count * nMels];       // [frame][mel]
        final int pairs = (count + 1) / 2, half = nFft / 2;
        Nn.par(pairs, (long) pairs * 40_000, (a, e) -> {
            double[] zr = new double[nFft], zi = new double[nFft], yr = new double[nFft], yi = new double[nFft];
            double[] pa = new double[nFreq], pb = new double[nFreq], tr = new double[maxFactor], ti = new double[maxFactor];
            for (int p = a; p < e; p++) {
                int t0 = 2 * p, t1 = 2 * p + 1;
                for (int i = 0; i < nFft; i++) {
                    zr[i] = sample(pcm, n, t0 * hop - half + i) * window[i];
                    zi[i] = t1 < count ? sample(pcm, n, t1 * hop - half + i) * window[i] : 0;
                }
                fft(zr, zi, 0, 1, nFft, yr, yi, 0, 0, tr, ti);
                for (int k = 0; k < nFreq; k++) {
                    int nk = k == 0 ? 0 : nFft - k;
                    double ar = (yr[k] + yr[nk]) * 0.5, ai = (yi[k] - yi[nk]) * 0.5;
                    double br = (yi[k] + yi[nk]) * 0.5, bi = (yr[nk] - yr[k]) * 0.5;
                    pa[k] = ar * ar + ai * ai; pb[k] = br * br + bi * bi;
                }
                melRow(pa, lg, t0 * nMels);
                if (t1 < count) melRow(pb, lg, t1 * nMels);
            }
        });
        float mx = -10f;   // log10(1e-10): the value of every all-zero frame of the 30 s window
        for (float v : lg) if (v > mx) mx = v;
        final float floor = mx - 8.0f;
        float[] out = new float[nMels * frames];
        for (int t = 0; t < frames; t++)
            for (int c = 0; c < nMels; c++) {
                float v = t < count ? lg[t * nMels + c] : -10f;
                out[c * frames + t] = (Math.max(v, floor) + 4.0f) / 4.0f;
            }
        return out;
    }

    /** Sample j of the 30 s window (audio then zeros) with torch.stft's reflect padding at both ends. */
    private float sample(float[] pcm, int n, int j) {
        if (j < 0) j = -j;
        if (j >= chunkSamples) j = 2 * (chunkSamples - 1) - j;
        return j < n ? pcm[j] : 0f;
    }

    private void melRow(double[] power, float[] dst, int off) {
        for (int m = 0; m < nMels; m++) {
            double s = 0; int o = m * nFreq;
            for (int k = melLo[m]; k < melHi[m]; k++) s += melFb[o + k] * power[k];
            dst[off + m] = (float) Math.log10(Math.max(s, 1e-10));
        }
    }

    static int[] factor(int n) {
        List<Integer> f = new ArrayList<>();
        for (int p : new int[]{4, 2, 3, 5}) while (n % p == 0 && n > 1) { f.add(p); n /= p; }
        for (int p = 7; n > 1; p += 2) while (n % p == 0) { f.add(p); n /= p; }
        int[] a = new int[f.size()]; for (int i = 0; i < a.length; i++) a[i] = f.get(i); return a;
    }

    /**
     * Mixed-radix decimation-in-time FFT: y[yo..yo+n) = DFT of x[xo], x[xo+s], ... (n points), twiddles from the N-point
     * table. tr/ti: scratch of length >= the largest factor (one pair per thread; levels never overlap).
     */
    private void fft(double[] xr, double[] xi, int xo, int s, int n, double[] yr, double[] yi, int yo, int fi, double[] tr, double[] ti) {
        if (n == 1) { yr[yo] = xr[xo]; yi[yo] = xi[xo]; return; }
        int p = fftFactors[fi], m = n / p, N = nFft, tw = N / n;
        for (int q = 0; q < p; q++) fft(xr, xi, xo + q * s, s * p, m, yr, yi, yo + q * m, fi + 1, tr, ti);
        for (int k = 0; k < m; k++) {
            for (int q = 0; q < p; q++) {      // t_q = W_n^{qk} * Y_q[k]
                int e = (q * k * tw) % N; double c = fftCos[e], sn = fftSin[e], a = yr[yo + q * m + k], b = yi[yo + q * m + k];
                tr[q] = a * c + b * sn; ti[q] = b * c - a * sn;
            }
            for (int r = 0; r < p; r++) {      // X[k + r m] = sum_q t_q W_p^{qr}
                double sr = 0, si = 0;
                for (int q = 0; q < p; q++) {
                    int e = (q * r * m * tw) % N; double c = fftCos[e], sn = fftSin[e];
                    sr += tr[q] * c + ti[q] * sn; si += ti[q] * c - tr[q] * sn;
                }
                yr[yo + k + r * m] = sr; yi[yo + k + r * m] = si;
            }
        }
    }

    // ------------------------------------------------------------------ encoder
    /** mel [nMels][frames] (frames even, <= 3000) -> hidden states [frames/2][d] after ln_post. */
    public synchronized float[] encode(float[] mel, int frames) {
        if (frames < 2 || frames > 2 * nAudioCtx) throw new IllegalArgumentException("frames " + frames);
        int T = (frames - 1) / 2 + 1;
        float[] h;
        if (nnKernels) {
            float[] x = Nn.conv1d(mel, nMels, frames, conv1W, conv1b, d, 3, 1, 1, 1, 1); WhisperMath.gelu(x);
            float[] y = Nn.conv1d(x, d, frames, conv2W, conv2b, d, 3, 2, 1, 1, 1); x = null; WhisperMath.gelu(y);
            h = new float[T * d];
            for (int c = 0; c < d; c++) { int yo = c * T; for (int t = 0; t < T; t++) h[t * d + c] = y[yo + t]; }
        } else {
            float[] x = WhisperMath.conv3(mel, nMels, frames, true, 1, conv1W, conv1b); WhisperMath.gelu(x);   // [frames][d]
            h = WhisperMath.conv3(x, d, frames, false, 2, conv2W, conv2b); x = null; WhisperMath.gelu(h);      // [T][d]
        }
        for (int i = 0; i < T * d; i++) h[i] += encPos[i];
        for (EncLayer L : enc) {
            float[] u = h.clone(); Nn.layerNorm(u, T, d, L.ln1g, L.ln1b, eps);
            float[] q = L.q.apply(u, T), k = L.k.apply(u, T), v = L.v.apply(u, T); u = null;
            float[] a = attn(q, k, v, T, T, d, encHeads, false); q = k = v = null;
            add(h, L.o.apply(a, T)); a = null;
            u = h.clone(); Nn.layerNorm(u, T, d, L.ln2g, L.ln2b, eps);
            float[] f = L.fc1.apply(u, T); u = null; WhisperMath.gelu(f);
            add(h, L.fc2.apply(f, T));
        }
        Nn.layerNorm(h, T, d, lnPostG, lnPostB, eps);
        return h;
    }

    static void add(float[] h, float[] o) { for (int i = 0; i < h.length; i++) h[i] += o[i]; }

    // ------------------------------------------------------------------ decoder
    /** Cross-attention K/V of every decoder layer, computed once per utterance. */
    synchronized void setEncoder(float[] encOut, int T) {
        if (xK == null) { xK = new float[decLayers][]; xV = new float[decLayers][]; }
        for (int l = 0; l < decLayers; l++) { xK[l] = dec[l].xk.apply(encOut, T); xV[l] = dec[l].xv.apply(encOut, T); }
        xT = T;
    }

    private void ensureCache(int rows) {
        if (kCache != null && cacheRows >= rows) return;
        cacheRows = Math.max(rows, prompt.length + maxNewTokens);
        kCache = new float[decLayers][cacheRows * d]; vCache = new float[decLayers][cacheRows * d];
    }

    /** Runs n tokens at positions pos0.. through the decoder (KV cache updated); returns final-LN hidden [n][d]. */
    private float[] decoderStep(int[] toks, int n, int pos0) {
        ensureCache(pos0 + n);
        float[] h = new float[n * d];
        for (int i = 0; i < n; i++) {
            tokEmb.row(rowOf(toks[i]), h, i * d);
            int po = (pos0 + i) * d; for (int c = 0; c < d; c++) h[i * d + c] += decPos[po + c];
        }
        for (int l = 0; l < decLayers; l++) {
            DecLayer L = dec[l];
            float[] u = h.clone(); Nn.layerNorm(u, n, d, L.ln1g, L.ln1b, eps);
            float[] qkv = L.qkv.apply(u, n), q = new float[n * d];
            for (int i = 0; i < n; i++) {
                System.arraycopy(qkv, i * 3 * d, q, i * d, d);
                System.arraycopy(qkv, i * 3 * d + d, kCache[l], (pos0 + i) * d, d);
                System.arraycopy(qkv, i * 3 * d + 2 * d, vCache[l], (pos0 + i) * d, d);
            }
            add(h, L.o.apply(attn(q, kCache[l], vCache[l], n, pos0 + n, d, decHeads, true), n));
            u = h.clone(); Nn.layerNorm(u, n, d, L.lnxg, L.lnxb, eps);
            add(h, L.xo.apply(attn(L.xq.apply(u, n), xK[l], xV[l], n, xT, d, decHeads, false), n));
            u = h.clone(); Nn.layerNorm(u, n, d, L.ln2g, L.ln2b, eps);
            float[] f = L.fc1.apply(u, n); WhisperMath.gelu(f);
            add(h, L.fc2.apply(f, n));
        }
        Nn.layerNorm(h, n, d, lnDecG, lnDecB, eps);
        return h;
    }

    /** Raw logits (no suppression) after the forced prompt, for row sot_index and the last prompt row: [2][rows]. */
    private float[] promptLogits() {
        int P = prompt.length;
        float[] h = decoderStep(prompt, P, 0), rows = new float[2 * d];
        System.arraycopy(h, sotIndex * d, rows, 0, d); System.arraycopy(h, (P - 1) * d, rows, d, d);
        return mm(outW, null, rows, 2);
    }

    /** Raw first-step logits after the forced prefix, indexed by token id (-inf for ids outside a restricted vocabulary). */
    public synchronized float[] firstLogits(float[] encOut, int T) {
        setEncoder(encOut, T);
        float[] lg = promptLogits(), out = new float[vocab];
        if (idOfRow == null) System.arraycopy(lg, rows, out, 0, rows);
        else { Arrays.fill(out, Float.NEGATIVE_INFINITY); for (int r = 0; r < rows; r++) out[idOfRow[r]] = lg[rows + r]; }
        return out;
    }

    /**
     * Greedy decoding: suppress_tokens always, begin_suppress_tokens at the first step, stop at eot (if stopAtEot) or after
     * maxNew tokens. Returns every generated id (incl. eot); fills avgLogProb / noSpeechProb / hitMaxTokens / steps of r.
     */
    public synchronized int[] greedy(float[] encOut, int T, int maxNew, boolean stopAtEot, Result r) {
        maxNew = Math.max(1, Math.min(maxNew, nTextCtx - prompt.length));
        setEncoder(encOut, T);
        float[] lg = promptLogits();
        int nsr = rowOf(noSpeech);
        if (r != null) r.noSpeechProb = nsr >= 0 ? softmaxAt(lg, 0, rows, nsr) : 0;
        float[] logits = Arrays.copyOfRange(lg, rows, 2 * rows);
        int[] out = new int[maxNew]; int n = 0; double sum = 0; int[] one = new int[1];
        for (int step = 0; step < maxNew; step++) {
            for (int t = 0; t < rows; t++) if (suppress[t]) logits[t] = Float.NEGATIVE_INFINITY;
            if (step == 0) for (int t : beginSuppress) logits[t] = Float.NEGATIVE_INFINITY;
            int bestRow = 0; float bv = Float.NEGATIVE_INFINITY;
            for (int t = 0; t < rows; t++) if (logits[t] > bv) { bv = logits[t]; bestRow = t; }
            double lse = 0; for (int t = 0; t < rows; t++) if (logits[t] != Float.NEGATIVE_INFINITY) lse += Math.exp(logits[t] - bv);
            sum += -Math.log(lse);    // log p(best) = bv - (bv + log sum exp(l - bv))
            int best = idOf(bestRow);
            out[n++] = best;
            if (best == eot && stopAtEot) break;
            if (step == maxNew - 1) break;
            one[0] = best;
            logits = mm(outW, null, decoderStep(one, 1, prompt.length + step), 1);
        }
        if (r != null) {
            r.steps = n; r.avgLogProb = sum / Math.max(1, n);
            r.hitMaxTokens = n == maxNew && out[n - 1] != eot;
        }
        return Arrays.copyOf(out, n);
    }

    static double softmaxAt(float[] x, int off, int n, int idx) {
        float mx = Float.NEGATIVE_INFINITY; for (int i = 0; i < n; i++) mx = Math.max(mx, x[off + i]);
        double s = 0; for (int i = 0; i < n; i++) s += Math.exp(x[off + i] - mx);
        return Math.exp(x[off + idx] - mx) / s;
    }

    // ------------------------------------------------------------------ text
    /** Text tokens -> string: raw bytes of every id below eot (special ids skipped), decoded as UTF-8, trimmed. */
    public String detokenize(int[] ids, int n) {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        for (int i = 0; i < n; i++) {
            int t = ids[i];
            if (t < 0 || t >= textBelow || t >= nontext.length || nontext[t]) continue;
            b.write(vocabBytes, vocabOff[t], vocabOff[t + 1] - vocabOff[t]);
        }
        return new String(b.toByteArray(), StandardCharsets.UTF_8).trim();
    }

    static double compressionRatio(String s) {
        byte[] b = s.getBytes(StandardCharsets.UTF_8); if (b.length == 0) return 0;
        Deflater z = new Deflater(9); z.setInput(b); z.finish();
        byte[] buf = new byte[b.length + 64]; int n = 0;
        while (!z.finished()) { int k = z.deflate(buf, n, buf.length - n); n += k; if (k == 0 && n >= buf.length) break; }
        z.end();
        return (double) b.length / Math.max(1, n);
    }

    // ------------------------------------------------------------------ one call
    /** pcm: 16 kHz mono floats in [-1, 1]. fullWindow = HF-identical 30 s window; false = SHORT mode (phone). */
    public synchronized Result transcribe(float[] pcm, int n, boolean fullWindow) { return transcribe(pcm, n, fullWindow, maxNewTokens); }

    public synchronized Result transcribe(float[] pcm, int n, boolean fullWindow, int maxNew) {
        Result r = new Result(); r.fullWindow = fullWindow; n = Math.max(0, Math.min(n, pcm.length)); r.samples = n;
        if (n < hop) return r;
        long t0 = System.nanoTime();
        int frames = fullWindow ? nFrames : shortFrames(n);
        float[] mel = logMel(pcm, n, frames);
        long t1 = System.nanoTime();
        float[] e = encode(mel, frames); mel = null;
        int T = frames / 2;
        long t2 = System.nanoTime();
        int[] ids = greedy(e, T, maxNew, true, r);
        long t3 = System.nanoTime();
        int k = ids.length; if (k > 0 && ids[k - 1] == eot) k--;
        r.tokens = Arrays.copyOf(ids, k); r.text = detokenize(ids, k); r.compressionRatio = compressionRatio(r.text);
        r.melFrames = frames; r.encPositions = T;
        r.melMs = (t1 - t0) / 1_000_000; r.encMs = (t2 - t1) / 1_000_000; r.decMs = (t3 - t2) / 1_000_000;
        xK = xV = null;   // free the per-utterance cross K/V
        return r;
    }

    /** Frees per-utterance buffers (the weights stay). */
    public synchronized void trim() { xK = xV = null; kCache = vCache = null; cacheRows = 0; }
}
