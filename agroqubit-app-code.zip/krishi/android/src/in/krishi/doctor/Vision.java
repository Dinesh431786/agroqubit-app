package in.krishi.doctor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/**
 * Photo -> 256-number fingerprint, in plain Java (no TensorFlow / ONNX runtime, no native code).
 * Runs the op list written by tools/export_vision.py (MobileNetV3-Large backbone, BatchNorm already folded).
 * Pointwise / head weights stay int8 in memory (one fp32 scale per output channel, applied on the fly);
 * depthwise + stem weights are fp16 on disk. Peak memory is about 5 MB of weights + 7 MB of activations.
 * Diagnosis = best cosine to a few fingerprints per disease (k-means sub-centroids of training photos).
 */
@SuppressWarnings("unchecked")
public final class Vision {
    static final class W { float[] f; byte[] q; float[] sc; int rows, cols; }

    final List<Map<String, Object>> prog; final Map<String, W> w = new HashMap<>(); final Map<String, Integer> lastUse = new HashMap<>();
    public final List<String> labels; public final Map<String, String> app; public final double notSure; public final int size, resize;
    /** label -> {crop, kind: disease|pest|healthy|other, app: [doctor diseases], target: fact-bank target} (field-photo model; may be null) */
    public final Map<String, Object> meta;
    final float[] fp; final int nfp, dim; final int[] protoClass; final String input, output;
    static ExecutorService pool; static int threads;

    public Vision(InputStream bin, String json) throws IOException {
        Map<String, Object> m = (Map<String, Object>) Json.parse(json);
        prog = (List<Map<String, Object>>) (List<?>) m.get("prog"); labels = (List<String>) (List<?>) m.get("labels");
        app = new HashMap<>(); for (Map.Entry<String, Object> e : ((Map<String, Object>) m.get("app")).entrySet()) app.put(e.getKey(), (String) e.getValue());
        notSure = ((Number) m.get("not_sure")).doubleValue(); size = ((Number) m.get("size")).intValue(); resize = ((Number) m.get("resize")).intValue();
        meta = m.get("meta") instanceof Map ? (Map<String, Object>) m.get("meta") : null;
        input = (String) m.get("input"); output = (String) m.get("output");
        DataInputStream d = new DataInputStream(new BufferedInputStream(bin, 1 << 16));
        byte[] magic = new byte[4]; d.readFully(magic);
        if (!new String(magic, StandardCharsets.US_ASCII).equals("KRW1")) throw new IOException("bad vision file");
        int n = d.readInt();
        for (int t = 0; t < n; t++) {
            byte[] nb = new byte[d.readShort()]; d.readFully(nb); String name = new String(nb, StandardCharsets.UTF_8);
            byte dtype = d.readByte(); int nd = d.readInt(); int[] sh = new int[nd]; int size = 1;
            for (int i = 0; i < nd; i++) { sh[i] = d.readInt(); size *= sh[i]; }
            W x = new W(); x.rows = sh[0]; x.cols = nd > 1 ? size / sh[0] : 1;
            if (dtype == 1) { x.q = new byte[size]; d.readFully(x.q); x.sc = new float[sh[0]]; for (int i = 0; i < sh[0]; i++) x.sc[i] = d.readFloat(); }
            else if (dtype == 2) { x.f = new float[size]; for (int i = 0; i < size; i++) x.f[i] = half(d.readShort()); }
            else { x.f = new float[size]; for (int i = 0; i < size; i++) x.f[i] = d.readFloat(); }
            w.put(name, x);
        }
        W f = w.get("fingerprints"); fp = f.f; nfp = f.rows; dim = f.cols; protoClass = new int[nfp];
        List<Object> pc = (List<Object>) m.get("proto_class");
        for (int i = 0; i < nfp; i++) protoClass[i] = pc != null ? ((Number) pc.get(i)).intValue() : i;
        for (int i = 0; i < prog.size(); i++) { Map<String, Object> op = prog.get(i); lastUse.put((String) op.get("in"), i); if (op.get("in2") != null) lastUse.put((String) op.get("in2"), i); }
    }

    static float half(short h) {
        int s = (h >> 15) & 1, e = (h >> 10) & 0x1f, m = h & 0x3ff; float v;
        if (e == 0) v = (float) (m * Math.pow(2, -24)); else if (e == 31) v = m == 0 ? Float.POSITIVE_INFINITY : Float.NaN;
        else v = Float.intBitsToFloat(((e - 15 + 127) << 23) | (m << 13));
        return s == 1 ? -v : v;
    }

    static synchronized ExecutorService pool() {
        if (pool == null) { threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors())); pool = Executors.newFixedThreadPool(threads); }
        return pool;
    }
    /** Frees the worker threads (call when the photo screen is done). */
    public static synchronized void release() { if (pool != null) { pool.shutdown(); pool = null; } }

    interface Range { void run(int from, int to); }
    static void par(int n, long work, Range r) {
        if (work < 200_000 || n < 2) { r.run(0, n); return; }
        ExecutorService p = pool(); int k = Math.min(threads, n); List<Future<?>> fs = new ArrayList<>();
        for (int t = 0; t < k; t++) { final int a = n * t / k, b = n * (t + 1) / k; fs.add(p.submit(() -> r.run(a, b))); }
        try { for (Future<?> f : fs) f.get(); } catch (Exception e) { throw new RuntimeException(e); }
    }

    /** chw: 3 x size x size RGB in 0..255 (no normalisation; the program does it). Returns the unit fingerprint vector. */
    public float[] embed(float[] chw) {
        Map<String, float[]> v = new HashMap<>(); Map<String, int[]> s = new HashMap<>();
        v.put(input, chw); s.put(input, new int[]{3, size, size});
        for (int i = 0; i < prog.size(); i++) {
            Map<String, Object> op = prog.get(i); String o = (String) op.get("op"), in = (String) op.get("in"), out = (String) op.get("out");
            float[] x = v.get(in); int[] xs = s.get(in); float[] y; int[] ys = xs;
            switch (o) {
                case "conv": {
                    int cout = ni(op, "cout"), k = ni(op, "k"), st = ni(op, "stride"), pd = ni(op, "pad"), g = ni(op, "group");
                    int oh = (xs[1] + 2 * pd - k) / st + 1, ow = (xs[2] + 2 * pd - k) / st + 1; ys = new int[]{cout, oh, ow};
                    y = conv(x, xs[0], xs[1], xs[2], w.get((String) op.get("w")), w.get((String) op.get("b")).f, cout, k, st, pd, g, oh, ow); break;
                }
                case "gemm": {
                    W wt = w.get((String) op.get("w")); float[] b = w.get((String) op.get("b")).f; int co = ni(op, "cout"), ci = ni(op, "cin");
                    y = new float[co]; for (int r = 0; r < co; r++) y[r] = b[r] + dot(wt, r, x, ci); ys = new int[]{co, 1, 1}; break;
                }
                case "hswish": { y = new float[x.length]; for (int j = 0; j < x.length; j++) { float a = x[j]; y[j] = a * Math.min(Math.max(a + 3f, 0f), 6f) / 6f; } break; }
                case "relu": { y = new float[x.length]; for (int j = 0; j < x.length; j++) y[j] = Math.max(x[j], 0f); break; }
                case "hsig": {
                    float al = (float) nd(op, "alpha"), be = (float) nd(op, "beta"); y = new float[x.length];
                    for (int j = 0; j < x.length; j++) y[j] = Math.max(0f, Math.min(1f, al * x[j] + be)); break;
                }
                case "add": { float[] x2 = v.get((String) op.get("in2")); y = new float[x.length]; for (int j = 0; j < x.length; j++) y[j] = x[j] + x2[j]; break; }
                case "mul": {
                    float[] x2 = v.get((String) op.get("in2")); int[] s2 = s.get((String) op.get("in2"));
                    if (x2.length > x.length) { float[] t = x; x = x2; x2 = t; ys = s2; }
                    y = new float[x.length];
                    if (x2.length == x.length) for (int j = 0; j < x.length; j++) y[j] = x[j] * x2[j];
                    else { int hw = x.length / x2.length; for (int c = 0; c < x2.length; c++) { float g = x2[c]; for (int j = c * hw, e = j + hw; j < e; j++) y[j] = x[j] * g; } }
                    break;
                }
                case "gap": {
                    int C = xs[0], hw = xs[1] * xs[2]; y = new float[C];
                    for (int c = 0; c < C; c++) { double a = 0; for (int j = c * hw, e = j + hw; j < e; j++) a += x[j]; y[c] = (float) (a / hw); }
                    ys = new int[]{C, 1, 1}; break;
                }
                case "affine": {
                    List<Object> sc = (List<Object>) op.get("scale"), sh = (List<Object>) op.get("shift"); int C = xs[0], hw = xs[1] * xs[2]; y = new float[x.length];
                    for (int c = 0; c < C; c++) { float a = ((Number) sc.get(c)).floatValue(), b = ((Number) sh.get(c)).floatValue(); for (int j = c * hw, e = j + hw; j < e; j++) y[j] = x[j] * a + b; }
                    break;
                }
                case "l2norm": { double n2 = 0; for (float a : x) n2 += a * a; float inv = (float) (1 / Math.max(Math.sqrt(n2), 1e-12)); y = new float[x.length]; for (int j = 0; j < x.length; j++) y[j] = x[j] * inv; break; }
                case "alias": y = x; break;
                default: throw new IllegalStateException("op " + o);
            }
            v.put(out, y); s.put(out, ys);
            if (lastUse.get(in) != null && lastUse.get(in) == i && !in.equals(out)) v.remove(in);      // free activations early
            String in2 = (String) op.get("in2"); if (in2 != null && lastUse.get(in2) == i) v.remove(in2);
        }
        return v.get(output);
    }
    static int ni(Map<String, Object> m, String k) { return ((Number) m.get(k)).intValue(); }
    static double nd(Map<String, Object> m, String k) { return ((Number) m.get(k)).doubleValue(); }
    static float dot(W wt, int r, float[] x, int n) {
        float a = 0; int o = r * n;
        if (wt.q != null) { for (int i = 0; i < n; i++) a += wt.q[o + i] * x[i]; return a * wt.sc[r]; }
        for (int i = 0; i < n; i++) a += wt.f[o + i] * x[i]; return a;
    }

    static float[] conv(float[] x, int C, int H, int Wd, W wt, float[] b, int cout, int k, int st, int pd, int g, int oh, int ow) {
        final float[] y = new float[cout * oh * ow]; final int ohw = oh * ow;
        if (k == 1 && st == 1 && g == 1) {                                     // pointwise: y[co] = b + sum_ci w * x[ci]
            final int hw = H * Wd;
            par(cout, (long) cout * C * hw, (a, e) -> {
                for (int co = a; co < e; co++) {
                    int yo = co * hw; float bb = b[co]; for (int p = 0; p < hw; p++) y[yo + p] = bb;
                    int ro = co * C; float sc = wt.q != null ? wt.sc[co] : 1f;
                    for (int ci = 0; ci < C; ci++) {
                        float wv = wt.q != null ? wt.q[ro + ci] * sc : wt.f[ro + ci]; if (wv == 0f) continue;
                        int xo = ci * hw; for (int p = 0; p < hw; p++) y[yo + p] += wv * x[xo + p];
                    }
                }
            });
        } else if (g == C && g == cout) {                                      // depthwise k x k
            final float[] wf = wt.f != null ? wt.f : deq(wt);
            par(C, (long) C * ohw * k * k, (a, e) -> {
                for (int c = a; c < e; c++) {
                    int xo = c * H * Wd, wo = c * k * k, yo = c * ohw; float bb = b[c];
                    for (int oy = 0; oy < oh; oy++) {
                        int iy0 = oy * st - pd, ky0 = Math.max(0, -iy0), ky1 = Math.min(k, H - iy0);
                        for (int ox = 0; ox < ow; ox++) {
                            int ix0 = ox * st - pd, kx0 = Math.max(0, -ix0), kx1 = Math.min(k, Wd - ix0); float acc = bb;
                            for (int ky = ky0; ky < ky1; ky++) { int xr = xo + (iy0 + ky) * Wd + ix0, wr = wo + ky * k; for (int kx = kx0; kx < kx1; kx++) acc += wf[wr + kx] * x[xr + kx]; }
                            y[yo + oy * ow + ox] = acc;
                        }
                    }
                }
            });
        } else {                                                               // general (the stem: 3 -> 16, 3x3, stride 2)
            if (g != 1) throw new IllegalStateException("grouped conv not supported");
            final float[] wf = wt.f != null ? wt.f : deq(wt);
            par(cout, (long) cout * ohw * C * k * k, (a, e) -> {
                for (int co = a; co < e; co++) {
                    int yo = co * ohw;
                    for (int oy = 0; oy < oh; oy++) for (int ox = 0; ox < ow; ox++) {
                        float acc = b[co];
                        for (int ci = 0; ci < C; ci++) for (int ky = 0; ky < k; ky++) {
                            int iy = oy * st - pd + ky; if (iy < 0 || iy >= H) continue;
                            for (int kx = 0; kx < k; kx++) { int ix = ox * st - pd + kx; if (ix < 0 || ix >= Wd) continue; acc += wf[((co * C + ci) * k + ky) * k + kx] * x[(ci * H + iy) * Wd + ix]; }
                        }
                        y[yo + oy * ow + ox] = acc;
                    }
                }
            });
        }
        return y;
    }
    static float[] deq(W wt) { float[] f = new float[wt.q.length]; for (int r = 0; r < wt.rows; r++) for (int c = 0; c < wt.cols; c++) f[r * wt.cols + c] = wt.q[r * wt.cols + c] * wt.sc[r]; return f; }

    /** Score per disease (labels order) = best cosine over that disease's fingerprints (several per disease:
     *  stages / backgrounds). New diseases can be added as extra fingerprint rows, no retraining. */
    public double[] scores(float[] z) {
        double[] s = new double[labels.size()]; Arrays.fill(s, -2);
        for (int i = 0; i < nfp; i++) { double a = 0; for (int j = 0; j < dim; j++) a += fp[i * dim + j] * z[j]; int c = protoClass[i]; if (a > s[c]) s[c] = a; }
        return s;
    }
}
