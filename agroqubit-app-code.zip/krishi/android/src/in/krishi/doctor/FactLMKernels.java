package in.krishi.doctor;

/**
 * Faster dense kernel for FactLM (same math and summation order per output as Nn.linear).
 * Java does not vectorise float reductions, so one long dependency chain limits Nn.linear. Here each weight row is
 * converted once and reused for 4 time steps (4 independent accumulators), and calls with fewer than 4 time steps
 * (decoder) compute 4 weight rows at once so every input load feeds 4 accumulators. Each output keeps the sequential
 * summation order of Nn.linear. Rows are spread over the Nn worker threads.
 */
final class FactLMKernels {
    private FactLMKernels() {}

    // exact (erf) GELU by linear interpolation in a table over [-8, 8], step 1/512: max |error| < 5e-7 (plus Nn.erf's 1.2e-7)
    private static final int GS = 512; private static final float GMAX = 8f; private static final float[] GT = new float[(int) (2 * GMAX * GS) + 2];
    static {
        for (int i = 0; i < GT.length; i++) { double v = -GMAX + (double) i / GS; GT[i] = (float) (0.5 * v * (1 + Nn.erf(v / 1.4142135623730951))); }
    }
    /** In-place exact GELU (torch.nn.GELU()), ~10x faster than Nn.gelu. */
    static void gelu(float[] x) {
        for (int i = 0; i < x.length; i++) {
            float v = x[i];
            if (v >= GMAX) continue;
            if (v <= -GMAX) { x[i] = 0f; continue; }
            float p = (v + GMAX) * GS; int k = (int) p; float fr = p - k;
            x[i] = GT[k] + (GT[k + 1] - GT[k]) * fr;
        }
    }

    /** y[T][out] = x[T][in] * W^T + b, W rows = out (int8 rows + scale, or float). b may be null. */
    static float[] linear(final Krw.T W, final float[] b, final float[] x, final int T) {
        final int out = W.rows, in = W.cols;
        if (x.length < T * in) throw new IllegalArgumentException("linear: x has " + x.length + " values, need " + T + "x" + in);
        final float[] y = new float[T * out];
        if (T < 4) { rows4(W, b, x, T, y); return y; }
        Nn.par(out, (long) T * out * in, (from, to) -> {
            final float[] w = new float[in];
            final byte[] q = W.q; final float[] f = W.f;
            for (int o = from; o < to; o++) {
                final int wo = o * in; final float s = q != null ? W.sc[o] : 1f, bias = b == null ? 0f : b[o];
                if (q != null) for (int i = 0; i < in; i++) w[i] = q[wo + i]; else System.arraycopy(f, wo, w, 0, in);
                int t = 0;
                for (; t + 4 <= T; t += 4) {   // one converted weight row, 4 time steps, 4 independent accumulators
                    final int x0 = t * in, x1 = x0 + in, x2 = x1 + in, x3 = x2 + in;
                    float a0 = 0f, a1 = 0f, a2 = 0f, a3 = 0f;
                    for (int i = 0; i < in; i++) { final float wi = w[i]; a0 += wi * x[x0 + i]; a1 += wi * x[x1 + i]; a2 += wi * x[x2 + i]; a3 += wi * x[x3 + i]; }
                    y[t * out + o] = a0 * s + bias; y[(t + 1) * out + o] = a1 * s + bias;
                    y[(t + 2) * out + o] = a2 * s + bias; y[(t + 3) * out + o] = a3 * s + bias;
                }
                for (; t < T; t++) {
                    final int x0 = t * in; float a0 = 0f;
                    for (int i = 0; i < in; i++) a0 += w[i] * x[x0 + i];
                    y[t * out + o] = a0 * s + bias;
                }
            }
        });
        return y;
    }

    /** Few time steps (decoder): 4 weight rows at a time share each input load (4 independent accumulators). */
    private static void rows4(final Krw.T W, final float[] b, final float[] x, final int T, final float[] y) {
        final int out = W.rows, in = W.cols; final int blocks = (out + 3) / 4;
        Nn.par(blocks, (long) T * out * in, (from, to) -> {
            final byte[] q = W.q; final float[] f = W.f;
            for (int bk = from; bk < to; bk++) {
                final int o = bk * 4;
                if (o + 4 > out) { tail(W, b, x, T, y, o, out); continue; }
                final int w0 = o * in, w1 = w0 + in, w2 = w1 + in, w3 = w2 + in;
                for (int t = 0; t < T; t++) {
                    final int x0 = t * in; float a0 = 0f, a1 = 0f, a2 = 0f, a3 = 0f;
                    if (q != null) for (int i = 0; i < in; i++) { final float xi = x[x0 + i]; a0 += q[w0 + i] * xi; a1 += q[w1 + i] * xi; a2 += q[w2 + i] * xi; a3 += q[w3 + i] * xi; }
                    else for (int i = 0; i < in; i++) { final float xi = x[x0 + i]; a0 += f[w0 + i] * xi; a1 += f[w1 + i] * xi; a2 += f[w2 + i] * xi; a3 += f[w3 + i] * xi; }
                    final int yo = t * out + o;
                    if (q != null) { y[yo] = a0 * W.sc[o]; y[yo + 1] = a1 * W.sc[o + 1]; y[yo + 2] = a2 * W.sc[o + 2]; y[yo + 3] = a3 * W.sc[o + 3]; }
                    else { y[yo] = a0; y[yo + 1] = a1; y[yo + 2] = a2; y[yo + 3] = a3; }
                    if (b != null) { y[yo] += b[o]; y[yo + 1] += b[o + 1]; y[yo + 2] += b[o + 2]; y[yo + 3] += b[o + 3]; }
                }
            }
        });
    }

    private static void tail(Krw.T W, float[] b, float[] x, int T, float[] y, int from, int out) {
        final int in = W.cols;
        for (int o = from; o < out; o++) for (int t = 0; t < T; t++) {
            float acc = 0f; final int wo = o * in, x0 = t * in;
            if (W.q != null) { for (int i = 0; i < in; i++) acc += W.q[wo + i] * x[x0 + i]; acc *= W.sc[o]; }
            else for (int i = 0; i < in; i++) acc += W.f[wo + i] * x[x0 + i];
            y[t * out + o] = acc + (b == null ? 0f : b[o]);
        }
    }
}
