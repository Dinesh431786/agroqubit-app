package in.krishi.doctor;

import java.util.*;

/** Port of freechat/freechat.py: understand a free question (intent + disease) and answer ONLY from verified cards. */
@SuppressWarnings("unchecked")
public final class FreeChat {
    final TextModel net; final List<String> I, D; final Krishi k; final double cm = 0.5, dm = 0.6;
    public double lastMargin = 1.0;

    FreeChat(Krishi k, TextModel net, Map<String, Object> labels) {
        this.k = k; this.net = net; I = (List<String>) (List<?>) labels.get("intents"); D = (List<String>) (List<?>) labels.get("diseases");
    }
    String cropOf(double[] P) {
        String best = null; double bv = -1;
        for (String c : Brain.CROPS) { double v = P[k.slotIndex("crop_" + c)]; if (v > bv) { bv = v; best = c; } }
        return bv >= 0.5 ? best : null;
    }
    /** returns {intent, intentConf, disease (or null), diseaseConf} */
    Object[] understand(String text) {
        double[][] h = net.freeHeads(text); double[] pi = h[0], pd = h[1];
        String crop = cropOf(k.understand(text)); lastMargin = 1.0;
        if (crop != null) {
            double s = 0;
            for (int i = 1; i < pd.length; i++) if (!crop.equals(k.cropOfDisease(D.get(i - 1)))) pd[i] = 0;
            for (double v : pd) s += v; for (int i = 0; i < pd.length; i++) pd[i] /= Math.max(s, 1e-9);
        }
        int a = argmax(pd); double second = -1; for (int i = 0; i < pd.length; i++) if (i != a) second = Math.max(second, pd[i]);
        lastMargin = pd[a] - second; int ia = argmax(pi);
        return new Object[]{I.get(ia), pi[ia], a > 0 ? D.get(a - 1) : null, pd[a]};
    }
    static int argmax(double[] p) { int b = 0; for (int i = 1; i < p.length; i++) if (p[i] > p[b]) b = i; return b; }

    List<String> items(String d, String field, String lang) {
        if (lang.equals("en")) return (List<String>) (List<?>) ((Map<String, Object>) k.adv(d)).get(field);
        return (List<String>) (List<?>) ((Map<String, Object>) ((Map<String, Object>) k.i18n.get(d)).get(field)).get(lang);
    }

    /** Answer from verified cards only. "say" is the text shown; "segs" are the voice clip ids that say exactly that, in order
     *  (closed-world voice: every sentence the app can say is pre-rendered, see voice/closed_world.py). */
    public Map<String, Object> answer(String text, String lang, String knownDisease, boolean confirmed) {
        Object[] u = understand(text); String intent = (String) u[0], dis = (String) u[2];
        double ci = (Double) u[1], cd = (Double) u[3];
        if (knownDisease != null && (dis == null || cd < dm)) { dis = knownDisease; cd = 1.0; }
        Map<String, Object> out = new LinkedHashMap<>(); List<String> segs = new ArrayList<>();
        out.put("intent", intent); out.put("intent_conf", ci); out.put("disease", dis); out.put("disease_conf", cd); out.put("segs", segs);
        Map<String, Object> PH = (Map<String, Object>) k.i18n.get("phrases");
        if (ci < cm) { segs.add("ph_need_diagnosis"); return act(out, "clarify", ph(PH, "need_diagnosis", lang)); }
        if (intent.equals("off_topic")) { segs.add("ph_off_topic"); return act(out, "off_topic", ph(PH, "off_topic", lang)); }
        if (intent.equals("out_of_scope_known")) { segs.add("ph_out_of_scope"); return act(out, "refer_kcc", ph(PH, "out_of_scope", lang)); }
        if (intent.equals("helpline")) { segs.add("generic_kvk"); return act(out, "helpline", k.cat("generic_kvk", lang)); }
        if (intent.equals("diagnose") || dis == null || cd < dm || k.adv(dis) == null || lastMargin < 0.25) {
            segs.add("ph_need_diagnosis"); return act(out, "start_diagnosis", ph(PH, "need_diagnosis", lang));
        }
        String name = k.catOr("name_" + dis, lang, dis); String src = (String) ((Map<String, Object>) k.adv(dis)).get("source");
        String nameClip = "name_" + dis, adv = k.catOr("adv_" + dis, lang, "");
        if (intent.equals("dose") && !confirmed) {
            segs.add(nameClip); segs.add("confirm_q");
            return act(out, "confirm_disease", name + "? " + k.phrase("confirm_q", lang));
        }
        String say;
        if (intent.equals("dose")) {
            List<String> ex = items(dis, "chemical_examples", lang); segs.add(nameClip);
            if (!ex.isEmpty()) { say = name + ". " + ph(PH, "dose_intro", lang) + " " + sents(ex) + " " + ph(PH, "dose_caution", lang); segs.add("ph_dose_intro"); its(segs, dis, "x", ex.size()); segs.add("ph_dose_caution"); }
            else { say = name + ". " + k.cat("generic_kvk", lang); segs.add("generic_kvk"); }
        } else if (intent.equals("organic")) {
            List<String> bio = items(dis, "biological", lang), cul = items(dis, "cultural", lang); List<String> b = new ArrayList<>(bio); b.addAll(cul); segs.add(nameClip);
            if (!b.isEmpty()) { say = name + ". " + ph(PH, "organic_intro", lang) + " " + sents(b); segs.add("ph_organic_intro"); its(segs, dis, "b", bio.size()); its(segs, dis, "c", cul.size()); }
            else { say = name + ". " + ph(PH, "organic_none", lang); segs.add("ph_organic_none"); }
        } else if (intent.equals("prevention")) {
            List<String> c = items(dis, "cultural", lang); segs.add(nameClip);
            if (!c.isEmpty()) { say = name + ". " + ph(PH, "prevention_intro", lang) + " " + sents(c); segs.add("ph_prevention_intro"); its(segs, dis, "c", c.size()); }
            else { say = name + ". " + k.cat("generic_kvk", lang); segs.add("generic_kvk"); }
        } else if (intent.equals("disease_info")) {
            say = ph(PH, "info_intro", lang) + " " + name + ". " + adv; segs.add("ph_info_intro"); segs.add(nameClip); if (!adv.isEmpty()) segs.add("adv_" + dis);
        } else {
            say = name + ". " + adv; segs.add(nameClip); if (!adv.isEmpty()) segs.add("adv_" + dis);
        }
        out.put("source", src);
        return act(out, "answer_" + intent, say.trim());
    }
    /** Advice items as separate sentences (English IPM items have no full stop of their own); same as freechat.py sents(). */
    static String sents(List<String> items) {
        List<String> o = new ArrayList<>();
        for (String t : items) { String r = t.replaceAll("\\s+$", ""); char c = r.isEmpty() ? ' ' : r.charAt(r.length() - 1); o.add(c == '.' || c == '।' || c == '!' || c == '?' ? t : r + "."); }
        return TextModel.join(o);
    }
    static void its(List<String> segs, String dis, String code, int n) { for (int i = 0; i < n; i++) segs.add("it_" + dis + "_" + code + i); }
    static String ph(Map<String, Object> PH, String key, String lang) { return (String) ((Map<String, Object>) PH.get(key)).get(lang); }
    static Map<String, Object> act(Map<String, Object> out, String a, String say) { out.put("action", a); out.put("say", say); return out; }
}
