package in.krishi.doctor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.CRC32;

/**
 * FactLM, the fact-token model, on the phone (pure Java, no ML runtime, no Android imports).
 * A farmer question in any wording/script -> a short sequence of VERIFIED fact ids + control tokens.
 *
 *  words -> mean of hashed char 2-4-gram + word rows (int8 bag) -> [CTX_CROP, CTX_TARGET, w1..w40] + positions
 *  -> 4-layer pre-LN transformer encoder (word positions do not attend to the 2 context tokens) -> LN
 *  -> mean over word positions -> slot head (38 sigmoids) and target head (the disease the TEXT names)
 *  -> 2-layer pre-LN decoder (KV cache; input = item embedding of the previous item or BOS, + step embedding),
 *     logits = h . E_items^T + b, greedy under the constraints of facts/SCHEMA.md (same as factlm/model.py):
 *     no repeats; ctx crop masks facts of other crops (general allowed); requires_confirmed facts need fact.target ==
 *     ctx target, and none at all when the target head names another disease (dose gate); with no app crop, the crop
 *     the text names (crop slot >= text_crop_min) masks like an app crop; END never first; a first fact with
 *     probability < min_first_prob becomes ASK; stop at any control token or after maxSteps items.
 * Files: factlm.json (factlm/export.py) + factlm.bin (KRW1). Parity test: android/test/factlm.
 */
@SuppressWarnings("unchecked")
public final class FactLM {
    public static final String END = "<END>", ASK = "<ASK>", NOT_SURE = "<NOT_SURE>", WHICH_CROP = "<WHICH_CROP>", CONFIRM = "<CONFIRM>";

    /** One answer: item ids (facts and/or one control token, last) with the probability of each pick. */
    public static final class Result {
        public final List<String> items = new ArrayList<>();
        public float[] scores = new float[0];
        /** Target head: which disease the question is about (null = none), e.g. the disease to confirm after CONFIRM. */
        public String target; public float targetScore;
        /** Raw item logits per step before masking (for tests). */
        public float[][] logits;
        public double ms;
        public List<String> facts() { List<String> f = new ArrayList<>(); for (String s : items) if (!s.startsWith("<")) f.add(s); return f; }
        public String control() { return items.isEmpty() ? null : (items.get(items.size() - 1).startsWith("<") ? items.get(items.size() - 1) : null); }
        @Override public String toString() {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < items.size(); i++) b.append(i == 0 ? "" : " ").append(items.get(i)).append(String.format(Locale.ROOT, "(%.2f)", scores[i]));
            if (target != null) b.append(String.format(Locale.ROOT, " | target %s %.2f", target, targetScore));
            return b.toString();
        }
    }

    final int d, heads, ffn, encLayers, decLayers, nb, maxWords, maxSteps, nItems, head, tail, askIndex, endIndex;
    /** Dose gate: no requires_confirmed fact when the target head names another disease than the confirmed one. */
    final boolean doseGate;
    /** target -> unambiguous normalised names (all languages): the deterministic dose guard (identical to model.py lex_named). */
    final Map<String, List<String>> nameLex = new LinkedHashMap<>();
    /** Step 0: a fact picked with probability below this becomes ASK. No app crop: the crop slot >= textCropMin masks as that crop. */
    final float minFirstProb, textCropMin;
    final int[] cropSlot, cropSlotCtx;   // slot index of crop_X and the ctx crop index of X
    public final List<String> ids, ctxCrops, ctxTargets, slotNames;
    final String[] itemCrop, itemTarget, targetCrop; final boolean[] itemReq, isStop;
    public final float slotThreshold;
    final Krw.T bag, itemsE, slotW, targetW;
    final float[] pos, ctxCrop, ctxTarget, itemsB, bos, step, slotB, targetB, encLnG, encLnB, decLnG, decLnB;
    final Enc[] enc; final Dec[] dec;
    final Map<String, int[]> wordCache = new HashMap<>();

    static final class Lin { Krw.T W; float[] b; Lin(Map<String, Krw.T> m, String p) { W = need(m, p + ".W"); b = need(m, p + ".b").floats(); } }
    static final class Enc { float[] ln1g, ln1b, ln2g, ln2b; Lin q, k, v, o, fc1, fc2; }
    static final class Dec { float[] ln1g, ln1b, ln2g, ln2b, ln3g, ln3b; Lin sq, sk, sv, so, cq, ck, cv, co, fc1, fc2; }

    public FactLM(String json, InputStream bin) throws IOException {
        Map<String, Object> j = (Map<String, Object>) Json.parse(json);
        if (!"factlm-1".equals(j.get("format"))) throw new IOException("not a factlm-1 config");
        Map<String, Object> c = (Map<String, Object>) j.get("cfg");
        d = num(c, "d"); heads = num(c, "heads"); ffn = num(c, "ffn"); encLayers = num(c, "enc_layers"); decLayers = num(c, "dec_layers");
        nb = num(c, "nb"); maxWords = num(c, "max_words"); maxSteps = num(c, "max_steps");
        head = maxWords / 2; tail = maxWords - head; doseGate = !Boolean.FALSE.equals(c.get("dose_gate"));
        minFirstProb = c.get("min_first_prob") == null ? 0.3f : ((Double) c.get("min_first_prob")).floatValue();
        textCropMin = c.get("text_crop_min") == null ? 0.5f : ((Double) c.get("text_crop_min")).floatValue();
        Map<String, Object> it = (Map<String, Object>) j.get("items");
        ids = strings(it.get("ids")); nItems = ids.size(); askIndex = ids.indexOf(ASK); endIndex = ids.indexOf(END);
        if (askIndex < 0 || endIndex < 0) throw new IOException("factlm.json: items must contain <ASK> and <END>");
        itemCrop = strings(it.get("crop")).toArray(new String[0]); itemTarget = strings(it.get("target")).toArray(new String[0]);
        List<Object> req = (List<Object>) it.get("requires_confirmed"); itemReq = new boolean[nItems];
        for (int i = 0; i < nItems; i++) itemReq[i] = Boolean.TRUE.equals(req.get(i));
        if (j.get("name_lexicon") instanceof Map)
            for (Map.Entry<String, Object> e : ((Map<String, Object>) j.get("name_lexicon")).entrySet()) nameLex.put(e.getKey(), strings(e.getValue()));
        Set<String> stop = new HashSet<>(strings(j.get("stop"))); isStop = new boolean[nItems];
        for (int i = 0; i < nItems; i++) isStop[i] = stop.contains(ids.get(i));
        ctxCrops = strings(j.get("ctx_crops")); ctxTargets = strings(j.get("ctx_targets")); slotNames = strings(j.get("slots"));
        List<String> tc = j.get("target_crop") == null ? null : strings(j.get("target_crop"));
        targetCrop = new String[ctxTargets.size()];
        for (int t = 2; t < targetCrop.length; t++) targetCrop[t] = tc != null && t < tc.size() ? tc.get(t) : null;
        slotThreshold = j.get("slot_threshold") == null ? 0.5f : ((Double) j.get("slot_threshold")).floatValue();
        List<Integer> cs = new ArrayList<>(), cc = new ArrayList<>();
        for (int k = 0; k < slotNames.size(); k++) {
            String sn = slotNames.get(k);
            if (sn.startsWith("crop_") && ctxCrops.indexOf(sn.substring(5)) >= 0) { cs.add(k); cc.add(ctxCrops.indexOf(sn.substring(5))); }
        }
        cropSlot = new int[cs.size()]; cropSlotCtx = new int[cs.size()];
        for (int k = 0; k < cropSlot.length; k++) { cropSlot[k] = cs.get(k); cropSlotCtx[k] = cc.get(k); }

        Map<String, Krw.T> m = Krw.read(bin);
        bag = need(m, "bag"); pos = need(m, "pos").floats(); ctxCrop = need(m, "ctx_crop").floats(); ctxTarget = need(m, "ctx_target").floats();
        if (bag.rows != nb || bag.cols != d) throw new IOException("bag " + bag.rows + "x" + bag.cols + " != " + nb + "x" + d);
        enc = new Enc[encLayers];
        for (int l = 0; l < encLayers; l++) {
            String p = "enc." + l + "."; Enc e = new Enc(); enc[l] = e;
            e.ln1g = need(m, p + "ln1.g").floats(); e.ln1b = need(m, p + "ln1.b").floats(); e.ln2g = need(m, p + "ln2.g").floats(); e.ln2b = need(m, p + "ln2.b").floats();
            e.q = new Lin(m, p + "att.q"); e.k = new Lin(m, p + "att.k"); e.v = new Lin(m, p + "att.v"); e.o = new Lin(m, p + "att.o");
            e.fc1 = new Lin(m, p + "fc1"); e.fc2 = new Lin(m, p + "fc2");
        }
        encLnG = need(m, "enc.ln.g").floats(); encLnB = need(m, "enc.ln.b").floats();
        slotW = need(m, "slot.W"); slotB = need(m, "slot.b").floats(); targetW = need(m, "target.W"); targetB = need(m, "target.b").floats();
        bos = need(m, "dec.bos").floats(); step = need(m, "dec.step").floats();
        dec = new Dec[decLayers];
        for (int l = 0; l < decLayers; l++) {
            String p = "dec." + l + "."; Dec e = new Dec(); dec[l] = e;
            e.ln1g = need(m, p + "ln1.g").floats(); e.ln1b = need(m, p + "ln1.b").floats(); e.ln2g = need(m, p + "ln2.g").floats();
            e.ln2b = need(m, p + "ln2.b").floats(); e.ln3g = need(m, p + "ln3.g").floats(); e.ln3b = need(m, p + "ln3.b").floats();
            e.sq = new Lin(m, p + "self.q"); e.sk = new Lin(m, p + "self.k"); e.sv = new Lin(m, p + "self.v"); e.so = new Lin(m, p + "self.o");
            e.cq = new Lin(m, p + "cross.q"); e.ck = new Lin(m, p + "cross.k"); e.cv = new Lin(m, p + "cross.v"); e.co = new Lin(m, p + "cross.o");
            e.fc1 = new Lin(m, p + "fc1"); e.fc2 = new Lin(m, p + "fc2");
        }
        decLnG = need(m, "dec.ln.g").floats(); decLnB = need(m, "dec.ln.b").floats();
        itemsE = need(m, "items.E"); itemsB = need(m, "items.b").floats();
        if (itemsE.rows != nItems) throw new IOException("items.E has " + itemsE.rows + " rows, config lists " + nItems + " items");
    }

    /** Loads factlm.json + factlm.bin from a folder. */
    public static FactLM load(File dir) throws IOException {
        try (InputStream in = new FileInputStream(new File(dir, "factlm.bin"))) { return new FactLM(readText(new File(dir, "factlm.json")), in); }
    }
    static String readText(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[1 << 15]; int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return new String(b.toByteArray(), StandardCharsets.UTF_8);
        }
    }
    static Krw.T need(Map<String, Krw.T> m, String k) throws IllegalArgumentException {
        Krw.T t = m.get(k); if (t == null) throw new IllegalArgumentException("factlm.bin: missing tensor " + k); return t;
    }
    static int num(Map<String, Object> m, String k) { return ((Double) m.get(k)).intValue(); }
    static List<String> strings(Object o) { List<String> a = new ArrayList<>(); for (Object x : (List<Object>) o) a.add((String) x); return a; }

    /** Worker threads used by the kernels (1 = run on the calling thread). */
    public static synchronized void threads(int n) { Nn.pool(); Nn.threads = Math.max(1, n); }

    // ------------------------------------------------------------------ features (factlm/text_features.py)
    String[] words(String text) {
        String norm = TextModel.normalise(text == null ? "" : text);
        String[] w = norm.isEmpty() ? new String[0] : norm.split(" ");
        if (w.length <= maxWords) return w;
        String[] o = new String[maxWords];
        System.arraycopy(w, 0, o, 0, head); System.arraycopy(w, w.length - tail, o, head, tail);
        return o;
    }
    int hash(String s) { CRC32 c = new CRC32(); c.update(s.getBytes(StandardCharsets.UTF_8)); return (int) (c.getValue() % nb); }
    int[] wordIds(String w) {
        synchronized (wordCache) { int[] v = wordCache.get(w); if (v != null) return v; }
        int[] cp = TextModel.codePoints("<" + w + ">"); List<Integer> ids = new ArrayList<>();
        ids.add(hash("W" + w));
        for (int n = 2; n <= 4; n++) for (int i = 0; i + n <= cp.length; i++) ids.add(hash(new String(cp, i, n)));
        int[] a = new int[ids.size()]; for (int i = 0; i < a.length; i++) a[i] = ids.get(i);
        synchronized (wordCache) { if (wordCache.size() < 20000) wordCache.put(w, a); }
        return a;
    }

    int cropIndex(String crop) { if (crop == null || crop.isEmpty()) return 0; int i = ctxCrops.indexOf(crop); return i < 0 ? 1 : i; }
    int targetIndex(String t) { if (t == null || t.isEmpty()) return 0; int i = ctxTargets.indexOf(t); return i < 0 ? 1 : i; }

    // ------------------------------------------------------------------ encoder
    /** Encoder output [T][d] (final LN applied); T = 2 + number of words. */
    float[] encode(String text, int cropIdx, int targetIdx, int[] Tout) {
        String[] w = words(text); int T = 2 + w.length; float[] x = new float[T * d];
        System.arraycopy(ctxCrop, cropIdx * d, x, 0, d); System.arraycopy(ctxTarget, targetIdx * d, x, d, d);
        for (int k = 0; k < w.length; k++) {
            int[] ids = wordIds(w[k]); int off = (2 + k) * d;
            for (int id : ids) bag.addRow(id, 1f, x, off);
            float inv = 1f / ids.length; for (int c = 0; c < d; c++) x[off + c] *= inv;
        }
        for (int i = 0; i < T * d; i++) x[i] += pos[i];
        boolean[] wordKeys = new boolean[T]; for (int j = 2; j < T; j++) wordKeys[j] = true;
        for (Enc e : enc) {
            float[] h = x.clone(); Nn.layerNorm(h, T, d, e.ln1g, e.ln1b, 1e-5f);
            float[] q = lin(e.q, h, T), k = lin(e.k, h, T), v = lin(e.v, h, T), a = new float[T * d];
            // the 2 context tokens attend to everything; word positions attend to words only (model.py encode())
            System.arraycopy(Nn.attention(Arrays.copyOfRange(q, 0, 2 * d), k, v, 2, T, d, heads, false, null), 0, a, 0, 2 * d);
            if (T > 2) System.arraycopy(Nn.attention(Arrays.copyOfRange(q, 2 * d, T * d), k, v, T - 2, T, d, heads, false, wordKeys), 0, a, 2 * d, (T - 2) * d);
            add(x, lin(e.o, a, T));
            h = x.clone(); Nn.layerNorm(h, T, d, e.ln2g, e.ln2b, 1e-5f);
            float[] f = lin(e.fc1, h, T); FactLMKernels.gelu(f); add(x, lin(e.fc2, f, T));
        }
        Nn.layerNorm(x, T, d, encLnG, encLnB, 1e-5f);
        Tout[0] = T; return x;
    }
    static float[] lin(Lin l, float[] x, int T) { return FactLMKernels.linear(l.W, l.b, x, T); }
    static void add(float[] a, float[] b) { for (int i = 0; i < a.length; i++) a[i] += b[i]; }
    /** Mean over the word positions (context tokens excluded); zeros for an empty text. */
    float[] pool(float[] mem, int T) {
        float[] z = new float[d]; if (T <= 2) return z;
        for (int t = 2; t < T; t++) for (int c = 0; c < d; c++) z[c] += mem[t * d + c];
        for (int c = 0; c < d; c++) z[c] /= (T - 2); return z;
    }

    // ------------------------------------------------------------------ public API
    /** Slot probabilities (38 meaning slots of slots.json, in slotNames order) for a sentence; no context. */
    public double[] slots(String text) {
        int[] T = new int[1]; float[] mem = encode(text, 0, 0, T); float[] l = FactLMKernels.linear(slotW, slotB, pool(mem, T[0]), 1);
        double[] p = new double[l.length]; for (int i = 0; i < l.length; i++) p[i] = 1 / (1 + Math.exp(-l[i])); return p;
    }

    /** Answer a question. crop: the crop the app knows (or null); target: the CONFIRMED disease (or null). */
    public Result answer(String text, String crop, String target) {
        long t0 = System.nanoTime(); Result r = new Result();
        int ci = cropIndex(crop), ti = targetIndex(target); int[] Tn = new int[1];
        float[] mem = encode(text, ci, ti, Tn); int T = Tn[0];
        float[] z = pool(mem, T);
        int top = targetHead(r, z, ci);
        boolean gate = doseGate && top >= 2 && top != ti;      // the text names another disease than the confirmed one
        int mc = ci;                                           // crop to mask with: the app's, else the one the text names
        if (ci == 0 && textCropMin > 0 && cropSlot.length > 0) {
            float[] sl = FactLMKernels.linear(slotW, slotB, z, 1); int bk = 0;
            for (int k = 1; k < cropSlot.length; k++) if (sl[cropSlot[k]] > sl[cropSlot[bk]]) bk = k;
            if (1 / (1 + Math.exp(-sl[cropSlot[bk]])) >= textCropMin) mc = cropSlotCtx[bk];
        }
        // context mask (identical to FactLM.gated_allowed in model.py)
        String cropName = ctxCrops.get(mc), targetName = ctxTargets.get(ti); boolean[] allowed = new boolean[nItems];
        if (ti >= 2 && !nameLex.isEmpty()) {                   // name guard: the words name only OTHER diseases -> no doses
            String tx = " " + TextModel.normalise(text) + " "; boolean self = false, other = false;
            for (Map.Entry<String, List<String>> e : nameLex.entrySet())
                for (String n : e.getValue()) if (tx.contains(" " + n + " ")) { if (e.getKey().equals(targetName)) self = true; else other = true; break; }
            if (other && !self) gate = true;
        }
        for (int i = 0; i < nItems; i++) {
            boolean ok = true;
            if (!isStop[i]) {
                if (mc > 0 && itemCrop[i] != null && !itemCrop[i].equals("general") && !itemCrop[i].equals(cropName)) ok = false;
                if (itemReq[i]) {   // needs fact.target == ctx target (a target-less fact: no ctx target), and no dose gate
                    boolean match = itemTarget[i] == null ? ti == 0 : (ti >= 2 && targetName.equals(itemTarget[i]));
                    if (!match || gate) ok = false;
                }
            }
            allowed[i] = ok;
        }
        // decoder: cross-attention K/V once, self-attention KV cache
        float[][] kc = new float[decLayers][], vc = new float[decLayers][], ks = new float[decLayers][maxSteps * d], vs = new float[decLayers][maxSteps * d];
        for (int l = 0; l < decLayers; l++) { kc[l] = lin(dec[l].ck, mem, T); vc[l] = lin(dec[l].cv, mem, T); }
        List<Float> sc = new ArrayList<>(); List<float[]> lg = new ArrayList<>(); int prev = -1;
        for (int s = 0; s < maxSteps; s++) {
            float[] x = new float[d];
            if (prev < 0) System.arraycopy(bos, 0, x, 0, d); else itemsE.row(prev, x, 0);
            for (int c = 0; c < d; c++) x[c] += step[s * d + c];
            for (int l = 0; l < decLayers; l++) {
                Dec e = dec[l];
                float[] h = x.clone(); Nn.layerNorm(h, 1, d, e.ln1g, e.ln1b, 1e-5f);
                float[] k = lin(e.sk, h, 1), v = lin(e.sv, h, 1);
                System.arraycopy(k, 0, ks[l], s * d, d); System.arraycopy(v, 0, vs[l], s * d, d);
                add(x, lin(e.so, Nn.attention(lin(e.sq, h, 1), ks[l], vs[l], 1, s + 1, d, heads, false, null), 1));
                h = x.clone(); Nn.layerNorm(h, 1, d, e.ln2g, e.ln2b, 1e-5f);
                add(x, lin(e.co, Nn.attention(lin(e.cq, h, 1), kc[l], vc[l], 1, T, d, heads, false, null), 1));
                h = x.clone(); Nn.layerNorm(h, 1, d, e.ln3g, e.ln3b, 1e-5f);
                float[] f = lin(e.fc1, h, 1); FactLMKernels.gelu(f); add(x, lin(e.fc2, f, 1));
            }
            Nn.layerNorm(x, 1, d, decLnG, decLnB, 1e-5f);
            float[] logits = FactLMKernels.linear(itemsE, itemsB, x, 1); lg.add(logits);
            int best = -1; float mx = Float.NEGATIVE_INFINITY;
            for (int i = 0; i < nItems; i++) if (allowed[i] && (s > 0 || i != endIndex) && logits[i] > mx) { mx = logits[i]; best = i; }
            double zs = 0; for (int i = 0; i < nItems; i++) if (allowed[i] && (s > 0 || i != endIndex)) zs += Math.exp(logits[i] - mx);
            double pb = 1 / zs;
            if (s == 0 && minFirstProb > 0 && !isStop[best] && pb < minFirstProb) {   // unsure first fact -> ASK (diagnose first)
                best = askIndex; pb = Math.exp(logits[best] - mx) / zs;
            }
            r.items.add(ids.get(best)); sc.add((float) pb); allowed[best] = false; prev = best;
            if (isStop[best]) break;
        }
        r.scores = new float[sc.size()]; for (int i = 0; i < r.scores.length; i++) r.scores[i] = sc.get(i);
        r.logits = lg.toArray(new float[0][]); r.ms = (System.nanoTime() - t0) / 1e6;
        return r;
    }

    /** Target head with targets of other crops masked; fills r.target/targetScore and returns the top index. */
    int targetHead(Result r, float[] z, int ci) {
        float[] l = FactLMKernels.linear(targetW, targetB, z, 1); String cropName = ctxCrops.get(ci);
        float mx = Float.NEGATIVE_INFINITY; int best = 0;
        for (int t = 0; t < l.length; t++) {
            if (ci > 0 && t >= 2 && targetCrop[t] != null && !targetCrop[t].equals("general") && !targetCrop[t].equals(cropName)) { l[t] = Float.NEGATIVE_INFINITY; continue; }
            if (l[t] > mx) { mx = l[t]; best = t; }
        }
        double s = 0; for (float v : l) if (v != Float.NEGATIVE_INFINITY) s += Math.exp(v - mx);
        r.target = best >= 2 ? ctxTargets.get(best) : null; r.targetScore = (float) (1 / s);
        return best;
    }
}
