package in.krishi.doctor;

import java.nio.file.*;
import java.util.*;

/** Replays Python-generated sessions; the Java engine must ask the same questions and reach the same beliefs. */
public final class ParityTest {
    @SuppressWarnings("unchecked")
    public static void main(String[] a) throws Exception {
        Doctor doc = new Doctor(new String(Files.readAllBytes(Paths.get(a[0])), "UTF-8"));
        List<Object> cases = (List<Object>) Json.parse(new String(Files.readAllBytes(Paths.get(a[1])), "UTF-8"));
        int seqOk = 0, statusOk = 0; double worst = 0; long t0 = System.nanoTime();
        for (Object o : cases) {
            Map<String, Object> c = (Map<String, Object>) o;
            String crop = (String) c.get("crop");
            List<Object> cl = (List<Object>) c.get("cos");
            double[] cos = null;
            if (cl != null) { cos = new double[cl.size()]; for (int i = 0; i < cos.length; i++) cos[i] = (Double) cl.get(i); }
            List<Object> ans = (List<Object>) c.get("answers");
            Doctor.Session s = doc.start(crop, cos);
            List<String> seq = new ArrayList<>();
            for (int i = 0; i < 6; i++) {
                String q = doc.nextQuestion(s);
                if (q == null) break;
                int av = ((Double) ans.get(i)).intValue();
                Integer k = av == 9 ? null : av % doc.optionsOf(q).length;
                seq.add(q + ":" + k);
                doc.answer(s, q, k);
            }
            List<String> exp = new ArrayList<>();
            for (Object e : (List<Object>) c.get("expected_seq")) {
                List<Object> p = (List<Object>) e;
                exp.add(p.get(0) + ":" + (p.get(1) == null ? null : ((Double) p.get(1)).intValue()));
            }
            if (seq.equals(exp)) seqOk++; else System.out.println("SEQ MISMATCH " + seq + " vs " + exp);
            List<Object> ep = (List<Object>) c.get("expected_post");
            for (int d = 0; d < s.post.length; d++) worst = Math.max(worst, Math.abs(s.post[d] - (Double) ep.get(d)));
            if (doc.result(s, 3).status.equals(c.get("expected_status"))) statusOk++;
        }
        double ms = (System.nanoTime() - t0) / 1e6;
        System.out.printf("cases=%d sameQuestions=%d sameStatus=%d maxPosteriorDiff=%.2e totalMs=%.1f (%.3f ms/session)%n",
                cases.size(), seqOk, statusOk, worst, ms, ms / cases.size());
        if (seqOk != cases.size() || statusOk != cases.size() || worst > 1e-9) { System.out.println("PARITY FAILED"); System.exit(1); }
        System.out.println("PARITY OK");
    }
}
