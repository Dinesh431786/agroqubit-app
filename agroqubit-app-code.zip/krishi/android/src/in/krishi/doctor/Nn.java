package in.krishi.doctor;

import java.util.*;
import java.util.concurrent.*;

/**
 * Small neural-network kernels in plain Java (no native code), shared by FactLM, the voice model and the speech model.
 * Conventions: token sequences are row-major [T][d]; 1-D conv tensors are channel-major [C][T].
 * Weights come from Krw (int8 rows kept int8, scaled per row on the fly; or float).
 */
public final class Nn {
    static ExecutorService pool; static int threads;

    static synchronized ExecutorService pool() {
        if (pool == null) {
            threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
            pool = Executors.newFixedThreadPool(threads, r -> { Thread t = new Thread(r, "nn"); t.setDaemon(true); return t; });
        }
        return pool;
    }
    /** Frees the worker threads. */
    public static synchronized void release() { if (pool != null) { pool.shutdown(); pool = null; } }

    public interface Range { void run(int from, int to); }
    /** Splits [0,n) over the worker threads when the job is big enough. */
    public static void par(int n, long work, Range r) {
        if (work < 150_000 || n < 2) { r.run(0, n); return; }
        ExecutorService p = pool(); int k = Math.min(threads, n);
        if (k < 2) { r.run(0, n); return; }
        List<Future<?>> fs = new ArrayList<>();
        for (int t = 0; t < k; t++) { final int a = (int) ((long) n * t / k), b = (int) ((long) n * (t + 1) / k); fs.add(p.submit(() -> r.run(a, b))); }
        try { for (Future<?> f : fs) f.get(); } catch (Exception e) { throw new RuntimeException(e); }
    }

    // ------------------------------------------------------------------ dense
    /** y[T][out] = x[T][in] * W^T + b, with W rows = out, cols = in. b may be null. */
    public static float[] linear(final Krw.T W, final float[] b, final float[] x, final int T) {
        final int out = W.rows, in = W.cols;
        if (x.length < T * in) throw new IllegalArgumentException("linear: x has " + x.length + " values, need " + T + "x" + in);
        final float[] y = new float[T * out];
        par(out, (long) T * out * in, (a, e) -> {
            for (int o = a; o < e; o++) {
                final int wo = o * in; final float bias = b == null ? 0f : b[o];
                if (W.q != null) {
                    final byte[] q = W.q; final float s = W.sc[o];
                    for (int t = 0; t < T; t++) { final int xo = t * in; float acc = 0f; for (int i = 0; i < in; i++) acc += q[wo + i] * x[xo + i]; y[t * out + o] = acc * s + bias; }
                } else {
                    final float[] f = W.f;
                    for (int t = 0; t < T; t++) { final int xo = t * in; float acc = 0f; for (int i = 0; i < in; i++) acc += f[wo + i] * x[xo + i]; y[t * out + o] = acc + bias; }
                }
            }
        });
        return y;
    }

    /** Scores of one vector against every row of W (rows = items): out[r] = W[r] . x (+ b[r]). */
    public static float[] scores(final Krw.T W, final float[] b, final float[] x) { return linear(W, b, x, 1); }

    // ------------------------------------------------------------------ norms / activations
    public static void layerNorm(float[] x, int T, int d, float[] g, float[] b, float eps) {
        for (int t = 0; t < T; t++) {
            int o = t * d; double m = 0; for (int i = 0; i < d; i++) m += x[o + i]; m /= d;
            double v = 0; for (int i = 0; i < d; i++) { double z = x[o + i] - m; v += z * z; } v /= d;
            float inv = (float) (1.0 / Math.sqrt(v + eps)), mf = (float) m;
            for (int i = 0; i < d; i++) { float z = (x[o + i] - mf) * inv; x[o + i] = z * (g == null ? 1f : g[i]) + (b == null ? 0f : b[i]); }
        }
    }
    /** LayerNorm over channels of a channel-major [C][T] tensor (per time step). */
    public static void layerNormChannels(float[] x, int C, int T, float[] g, float[] b, float eps) {
        for (int t = 0; t < T; t++) {
            double m = 0; for (int c = 0; c < C; c++) m += x[c * T + t]; m /= C;
            double v = 0; for (int c = 0; c < C; c++) { double z = x[c * T + t] - m; v += z * z; } v /= C;
            float inv = (float) (1.0 / Math.sqrt(v + eps)), mf = (float) m;
            for (int c = 0; c < C; c++) { float z = (x[c * T + t] - mf) * inv; x[c * T + t] = z * (g == null ? 1f : g[c]) + (b == null ? 0f : b[c]); }
        }
    }
    /** Exact GELU (erf form, as torch.nn.GELU()). */
    public static void gelu(float[] x) { for (int i = 0; i < x.length; i++) x[i] = (float) (0.5 * x[i] * (1 + erf(x[i] / 1.4142135623730951))); }
    /** tanh-approximate GELU (torch GELU(approximate='tanh')). */
    public static void geluTanh(float[] x) { for (int i = 0; i < x.length; i++) { double v = x[i]; x[i] = (float) (0.5 * v * (1 + Math.tanh(0.7978845608028654 * (v + 0.044715 * v * v * v)))); } }
    public static void relu(float[] x) { for (int i = 0; i < x.length; i++) if (x[i] < 0) x[i] = 0; }
    public static void leakyRelu(float[] x, float slope) { for (int i = 0; i < x.length; i++) if (x[i] < 0) x[i] *= slope; }
    public static void tanh(float[] x) { for (int i = 0; i < x.length; i++) x[i] = (float) Math.tanh(x[i]); }
    public static void sigmoid(float[] x) { for (int i = 0; i < x.length; i++) x[i] = (float) (1 / (1 + Math.exp(-x[i]))); }
    public static void silu(float[] x) { for (int i = 0; i < x.length; i++) x[i] = (float) (x[i] / (1 + Math.exp(-x[i]))); }
    /** erf, |error| < 1.2e-7. */
    public static double erf(double x) {
        double z = Math.abs(x), t = 1 / (1 + 0.5 * z);
        double r = t * Math.exp(-z * z - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807
                + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))));
        return x >= 0 ? 1 - r : r - 1;
    }
    public static void softmax(float[] x, int off, int n) {
        float mx = Float.NEGATIVE_INFINITY; for (int i = 0; i < n; i++) mx = Math.max(mx, x[off + i]);
        double s = 0; for (int i = 0; i < n; i++) { double e = Math.exp(x[off + i] - mx); x[off + i] = (float) e; s += e; }
        float inv = (float) (1 / s); for (int i = 0; i < n; i++) x[off + i] *= inv;
    }
    public static void addInPlace(float[] a, float[] b) { for (int i = 0; i < a.length; i++) a[i] += b[i]; }

    // ------------------------------------------------------------------ attention
    /**
     * Multi-head scaled dot-product attention. q [Tq][d], k/v [Tk][d]; head h uses columns h*d/heads .. (h+1)*d/heads.
     * causal: query i sees keys j <= i + (Tk - Tq) (works with a KV cache). keyMask (may be null): false = ignore key.
     */
    public static float[] attention(final float[] q, final float[] k, final float[] v, final int Tq, final int Tk, final int d, final int heads,
                                    final boolean causal, final boolean[] keyMask) {
        final int dh = d / heads; final float scale = (float) (1 / Math.sqrt(dh)); final float[] out = new float[Tq * d];
        par(Tq, (long) Tq * Tk * d * 2, (a, e) -> {
            float[] s = new float[Tk];
            for (int i = a; i < e; i++) {
                int lim = causal ? Math.min(Tk, i + (Tk - Tq) + 1) : Tk;
                for (int h = 0; h < heads; h++) {
                    int qo = i * d + h * dh; float mx = Float.NEGATIVE_INFINITY;
                    for (int j = 0; j < lim; j++) {
                        if (keyMask != null && !keyMask[j]) { s[j] = Float.NEGATIVE_INFINITY; continue; }
                        int ko = j * d + h * dh; float acc = 0f; for (int c = 0; c < dh; c++) acc += q[qo + c] * k[ko + c];
                        s[j] = acc * scale; if (s[j] > mx) mx = s[j];
                    }
                    double sum = 0; for (int j = 0; j < lim; j++) { double ex = s[j] == Float.NEGATIVE_INFINITY ? 0 : Math.exp(s[j] - mx); s[j] = (float) ex; sum += ex; }
                    float inv = sum > 0 ? (float) (1 / sum) : 0f; int oo = i * d + h * dh;
                    for (int j = 0; j < lim; j++) { float p = s[j] * inv; if (p == 0f) continue; int vo = j * d + h * dh; for (int c = 0; c < dh; c++) out[oo + c] += p * v[vo + c]; }
                }
            }
        });
        return out;
    }

    // ------------------------------------------------------------------ 1-D convolution (channel-major)
    public static int convOut(int T, int k, int stride, int pad, int dil) { return (T + 2 * pad - dil * (k - 1) - 1) / stride + 1; }

    /**
     * x [cin][T] -> y [cout][Tout]. W: torch Conv1d weight [cout][cin/groups][k] stored as rows=cout (int8 or float). b may be null.
     */
    public static float[] conv1d(final float[] x, final int cin, final int T, final Krw.T W, final float[] b, final int cout, final int k,
                                 final int stride, final int pad, final int dil, final int groups) {
        final int Tout = convOut(T, k, stride, pad, dil), cpg = cin / groups, opg = cout / groups; final float[] y = new float[cout * Tout];
        if (W.rows != cout || W.cols != cpg * k) throw new IllegalArgumentException("conv1d weight " + W.rows + "x" + W.cols + " != " + cout + "x" + cpg * k);
        par(cout, (long) cout * cpg * k * Tout, (a, e) -> {
            for (int o = a; o < e; o++) {
                int g = o / opg, yo = o * Tout; float bias = b == null ? 0f : b[o]; float s = W.q != null ? W.sc[o] : 1f;
                for (int t = 0; t < Tout; t++) y[yo + t] = 0f;
                for (int ci = 0; ci < cpg; ci++) {
                    int xo = (g * cpg + ci) * T;
                    for (int kk = 0; kk < k; kk++) {
                        int wi = o * cpg * k + ci * k + kk; float w = W.q != null ? W.q[wi] : W.f[wi]; if (w == 0f) continue;
                        int shift = kk * dil - pad;
                        int t0 = shift >= 0 ? 0 : (-shift + stride - 1) / stride; int t1 = Math.min(Tout, (T - 1 - shift) / stride + 1);
                        if (T - 1 - shift < 0) continue;
                        for (int t = t0; t < t1; t++) y[yo + t] += w * x[xo + t * stride + shift];
                    }
                }
                for (int t = 0; t < Tout; t++) y[yo + t] = y[yo + t] * s + bias;
            }
        });
        return y;
    }

    /**
     * Transposed conv: x [cin][T] -> y [cout][Tout], Tout = (T-1)*stride - 2*pad + dil*(k-1) + outPad + 1.
     * W: torch ConvTranspose1d weight [cin][cout/groups][k] stored as rows=cin. groups must divide both.
     */
    public static float[] convTranspose1d(final float[] x, final int cin, final int T, final Krw.T W, final float[] b, final int cout, final int k,
                                          final int stride, final int pad, final int dil, final int outPad, final int groups) {
        final int Tout = (T - 1) * stride - 2 * pad + dil * (k - 1) + outPad + 1, cpg = cin / groups, opg = cout / groups;
        if (W.rows != cin || W.cols != opg * k) throw new IllegalArgumentException("convT weight " + W.rows + "x" + W.cols + " != " + cin + "x" + opg * k);
        final float[] y = new float[cout * Tout];
        par(cout, (long) cout * cpg * k * T, (a, e) -> {
            for (int o = a; o < e; o++) {
                int g = o / opg, ol = o % opg, yo = o * Tout;
                for (int ci = 0; ci < cpg; ci++) {
                    int c = g * cpg + ci, xo = c * T; float s = W.q != null ? W.sc[c] : 1f;
                    for (int kk = 0; kk < k; kk++) {
                        int wi = c * opg * k + ol * k + kk; float w = (W.q != null ? W.q[wi] : W.f[wi]) * s; if (w == 0f) continue;
                        int off = kk * dil - pad;
                        for (int t = 0; t < T; t++) { int to = t * stride + off; if (to >= 0 && to < Tout) y[yo + to] += w * x[xo + t]; }
                    }
                }
                if (b != null) for (int t = 0; t < Tout; t++) y[yo + t] += b[o];
            }
        });
        return y;
    }

    /** [rows][cols] -> [cols][rows] */
    public static float[] transpose(float[] x, int rows, int cols) {
        float[] y = new float[rows * cols];
        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) y[c * rows + r] = x[r * cols + c];
        return y;
    }
}
