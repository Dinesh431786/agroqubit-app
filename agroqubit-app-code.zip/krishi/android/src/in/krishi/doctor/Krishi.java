package in.krishi.doctor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Loads all models + verified content once (from Android assets or a folder) and serves the shared pieces. */
@SuppressWarnings("unchecked")
public final class Krishi {
    public interface Res { InputStream open(String name) throws IOException; }

    public final Doctor doctor; public final List<String> slots; final Map<String, Integer> si = new HashMap<>();
    final TextModel AL, DL, free; final Map<String, Object> labels, catalogue, advice, meta, phrases; final Map<String, Object> i18n;
    final Res res; Vision vision;
    /** Verified facts (id -> text in 4 languages, kind, crop, target, clip, source) and the fact-token model that answers
     *  free questions with fact ids. Optional assets: without them the older intent-based FreeChat is used. */
    Map<String, Object> facts, factTargets; public FactLM factlm;
    Speak speak; boolean speakTried;

    public Krishi(Res r) throws IOException {
        res = r;
        doctor = new Doctor(text(r, "doctor_kb.json"));
        slots = new ArrayList<>(((Map<String, Object>) Json.parse(text(r, "slots.json"))).keySet());
        for (int i = 0; i < slots.size(); i++) si.put(slots.get(i), i);
        try (InputStream a = r.open("text_AL.bin")) { AL = new TextModel(a); }
        try (InputStream a = r.open("text_DL.bin")) { DL = new TextModel(a); }
        try (InputStream a = r.open("free_intent.bin")) { free = new TextModel(a); }
        labels = (Map<String, Object>) Json.parse(text(r, "free_labels.json"));
        catalogue = (Map<String, Object>) Json.parse(text(r, "catalogue.json"));
        advice = (Map<String, Object>) Json.parse(text(r, "advice.json"));
        i18n = (Map<String, Object>) Json.parse(text(r, "advice_i18n.json"));
        meta = (Map<String, Object>) Json.parse(text(r, "kb_meta.json"));
        phrases = (Map<String, Object>) Json.parse(text(r, "app_phrases.json"));
        if (has(r, "facts.json") && has(r, "factlm.json")) {
            Map<String, Object> fj = (Map<String, Object>) Json.parse(text(r, "facts.json"));
            facts = (Map<String, Object>) fj.get("facts"); factTargets = (Map<String, Object>) fj.get("targets");
            try (InputStream b = r.open("factlm.bin")) { factlm = new FactLM(text(r, "factlm.json"), b); }
        }
    }
    static boolean has(Res r, String name) { try (InputStream in = r.open(name)) { return in != null; } catch (IOException e) { return false; } }

    // ---------------- verified facts ----------------
    public boolean factsOn() { return factlm != null && facts != null; }
    public Map<String, Object> fact(String id) { return facts == null ? null : (Map<String, Object>) facts.get(id); }
    public String factText(String id, String lang) {
        Map<String, Object> f = fact(id); if (f == null) return null; Map<String, Object> t = (Map<String, Object>) f.get("text");
        Object v = t.get(lang); return (String) (v != null ? v : t.get("en"));
    }
    public String factKind(String id) { Map<String, Object> f = fact(id); return f == null ? null : (String) f.get("kind"); }
    public String factTarget(String id) { Map<String, Object> f = fact(id); return f == null ? null : (String) f.get("target"); }
    /** Voice clip of a fact: seed facts reuse the clips the app already had (adv_* / it_*), new facts use their own id. */
    public String factClip(String id) { Map<String, Object> f = fact(id); Object c = f == null ? null : f.get("clip"); return c != null ? (String) c : id; }
    public String factSource(String id) { Map<String, Object> f = fact(id); return f == null ? null : (String) f.get("src"); }
    /** Facts of one disease/pest with the given kind, in canonical order (facts.json keeps that order). */
    public List<String> factsOf(String target, String kind) {
        List<String> out = new ArrayList<>(); if (facts == null) return out;
        for (Map.Entry<String, Object> e : facts.entrySet()) {
            Map<String, Object> f = (Map<String, Object>) e.getValue();
            if (target.equals(f.get("target")) && kind.equals(f.get("kind"))) out.add(e.getKey());
        }
        return out;
    }
    /** Local name of a disease or pest: the catalogue's colloquial name, else the fact bank's target names. */
    public String targetName(String t, String lang) {
        if (catalogue.containsKey("name_" + t)) return catOr("name_" + t, lang, t);
        Map<String, Object> n = factTargets == null ? null : (Map<String, Object>) factTargets.get(t);
        Object v = n == null ? null : n.get(lang); if (v == null && n != null) v = n.get("en");
        return v != null ? (String) v : t.replace('_', ' ');
    }
    /** The sentence behind any voice clip id (for the trained voice model when a clip is missing). */
    public String clipText(String id, String lang) {
        if (catalogue.containsKey(id)) return catOr(id, lang, null);
        if (phrases.containsKey(id)) return phrase(id, lang);
        if (id.equals("generic")) return generic(lang);
        Map<String, Object> PH = (Map<String, Object>) i18n.get("phrases");
        if (id.startsWith("ph_") && PH != null && PH.containsKey(id.substring(3))) return (String) ((Map<String, Object>) PH.get(id.substring(3))).get(lang);
        if (id.startsWith("name_") && factTargets != null && factTargets.containsKey(id.substring(5))) return targetName(id.substring(5), lang);
        if (fact(id) != null) return factText(id, lang);
        if (id.startsWith("it_")) {
            String m = id.substring(3); int us = m.lastIndexOf('_'); if (us < 0 || us + 2 > m.length()) return null;
            String d = m.substring(0, us), field = m.charAt(us + 1) == 'c' ? "cultural" : m.charAt(us + 1) == 'b' ? "biological" : "chemical_examples";
            int i = Integer.parseInt(m.substring(us + 2)); List<Object> l;
            if (lang.equals("en")) l = (List<Object>) ((Map<String, Object>) adv(d)).get(field);
            else l = (List<Object>) ((Map<String, Object>) ((Map<String, Object>) i18n.get(d)).get(field)).get(lang);
            return i < l.size() ? (String) l.get(i) : null;
        }
        return null;
    }

    // ---------------- our own trained voice model (speaks anything that has no pre-rendered clip) ----------------
    public synchronized Speak speak() {
        if (!speakTried) {
            speakTried = true;
            if (has(res, "voice.json")) {
                try (InputStream j = res.open("voice.json"); InputStream a = res.open("voice_am.bin"); InputStream v = res.open("voice_voc.bin")) { speak = new Speak(j, a, v); }
                catch (Throwable e) { speak = null; }
            }
        }
        return speak;
    }
    static String text(Res r, String name) throws IOException {
        try (InputStream in = r.open(name)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[1 << 15]; int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return new String(b.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    /** Text -> 38 slot probabilities (ensemble of whole-sentence AL and window-max DL models). */
    public double[] understand(String text) {
        double[] a = AL.slotProbs(text), b = DL.slotProbsMil(text), p = new double[a.length];
        for (int i = 0; i < p.length; i++) p[i] = (a[i] + b[i]) / 2; return p;
    }
    public int slotIndex(String s) { return si.get(s); }
    String cropOfDisease(String d) { return (String) ((Map<String, Object>) ((Map<String, Object>) meta.get("diseases")).get(d)).get("crop"); }
    Object adv(String d) { return ((Map<String, Object>) advice.get("advice")).get(d); }
    public String generic(String lang) { return (String) ((Map<String, Object>) advice.get("generic")).get(lang); }
    public String cat(String id, String lang) { return (String) ((Map<String, Object>) catalogue.get(id)).get(lang); }
    public boolean hasClip(String id) { return catalogue.containsKey(id); }
    public String catOr(String id, String lang, String dflt) {
        Map<String, Object> m = (Map<String, Object>) catalogue.get(id); if (m == null) return dflt;
        Object v = m.get(lang); return v == null ? dflt : (String) v;
    }
    public FreeChat newFreeChat() { return new FreeChat(this, free, labels); }
    /** Fixed app phrase (photo, mic, confirm) in the farmer's language; its voice clip has the same id. */
    public String phrase(String key, String lang) { return (String) ((Map<String, Object>) phrases.get(key)).get(lang); }

    /** Hindi first-person verbs agree with the speaker: the text is written for the female voice (same rules as voice/verbalize.py). */
    public static String forVoice(String t, String lang, String voice) {
        if (t == null || !"hi".equals(lang) || !"m".equals(voice)) return t;
        String[][] R = {{"सकती हूँ", "सकता हूँ"}, {"रही हूँ", "रहा हूँ"}, {"ती हूँ", "ता हूँ"}, {"ूँगी", "ूँगा"}, {"गई हूँ", "गया हूँ"}};
        for (String[] r : R) t = t.replace(r[0], r[1]);
        return t;
    }

    // ---------------- photo ----------------
    /** Loaded on the first photo only (about 5 MB of weights), so text-only chats never pay for it. */
    public synchronized Vision vision() throws IOException {
        if (vision == null) try (InputStream in = res.open("vision.bin")) { vision = new Vision(in, text(res, "vision.json")); }
        return vision;
    }
    public static final class Photo {
        public String label, disease, crop, kind, target; public double score, ms; public final Map<String, Double> cos = new LinkedHashMap<>();
        public final List<String> diseases = new ArrayList<>();      // doctor diseases this photo class is evidence for (2 for a combined class)
        public final List<String> targets = new ArrayList<>();       // fact-bank pests / diseases the class shows (2 for e.g. mites + thrips)
        @Override public String toString() { return label + " " + Math.round(score * 1000) / 1000.0 + (disease != null ? " -> " + disease : "") + " (" + Math.round(ms) + " ms)"; }
    }
    /** chw: 3 x 224 x 224 RGB 0..255 (centre crop). Top fingerprint + cosine for every app disease that has a photo class. */
    public Photo photo(float[] chw) throws IOException {
        Vision v = vision(); long t0 = System.nanoTime(); double[] s = v.scores(v.embed(chw)); Photo p = new Photo();
        int b = 0; for (int i = 1; i < s.length; i++) if (s[i] > s[b]) b = i;
        p.label = v.labels.get(b); p.score = s[b]; p.disease = v.app.get(p.label);
        if (v.meta == null) {                                   // older tomato-only model
            p.crop = p.disease != null ? "tomato" : null; p.kind = p.disease != null ? "disease" : "other"; if (p.disease != null) p.diseases.add(p.disease);
            for (int i = 0; i < s.length; i++) { String d = v.app.get(v.labels.get(i)); if (d != null) p.cos.put(d, s[i]); }
        } else {                                                // field-photo model: crop, kind, target, and cosines for that crop's diseases
            Map<String, Object> m = (Map<String, Object>) v.meta.get(p.label);
            p.crop = (String) m.get("crop"); p.kind = (String) m.get("kind"); p.target = (String) m.get("target");
            for (Object d : (List<Object>) m.get("app")) p.diseases.add((String) d);
            if (m.get("targets") instanceof List) for (Object t : (List<Object>) m.get("targets")) p.targets.add((String) t);
            else if (p.target != null) p.targets.add(p.target);
            if (p.disease == null && !p.diseases.isEmpty()) p.disease = p.diseases.get(0);
            for (int i = 0; i < s.length; i++) {
                Map<String, Object> mi = (Map<String, Object>) v.meta.get(v.labels.get(i));
                if (p.crop == null || !p.crop.equals(mi.get("crop"))) continue;
                for (Object d : (List<Object>) mi.get("app")) { Double old = p.cos.get((String) d); if (old == null || s[i] > old) p.cos.put((String) d, s[i]); }
            }
        }
        p.ms = (System.nanoTime() - t0) / 1e6; return p;
    }
    public double notSure() throws IOException { return vision().notSure; }
    /** true for the field-photo model (rice, tomato, chilli, groundnut + other crops), false for the older tomato-only one. */
    public boolean visionHasMeta() { try { return vision().meta != null; } catch (IOException e) { return false; } }

    /** Button label for an option in the farmer's language. */
    public String optionLabel(String qid, String opt, String lang) {
        int li = Arrays.asList("hi", "ta", "kn", "en").indexOf(lang);
        String[][] L = {
            {"yes", "हाँ", "ஆமா", "ಹೌದು", "Yes"}, {"no", "नहीं", "இல்ல", "ಇಲ್ಲ", "No"},
            {"__dont_know__", "पता नहीं", "தெரியல", "ಗೊತ್ತಿಲ್ಲ", "Don't know"},
            {"rice", "धान", "நெல்", "ಭತ್ತ", "Rice"}, {"tomato", "टमाटर", "தக்காளி", "ಟೊಮೇಟೊ", "Tomato"},
            {"chilli", "मिर्च", "மிளகாய்", "ಮೆಣಸಿನಕಾಯಿ", "Chilli"}, {"groundnut", "मूंगफली", "நிலக்கடலை", "ಶೇಂಗಾ", "Groundnut"},
            {"leaf", "पत्ती", "இலை", "ಎಲೆ", "Leaf"}, {"stem_or_sheath", "तना", "தண்டு", "ಕಾಂಡ", "Stem"},
            {"grain_or_fruit", "दाना / फल", "மணி / காய்", "ಕಾಳು / ಕಾಯಿ", "Grain / fruit"},
            {"whole_plant_yellow_stunted", "पूरा पौधा पीला", "முழு செடி மஞ்சள்", "ಇಡೀ ಗಿಡ ಹಳದಿ", "Whole plant yellow"},
            {"none", "इनमें से कोई नहीं", "இதுல எதுவும் இல்ல", "ಇದರಲ್ಲಿ ಯಾವುದೂ ಅಲ್ಲ", "None of these"}};
        for (String[] row : L) if (row[0].equals(opt)) return row[li + 1];
        return catOr("name_" + opt, lang, opt.replace('_', ' '));
    }
}
