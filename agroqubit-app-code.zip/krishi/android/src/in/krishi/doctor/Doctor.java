package in.krishi.doctor;

import java.util.*;

/**
 * On-phone diagnosis engine: a line-for-line port of engine_v2.DoctorCore (Python), verified by ParityTest.
 * posterior ∝ crop filter × exp((visionCos − max)/tau) × Π P(answer | disease);
 * next question = maximum expected information gain. Pure Java, no Android dependencies (callable from Kotlin).
 * Soft evidence from speech/text understanding is applied with {@link #applyLikelihood}.
 */
public final class Doctor {
    public static final String KCC = "1800-180-1551";
    public final String[] names, crops, qids;
    public final String[][] options;
    final double[][][] theta;                 // [question][disease][option]
    final Map<String, String> qCrop = new HashMap<>();
    final Map<String, Integer> qIndex = new HashMap<>();
    public final double tau, stopP, minGain, finalMinP;
    public final int maxQ;

    @SuppressWarnings("unchecked")
    public Doctor(String kbJson) {
        Map<String, Object> m = (Map<String, Object>) Json.parse(kbJson);
        names = strs((List<Object>) m.get("names"));
        crops = strs((List<Object>) m.get("crops"));
        qids = strs((List<Object>) m.get("qids"));
        List<Object> opts = (List<Object>) m.get("options"), th = (List<Object>) m.get("theta");
        options = new String[qids.length][];
        theta = new double[qids.length][][];
        for (int q = 0; q < qids.length; q++) {
            options[q] = strs((List<Object>) opts.get(q));
            qIndex.put(qids[q], q);
            List<Object> rows = (List<Object>) th.get(q);
            theta[q] = new double[rows.size()][];
            for (int d = 0; d < rows.size(); d++) {
                List<Object> r = (List<Object>) rows.get(d);
                theta[q][d] = new double[r.size()];
                for (int k = 0; k < r.size(); k++) theta[q][d][k] = (Double) r.get(k);
            }
        }
        for (Map.Entry<String, Object> e : ((Map<String, Object>) m.get("q_crop")).entrySet()) qCrop.put(e.getKey(), (String) e.getValue());
        Map<String, Object> p = (Map<String, Object>) m.get("params");
        tau = (Double) p.get("tau");
        stopP = (Double) p.get("stop_p");
        maxQ = ((Double) p.get("max_q")).intValue();
        minGain = (Double) p.get("min_gain");
        finalMinP = (Double) p.get("final_min_p");
    }

    private static String[] strs(List<Object> l) {
        String[] a = new String[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = (String) l.get(i);
        return a;
    }

    /** One diagnosis conversation. */
    public static final class Session {
        public double[] post;
        public final List<String> asked = new ArrayList<>();
        public final Map<String, String> answers = new LinkedHashMap<>();
        public final String crop;
        Session(double[] post, String crop) { this.post = post; this.crop = crop; }
    }

    /** crop may be null; visionCos may be null (no photo) or one cosine per disease in {@link #names} order. */
    public Session start(String crop, double[] visionCos) {
        int n = names.length;
        double[] p = new double[n];
        for (int d = 0; d < n; d++) p[d] = (crop == null || crops[d].equals(crop)) ? 1.0 : 0.0;
        if (visionCos != null) {
            double m = Double.NEGATIVE_INFINITY;
            for (int d = 0; d < n; d++) if (p[d] > 0 && visionCos[d] > m) m = visionCos[d];
            for (int d = 0; d < n; d++) p[d] *= Math.exp((visionCos[d] - m) / tau);
        }
        normalise(p);
        return new Session(p, crop);
    }

    static void normalise(double[] p) {
        double s = 0; for (double x : p) s += x;
        for (int i = 0; i < p.length; i++) p[i] /= s;
    }

    static double entropy(double[] p) {
        double h = 0;
        for (double x : p) if (x > 0) h -= x * Math.log(x) / Math.log(2);
        return h;
    }

    double gain(double[] p, int q) {
        double[][] T = theta[q];
        int K = T[0].length;
        double g = entropy(p);
        double[] c = new double[p.length];
        for (int k = 0; k < K; k++) {
            double pk = 0;
            for (int d = 0; d < p.length; d++) pk += p[d] * T[d][k];
            if (pk > 1e-12) {
                for (int d = 0; d < p.length; d++) c[d] = p[d] * T[d][k] / pk;
                g -= pk * entropy(c);
            }
        }
        return g;
    }

    /** Next question id, or null to stop (confident, enough questions, or nothing useful left to ask). */
    public String nextQuestion(Session s) { return nextQuestion(s, Collections.<String>emptySet()); }

    /** Same, never choosing a question in {@code skip} (e.g. picture grids the device has no photos for). */
    public String nextQuestion(Session s, Set<String> skip) {
        double mx = 0; for (double x : s.post) mx = Math.max(mx, x);
        if (mx >= stopP || s.asked.size() >= maxQ) return null;
        String best = null; double bg = 0;
        for (int q = 0; q < qids.length; q++) {
            if (s.asked.contains(qids[q]) || skip.contains(qids[q])) continue;
            String qc = qCrop.get(qids[q]);
            if (qc != null && !qc.equals(s.crop)) continue;
            double g = gain(s.post, q);
            if (g > bg + 1e-12) { best = qids[q]; bg = g; }
        }
        return bg >= minGain ? best : null;
    }

    /** Hard answer (button tap). optionIndex null = "don't know" (no update). */
    public void answer(Session s, String qid, Integer optionIndex) {
        int q = qIndex.get(qid);
        s.asked.add(qid);
        s.answers.put(qid, optionIndex == null ? null : options[q][optionIndex]);
        if (optionIndex == null) return;
        for (int d = 0; d < s.post.length; d++) s.post[d] *= theta[q][d][optionIndex];
        normalise(s.post);
    }

    /** Soft answer from speech/text understanding: probability per option (may sum to < 1; the rest = no update). */
    public void answerSoft(Session s, String qid, double[] optionProbs) {
        int q = qIndex.get(qid); double rest = 1;
        for (double x : optionProbs) rest -= x;
        double[] L = new double[s.post.length];
        for (int d = 0; d < L.length; d++) {
            double l = Math.max(rest, 0);
            for (int k = 0; k < optionProbs.length; k++) l += optionProbs[k] * theta[q][d][k];
            L[d] = l;
        }
        s.asked.add(qid);
        applyLikelihood(s, L);
    }

    /** Multiply any likelihood vector into the belief (used for free 'mentions' and new evidence). */
    public void applyLikelihood(Session s, double[] L) {
        for (int d = 0; d < s.post.length; d++) s.post[d] *= Math.max(L[d], 1e-6);
        normalise(s.post);
    }

    public String[] optionsOf(String qid) { return options[qIndex.get(qid)]; }

    /** Top-k diseases with status "ok" or "not_sure" (then show KVK / KCC advice). */
    public Result result(Session s, int k) {
        Integer[] idx = new Integer[s.post.length];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        final double[] p = s.post;
        Arrays.sort(idx, (a, b) -> Double.compare(p[b], p[a]));   // stable, like numpy's stable argsort
        Result r = new Result();
        for (int i = 0; i < Math.min(k, idx.length); i++) { r.top.add(names[idx[i]]); r.prob.add(p[idx[i]]); }
        r.status = r.prob.get(0) >= finalMinP ? "ok" : "not_sure";
        return r;
    }

    public static final class Result {
        public String status;
        public final List<String> top = new ArrayList<>();
        public final List<Double> prob = new ArrayList<>();
    }
}
