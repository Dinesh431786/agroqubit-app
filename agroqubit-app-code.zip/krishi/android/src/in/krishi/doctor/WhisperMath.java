package in.krishi.doctor;

/**
 * Register-blocked kernels for Whisper.java. Same maths and the same per-output summation order as Nn.linear /
 * Nn.attention / Nn.conv1d (so results are bit-identical), but 4 output rows x 4 time steps share every weight and
 * activation load and run 16 independent accumulator chains instead of one: the JIT (C2 on servers, ART on phones)
 * cannot reorder float sums, so Nn's single-accumulator loops are bound by the add latency. int8 weights stay int8.
 * Work is split with Nn.par (same worker pool and thread count as every other model).
 */
public final class WhisperMath {
    private WhisperMath() {}

    /** Time steps per activation tile; int8 weight blocks are expanded to floats once per tile (exact conversion). */
    static final int TILE = 32;

    /** y[T][out] = x[T][in] * W^T (* row scale if int8) + b. W rows = out, cols = in; int8 rows or float. */
    public static float[] linear(final Krw.T W, final float[] b, final float[] x, final int T) {
        final int out = W.rows, in = W.cols;
        if (x.length < T * in) throw new IllegalArgumentException("linear: x has " + x.length + " values, need " + T + "x" + in);
        final float[] y = new float[T * out];
        final int blocks = (out + 3) / 4;
        Nn.par(blocks, (long) T * out * in, (a, e) -> {
            final boolean expand = W.q != null && T >= 8;
            final float[] wf = expand ? new float[4 * in] : null;
            for (int t0 = 0; t0 < T; t0 += TILE) {
                final int t1 = Math.min(T, t0 + TILE);
                for (int blk = a; blk < e; blk++) {
                    final int o = blk * 4;
                    if (o + 4 > out) { for (int r = o; r < out; r++) row1(W, b, x, y, r, in, out, t0, t1); continue; }
                    if (expand) {
                        final byte[] q = W.q; final int w0 = o * in;
                        for (int i = 0; i < 4 * in; i++) wf[i] = q[w0 + i];
                        block4f(wf, 0, W.sc, b, x, y, o, in, out, t0, t1);
                    } else if (W.q != null) block4q(W.q, W.sc, b, x, y, o, in, out, t0, t1);
                    else block4f(W.f, o * in, null, b, x, y, o, in, out, t0, t1);
                }
            }
        });
        return y;
    }

    private static void block4q(final byte[] q, final float[] sc, final float[] b, final float[] x, final float[] y,
                                final int o, final int in, final int out, final int t0, final int t1) {
        final int w0 = o * in, w1 = w0 + in, w2 = w1 + in, w3 = w2 + in;
        final float s0 = sc[o], s1 = sc[o + 1], s2 = sc[o + 2], s3 = sc[o + 3];
        final float b0 = b == null ? 0f : b[o], b1 = b == null ? 0f : b[o + 1], b2 = b == null ? 0f : b[o + 2], b3 = b == null ? 0f : b[o + 3];
        int t = t0;
        for (; t + 4 <= t1; t += 4) {
            final int x0 = t * in, x1 = x0 + in, x2 = x1 + in, x3 = x2 + in;
            float c00 = 0f, c01 = 0f, c02 = 0f, c03 = 0f, c10 = 0f, c11 = 0f, c12 = 0f, c13 = 0f;
            float c20 = 0f, c21 = 0f, c22 = 0f, c23 = 0f, c30 = 0f, c31 = 0f, c32 = 0f, c33 = 0f;
            for (int i = 0; i < in; i++) {
                final float q0 = q[w0 + i], q1 = q[w1 + i], q2 = q[w2 + i], q3 = q[w3 + i];
                final float v0 = x[x0 + i], v1 = x[x1 + i], v2 = x[x2 + i], v3 = x[x3 + i];
                c00 += q0 * v0; c01 += q0 * v1; c02 += q0 * v2; c03 += q0 * v3;
                c10 += q1 * v0; c11 += q1 * v1; c12 += q1 * v2; c13 += q1 * v3;
                c20 += q2 * v0; c21 += q2 * v1; c22 += q2 * v2; c23 += q2 * v3;
                c30 += q3 * v0; c31 += q3 * v1; c32 += q3 * v2; c33 += q3 * v3;
            }
            int y0 = t * out + o, y1 = y0 + out, y2 = y1 + out, y3 = y2 + out;
            y[y0] = c00 * s0 + b0; y[y0 + 1] = c10 * s1 + b1; y[y0 + 2] = c20 * s2 + b2; y[y0 + 3] = c30 * s3 + b3;
            y[y1] = c01 * s0 + b0; y[y1 + 1] = c11 * s1 + b1; y[y1 + 2] = c21 * s2 + b2; y[y1 + 3] = c31 * s3 + b3;
            y[y2] = c02 * s0 + b0; y[y2 + 1] = c12 * s1 + b1; y[y2 + 2] = c22 * s2 + b2; y[y2 + 3] = c32 * s3 + b3;
            y[y3] = c03 * s0 + b0; y[y3 + 1] = c13 * s1 + b1; y[y3 + 2] = c23 * s2 + b2; y[y3 + 3] = c33 * s3 + b3;
        }
        for (; t < t1; t++) {
            final int x0 = t * in;
            float c0 = 0f, c1 = 0f, c2 = 0f, c3 = 0f;
            for (int i = 0; i < in; i++) {
                final float v = x[x0 + i];
                c0 += q[w0 + i] * v; c1 += q[w1 + i] * v; c2 += q[w2 + i] * v; c3 += q[w3 + i] * v;
            }
            int y0 = t * out + o;
            y[y0] = c0 * s0 + b0; y[y0 + 1] = c1 * s1 + b1; y[y0 + 2] = c2 * s2 + b2; y[y0 + 3] = c3 * s3 + b3;
        }
    }

    /** Float weights f[w0..w0+4*in) for rows o..o+3; sc = per-row int8 scales (null for float weights: y = acc + b). */
    private static void block4f(final float[] f, final int w0, final float[] sc, final float[] b, final float[] x, final float[] y,
                                final int o, final int in, final int out, final int t0, final int t1) {
        final int w1 = w0 + in, w2 = w1 + in, w3 = w2 + in;
        final float b0 = b == null ? 0f : b[o], b1 = b == null ? 0f : b[o + 1], b2 = b == null ? 0f : b[o + 2], b3 = b == null ? 0f : b[o + 3];
        // x * 1f == x exactly, so float weights (sc == null) give acc + b like Nn.linear
        final float s0 = sc == null ? 1f : sc[o], s1 = sc == null ? 1f : sc[o + 1], s2 = sc == null ? 1f : sc[o + 2], s3 = sc == null ? 1f : sc[o + 3];
        int t = t0;
        for (; t + 4 <= t1; t += 4) {
            final int x0 = t * in, x1 = x0 + in, x2 = x1 + in, x3 = x2 + in;
            float c00 = 0f, c01 = 0f, c02 = 0f, c03 = 0f, c10 = 0f, c11 = 0f, c12 = 0f, c13 = 0f;
            float c20 = 0f, c21 = 0f, c22 = 0f, c23 = 0f, c30 = 0f, c31 = 0f, c32 = 0f, c33 = 0f;
            for (int i = 0; i < in; i++) {
                final float q0 = f[w0 + i], q1 = f[w1 + i], q2 = f[w2 + i], q3 = f[w3 + i];
                final float v0 = x[x0 + i], v1 = x[x1 + i], v2 = x[x2 + i], v3 = x[x3 + i];
                c00 += q0 * v0; c01 += q0 * v1; c02 += q0 * v2; c03 += q0 * v3;
                c10 += q1 * v0; c11 += q1 * v1; c12 += q1 * v2; c13 += q1 * v3;
                c20 += q2 * v0; c21 += q2 * v1; c22 += q2 * v2; c23 += q2 * v3;
                c30 += q3 * v0; c31 += q3 * v1; c32 += q3 * v2; c33 += q3 * v3;
            }
            int y0 = t * out + o, y1 = y0 + out, y2 = y1 + out, y3 = y2 + out;
            y[y0] = c00 * s0 + b0; y[y0 + 1] = c10 * s1 + b1; y[y0 + 2] = c20 * s2 + b2; y[y0 + 3] = c30 * s3 + b3;
            y[y1] = c01 * s0 + b0; y[y1 + 1] = c11 * s1 + b1; y[y1 + 2] = c21 * s2 + b2; y[y1 + 3] = c31 * s3 + b3;
            y[y2] = c02 * s0 + b0; y[y2 + 1] = c12 * s1 + b1; y[y2 + 2] = c22 * s2 + b2; y[y2 + 3] = c32 * s3 + b3;
            y[y3] = c03 * s0 + b0; y[y3 + 1] = c13 * s1 + b1; y[y3 + 2] = c23 * s2 + b2; y[y3 + 3] = c33 * s3 + b3;
        }
        for (; t < t1; t++) {
            final int x0 = t * in;
            float c0 = 0f, c1 = 0f, c2 = 0f, c3 = 0f;
            for (int i = 0; i < in; i++) {
                final float v = x[x0 + i];
                c0 += f[w0 + i] * v; c1 += f[w1 + i] * v; c2 += f[w2 + i] * v; c3 += f[w3 + i] * v;
            }
            int y0 = t * out + o;
            y[y0] = c0 * s0 + b0; y[y0 + 1] = c1 * s1 + b1; y[y0 + 2] = c2 * s2 + b2; y[y0 + 3] = c3 * s3 + b3;
        }
    }

    private static void row1(Krw.T W, float[] b, float[] x, float[] y, int o, int in, int out, int t0, int t1) {
        final int wo = o * in; final float bias = b == null ? 0f : b[o];
        for (int t = t0; t < t1; t++) {
            final int xo = t * in; float acc = 0f;
            if (W.q != null) { final byte[] q = W.q; for (int i = 0; i < in; i++) acc += q[wo + i] * x[xo + i]; y[t * out + o] = acc * W.sc[o] + bias; }
            else { final float[] f = W.f; for (int i = 0; i < in; i++) acc += f[wo + i] * x[xo + i]; y[t * out + o] = acc + bias; }
        }
    }

    /**
     * Multi-head attention, same contract and results as Nn.attention (no key mask): q [Tq][d], k/v [Tk][d] (only the
     * first Tk rows are read, so a preallocated KV cache can be passed); causal: query i sees keys j <= i + (Tk - Tq).
     * Scores for 4 keys at a time; work split over (query, head) pairs.
     */
    public static float[] attention(final float[] q, final float[] k, final float[] v, final int Tq, final int Tk, final int d,
                                    final int heads, final boolean causal) {
        final int dh = d / heads; final float scale = (float) (1 / Math.sqrt(dh)); final float[] out = new float[Tq * d];
        Nn.par(Tq * heads, (long) Tq * Tk * d * 2, (a, e) -> {
            float[] s = new float[Tk];
            for (int u = a; u < e; u++) {
                final int i = u / heads, h = u % heads;
                final int lim = causal ? Math.min(Tk, i + (Tk - Tq) + 1) : Tk;
                final int qo = i * d + h * dh;
                float mx = Float.NEGATIVE_INFINITY;
                int j = 0;
                for (; j + 4 <= lim; j += 4) {
                    final int k0 = j * d + h * dh, k1 = k0 + d, k2 = k1 + d, k3 = k2 + d;
                    float a0 = 0f, a1 = 0f, a2 = 0f, a3 = 0f;
                    for (int c = 0; c < dh; c++) {
                        final float qc = q[qo + c];
                        a0 += qc * k[k0 + c]; a1 += qc * k[k1 + c]; a2 += qc * k[k2 + c]; a3 += qc * k[k3 + c];
                    }
                    s[j] = a0 * scale; s[j + 1] = a1 * scale; s[j + 2] = a2 * scale; s[j + 3] = a3 * scale;
                    if (s[j] > mx) mx = s[j];
                    if (s[j + 1] > mx) mx = s[j + 1];
                    if (s[j + 2] > mx) mx = s[j + 2];
                    if (s[j + 3] > mx) mx = s[j + 3];
                }
                for (; j < lim; j++) {
                    final int ko = j * d + h * dh; float acc = 0f;
                    for (int c = 0; c < dh; c++) acc += q[qo + c] * k[ko + c];
                    s[j] = acc * scale; if (s[j] > mx) mx = s[j];
                }
                double sum = 0;
                for (j = 0; j < lim; j++) { double ex = Math.exp(s[j] - mx); s[j] = (float) ex; sum += ex; }
                final float inv = sum > 0 ? (float) (1 / sum) : 0f;
                for (j = 0; j < lim; j++) {
                    final float p = s[j] * inv; if (p == 0f) continue;
                    final int vo = j * d + h * dh;
                    for (int c = 0; c < dh; c++) out[qo + c] += p * v[vo + c];
                }
            }
        });
        return out;
    }

    /**
     * Conv1d with kernel 3, padding 1, stride 1 or 2 as im2col + linear: same sums as Nn.conv1d (input channel outer,
     * tap inner) but blocked. x is channel-major [cin][T] (channelMajor) or token-major [T][cin]; W rows = cout,
     * cols = cin*3 (torch layout). Returns token-major [Tout][cout], Tout = (T - 1) / stride + 1.
     */
    public static float[] conv3(final float[] x, final int cin, final int T, final boolean channelMajor, final int stride,
                                final Krw.T W, final float[] b) {
        final int Tout = (T - 1) / stride + 1, K = cin * 3;
        if (W.cols != K) throw new IllegalArgumentException("conv3 weight cols " + W.cols + " != " + K);
        final float[] col = new float[Tout * K];
        Nn.par(Tout, (long) Tout * K * 8, (a, e) -> {
            for (int t = a; t < e; t++) {
                final int co = t * K, base = t * stride - 1;
                for (int kk = 0; kk < 3; kk++) {
                    final int src = base + kk;
                    if (src < 0 || src >= T) continue;
                    if (channelMajor) for (int ci = 0; ci < cin; ci++) col[co + ci * 3 + kk] = x[ci * T + src];
                    else { final int xo = src * cin; for (int ci = 0; ci < cin; ci++) col[co + ci * 3 + kk] = x[xo + ci]; }
                }
            }
        });
        return linear(W, b, col, Tout);
    }

    /** Exact GELU (erf form, Nn.erf, same as Nn.gelu), split over the worker threads. */
    public static void gelu(final float[] x) {
        final int n = x.length, chunk = 4096, parts = (n + chunk - 1) / chunk;
        Nn.par(parts, (long) n * 40, (a, e) -> {
            for (int i = a * chunk, end = Math.min(n, e * chunk); i < end; i++) x[i] = (float) (0.5 * x[i] * (1 + Nn.erf(x[i] / 1.4142135623730951)));
        });
    }
}
