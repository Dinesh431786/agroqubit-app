package in.krishi.doctor;

/**
 * Kernels for the KrishiVoice TTS (Speak.java) that Nn does not have, all on row-major [T][C] activations:
 * a register-tiled GEMM over int8 (or float) weight rows that also runs k-tap 1-D convolutions (rows stored tap-major,
 * so the conv input for output t is k consecutive rows of the zero-padded input), depthwise conv, GELU, and the
 * inverse STFT (radix-2 real IFFT via a half-size complex FFT, Hann window, overlap-add, centred like torch.istft).
 * Threads come from Nn.par. No per-sample allocation: scratch is per call / per thread chunk.
 */
final class SpeakOps {
    private SpeakOps() {}

    /**
     * y[t][o] = b[o] + sum_i W[o][i] * x[xoff + t*xs + i], t < T. W rows = outputs (int8 + row scale, or float).
     * 4 output rows are dequantised into an interleaved float tile, then 4 rows x 4 time steps are accumulated in registers.
     */
    static float[] gemm(final Krw.T W, final float[] b, final float[] x, final int xoff, final int xs, final int T) {
        final int out = W.rows, in = W.cols, nb = (out + 3) >> 2;
        if (T > 0 && xoff + (long) (T - 1) * xs + in > x.length) throw new IllegalArgumentException("gemm: input too short");
        final float[] y = new float[T * out];
        Nn.par(nb, (long) T * out * in, (a, e) -> {
            final float[] w = new float[4 * in];
            for (int blk = a; blk < e; blk++) {
                final int o0 = blk << 2, no = Math.min(4, out - o0);
                for (int r = 0; r < 4; r++) {
                    if (r < no) {
                        final int ro = (o0 + r) * in;
                        if (W.q != null) { final byte[] q = W.q; final float s = W.sc[o0 + r]; for (int i = 0; i < in; i++) w[(i << 2) + r] = q[ro + i] * s; }
                        else { final float[] f = W.f; for (int i = 0; i < in; i++) w[(i << 2) + r] = f[ro + i]; }
                    } else for (int i = 0; i < in; i++) w[(i << 2) + r] = 0f;
                }
                final float b0 = b == null ? 0f : b[o0], b1 = b == null || no < 2 ? 0f : b[o0 + 1], b2 = b == null || no < 3 ? 0f : b[o0 + 2], b3 = b == null || no < 4 ? 0f : b[o0 + 3];
                int t = 0;
                for (; t + 4 <= T; t += 4) {
                    final int x0 = xoff + t * xs, x1 = x0 + xs, x2 = x1 + xs, x3 = x2 + xs;
                    float a00 = 0, a10 = 0, a20 = 0, a30 = 0, a01 = 0, a11 = 0, a21 = 0, a31 = 0, a02 = 0, a12 = 0, a22 = 0, a32 = 0, a03 = 0, a13 = 0, a23 = 0, a33 = 0;
                    for (int i = 0, wi = 0; i < in; i++, wi += 4) {
                        final float w0 = w[wi], w1 = w[wi + 1], w2 = w[wi + 2], w3 = w[wi + 3];
                        final float v0 = x[x0 + i], v1 = x[x1 + i], v2 = x[x2 + i], v3 = x[x3 + i];
                        a00 += w0 * v0; a10 += w1 * v0; a20 += w2 * v0; a30 += w3 * v0;
                        a01 += w0 * v1; a11 += w1 * v1; a21 += w2 * v1; a31 += w3 * v1;
                        a02 += w0 * v2; a12 += w1 * v2; a22 += w2 * v2; a32 += w3 * v2;
                        a03 += w0 * v3; a13 += w1 * v3; a23 += w2 * v3; a33 += w3 * v3;
                    }
                    final int y0 = t * out + o0, y1 = y0 + out, y2 = y1 + out, y3 = y2 + out;
                    y[y0] = a00 + b0; y[y1] = a01 + b0; y[y2] = a02 + b0; y[y3] = a03 + b0;
                    if (no > 1) { y[y0 + 1] = a10 + b1; y[y1 + 1] = a11 + b1; y[y2 + 1] = a12 + b1; y[y3 + 1] = a13 + b1; }
                    if (no > 2) { y[y0 + 2] = a20 + b2; y[y1 + 2] = a21 + b2; y[y2 + 2] = a22 + b2; y[y3 + 2] = a23 + b2; }
                    if (no > 3) { y[y0 + 3] = a30 + b3; y[y1 + 3] = a31 + b3; y[y2 + 3] = a32 + b3; y[y3 + 3] = a33 + b3; }
                }
                for (; t < T; t++) {
                    final int x0 = xoff + t * xs; float a0 = 0, a1 = 0, a2 = 0, a3 = 0;
                    for (int i = 0, wi = 0; i < in; i++, wi += 4) { final float v = x[x0 + i]; a0 += w[wi] * v; a1 += w[wi + 1] * v; a2 += w[wi + 2] * v; a3 += w[wi + 3] * v; }
                    final int y0 = t * out + o0;
                    y[y0] = a0 + b0; if (no > 1) y[y0 + 1] = a1 + b1; if (no > 2) y[y0 + 2] = a2 + b2; if (no > 3) y[y0 + 3] = a3 + b3;
                }
            }
        });
        return y;
    }

    /** 'Same' 1-D conv (odd k, stride 1) on row-major x [T][cin] -> [T][cout]; W rows [cout][k*cin] tap-major. */
    static float[] conv(Krw.T W, float[] b, float[] x, int T, int cin, int k) {
        if (W.cols != k * cin) throw new IllegalArgumentException("conv weight " + W.rows + "x" + W.cols + " != k*cin " + k * cin);
        if (k == 1) return gemm(W, b, x, 0, cin, T);
        final int p = k / 2; final float[] xp = new float[(T + 2 * p) * cin];
        System.arraycopy(x, 0, xp, p * cin, T * cin);
        return gemm(W, b, xp, 0, cin, T);
    }

    /** Depthwise 'same' conv: y[t][c] = b[c] + sum_j w[j][c] * x[t+j-k/2][c] (w tap-major [k][C]). */
    static float[] dwconv(final float[] x, final int T, final int C, final float[] w, final float[] b, final int k) {
        final float[] y = new float[T * C]; final int p = k / 2;
        Nn.par(T, (long) T * C * k, (a, e) -> {
            for (int t = a; t < e; t++) {
                final int yo = t * C;
                System.arraycopy(b, 0, y, yo, C);
                for (int j = 0; j < k; j++) {
                    final int s = t + j - p; if (s < 0 || s >= T) continue;
                    final int xo = s * C, wo = j * C;
                    for (int c = 0; c < C; c++) y[yo + c] += w[wo + c] * x[xo + c];
                }
            }
        });
        return y;
    }

    static void relu(float[] x) { for (int i = 0; i < x.length; i++) if (x[i] < 0f) x[i] = 0f; }

    /** Exact GELU (x * Phi(x), erf form, |error| ~1e-7) over threads. */
    static void gelu(final float[] x) {
        Nn.par(x.length, (long) x.length * 40, (a, e) -> {
            for (int i = a; i < e; i++) { final float v = x[i]; x[i] = (float) (0.5 * v * (1 + Nn.erf(v * 0.7071067811865476))); }
        });
    }

    // ------------------------------------------------------------------ inverse STFT
    /** Precomputed tables for one FFT size (power of two). */
    static final class Istft {
        final int n, half, hop, bins; final float[] win, cosH, sinH, cosN, sinN; final int[] rev;

        Istft(int n, int hop) {
            if (Integer.bitCount(n) != 1 || n < 4) throw new IllegalArgumentException("n_fft must be a power of two");
            this.n = n; this.half = n / 2; this.hop = hop; this.bins = n / 2 + 1;
            win = new float[n]; for (int i = 0; i < n; i++) win[i] = (float) (0.5 - 0.5 * Math.cos(2 * Math.PI * i / n));   // periodic Hann
            cosH = new float[half / 2]; sinH = new float[half / 2];                                                            // e^{+2 pi i k/half}
            for (int k = 0; k < half / 2; k++) { cosH[k] = (float) Math.cos(2 * Math.PI * k / half); sinH[k] = (float) Math.sin(2 * Math.PI * k / half); }
            cosN = new float[half]; sinN = new float[half];                                                                    // e^{+2 pi i k/n}
            for (int k = 0; k < half; k++) { cosN[k] = (float) Math.cos(2 * Math.PI * k / n); sinN[k] = (float) Math.sin(2 * Math.PI * k / n); }
            rev = new int[half]; int bits = Integer.numberOfTrailingZeros(half);
            for (int i = 0; i < half; i++) rev[i] = Integer.reverse(i) >>> (32 - bits);
        }

        /** irfft of re/im [bins] (imaginary parts of DC and Nyquist ignored, as torch) into out[off..off+n), scaled 1/n. */
        void irfft(float[] re, float[] im, float[] zr, float[] zi, float[] out, int off) {
            final int H = half;
            for (int k = 0; k < H; k++) {
                final float ar = re[k], ai = k == 0 ? 0f : im[k];
                final float br = re[H - k], bi = (k == 0) ? 0f : -im[H - k];          // conj(X[H-k]); X[H] imaginary ignored
                final float er = 0.5f * (ar + br), ei = 0.5f * (ai + bi);
                final float dr = 0.5f * (ar - br), di = 0.5f * (ai - bi);
                final float c = cosN[k], s = sinN[k];
                final float or = dr * c - di * s, oi = dr * s + di * c;                // O = D * e^{+2 pi i k/n}
                final int j = rev[k]; zr[j] = er - oi; zi[j] = ei + or;               // Z = E + i O, stored bit-reversed
            }
            for (int len = 2; len <= H; len <<= 1) {                                  // iterative radix-2 inverse FFT
                final int hl = len >> 1, step = H / len;
                for (int st = 0; st < H; st += len) {
                    for (int m = 0, tw = 0; m < hl; m++, tw += step) {
                        final float c = cosH[tw], s = sinH[tw];
                        final int p = st + m, q = p + hl;
                        final float tr = zr[q] * c - zi[q] * s, ti = zr[q] * s + zi[q] * c;
                        zr[q] = zr[p] - tr; zi[q] = zi[p] - ti; zr[p] += tr; zi[p] += ti;
                    }
                }
            }
            final float sc = 1f / H;
            for (int m = 0; m < H; m++) { out[off + 2 * m] = zr[m] * sc; out[off + 2 * m + 1] = zi[m] * sc; }
        }

        /**
         * Vocos head output s [T][2*bins] (log-magnitude | phase) -> waveform of (T-1)*hop samples, exactly
         * torch.istft(min(exp(logmag),100) * e^{i phase}, n, hop, n, hann, center=True).
         */
        float[] synth(final float[] s, final int T, final float maxMag) {
            final int n = this.n, B = bins, cols = 2 * B;
            if (T < 2) return new float[0];
            final float[] frames = new float[T * n];
            Nn.par(T, (long) T * n * 40, (a, e) -> {
                final float[] re = new float[B], im = new float[B], zr = new float[half], zi = new float[half];
                for (int t = a; t < e; t++) {
                    final int so = t * cols;
                    for (int k = 0; k < B; k++) {
                        final float mag = (float) Math.min(Math.exp(s[so + k]), maxMag); final double ph = s[so + B + k];
                        re[k] = mag * (float) Math.cos(ph); im[k] = mag * (float) Math.sin(ph);
                    }
                    irfft(re, im, zr, zi, frames, t * n);
                    final int fo = t * n; for (int i = 0; i < n; i++) frames[fo + i] *= win[i];
                }
            });
            final int full = n + hop * (T - 1), start = n / 2, len = (T - 1) * hop;
            final float[] ola = new float[full], env = new float[full];
            for (int t = 0; t < T; t++) {
                final int o = t * hop, fo = t * n;
                for (int i = 0; i < n; i++) { ola[o + i] += frames[fo + i]; env[o + i] += win[i] * win[i]; }
            }
            final float[] y = new float[len];
            for (int i = 0; i < len; i++) { final float ev = env[start + i]; y[i] = ev > 1e-11f ? ola[start + i] / ev : 0f; }
            return y;
        }
    }
}
