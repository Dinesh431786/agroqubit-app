package in.krishi.doctor;

import java.util.*;

/** Port of brain/chat.py: the one-screen conversation. Every turn (typed text, voice-typed text, a tap or a photo) updates
 *  ONE belief and returns a reply: a question with buttons, a verified answer, or a KVK / Kisan Call Centre referral.
 *  Free questions go to the fact-token model (FactLM): its answer is a list of VERIFIED FACT ids, so whatever the
 *  farmer asks, the app only ever says checked sentences (each with its own voice clip). Symptom talk goes to the
 *  Bayesian doctor first; a dose is only given for a disease that is diagnosed or confirmed by the farmer. */
@SuppressWarnings("unchecked")
public final class Chat {
    public static final class Reply {
        public String type, say, qid, disease, source, action, note; public double confidence;   // note: shown (and spoken) before the reply
        public List<String> buttons = new ArrayList<>(), clips = new ArrayList<>(), facts = new ArrayList<>();   // option ids; voice clip ids; fact ids
        @Override public String toString() { return type + (qid != null ? "/" + qid : "") + (disease != null ? "/" + disease : "") + (action != null ? "/" + action : "") + ": " + say; }
    }
    /** A side question in the middle of the diagnosis is answered only when the model is this sure of its first fact. */
    public static final double SIDE_MIN = 0.6;
    public static final String CONFIRM_Q = "__confirm__", CROP_Q = "__crop__";

    final Krishi k; public final String lang; public Brain brain; public String lastQ; String diagnosed, pendingText; boolean pendingDose;
    String topic, confirmTarget;            // topic: disease/pest the last fact answer was about (NOT a confirmed diagnosis)
    FreeChat free; final List<Integer> sym = new ArrayList<>();

    public Chat(Krishi k, String lang, Set<String> skip) {
        this.k = k; this.lang = lang; brain = new Brain(k.doctor, k.slots, skip);
        for (int i = 0; i < k.slots.size(); i++) { String s = k.slots.get(i); if (!s.startsWith("crop_") && !s.startsWith("ans_") && !s.startsWith("req_")) sym.add(i); }
    }

    Reply ask() {
        String q = brain.nextQuestion();
        if (q == null) return conclude();
        lastQ = q; Reply r = new Reply(); r.type = "question"; r.qid = q; r.say = questionText(q);
        if (q.equals(CROP_Q)) r.buttons.addAll(Arrays.asList(Brain.CROPS)); else r.buttons.addAll(Arrays.asList(k.doctor.optionsOf(q)));
        r.clips.add("filler_ok"); r.clips.add("q_" + q); return r;
    }
    public String questionText(String q) {
        if (k.hasClip("q_" + q)) return k.cat("q_" + q, lang);
        Map<String, Object> qs = (Map<String, Object>) k.meta.get("questions"); Object m = qs.get(q);
        return m instanceof Map ? (String) ((Map<String, Object>) m).get(lang) : q;
    }
    Reply conclude() {
        Doctor.Result r = brain.result(); String name = r.top.get(0); double p = r.prob.get(0); Reply out = new Reply();
        if (!r.status.equals("ok")) { out.type = "not_sure"; out.say = k.generic(lang); out.clips.addAll(Arrays.asList("filler_think", "generic")); return out; }
        Map<String, Object> a = (Map<String, Object>) k.adv(name);
        diagnosed = name; out.type = "diagnosis"; out.disease = name; out.confidence = Math.round(p * 100) / 100.0;
        String local = k.catOr("name_" + name, lang, name.replace('_', ' '));
        String adv = a != null ? k.catOr("adv_" + name, lang, (String) ((Map<String, Object>) a.get("first")).get(lang)) : k.cat("generic_kvk", lang);
        out.say = local + "\n" + adv; out.source = a != null ? (String) a.get("source") : null;
        out.clips.addAll(Arrays.asList("filler_think", "likely", "name_" + name, "first_step", a != null && k.hasClip("adv_" + name) ? "adv_" + name : "generic_kvk"));
        if (out.confidence < 0.75) out.clips.add("generic_kvk");
        return out;
    }

    // ------------------------------------------------------------------ free questions: fact-token model
    static String sentence(String t) {
        String r = t.replaceAll("\\s+$", ""); char c = r.isEmpty() ? ' ' : r.charAt(r.length() - 1);
        return c == '.' || c == '।' || c == '!' || c == '?' ? r : r + ".";
    }
    static String ph(Krishi k, String key, String lang) { return (String) ((Map<String, Object>) ((Map<String, Object>) k.i18n.get("phrases")).get(key)).get(lang); }

    /** The facts, in the model's order, with the disease/pest name first and the KVK/label caution after any dose. */
    Reply factReply(List<String> facts, String control) {
        Reply out = new Reply(); out.type = "fact_answer"; out.action = "answer"; String target = null;
        for (String f : facts) if (k.factTarget(f) != null) { target = k.factTarget(f); break; }
        List<String> say = new ArrayList<>();
        if (target != null) { say.add(sentence(k.targetName(target, lang))); out.clips.add("name_" + target); out.disease = target; }
        boolean dose = false;
        for (String f : facts) {
            if ("dose".equals(k.factKind(f)) && !dose) { dose = true; say.add(ph(k, "dose_intro", lang)); out.clips.add("ph_dose_intro"); }
            say.add(sentence(k.factText(f, lang))); out.clips.add(k.factClip(f)); out.facts.add(f);
        }
        if (dose) { say.add(ph(k, "dose_caution", lang)); out.clips.add("ph_dose_caution"); }
        if (FactLM.NOT_SURE.equals(control)) { say.add(k.cat("generic_kvk", lang)); out.clips.add("generic_kvk"); }
        out.say = TextModel.join(say); out.source = k.factSource(facts.get(0));
        if (target != null && diagnosed == null) topic = target;
        return out;
    }

    /** side: the farmer is in the middle of the diagnosis questions - only a confident fact answer interrupts them. */
    Reply factTurn(String text, boolean side) {
        FactLM.Result res = k.factlm.answer(text, brain.crop, diagnosed);
        List<String> facts = res.facts(); String ctl = res.control();
        if (!facts.isEmpty()) return side && res.scores[0] < SIDE_MIN ? null : factReply(facts, ctl);
        if (side || ctl == null || FactLM.ASK.equals(ctl) || FactLM.END.equals(ctl)) return null;     // -> diagnosis questions
        if (FactLM.NOT_SURE.equals(ctl)) {
            Reply r = new Reply(); r.type = "referral"; r.action = "not_covered"; r.say = k.phrase("not_covered", lang); r.clips.add("not_covered"); return r;
        }
        if (FactLM.WHICH_CROP.equals(ctl)) {
            if (brain.crop != null) return null;
            pendingText = text; lastQ = CROP_Q; Reply r = new Reply(); r.type = "question"; r.qid = CROP_Q; r.say = questionText(CROP_Q);
            r.buttons.addAll(Arrays.asList(Brain.CROPS)); r.clips.add("q_" + CROP_Q); return r;
        }
        // <CONFIRM>: a dose was asked before any diagnosis. Confirm the disease the text names (or the chat's topic) first.
        String t = res.target != null && res.targetScore >= 0.5 ? res.target : topic;
        if (t == null || k.factsOf(t, "dose").isEmpty()) return null;                                 // -> diagnosis questions
        confirmTarget = t; pendingText = text; lastQ = CONFIRM_Q;
        Reply r = new Reply(); r.type = "question"; r.qid = CONFIRM_Q; r.disease = t; r.say = sentence(k.targetName(t, lang)) + " " + k.phrase("confirm_q", lang);
        r.buttons.addAll(Arrays.asList("yes", "no")); r.clips.addAll(Arrays.asList("name_" + t, "confirm_q")); return r;
    }

    /** The farmer answered the confirm question: yes -> the disease counts as confirmed and the dose question is answered. */
    Reply confirmed(boolean yes) {
        String t = confirmTarget, text = pendingText; confirmTarget = null; pendingText = null; lastQ = null;
        if (!yes) return ask();
        diagnosed = t;
        Reply r = factTurn(text, false);
        if (r != null && "fact_answer".equals(r.type)) return r;
        List<String> d = k.factsOf(t, "dose");                         // the model still gave no facts: the confirmed disease's doses
        return factReply(d.isEmpty() ? k.factsOf(t, "first") : d, null);
    }

    Reply freeTurn(String text, double[] P) {
        if (free == null) free = k.newFreeChat();
        Map<String, Object> r;
        if (pendingDose) {
            pendingDose = false;
            if (P[k.slotIndex("ans_yes")] > 0.5) r = free.answer(pendingText, lang, diagnosed, true); else return null;
        } else {
            r = free.answer(text, lang, diagnosed, false);
            if (r.get("action").equals("confirm_disease")) { pendingDose = true; pendingText = text; }
            if (((String) r.get("action")).startsWith("answer_") && diagnosed == null) diagnosed = (String) r.get("disease");
        }
        String a = (String) r.get("action");
        if (a.equals("clarify") || a.equals("start_diagnosis")) return null;
        Reply out = new Reply(); out.type = "free_answer"; out.action = a; out.say = (String) r.get("say");
        out.disease = (String) r.get("disease"); out.source = (String) r.get("source");
        out.clips.addAll((List<String>) r.get("segs"));      // the whole answer is spoken, sentence by sentence
        return out;
    }

    /** A photo turn. A confident photo of a disease the doctor knows sets the crop and becomes the PRIOR of the Bayesian
     *  belief, so the questions only ask what the photo could not tell. A pest (or a disease known only from the fact
     *  bank) is answered with its verified facts; a healthy leaf or another crop gets an honest note, then the questions. */
    public Reply photo(Krishi.Photo ph) throws java.io.IOException {
        if (diagnosed != null || pendingDose || CONFIRM_Q.equals(lastQ)) restart();      // a new photo after an answer = a new consultation
        List<String> noteClips = new ArrayList<>(); String note; boolean used = false;
        boolean sure = ph.score >= k.notSure(), otherCrop = ph.crop == null || "other".equals(ph.kind);
        if (sure && !otherCrop && brain.crop != null && !brain.crop.equals(ph.crop)) restart();     // a photo of another of my crops = a new consultation
        if (!sure) { note = k.phrase("photo_unclear", lang); noteClips.add("photo_unclear"); }
        else if (otherCrop) {      // field-photo model: 'not one of my four crops'; older tomato-only model: its own wording
            String key = k.visionHasMeta() && k.phrases.containsKey("photo_not_my_crop") ? "photo_not_my_crop" : "photo_other_crop";
            note = k.phrase(key, lang); noteClips.add(key);
        }
        else if ("healthy".equals(ph.kind)) {
            if (brain.crop == null) brain.setCrop(ph.crop);
            note = k.phrase("photo_healthy", lang); noteClips.add("photo_healthy");
        } else if (!ph.diseases.isEmpty()) {
            if (brain.crop == null) brain.setCrop(ph.crop);
            brain.addPhotoScores(ph.cos); used = true; StringBuilder names = new StringBuilder(); noteClips.add("photo_looks_like");
            for (String d : ph.diseases) { if (names.length() > 0) names.append(" / "); names.append(k.catOr("name_" + d, lang, k.targetName(d, lang))); noteClips.add("name_" + d); }
            note = k.phrase("photo_looks_like", lang) + " " + names;
        } else if (!ph.targets.isEmpty() && k.factsOn()) {
            // a pest (or a disease known only from the fact bank): its verified facts; a class showing two pests gets both
            int per = ph.targets.size() > 1 ? 2 : 4; Reply r = null; StringBuilder names = new StringBuilder();
            List<String> nameClips = new ArrayList<>(Collections.singletonList("photo_looks_like"));
            for (String t : ph.targets) {
                if (names.length() > 0) names.append(" / "); names.append(k.targetName(t, lang)); nameClips.add("name_" + t);
                List<String> f = new ArrayList<>();
                for (String kind : new String[]{"first", "info", "action"}) f.addAll(k.factsOf(t, kind));
                if (f.isEmpty()) continue;
                Reply part = factReply(f.subList(0, Math.min(per, f.size())), null);
                if (ph.targets.size() == 1 && !part.clips.isEmpty() && part.clips.get(0).equals("name_" + t)) {   // the note already says the name
                    part.clips.remove(0); String nm = sentence(k.targetName(t, lang)); if (part.say.startsWith(nm)) part.say = part.say.substring(nm.length()).trim();
                }
                if (r == null) r = part;
                else { r.say = TextModel.join(Arrays.asList(r.say, part.say)); r.clips.addAll(part.clips); r.facts.addAll(part.facts); }
            }
            if (brain.crop == null) brain.setCrop(ph.crop);
            if (r != null) { r.note = k.phrase("photo_looks_like", lang) + " " + names; r.clips.addAll(0, nameClips); return r; }
            note = k.phrase("photo_looks_like", lang) + " " + names; noteClips.addAll(nameClips);
        } else { note = k.phrase("photo_unclear", lang); noteClips.add("photo_unclear"); }
        Reply r = ask();
        if (used && !"diagnosis".equals(r.type) && !"not_sure".equals(r.type)) { note += "\n" + k.phrase("photo_confirm", lang); noteClips.add("photo_confirm"); }
        r.note = note; r.clips.remove("filler_ok"); r.clips.addAll(0, noteClips); return r;
    }
    void restart() {
        brain = new Brain(k.doctor, k.slots, brain.skip); lastQ = null; diagnosed = null; pendingDose = false; pendingText = null; free = null;
        topic = null; confirmTarget = null;
    }

    double maxSym(double[] P) { double ms = 0; for (int i : sym) ms = Math.max(ms, P[i]); return ms; }
    String cropSaid(double[] P) {
        String best = null; double bv = 0.5;
        for (String c : Brain.CROPS) { double v = P[k.slotIndex("crop_" + c)]; if (v >= bv) { bv = v; best = c; } }
        return best;
    }

    /** One farmer turn: typed / voice-typed text, or a tap on a button (option id; "__dont_know__" allowed). */
    public Reply turn(String text, String tap) {
        if (tap != null) {
            if (CONFIRM_Q.equals(lastQ)) return confirmed("yes".equals(tap));
            if (CROP_Q.equals(lastQ)) {
                brain.setCrop(tap);
                if (pendingText != null) { String t = pendingText; pendingText = null; lastQ = null; Reply r = factTurn(t, false); if (r != null) return r; }
                return ask();
            }
            brain.answerChoice(lastQ, tap.equals("__dont_know__") ? null : Arrays.asList(k.doctor.optionsOf(lastQ)).indexOf(tap));
            return ask();
        }
        if (text == null) return ask();
        double[] P = k.understand(text);
        if (k.factsOn()) {
            if (CONFIRM_Q.equals(lastQ)) {
                if (P[k.slotIndex("ans_yes")] > 0.5) return confirmed(true);
                if (P[k.slotIndex("ans_no")] > 0.5) return confirmed(false);
                lastQ = null; confirmTarget = null; pendingText = null;                    // something else: a new message
            }
            if (CROP_Q.equals(lastQ) && pendingText != null) {
                String c = cropSaid(P);
                if (c != null) { brain.setCrop(c); String t = pendingText; pendingText = null; lastQ = null; Reply r = factTurn(t, false); if (r != null) return r; return ask(); }
                pendingText = null;
            }
            if (lastQ == null || diagnosed != null) {
                // symptom talk always goes to the diagnosis questions first (never answer straight from one description)
                Reply r = (diagnosed == null && maxSym(P) > 0.5) ? null : factTurn(text, false);
                if (r != null) return r;
            } else if (!CROP_Q.equals(lastQ) && maxSym(P) < 0.5 && P[k.slotIndex("ans_yes")] < 0.5 && P[k.slotIndex("ans_no")] < 0.5
                    && P[k.slotIndex("ans_dont_know")] < 0.5) {
                Reply r = factTurn(text, true);                       // a side question during the diagnosis: answer, then ask again
                if (r != null) {
                    r.say = r.say + "\n" + questionText(lastQ); r.clips.add("q_" + lastQ); r.qid = lastQ; r.buttons.addAll(Arrays.asList(k.doctor.optionsOf(lastQ)));
                    return r;
                }
            }
        } else if (lastQ == null || diagnosed != null || pendingDose) {
            Reply r = (diagnosed == null && !pendingDose && maxSym(P) > 0.5) ? null : freeTurn(text, P);
            if (r != null) return r;
        }
        String act = brain.hear(P);
        if (act.equals("refer")) { Reply r = new Reply(); r.type = "referral"; r.say = k.generic(lang); r.clips.addAll(Arrays.asList("filler_think", "generic")); return r; }
        if (act.equals("treat")) return conclude();
        if (act.equals("repeat") && lastQ != null) { Reply r = new Reply(); r.type = "question"; r.qid = lastQ; r.say = questionText(lastQ); r.clips.add("q_" + lastQ); return r; }
        return ask();
    }
}
