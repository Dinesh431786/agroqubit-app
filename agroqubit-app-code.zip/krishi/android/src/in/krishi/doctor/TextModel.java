package in.krishi.doctor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

/**
 * Port of text/textenc.py: hashed char 2-4-grams + word unigrams/bigrams (CRC32 mod 65536) -> mean EmbeddingBag
 * (int8 rows x per-row scale) -> MLP -> unit 256-d meaning vector -> cosine to 38 slot prototypes -> sigmoid.
 * Also the free-chat net (bag -> Linear -> GELU -> intent / disease heads). No Android dependencies.
 */
public final class TextModel {
    public static final int NB = 1 << 16;
    static final Pattern PUNCT = Pattern.compile("[।॥.,!?;:\"'()\\-–—/]+");
    /** Python's Unicode whitespace set (str.split / re \\s); Android's regex has no UNICODE_CHARACTER_CLASS. */
    static final Pattern WS = Pattern.compile("[ \\t\\n\\r\\f\\u000B\\u001C-\\u001F\\u0085\\u00A0\\u1680\\u2000-\\u200A\\u2028\\u2029\\u202F\\u205F\\u3000]+");

    // ---------------- weights ----------------
    final byte[] bagQ; final float[] bagScale; final int emb;
    final Map<String, float[]> f = new HashMap<>(); final Map<String, int[]> shape = new HashMap<>();

    public TextModel(InputStream in) throws IOException {
        DataInputStream d = new DataInputStream(new BufferedInputStream(in, 1 << 16));
        byte[] magic = new byte[4]; d.readFully(magic);
        if (!new String(magic, StandardCharsets.US_ASCII).equals("KRW1")) throw new IOException("bad weights file");
        int n = d.readInt(); byte[] q = null; float[] sc = null; int e = 0;
        for (int t = 0; t < n; t++) {
            byte[] nb = new byte[d.readShort()]; d.readFully(nb); String name = new String(nb, StandardCharsets.UTF_8);
            byte dtype = d.readByte(); int nd = d.readInt(); int[] sh = new int[nd]; int size = 1;
            for (int i = 0; i < nd; i++) { sh[i] = d.readInt(); size *= sh[i]; }
            if (dtype == 1) {
                q = new byte[size]; d.readFully(q); sc = new float[sh[0]]; for (int i = 0; i < sh[0]; i++) sc[i] = d.readFloat(); e = sh[1];
            } else {
                float[] a = new float[size]; for (int i = 0; i < size; i++) a[i] = d.readFloat(); f.put(name, a); shape.put(name, sh);
            }
        }
        bagQ = q; bagScale = sc; emb = e;
    }

    // ---------------- features (identical to Python) ----------------
    public static String normalise(String s) {
        s = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFC);
        s = PUNCT.matcher(s).replaceAll(" ");
        return WS.matcher(s).replaceAll(" ").trim();
    }
    static int[] codePoints(String s) {
        int[] a = new int[s.codePointCount(0, s.length())]; int k = 0;
        for (int i = 0; i < s.length(); i += Character.charCount(s.codePointAt(i))) a[k++] = s.codePointAt(i);
        return a;
    }
    public static String join(Iterable<String> parts) { StringBuilder b = new StringBuilder(); for (String p : parts) { if (b.length() > 0) b.append(' '); b.append(p); } return b.toString(); }
    static String join(String[] parts) { return join(Arrays.asList(parts)); }
    static String[] words(String norm) { return norm.isEmpty() ? new String[0] : norm.split(" "); }
    static int h(String s) { CRC32 c = new CRC32(); c.update(s.getBytes(StandardCharsets.UTF_8)); return (int) (c.getValue() % NB); }

    public static int[] features(String s) {
        String[] w = words(normalise(s)); List<Integer> ids = new ArrayList<>();
        for (String word : w) {
            ids.add(h("W" + word));
            int[] cp = codePoints("<" + word + ">");
            for (int n = 2; n <= 4; n++) for (int i = 0; i + n <= cp.length; i++) ids.add(h(new String(cp, i, n)));
        }
        for (int i = 0; i + 1 < w.length; i++) ids.add(h("B" + w[i] + " " + w[i + 1]));
        if (ids.isEmpty()) return new int[]{0};
        int[] a = new int[ids.size()]; for (int i = 0; i < a.length; i++) a[i] = ids.get(i); return a;
    }

    float[] bag(int[] ids) {
        float[] x = new float[emb];
        for (int id : ids) { float s = bagScale[id]; int o = id * emb; for (int j = 0; j < emb; j++) x[j] += bagQ[o + j] * s; }
        for (int j = 0; j < emb; j++) x[j] /= ids.length;
        return x;
    }
    float[] linear(String w, float[] x) {
        float[] W = f.get(w + ".weight"), b = f.get(w + ".bias"); int out = shape.get(w + ".weight")[0], in = x.length;
        float[] y = new float[out];
        for (int i = 0; i < out; i++) { double s = b[i]; int o = i * in; for (int j = 0; j < in; j++) s += W[o + j] * x[j]; y[i] = (float) s; }
        return y;
    }
    static float[] gelu(float[] x) { for (int i = 0; i < x.length; i++) x[i] = (float) (0.5 * x[i] * (1 + erf(x[i] / Math.sqrt(2)))); return x; }
    /** erf, |error| < 1.2e-7 (Numerical Recipes erfc Chebyshev fit). */
    static double erf(double x) {
        double z = Math.abs(x), t = 1 / (1 + 0.5 * z);
        double r = t * Math.exp(-z * z - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807
                + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))));
        return x >= 0 ? 1 - r : r - 1;
    }

    /** Slot logits of one bag (meaning encoder). */
    float[] slotLogits(int[] ids) {
        float[] z = linear("mlp.3", gelu(linear("mlp.0", bag(ids))));
        double n = 0; for (float v : z) n += v * v; n = Math.max(Math.sqrt(n), 1e-12);
        float[] S = f.get("slots"); int ns = shape.get("slots")[0], dim = z.length; float scale = f.get("scale")[0], bias = f.get("bias")[0];
        float[] out = new float[ns];
        for (int s = 0; s < ns; s++) {
            double sn = 0, dot = 0; for (int j = 0; j < dim; j++) { sn += S[s * dim + j] * S[s * dim + j]; dot += S[s * dim + j] * z[j]; }
            out[s] = (float) (scale * dot / (n * Math.max(Math.sqrt(sn), 1e-12)) + bias);
        }
        return out;
    }
    static double[] sigmoid(float[] l) { double[] p = new double[l.length]; for (int i = 0; i < l.length; i++) p[i] = 1 / (1 + Math.exp(-l[i])); return p; }

    /** Whole-sentence slot probabilities (model A / AL). */
    public double[] slotProbs(String text) { return sigmoid(slotLogits(features(text))); }

    /** Window max-pool slot probabilities (model D / DL): a slot fires if any part of the sentence says it. */
    public double[] slotProbsMil(String text) {
        String[] w = words(normalise(text)); if (w.length == 0) w = new String[]{""};
        List<int[]> spans = new ArrayList<>(); spans.add(new int[]{0, w.length});
        int win = 4, stride = 2;
        if (w.length > win) for (int i = 0; i < Math.max(1, w.length - win + stride); i += stride) spans.add(new int[]{i, Math.min(i + win, w.length)});
        float[] best = null;
        for (int[] sp : spans) {
            float[] l = slotLogits(features(join(Arrays.copyOfRange(w, sp[0], sp[1]))));
            if (best == null) best = l; else for (int i = 0; i < l.length; i++) best[i] = Math.max(best[i], l[i]);
        }
        return sigmoid(best);
    }

    /** Free-chat net: returns {intentProbs, diseaseProbs} (disease index 0 = none). */
    public double[][] freeHeads(String text) {
        float[] z = gelu(linear("h.0", bag(features(text))));
        return new double[][]{softmax(linear("intent", z)), softmax(linear("dis", z))};
    }
    static double[] softmax(float[] l) {
        double m = Double.NEGATIVE_INFINITY; for (float v : l) m = Math.max(m, v);
        double[] p = new double[l.length]; double s = 0; for (int i = 0; i < l.length; i++) { p[i] = Math.exp(l[i] - m); s += p[i]; }
        for (int i = 0; i < p.length; i++) p[i] /= s; return p;
    }
}
