package in.krishi.doctor;

import java.text.Normalizer;
import java.util.*;

/**
 * KrishiVoice text front end: the same algorithm as voice/student/text.py, driven by the tables export.py writes into
 * voice.json ("text"). Normalise (NFC, delete zero-width marks, lower-case ASCII, fold accents, digits and Latin
 * letters in Indic text to words, punctuation map, unknown -> space, tidy spaces/punctuation), split into sentences
 * after . ? ! + space, and encode each sentence as [bnd] chars [bnd].
 */
final class SpeakText {
    final String[] langs, speakers;
    final float gapSeconds;
    final int bndId;
    private final Map<Character, Integer> sym = new HashMap<>();
    private final Map<Character, Character> punct = new HashMap<>(), fold = new HashMap<>();
    private final String delete;
    private final Map<String, String[]> digitWords = new HashMap<>(), letterWords = new HashMap<>();
    private final Map<String, String> pointWords = new HashMap<>();
    private static final int[] DIGIT_BASES = {0x30, 0x0966, 0x0BE6, 0x0CE6};

    @SuppressWarnings("unchecked")
    SpeakText(Map<String, Object> t) {
        List<Object> s = (List<Object>) t.get("symbols");
        for (int i = 0; i < s.size(); i++) { String x = (String) s.get(i); if (x.length() == 1) sym.put(x.charAt(0), i); }
        langs = strings((List<Object>) t.get("langs")); speakers = strings((List<Object>) t.get("speakers"));
        for (Map.Entry<String, Object> e : ((Map<String, Object>) t.get("digit_words")).entrySet()) digitWords.put(e.getKey(), strings((List<Object>) e.getValue()));
        for (Map.Entry<String, Object> e : ((Map<String, Object>) t.get("letter_words")).entrySet()) letterWords.put(e.getKey(), strings((List<Object>) e.getValue()));
        for (Map.Entry<String, Object> e : ((Map<String, Object>) t.get("point_words")).entrySet()) pointWords.put(e.getKey(), (String) e.getValue());
        for (Map.Entry<String, Object> e : ((Map<String, Object>) t.get("punct_map")).entrySet()) punct.put(e.getKey().charAt(0), ((String) e.getValue()).charAt(0));
        for (Map.Entry<String, Object> e : ((Map<String, Object>) t.get("fold")).entrySet()) fold.put(e.getKey().charAt(0), ((String) e.getValue()).charAt(0));
        delete = (String) t.get("delete");
        gapSeconds = ((Number) t.get("gap_seconds")).floatValue(); bndId = ((Number) t.get("bnd_id")).intValue();
    }

    private static String[] strings(List<Object> l) { String[] a = new String[l.size()]; for (int i = 0; i < a.length; i++) a[i] = (String) l.get(i); return a; }

    private static int digit(char c) { for (int b : DIGIT_BASES) if (c >= b && c < b + 10) return c - b; return -1; }

    private static boolean isPunct(char c) { return c == ',' || c == '.' || c == '?' || c == '!'; }

    int langId(String lang) { for (int i = 0; i < langs.length; i++) if (langs[i].equals(lang)) return i; throw new IllegalArgumentException("unknown language " + lang); }

    int speakerId(String spk) {
        String s = "f".equals(spk) ? "female" : "m".equals(spk) ? "male" : spk;
        for (int i = 0; i < speakers.length; i++) if (speakers[i].equals(s)) return i;
        throw new IllegalArgumentException("unknown speaker " + spk);
    }

    int voiceId(String lang, String spk) { return langId(lang) * speakers.length + speakerId(spk); }

    String normalize(String text, String lang) {
        String[] digits = digitWords.get(lang), letters = letterWords.get(lang);
        if (digits == null) throw new IllegalArgumentException("unknown language " + lang);
        String n = Normalizer.normalize(text, Normalizer.Form.NFC);
        StringBuilder sb = new StringBuilder(n.length());
        for (int i = 0; i < n.length(); i++) { char c = n.charAt(i); if (delete.indexOf(c) < 0) sb.append(c); }
        String s = sb.toString(); StringBuilder buf = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= 'A' && ch <= 'Z') ch = (char) (ch + 32);
            Character f = fold.get(ch); if (f != null) ch = f;
            int d = digit(ch);
            if (d >= 0) { buf.append(' ').append(digits[d]).append(' '); continue; }
            if ((ch == '.' || ch == ',') && i > 0 && i < s.length() - 1 && digit(s.charAt(i - 1)) >= 0 && digit(s.charAt(i + 1)) >= 0) {
                if (ch == '.') buf.append(' ').append(pointWords.get(lang)).append(' '); else buf.append(' ');
                continue;
            }
            if (letters != null && ch >= 'a' && ch <= 'z') { buf.append(' ').append(letters[ch - 'a']).append(' '); continue; }
            Character p = punct.get(ch); if (p != null) ch = p;
            if (!sym.containsKey(ch)) ch = ' ';
            buf.append(ch);
        }
        StringBuilder out = new StringBuilder(buf.length());
        for (int i = 0; i < buf.length(); i++) {
            char ch = buf.charAt(i); int L = out.length();
            if (ch == ' ') { if (L > 0 && out.charAt(L - 1) != ' ') out.append(' '); }
            else if (isPunct(ch)) {
                while (out.length() > 0 && out.charAt(out.length() - 1) == ' ') out.setLength(out.length() - 1);
                L = out.length(); if (L == 0) continue;
                char last = out.charAt(L - 1);
                if (isPunct(last)) { if (last == ',') out.setCharAt(L - 1, ch); continue; }
                out.append(ch);
            } else {
                if (L > 0 && isPunct(out.charAt(L - 1))) out.append(' ');
                out.append(ch);
            }
        }
        while (out.length() > 0 && out.charAt(out.length() - 1) == ' ') out.setLength(out.length() - 1);
        return out.toString();
    }

    static List<String> sentences(String norm) {
        List<String> out = new ArrayList<>(); int start = 0;
        for (int i = 0; i < norm.length(); i++) {
            char c = norm.charAt(i);
            if ((c == '.' || c == '?' || c == '!') && i + 1 < norm.length() && norm.charAt(i + 1) == ' ') { out.add(norm.substring(start, i + 1)); start = i + 2; }
        }
        if (start < norm.length()) out.add(norm.substring(start));
        List<String> r = new ArrayList<>(); for (String x : out) if (!x.isEmpty()) r.add(x);
        return r;
    }

    int[] encode(String sentence) {
        int[] ids = new int[sentence.length() + 2]; ids[0] = bndId; ids[ids.length - 1] = bndId;
        for (int i = 0; i < sentence.length(); i++) {
            Integer id = sym.get(sentence.charAt(i));
            if (id == null) throw new IllegalStateException("normalised text has unknown char U+" + Integer.toHexString(sentence.charAt(i)));
            ids[i + 1] = id;
        }
        return ids;
    }
}
