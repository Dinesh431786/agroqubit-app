package in.krishi.doctor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Reader for KRW1 weight files (writer: tools/krw.py). Shared by FactLM, the voice model and the speech model.
 * dtype 0 fp32, 1 int8 rows [rows, cols] + one fp32 scale per row (kept int8 in memory), 2 fp16 (expanded to float).
 */
public final class Krw {
    public static final class T {
        public float[] f; public byte[] q; public float[] sc; public int[] shape; public int rows, cols;
        public boolean isQ8() { return q != null; }
        /** Full float copy (dequantised if int8). Use only for small tensors. */
        public float[] floats() {
            if (f != null) return f;
            float[] a = new float[rows * cols];
            for (int r = 0; r < rows; r++) { float s = sc[r]; int o = r * cols; for (int c = 0; c < cols; c++) a[o + c] = q[o + c] * s; }
            return a;
        }
        /** One row as floats (embedding lookup). */
        public void row(int r, float[] dst, int off) {
            int o = r * cols;
            if (f != null) System.arraycopy(f, o, dst, off, cols);
            else { float s = sc[r]; for (int c = 0; c < cols; c++) dst[off + c] = q[o + c] * s; }
        }
        /** dst[off..] += w * row r */
        public void addRow(int r, float w, float[] dst, int off) {
            int o = r * cols;
            if (f != null) for (int c = 0; c < cols; c++) dst[off + c] += w * f[o + c];
            else { float s = sc[r] * w; for (int c = 0; c < cols; c++) dst[off + c] += s * q[o + c]; }
        }
    }

    public static Map<String, T> read(InputStream in) throws IOException {
        DataInputStream d = new DataInputStream(new BufferedInputStream(in, 1 << 16));
        byte[] magic = new byte[4]; d.readFully(magic);
        if (!new String(magic, StandardCharsets.US_ASCII).equals("KRW1")) throw new IOException("not a KRW1 file");
        int n = d.readInt(); Map<String, T> m = new LinkedHashMap<>();
        for (int t = 0; t < n; t++) {
            byte[] nb = new byte[d.readShort()]; d.readFully(nb); String name = new String(nb, StandardCharsets.UTF_8);
            byte dtype = d.readByte(); int nd = d.readInt(); int[] sh = new int[nd]; int size = 1;
            for (int i = 0; i < nd; i++) { sh[i] = d.readInt(); size *= sh[i]; }
            T x = new T(); x.shape = sh; x.rows = nd > 0 ? sh[0] : 1; x.cols = x.rows > 0 ? size / x.rows : 0;
            if (dtype == 1) { x.q = new byte[size]; d.readFully(x.q); x.sc = new float[sh[0]]; for (int i = 0; i < sh[0]; i++) x.sc[i] = d.readFloat(); }
            else if (dtype == 2) { x.f = new float[size]; for (int i = 0; i < size; i++) x.f[i] = half(d.readShort()); }
            else { x.f = new float[size]; for (int i = 0; i < size; i++) x.f[i] = d.readFloat(); }
            m.put(name, x);
        }
        return m;
    }

    public static Map<String, T> read(File f) throws IOException { try (InputStream in = new FileInputStream(f)) { return read(in); } }

    static float half(short h) {
        int s = (h >> 15) & 1, e = (h >> 10) & 0x1f, m = h & 0x3ff; float v;
        if (e == 0) v = (float) (m * Math.pow(2, -24)); else if (e == 31) v = m == 0 ? Float.POSITIVE_INFINITY : Float.NaN;
        else v = Float.intBitsToFloat(((e - 15 + 127) << 23) | (m << 13));
        return s == 1 ? -v : v;
    }
}
