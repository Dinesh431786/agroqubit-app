package in.krishi.doctor;

import java.util.*;

/** Port of brain/brain.py: one Bayesian belief, updated by slot probabilities from any modality, plus taps. */
public final class Brain {
    public static final String[] CROPS = {"rice", "tomato", "chilli", "groundnut"};
    static final Map<String, String> PART_SLOTS = new LinkedHashMap<>();
    static {
        PART_SLOTS.put("leaf", "part_leaf"); PART_SLOTS.put("stem_or_sheath", "part_stem_or_sheath");
        PART_SLOTS.put("grain_or_fruit", "part_grain_or_fruit"); PART_SLOTS.put("whole_plant_yellow_stunted", "part_whole_plant_yellow_stunted");
    }
    public final Doctor core; final List<String> slots; final Map<String, Integer> si = new HashMap<>();
    final double mentionThr = 0.5; public final Set<String> skip;
    public Doctor.Session st; public String crop, pending; double[] cos;   // cos: photo cosines (null = no photo)

    public Brain(Doctor core, List<String> slots, Set<String> skip) {
        this.core = core; this.slots = slots; this.skip = skip;
        for (int i = 0; i < slots.size(); i++) si.put(slots.get(i), i);
    }
    void ensure() { if (st == null) st = core.start(crop, cos); }
    public void setCrop(String c) { crop = c; st = core.start(c, cos); }
    /** Photo evidence: cosine per disease that has a photo class (others get the mean); keeps what was already learned. */
    public void addPhotoScores(Map<String, Double> byDisease) {
        String[] names = core.names; double fill = 0; int n = 0;
        for (String d : names) if (byDisease.containsKey(d)) { fill += byDisease.get(d); n++; }
        fill = n > 0 ? fill / n : 0; cos = new double[names.length];
        for (int d = 0; d < names.length; d++) cos[d] = byDisease.containsKey(names[d]) ? byDisease.get(names[d]) : fill;
        List<String> asked = st != null ? new ArrayList<>(st.asked) : new ArrayList<String>(); double[] before = st != null ? st.post.clone() : null;
        st = core.start(crop, cos);
        if (before != null) {
            double[] prior = core.start(crop, null).post, p = st.post; double s = 0;
            for (int d = 0; d < p.length; d++) { p[d] *= prior[d] > 0 ? before[d] / Math.max(prior[d], 1e-12) : 0; s += p[d]; }
            for (int d = 0; d < p.length; d++) p[d] /= s;
            st.asked.addAll(asked);
        }
    }
    void mult(double[] L) { core.applyLikelihood(st, L); }
    int q(String qid) { return core.qIndex.get(qid); }
    double[] col(String qid, int k) { double[][] T = core.theta[q(qid)]; double[] c = new double[T.length]; for (int d = 0; d < c.length; d++) c[d] = T[d][k]; return c; }

    /** Evidence from one utterance. Returns "refer", "repeat", "treat", "answered" or "statement". */
    public String hear(double[] P) {
        double best = -1; String c = null;
        for (String cr : CROPS) { double v = P[si.get("crop_" + cr)]; if (v > best) { best = v; c = cr; } }
        if (!c.equals(crop) && best >= (crop == null ? 0.5 : 0.9)) setCrop(c);
        ensure(); String act = null; String qp = pending;
        if ("__crop__".equals(qp)) {
            if (crop != null) act = "answered";
        } else if (qp != null) {
            String[] opts = core.optionsOf(qp); int n = core.names.length;
            if (opts.length == 2 && opts[0].equals("yes") && opts[1].equals("no")) {
                double py = P[si.get("ans_yes")], pn = P[si.get("ans_no")], pd = P[si.get("ans_dont_know")];
                if (si.containsKey(qp)) py = Math.max(py, P[si.get(qp)]);
                double s = py + pn + pd;
                if (s > 0.3) {
                    py = py / Math.max(s, 1); pn = pn / Math.max(s, 1);
                    double[] Ty = col(qp, 0), Tn = col(qp, 1), L = new double[n];
                    for (int d = 0; d < n; d++) L[d] = py * Ty[d] + pn * Tn[d] + (1 - py - pn);
                    mult(L); st.asked.add(qp);
                    st.answers.put(qp, py > pn && py > pd ? "yes" : (pn > pd ? "no" : "dont_know")); act = "answered";
                }
            } else if (qp.equals("part")) {
                double[] pp = new double[opts.length]; double s = 0;
                for (int k = 0; k < opts.length; k++) { pp[k] = P[si.get(PART_SLOTS.get(opts[k]))]; s += pp[k]; }
                if (s > 0.3 || P[si.get("ans_dont_know")] > 0.5) {
                    double sum = 0; for (int k = 0; k < pp.length; k++) { pp[k] /= Math.max(s, 1); sum += pp[k]; }
                    mult(partL(pp, 1 - sum)); st.asked.add(qp); act = "answered";
                }
            }
        }
        for (String qq : core.qids) {
            if (si.containsKey(qq) && !qq.equals(qp) && !st.asked.contains(qq) && P[si.get(qq)] >= mentionThr) {
                double p = P[si.get(qq)]; double[] T0 = col(qq, 0), L = new double[T0.length];
                for (int d = 0; d < L.length; d++) L[d] = (1 - p) + p * T0[d];
                mult(L); st.asked.add(qq); st.answers.put(qq, "said");
            }
        }
        if (!st.asked.contains("part") && !"part".equals(qp)) {
            String[] opts = core.optionsOf("part"); double[] pp = new double[opts.length]; double s = 0, mx = 0;
            for (int k = 0; k < opts.length; k++) { pp[k] = P[si.get(PART_SLOTS.get(opts[k]))]; s += pp[k]; mx = Math.max(mx, pp[k]); }
            if (mx >= mentionThr) {
                for (int k = 0; k < pp.length; k++) pp[k] /= Math.max(s, 1);
                mult(partL(pp, 1 - Math.min(s, 1))); st.asked.add("part");
            }
        }
        if ("answered".equals(act)) pending = null;
        if (P[si.get("req_expert")] >= 0.5) return "refer";
        if (P[si.get("req_repeat")] >= 0.5 && pending != null) return "repeat";
        if (P[si.get("req_treatment")] >= 0.5) return "treat";
        return act != null ? act : "statement";
    }
    double[] partL(double[] pp, double rest) {
        double[][] T = core.theta[q("part")]; double[] L = new double[T.length];
        for (int d = 0; d < L.length; d++) { double v = 0; for (int k = 0; k < pp.length; k++) v += T[d][k] * pp[k]; L[d] = v + rest; }
        return L;
    }
    /** Tap on an option button; optionIndex null = "don't know". */
    public void answerChoice(String qid, Integer optionIndex) {
        ensure(); core.answer(st, qid, optionIndex);
        if (qid.equals(pending)) pending = null;
    }
    public String nextQuestion() {
        ensure();
        if (crop == null) { pending = "__crop__"; return pending; }
        pending = core.nextQuestion(st, skip); return pending;
    }
    public Doctor.Result result() { ensure(); return core.result(st, 3); }
}
