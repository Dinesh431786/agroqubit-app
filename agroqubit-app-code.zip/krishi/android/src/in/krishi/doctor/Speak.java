package in.krishi.doctor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * KrishiVoice: the app's own trained TTS (student of the AI4Bharat Indic-TTS teacher voices), pure Java, no Android
 * dependencies. Files (voice/student/export.py): voice.json, voice_am.bin, voice_voc.bin (KRW1, int8 rows).
 *
 *   float[] pcm = new Speak(dir).synth("दो सौ पचास ग्राम", "hi", "female");   // 16 kHz mono, [-1, 1]
 *
 * Text is normalised and split into sentences exactly like voice/student/text.py; each sentence runs through the
 * acoustic model (FastPitch-style: encoder, duration + pitch predictors, length regulator, decoder -> 80-bin log-mel)
 * and the Vocos-style vocoder (ConvNeXt at frame rate -> magnitude/phase -> iSTFT); sentences are joined with the same
 * 0.28 s pause as the pre-rendered clips. Durations use float64 cumulative rounding identical to the Python reference
 * (model_am.durations_from_logd); speed > 1 speaks faster. Thread use comes from Nn.par.
 */
public final class Speak {
    final SpeakText text;
    final Map<String, Krw.T> am, voc;
    final int sampleRate, hop, nMels;
    // acoustic model dims
    final int d, heads, encLayers, decLayers, dff, ffK, predF, predK, pitchK; final float maxDur, amEps;
    // vocoder dims
    final int vDim, vInter, vLayers, vK; final float vEps, maxMag;
    final SpeakOps.Istft istft;
    private final double[] invFreq;

    public Speak(File dir) throws IOException {
        this(new FileInputStream(new File(dir, "voice.json")), new FileInputStream(new File(dir, "voice_am.bin")), new FileInputStream(new File(dir, "voice_voc.bin")));
    }

    @SuppressWarnings("unchecked")
    public Speak(InputStream json, InputStream amBin, InputStream vocBin) throws IOException {
        Map<String, Object> j;
        try (InputStream in = json) { j = (Map<String, Object>) Json.parse(readAll(in)); }
        try (InputStream in = amBin) { am = Krw.read(in); }
        try (InputStream in = vocBin) { voc = Krw.read(in); }
        text = new SpeakText((Map<String, Object>) j.get("text"));
        sampleRate = num(j, "sample_rate"); hop = num(j, "hop"); nMels = num(j, "n_mels");
        Map<String, Object> a = (Map<String, Object>) j.get("am"), v = (Map<String, Object>) j.get("voc");
        d = num(a, "d"); heads = num(a, "heads"); encLayers = num(a, "enc_layers"); decLayers = num(a, "dec_layers"); dff = num(a, "dff");
        ffK = num(a, "ff_kernel"); predF = num(a, "pred_filters"); predK = num(a, "pred_kernel"); pitchK = num(a, "pitch_kernel");
        maxDur = ((Number) a.get("max_dur")).floatValue(); amEps = ((Number) a.get("ln_eps")).floatValue();
        vDim = num(v, "dim"); vInter = num(v, "inter"); vLayers = num(v, "layers"); vK = num(v, "kernel");
        vEps = ((Number) v.get("ln_eps")).floatValue(); maxMag = ((Number) v.get("max_mag")).floatValue();
        istft = new SpeakOps.Istft(num(v, "n_fft"), num(v, "hop"));
        if (num(v, "hop") != hop) throw new IOException("vocoder hop " + num(v, "hop") + " != mel hop " + hop);
        invFreq = new double[d / 2];
        for (int i = 0; i < d / 2; i++) invFreq[i] = 1.0 / Math.pow(10000.0, (2.0 * i) / d);
        need(am, "tok"); need(am, "mel.w"); need(voc, "head.w");
    }

    private static int num(Map<String, Object> m, String k) {
        Object o = m.get(k); if (o == null) throw new IllegalArgumentException("voice.json: missing " + k); return ((Number) o).intValue();
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        return new String(b.toByteArray(), StandardCharsets.UTF_8);
    }

    private static Krw.T need(Map<String, Krw.T> m, String k) { Krw.T t = m.get(k); if (t == null) throw new IllegalStateException("weights: missing " + k); return t; }

    private Krw.T A(String k) { return need(am, k); }
    private float[] Af(String k) { return need(am, k).floats(); }
    private Krw.T V(String k) { return need(voc, k); }
    private float[] Vf(String k) { return need(voc, k).floats(); }

    public int sampleRate() { return sampleRate; }
    public String normalize(String t, String lang) { return text.normalize(t, lang); }
    public List<String> sentences(String normalized) { return SpeakText.sentences(normalized); }
    public int[] encode(String sentence) { return text.encode(sentence); }
    public int langId(String lang) { return text.langId(lang); }
    public int voiceId(String lang, String speaker) { return text.voiceId(lang, speaker); }

    /** Text -> 16 kHz PCM. */
    public float[] synth(String t, String lang, String speaker) { return synth(t, lang, speaker, 1f); }

    /**
     * Text -> 16 kHz PCM; speed 1 = teacher pace, 1.2 = 20% faster. Output has the format of the pre-rendered clips
     * (voice/render_segments.py): sentences joined with 0.28 s pauses, peak-normalised to 0.85, 50 ms silence before and
     * 100 ms after, so synthesised and pre-rendered speech play at the same loudness.
     */
    public float[] synth(String t, String lang, String speaker, float speed) {
        if (!(speed > 0.25f && speed < 4f)) throw new IllegalArgumentException("speed " + speed);
        int li = text.langId(lang), vi = text.voiceId(lang, speaker);
        List<float[]> parts = new ArrayList<>();
        for (String s : SpeakText.sentences(text.normalize(t, lang))) {
            float[] mel = acoustic(text.encode(s), li, vi, speed, null, null);
            parts.add(vocode(mel, mel.length / nMels));
        }
        if (parts.isEmpty()) return new float[0];
        int gap = Math.round(text.gapSeconds * sampleRate), lead = sampleRate / 20, tail = sampleRate / 10, n = lead + tail;
        for (int i = 0; i < parts.size(); i++) n += parts.get(i).length + (i > 0 ? gap : 0);
        float[] out = new float[n]; int o = lead; float peak = 0f;
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) o += gap;
            float[] p = parts.get(i); System.arraycopy(p, 0, out, o, p.length); o += p.length;
            for (float v : p) peak = Math.max(peak, Math.abs(v));
        }
        float g = 0.85f / (peak + 1e-6f); for (int i = 0; i < out.length; i++) out[i] *= g;
        return out;
    }

    // ------------------------------------------------------------------ acoustic model
    private void addPositions(float[] x, int T, int dim) {
        int h = dim / 2;
        for (int t = 0; t < T; t++) {
            int o = t * dim;
            for (int i = 0; i < h; i++) { double ang = t * invFreq[i]; x[o + i] += (float) Math.sin(ang); x[o + h + i] += (float) Math.cos(ang); }
        }
    }

    private static void addRow(float[] x, int T, int dim, float[] row) {
        for (int t = 0; t < T; t++) { int o = t * dim; for (int i = 0; i < dim; i++) x[o + i] += row[i]; }
    }

    /** One post-LN FFT block (attention + conv FFN), in place semantics: returns the new activations. */
    private float[] fft(float[] x, int T, String p) {
        float[] qkv = SpeakOps.gemm(A(p + "qkv.w"), Af(p + "qkv.b"), x, 0, d, T);
        float[] q = new float[T * d], k = new float[T * d], v = new float[T * d];
        for (int t = 0; t < T; t++) { int s = t * 3 * d, o = t * d; System.arraycopy(qkv, s, q, o, d); System.arraycopy(qkv, s + d, k, o, d); System.arraycopy(qkv, s + 2 * d, v, o, d); }
        float[] att = Nn.attention(q, k, v, T, T, d, heads, false, null);
        float[] o = SpeakOps.gemm(A(p + "o.w"), Af(p + "o.b"), att, 0, d, T);
        for (int i = 0; i < o.length; i++) o[i] += x[i];
        Nn.layerNorm(o, T, d, Af(p + "ln1.g"), Af(p + "ln1.b"), amEps);
        float[] h = SpeakOps.conv(A(p + "ff1.w"), Af(p + "ff1.b"), o, T, d, ffK);
        SpeakOps.relu(h);
        float[] f = SpeakOps.gemm(A(p + "ff2.w"), Af(p + "ff2.b"), h, 0, dff, T);
        for (int i = 0; i < f.length; i++) f[i] += o[i];
        Nn.layerNorm(f, T, d, Af(p + "ln2.g"), Af(p + "ln2.b"), amEps);
        return f;
    }

    /** Duration / pitch predictor: 2 x (conv, ReLU, LayerNorm) then one value per token. */
    private float[] predictor(float[] x, int N, String p) {
        float[] h = x; int cin = d;
        for (int i = 0; i < 2; i++) {
            h = SpeakOps.conv(A(p + ".c" + i + ".w"), Af(p + ".c" + i + ".b"), h, N, cin, predK);
            SpeakOps.relu(h); Nn.layerNorm(h, N, predF, Af(p + ".ln" + i + ".g"), Af(p + ".ln" + i + ".b"), amEps); cin = predF;
        }
        float[] w = Af(p + ".out.w"), b = Af(p + ".out.b"), y = new float[N];
        for (int t = 0; t < N; t++) { float acc = 0f; int o = t * predF; for (int i = 0; i < predF; i++) acc += w[i] * h[o + i]; y[t] = acc + b[0]; }
        return y;
    }

    /** Durations from predicted log(1+d): float64 cumulative rounding, half to even (model_am.durations_from_logd). */
    static int[] durations(float[] logd, float speed, float maxDur) {
        int N = logd.length; int[] dur = new int[N]; double cum = 0, prev = 0; int best = 0; double bestV = -1; long total = 0;
        for (int i = 0; i < N; i++) {
            double v = Math.exp((double) logd[i]) - 1.0;
            v = Math.min(Math.max(v, 0.0), (double) maxDur) / (double) speed;
            if (v > bestV) { bestV = v; best = i; }
            cum += v; double end = Math.rint(cum); dur[i] = (int) (end - prev); prev = end; total += dur[i];
        }
        if (total == 0 && N > 0) dur[best] = 1;
        return dur;
    }

    /**
     * Token ids -> log-mel [T][nMels] (row-major). forcedDur (may be null) replaces the predicted durations;
     * debug (may be null, length >= 3) receives {durations int[], logd float[], pitch float[]}.
     */
    public float[] acoustic(int[] ids, int lang, int voice, float speed, int[] forcedDur, Object[] debug) {
        final int N = ids.length; Krw.T tok = A("tok");
        float[] x = new float[N * d]; float[] lrow = new float[d], verow = new float[d], vdrow = new float[d];
        A("lang").row(lang, lrow, 0); A("voice_enc").row(voice, verow, 0); A("voice_dec").row(voice, vdrow, 0);
        for (int t = 0; t < N; t++) tok.row(ids[t], x, t * d);
        addRow(x, N, d, lrow); addRow(x, N, d, verow); addPositions(x, N, d);
        for (int l = 0; l < encLayers; l++) x = fft(x, N, "enc." + l + ".");
        float[] logd = predictor(x, N, "dur"), pitch = predictor(x, N, "pitch");
        float[] pw = Af("pitch_emb.w"), pb = Af("pitch_emb.b"); int pp = pitchK / 2;          // conv(1 -> d, k): w [d][k]
        for (int t = 0; t < N; t++) {
            int o = t * d;
            for (int c = 0; c < d; c++) {
                float acc = pb[c];
                for (int j = 0; j < pitchK; j++) { int s = t + j - pp; if (s >= 0 && s < N) acc += pw[c * pitchK + j] * pitch[s]; }
                x[o + c] += acc;
            }
        }
        int[] dur = forcedDur != null ? forcedDur : durations(logd, speed, maxDur);
        if (dur.length != N) throw new IllegalArgumentException("durations: " + dur.length + " != tokens " + N);
        int T = 0; for (int v : dur) T += v;
        float[] y = new float[T * d]; int r = 0;
        for (int t = 0; t < N; t++) for (int k = 0; k < dur[t]; k++) System.arraycopy(x, t * d, y, (r++) * d, d);
        addPositions(y, T, d); addRow(y, T, d, vdrow);
        for (int l = 0; l < decLayers; l++) y = fft(y, T, "dec." + l + ".");
        float[] mel = SpeakOps.gemm(A("mel.w"), Af("mel.b"), y, 0, d, T);
        if (debug != null) { debug[0] = dur; debug[1] = logd; debug[2] = pitch; }
        return mel;
    }

    // ------------------------------------------------------------------ vocoder
    /** log-mel [T][nMels] -> (T-1)*hop samples. */
    public float[] vocode(float[] mel, int T) {
        float[] x = SpeakOps.conv(V("embed.w"), Vf("embed.b"), mel, T, nMels, vK);
        Nn.layerNorm(x, T, vDim, Vf("norm.g"), Vf("norm.b"), vEps);
        for (int l = 0; l < vLayers; l++) {
            String p = "b" + l + ".";
            float[] h = SpeakOps.dwconv(x, T, vDim, Vf(p + "dw.w"), Vf(p + "dw.b"), vK);
            Nn.layerNorm(h, T, vDim, Vf(p + "ln.g"), Vf(p + "ln.b"), vEps);
            float[] u = SpeakOps.gemm(V(p + "pw1.w"), Vf(p + "pw1.b"), h, 0, vDim, T);
            SpeakOps.gelu(u);
            float[] w = SpeakOps.gemm(V(p + "pw2.w"), Vf(p + "pw2.b"), u, 0, vInter, T);
            float[] g = Vf(p + "gamma");
            for (int t = 0; t < T; t++) { int o = t * vDim; for (int c = 0; c < vDim; c++) x[o + c] += g[c] * w[o + c]; }
        }
        Nn.layerNorm(x, T, vDim, Vf("final.g"), Vf("final.b"), vEps);
        float[] s = SpeakOps.gemm(V("head.w"), Vf("head.b"), x, 0, vDim, T);
        return istft.synth(s, T, maxMag);
    }

    // ------------------------------------------------------------------ utilities
    /** 16-bit PCM mono WAV. */
    public static void writeWav(File f, float[] pcm, int sr) throws IOException {
        try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)))) {
            int n = pcm.length * 2;
            o.writeBytes("RIFF"); o.writeInt(Integer.reverseBytes(36 + n)); o.writeBytes("WAVEfmt ");
            o.writeInt(Integer.reverseBytes(16)); o.writeShort(Short.reverseBytes((short) 1)); o.writeShort(Short.reverseBytes((short) 1));
            o.writeInt(Integer.reverseBytes(sr)); o.writeInt(Integer.reverseBytes(sr * 2)); o.writeShort(Short.reverseBytes((short) 2)); o.writeShort(Short.reverseBytes((short) 16));
            o.writeBytes("data"); o.writeInt(Integer.reverseBytes(n));
            for (float v : pcm) { int s = Math.round(Math.max(-1f, Math.min(1f, v)) * 32767f); o.writeShort(Short.reverseBytes((short) s)); }
        }
    }

    /** CLI: java in.krishi.doctor.Speak <model dir> <lang> <speaker> <out.wav> <text...> */
    public static void main(String[] args) throws Exception {
        if (args.length < 5) { System.err.println("usage: Speak <model dir> <lang> <speaker> <out.wav> <text...>"); System.exit(1); }
        Speak s = new Speak(new File(args[0]));
        StringBuilder t = new StringBuilder(); for (int i = 4; i < args.length; i++) t.append(i > 4 ? " " : "").append(args[i]);
        long t0 = System.nanoTime(); float[] pcm = s.synth(t.toString(), args[1], args[2]); double sec = (System.nanoTime() - t0) / 1e9;
        writeWav(new File(args[3]), pcm, s.sampleRate);
        System.out.printf("%s: %.2f s audio in %.2f s (RTF %.3f)%n", args[3], pcm.length / (double) s.sampleRate, sec, sec / Math.max(1e-9, pcm.length / (double) s.sampleRate));
        Nn.release();
    }
}
