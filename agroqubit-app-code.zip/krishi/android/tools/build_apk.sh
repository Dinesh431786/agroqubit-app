#!/bin/bash
# Build the APK with the plain SDK tools (no Gradle): aapt2 -> javac -> d8 -> zipalign -> apksigner.
# Usage: build_apk.sh <android_dir> <assets_dir> <out.apk>
set -euo pipefail
A=$1; ASSETS=$2; OUT=$3
SDK=${ANDROID_SDK_ROOT:-/opt/android-sdk}; BT=$SDK/build-tools/34.0.0; AJ=$SDK/platforms/android-34/android.jar
W=$(mktemp -d); mkdir -p $W/gen $W/obj $W/dex
$BT/aapt2 compile --dir $A/app/res -o $W/res.zip
$BT/aapt2 link -o $W/base.apk -I $AJ --manifest $A/app/AndroidManifest.xml -A $ASSETS $W/res.zip --java $W/gen \
  --min-sdk-version 21 --target-sdk-version 34 --version-code 1 --version-name 0.1 -0 ogg -0 jpg
javac -nowarn --release 8 -classpath $AJ -encoding UTF-8 -d $W/obj \
  $(find $A/src $A/app/src $W/gen -name '*.java') 2>&1 | grep -v "warning: \[options\]" || true
test -f $W/obj/in/krishi/doctor/MainActivity.class
$BT/d8 --min-api 21 --release --lib $AJ --output $W/dex $(find $W/obj -name '*.class')
cp $W/base.apk $W/unsigned.apk; (cd $W/dex && zip -q $W/unsigned.apk classes.dex)
$BT/zipalign -f -p 4 $W/unsigned.apk $W/aligned.apk
KS=${KEYSTORE:-/opt/krishi.ks}
[ -f $KS ] || keytool -genkeypair -keystore $KS -storepass krishi123 -keypass krishi123 -alias krishi -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Krishi Doctor test build" >/dev/null 2>&1
$BT/apksigner sign --ks $KS --ks-pass pass:krishi123 --key-pass pass:krishi123 --out $OUT $W/aligned.apk
$BT/apksigner verify $OUT && ls -la $OUT
rm -rf $W
