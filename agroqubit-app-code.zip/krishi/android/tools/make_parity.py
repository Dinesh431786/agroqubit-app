"""Generate Python reference outputs for the Java port (int8-quantised bag, same as the phone):
 1) slot / free-chat probabilities for held-out sentences, 2) full scripted conversations (text + taps) with every reply.
Usage: python3 make_parity.py <krishi_dir> <out.json> [n_conv]"""
import json, os, random, sys, numpy as np, torch
K, OUT = sys.argv[1], sys.argv[2]; NCONV = int(sys.argv[3]) if len(sys.argv) > 3 else 300

def q8(src, dst):
    ck = torch.load(src); W = ck["state"]["bag.weight"].float().numpy()
    sc = (np.abs(W).max(1, keepdims=True) / 127 + 1e-12).astype(np.float32)
    ck["state"]["bag.weight"] = torch.tensor((np.clip(np.round(W / sc), -127, 127).astype(np.int8).astype(np.float32) * sc).astype(np.float32))
    torch.save(ck, dst)
q8(f"{K}/text/enc_AL_0.pt", f"{K}/text/enc_ALq8_0.pt"); q8(f"{K}/text/enc_DL_0.pt", f"{K}/text/enc_DLq8_0.pt")
q8(f"{K}/freechat/free_intent.pt", f"{K}/freechat/free_intent_q8.pt")
os.environ["KRISHI_TEXT"] = "q8"; os.environ["KRISHI_FREE_CK"] = f"{K}/freechat/free_intent_q8.pt"
sys.path.insert(0, f"{K}/brain"); sys.path.insert(0, f"{K}/freechat"); sys.path.insert(0, f"{K}/text")
from chat import Chat, TextUnderstanding
from freechat import FreeChat
from textenc import TextEncoder, pack, pack_windows, mil_logits
torch.set_num_threads(4)

rows = lambda f: [json.loads(l) for l in open(f"{K}/data/{f}")]
T, F = rows("text_test.jsonl"), rows("free_questions_test.jsonl")
S = rows("text_slang_test.jsonl") if os.path.exists(f"{K}/data/text_slang_test.jsonl") else T
rnd = random.Random(7)
sents = [r["text"] for r in rnd.sample(T, 150) + rnd.sample(S, 100) + rnd.sample(F, 100)] + ["", "!!", "ok", "धान 🌾 में झोंका?"]
tu = TextUnderstanding(); fc = FreeChat()
al, dl = tu.m[0][0], tu.m[1][0]
probs = []
with torch.no_grad():
    for s in sents:
        i, o = pack([s]); a = torch.sigmoid(al.slot_logits(al.embed(i, o))).numpy()[0]
        i, o, w, h = pack_windows([s]); d = torch.sigmoid(mil_logits(dl, i, o, w, 1)).numpy()[0]
        i, o = pack([s]); li, ld = fc.net(i, o)
        probs.append({"text": s, "AL": a.tolist(), "DL": d.tolist(), "intent": torch.softmax(li, 1)[0].tolist(), "dis": torch.softmax(ld, 1)[0].tolist()})

def lang_of(r): return r["lang"].split("-")[0] if r["lang"] in ("hi", "ta", "kn", "en") else None
pool = {L: [r["text"] for r in T + S + F if r.get("lang") == L] for L in ["hi", "ta", "kn", "en"]}
yesno = {L: [r["text"] for r in T if r.get("lang") == L and any(x.startswith("ans_") for x in r["slots"])] for L in ["hi", "ta", "kn", "en"]}
SKIP = ["pic_rice", "pic_chilli", "pic_groundnut"]
convs = []
for c in range(NCONV):
    L = rnd.choice(["hi", "ta", "kn", "en"]); skip = SKIP if c % 2 == 0 else []
    ch = Chat(L, skip=skip); turns = []; last = None
    for t in range(9):
        if t == 0: act = {"text": rnd.choice(pool[L])}
        elif last and last.get("buttons") and rnd.random() < 0.55: act = {"tap": rnd.choice(last["buttons"])}
        elif rnd.random() < 0.6: act = {"text": rnd.choice(yesno[L])}
        else: act = {"text": rnd.choice(pool[L])}
        r = ch.turn(text=act.get("text"), tap=act.get("tap")); last = r
        spoken = r["type"] in ("free_answer", "fact_answer") or r.get("action") == "not_covered" or r.get("qid") == "__confirm__"
        turns.append({**act, "type": r["type"], "qid": r.get("qid"), "disease": r.get("disease"), "action": r.get("action"),
                      "say": r["say"] if spoken else None, "facts": r.get("facts"), "confidence": r.get("confidence"),
                      "post": ch.brain.st["post"].tolist() if ch.brain.st is not None else None})
        if r["type"] in ("diagnosis", "not_sure", "referral") and rnd.random() < 0.5: break
    convs.append({"lang": L, "skip": skip, "turns": turns})
json.dump({"probs": probs, "convs": convs}, open(OUT, "w"), ensure_ascii=False)
from collections import Counter
print("sentences", len(probs), "conversations", len(convs), Counter(t["type"] for c in convs for t in c["turns"]))
