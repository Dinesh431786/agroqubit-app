#!/bin/bash
# One-time VM job: rebuild everything from public data and the code, then test like a farmer.
#  - retrain the phone text models; retrain the photo model (PlantDoc + ImageNet MobileNetV3) and export it for the phone
#  - closed-world voice: enumerate every sentence the app can say, render all with human neural voices (female + male)
#  - build the APK (no Gradle), boot a 2 GB Android 11 emulator (nested KVM) and an Android 7 one, run the tests, upload.
set -x
export K=/home/claude/krishi V=/home/claude/agri_vision OUTD=/opt/work/out SDK=/opt/android-sdk
export ANDROID_SDK_ROOT=$SDK ANDROID_HOME=$SDK ANDROID_AVD_HOME=/opt/avd PATH=$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:$SDK/emulator:$PATH
mkdir -p $OUTD /opt/avd
step() { echo "$(date -u +%H:%M:%S) $*" | tee -a $OUTD/progress.txt; }
waitfor() { for i in $(seq 1 ${2:-360}); do grep -q "$1" $OUTD/progress.txt && return 0; sleep 10; done; return 1; }
step start; nproc; free -g; ls -la /dev/kvm

apt-get install -y openjdk-17-jdk-headless unzip zip ffmpeg git python3-venv python3-pip libsndfile1 libpulse0 libgl1 libnss3 \
  libxcomposite1 libxcursor1 libxi6 libxtst6 libxdamage1 libxrandr2 libasound2t64 libxkbfile1 libbsd0 cpu-checker > $OUTD/apt.log 2>&1
kvm-ok > $OUTD/kvm.txt 2>&1; step "apt done; $(cat $OUTD/kvm.txt | tail -1)"

# ---------- downloads in the background: Android SDK, TTS checkpoints, PlantDoc photos + ImageNet weights
( mkdir -p $SDK/cmdline-tools && cd /tmp && curl -sSL -o clt.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip \
  && unzip -q clt.zip -d $SDK/cmdline-tools && mv $SDK/cmdline-tools/cmdline-tools $SDK/cmdline-tools/latest \
  && yes | sdkmanager --licenses > /dev/null \
  && sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" "emulator" "system-images;android-30;google_apis;x86_64" \
  && step sdk_done && sdkmanager "system-images;android-24;default;x86_64" && step sdk_old_done ) > $OUTD/sdk.log 2>&1 &
( mkdir -p /home/claude/tts_models && cd /home/claude/tts_models && for L in hi ta kn en; do
    curl -sSL -o $L.zip https://github.com/AI4Bharat/Indic-TTS/releases/download/v1-checkpoints-release/$L.zip && unzip -q -o $L.zip && rm $L.zip; done
  python3 - <<'PY'
import glob, re
for f in glob.glob("/home/claude/tts_models/*/fastpitch/config.json"):
    d = f.rsplit("/", 1)[0]; s = open(f).read()
    s = re.sub(r'"speakers_file": *"[^"]*"', f'"speakers_file": "{d}/speakers.pth"', s); open(f, "w").write(s)
print("patched")
PY
  step tts_models_done ) > $OUTD/ttsdl.log 2>&1 &
( mkdir -p /home/claude/data /home/claude/weights && cd /home/claude && git clone -q --depth 1 https://github.com/pratikkayal/PlantDoc-Dataset data/PlantDoc-Dataset \
  && curl -sSL -o weights/mnv3.pth https://github.com/huggingface/pytorch-image-models/releases/download/v0.1-weights/mobilenetv3_large_100_ra-f55367f5.pth \
  && md5sum weights/mnv3.pth && step plantdoc_done ) > $OUTD/plantdoc.log 2>&1 &

# ---------- Python env
python3 -m venv /opt/venv && . /opt/venv/bin/activate
pip install -q --upgrade pip
# torchvision must come from the SAME cpu index as torch (timm needs it; a PyPI torchvision breaks torch + TTS imports)
pip install -q torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu > $OUTD/pip.log 2>&1
pip install -q numpy scipy soundfile pillow boto3 indic_transliteration "timm==1.0.30" onnx onnxruntime >> $OUTD/pip.log 2>&1
( pip install -q "coqui-tts==0.27.5" "transformers<5" torchcodec >> $OUTD/pip_tts.log 2>&1; step pip_tts_done ) &
PIPTTS=$!
step pip_done; python3 -c "import torch, timm, onnxruntime; print(torch.__version__, timm.__version__, onnxruntime.__version__)" >> $OUTD/progress.txt

# ---------- text models (same scripts, same seeds) + accuracy
cd $K/text
for M in AL DL; do OMP_NUM_THREADS=4 python3 train_text2.py $M 0 > $OUTD/train_$M.log 2>&1; done
step "text models trained: AL $(grep -o 'single_top1[^,]*' res_AL_0.json) DL $(grep -o 'single_top1[^,]*' res_DL_0.json)"
cp res_AL_0.json res_DL_0.json $OUTD/
cd $K/freechat && OMP_NUM_THREADS=4 python3 train_free.py > $OUTD/train_free.log 2>&1 && python3 eval_freechat.py > $OUTD/eval_free.txt 2>&1; cp results_freechat.json $OUTD/ 2>/dev/null
step "free chat trained: $(grep -o '"WRONG_answer[^,]*' $K/freechat/results_freechat.json) $(grep -o '"correct_answer[^,]*' $K/freechat/results_freechat.json)"

# ---------- photo model (background): PlantDoc -> train -> multi-fingerprints -> phone format -> checks + test photos
( waitfor plantdoc_done 180 && cd $V && python3 prep.py /home/claude/data/PlantDoc-Dataset /home/claude/data/cache > $OUTD/vision_prep.log 2>&1 \
  && THREADS=4 python3 train.py 15 > $OUTD/vision_train.log 2>&1 && THREADS=4 python3 fingerprints.py > $OUTD/vision_fp.log 2>&1 \
  && python3 $K/android/tools/vision_check.py $V /home/claude/data/cache /home/claude/data/PlantDoc-Dataset /opt/vision $OUTD > $OUTD/vision_check.log 2>&1
  step "vision_done: $(tail -c 700 $OUTD/vision_check.log | tr '\n' ' ')" ) &
VISJOB=$!

# ---------- phone assets, closed-world sentence list, Python reference, Java parity (+ every reply fully voiced)
ASSETS=/opt/assets; rm -rf $ASSETS; python3 $K/android/tools/export_phone.py $K $ASSETS > $OUTD/export.log 2>&1
mkdir -p $ASSETS/pics && python3 - <<'PY'
import urllib.request, urllib.parse, io
from PIL import Image
P = {"tomato_bacterial_leaf_spot": ("Tomato leaf bacterial spot", "05-069f1.jpg"), "tomato_early_blight": ("Tomato Early blight leaf", "1576389-early%20blight%20symptoms.jpg"),
     "tomato_healthy": ("Tomato leaf", "003.JPG.jpg"), "tomato_late_blight": ("Tomato leaf late blight", "20150619d.jpg"), "tomato_leaf_curl": ("Tomato leaf yellow virus", "18071.img.jpg"),
     "tomato_leaf_mold": ("Tomato mold leaf", "100_4542.jpg"), "tomato_mosaic": ("Tomato leaf mosaic virus", "1422_0.jpeg.jpg"), "tomato_septoria_leaf_spot": ("Tomato Septoria leaf spot", "1b.jpg")}
for d, (c, f) in P.items():
    url = "https://raw.githubusercontent.com/pratikkayal/PlantDoc-Dataset/master/train/" + urllib.parse.quote(c) + "/" + urllib.parse.quote(f)
    try:
        im = Image.open(io.BytesIO(urllib.request.urlopen(url, timeout=60).read())).convert("RGB"); w, h = im.size; s = min(w, h)
        im.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s)).resize((240, 240), Image.LANCZOS).save(f"/opt/assets/pics/{d}.jpg", quality=62, optimize=True); print("ok", d)
    except Exception as e: print("FAILED", d, url, e)
PY
cd $K/voice && python3 closed_world.py $ASSETS $K/voice/segments.json > $OUTD/closed_world.log 2>&1; cp $K/voice/segments.json $OUTD/
step "closed-world sentences: $(tail -1 $OUTD/closed_world.log)"
python3 $K/android/tools/make_parity.py $K /opt/parity.json 300 > $OUTD/parity_py.log 2>&1
mkdir -p /opt/jb && javac -nowarn -encoding UTF-8 -d /opt/jb $(find $K/android/src $K/android/test -name "*.java") > $OUTD/javac_core.log 2>&1
java -Xmx1g -cp /opt/jb ChatParity $ASSETS /opt/parity.json $K/voice/segments.json > $OUTD/java_parity.txt 2>&1; step "java parity: $(tail -3 $OUTD/java_parity.txt | tr '\n' ' ')"

# ---------- closed-world voice packs: 2 voices x 2 language groups in parallel (1 thread each; the photo model trains alongside)
wait $PIPTTS; waitfor tts_models_done 240
cd $K/voice; RJ=""
for SPK in female male; do P=${SPK:0:1}; for G in hi,ta kn,en; do
  ( OMP_NUM_THREADS=1 PACK_OUT=pack_$P SPEAKER=$SPK LANGS=$G python3 render_segments.py segments.json > $OUTD/render_${P}_${G/,/_}.log 2>&1 ) & RJ="$RJ $!"
done; done

# ---------- emulator (boots while voices render)
waitfor sdk_done 240
echo no | avdmanager create avd -n k30 -k "system-images;android-30;google_apis;x86_64" -d pixel_4 --force > $OUTD/avd.log 2>&1
printf "hw.ramSize=2048\nhw.keyboard=no\ndisk.dataPartition.size=3G\nhw.audioOutput=yes\n" >> /opt/avd/k30.avd/config.ini
QEMU_AUDIO_DRV=none nohup emulator -avd k30 -no-window -no-snapshot -no-boot-anim -gpu swiftshader_indirect -memory 2048 -cores 2 -accel on > $OUTD/emulator.log 2>&1 &
timeout 900 adb wait-for-device; for i in $(seq 1 120); do [ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ] && break; sleep 5; done
step "emulator booted: $(adb shell getprop ro.build.version.release | tr -d '\r') api $(adb shell getprop ro.build.version.sdk | tr -d '\r')"
for s in window_animation_scale transition_animation_scale animator_duration_scale; do adb shell settings put global $s 0; done

# ---------- build APK (voices + photo model) and test
wait $RJ; step "voices: f=$(ls $K/voice/pack_f/*/*.ogg 2>/dev/null | wc -l) m=$(ls $K/voice/pack_m/*/*.ogg 2>/dev/null | wc -l) clips"
cat $K/voice/pack_*/render_report_*.json > /dev/null 2>&1; cp $K/voice/pack_*/render_report_*.json $OUTD/ 2>/dev/null
wait $VISJOB; cp /opt/vision/vision.bin /opt/vision/vision.json $ASSETS/ && step "photo model in assets: $(ls -la $ASSETS/vision.bin)"
for P in f m; do for L in hi ta kn en; do mkdir -p $ASSETS/voice/$P/$L; cp $K/voice/pack_$P/$L/*.ogg $ASSETS/voice/$P/$L/ 2>/dev/null; done; done
du -sh $ASSETS $ASSETS/voice/* $ASSETS/*.bin >> $OUTD/progress.txt
bash $K/android/tools/build_apk.sh $K/android $ASSETS $OUTD/krishi-doctor.apk > $OUTD/build.log 2>&1; step "apk: $(ls -la $OUTD/krishi-doctor.apk 2>&1)"
adb install -r $OUTD/krishi-doctor.apk > $OUTD/install.log 2>&1; step "install: $(tail -1 $OUTD/install.log)"
mkdir -p $OUTD/emu30 && APK=$OUTD/krishi-doctor.apk SEGMENTS=$K/voice/segments.json PHOTOS=$OUTD/test_photos timeout 3600 python3 $K/android/tools/emu_test.py $K $OUTD/emu30 > $OUTD/emu30.log 2>&1
step "emulator test (Android 11, 2GB): $(tail -1 $OUTD/emu30.log | cut -c1-900)"

# ---------- old Android (7.0, API 24): install without streaming, then smoke test incl. photo + spoken answers
adb emu kill; sleep 8
waitfor sdk_old_done 120
echo no | avdmanager create avd -n k24 -k "system-images;android-24;default;x86_64" -d pixel --force >> $OUTD/avd.log 2>&1
printf "hw.ramSize=2048\nhw.keyboard=no\n" >> /opt/avd/k24.avd/config.ini
QEMU_AUDIO_DRV=none nohup emulator -avd k24 -no-window -no-snapshot -no-boot-anim -gpu swiftshader_indirect -memory 2048 -cores 2 -accel on > $OUTD/emulator24.log 2>&1 &
timeout 900 adb wait-for-device; for i in $(seq 1 120); do [ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ] && break; sleep 5; done
for i in $(seq 1 30); do adb shell pm path android > /dev/null 2>&1 && break; sleep 5; done; sleep 20
timeout 300 adb install --no-streaming -r $OUTD/krishi-doctor.apk > $OUTD/install24.log 2>&1 || timeout 300 adb install -r $OUTD/krishi-doctor.apk >> $OUTD/install24.log 2>&1
step "install android 7: $(tail -1 $OUTD/install24.log)"
mkdir -p $OUTD/emu24 && SMOKE=1 APK=$OUTD/krishi-doctor.apk SEGMENTS=$K/voice/segments.json PHOTOS=$OUTD/test_photos timeout 1500 python3 $K/android/tools/emu_test.py $K $OUTD/emu24 > $OUTD/emu24.log 2>&1
step "android 7 smoke: $(tail -1 $OUTD/emu24.log | cut -c1-600)"
python3 - <<'PY'
import glob
from PIL import Image
for d in ["/opt/work/out/emu30", "/opt/work/out/emu24"]:
    fs = sorted(glob.glob(d + "/*.png"))
    if not fs: continue
    ims = [Image.open(f).convert("RGB") for f in fs]; ims = [i.resize((270, int(270 * i.height / i.width))) for i in ims]
    cols = 5; rows = (len(ims) + cols - 1) // cols; H = max(i.height for i in ims)
    M = Image.new("RGB", (270 * cols, H * rows), "white")
    for k, i in enumerate(ims): M.paste(i, ((k % cols) * 270, (k // cols) * H))
    M.save(d + "/montage.jpg", quality=55, optimize=True); print(d, len(fs))
PY
step FINISHED
