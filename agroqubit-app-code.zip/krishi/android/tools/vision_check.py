"""VM step after agri_vision/train.py + fingerprints.py: export the photo model for the phone and check it.
 1) student.pt -> leaf_fp32.onnx -> vision.bin/.json (int8 pointwise + fp16 depthwise, see export_vision.py)
 2) accuracy of the phone weights vs fp32 on the held-out PlantDoc test set (single view, as on the phone)
 3) 'not sure' threshold re-calibrated on validation photos for single-view phone inference (answers ~80%)
 4) 20 real test photos (JPEG) + the Python reference answer for each, to compare against the app on the emulator
Usage: python3 vision_check.py <agri_vision_dir> <cache_dir> <plantdoc_dir> <vision_out_dir> <results_dir>"""
import glob, json, os, shutil, subprocess, sys, numpy as np, torch, onnx, onnxruntime as ort
from onnx import numpy_helper
from PIL import Image, ImageOps
A, C, PD, VIS, RES = sys.argv[1:6]; sys.path.insert(0, A); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from model import Embedder
import export_vision as EV
os.makedirs(VIS, exist_ok=True); os.makedirs(f"{RES}/test_photos", exist_ok=True)

ck = torch.load(f"{A}/student.pt"); net = Embedder(); net.load_state_dict(ck["net"]); net.eval()
torch.onnx.export(net, torch.rand(1, 3, 224, 224) * 255, f"{A}/leaf_fp32.onnx", input_names=["image"], output_names=["embedding"], opset_version=17, dynamo=False)
_, _, _, deq = EV.convert(f"{A}/leaf_fp32.onnx", "int8"); m8 = onnx.load(f"{A}/leaf_fp32.onnx")
for ini in m8.graph.initializer:
    if ini.name in deq: ini.CopyFrom(numpy_helper.from_array(deq[ini.name].astype(np.float32), ini.name))
def sess(m): so = ort.SessionOptions(); so.intra_op_num_threads = 4; return ort.InferenceSession(m.SerializeToString(), so, providers=["CPUExecutionProvider"])
s32, s8 = sess(onnx.load(f"{A}/leaf_fp32.onnx")), sess(m8)
def emb(s, X): return np.concatenate([s.run(None, {"image": X[i:i + 1, 16:240, 16:240].transpose(0, 3, 1, 2).astype(np.float32)})[0] for i in range(len(X))])
def norm(v): return v / np.linalg.norm(v, axis=-1, keepdims=True)
def kmeans(X, k, it=30):
    rng = np.random.default_rng(0); Cc = X[rng.choice(len(X), k, replace=False)]
    for _ in range(it): a = (X @ Cc.T).argmax(1); Cc = np.stack([norm(X[a == j].mean(0)) if (a == j).any() else Cc[j] for j in range(k)])
    return Cc
# fingerprints from the PHONE weights, single view (exactly what the app computes). PROTOS_K per disease (default 1:
# 4 sub-centroids gave +6 tomato top-1 on one training run and -1 on another = no reliable gain); 1 for the 10-photo new disease
classes = json.load(open(f"{C}/classes.json")); tr = np.load(f"{C}/train.npz"); sp = np.load(f"{C}/split.npz"); ho = int(sp["ho"]); known = sp["known"].tolist()
Ztr = emb(s8, tr["X"]); ytr = tr["y"]; idx = sp["train_idx"]
names = [classes[c] for c in known] + [classes[ho]]; P, cls, P1 = [], [], []
for i, c in enumerate(known):
    X = Ztr[idx][ytr[idx] == c]; k = min(int(os.environ.get("PROTOS_K", "1")), max(1, len(X) // 8)); P1.append(norm(X.mean(0)))
    for v in (kmeans(X, k) if k > 1 else norm(X.mean(0))[None]): P.append(v); cls.append(i)
newfp = norm(Ztr[np.where(ytr == ho)[0][:10]].mean(0)); P.append(newfp); cls.append(len(known)); P1.append(newfp)
np.savez(f"{VIS}/protos.npz", P=np.stack(P), cls=np.array(cls), names=np.array(names))
subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "export_vision.py"), f"{A}/leaf_fp32.onnx", f"{VIS}/protos.npz", VIS, "int8"], check=True)
V = json.load(open(f"{VIS}/vision.json")); PR = np.stack(P); CL = np.array(cls); P1 = np.stack(P1); NC = len(names)
def scores(Z, multi=True):
    if not multi: return Z @ P1.T
    S = Z @ PR.T; return np.stack([S[:, CL == j].max(1) for j in range(NC)], 1)
te = np.load(f"{C}/test.npz"); lab = np.array([names.index(classes[c]) for c in te["y"]]); kn = lab != NC - 1
tom = np.array([names[l].startswith("Tomato") for l in lab])
def metrics(Z, multi=True):
    S = scores(Z, multi); o26 = np.argsort(-S[:, :NC - 1], 1); o27 = np.argsort(-S, 1)
    return dict(known_top1=round(float((o26[kn, 0] == lab[kn]).mean()), 4), known_top3=round(float(np.mean([lab[i] in o26[i, :3] for i in np.where(kn)[0]])), 4),
                tomato_top1=round(float((o27[tom, 0] == lab[tom]).mean()), 4), tomato_top3=round(float(np.mean([lab[i] in o27[i, :3] for i in np.where(tom)[0]])), 4))
Z32, Z8 = emb(s32, te["X"]), emb(s8, te["X"])
R = {"fp32_single_view_one_fingerprint": metrics(Z32, False), "phone_int8_one_fingerprint": metrics(Z8, False), "phone_int8_multi_fingerprints (shipped)": metrics(Z8),
     "n_fingerprints": len(P), "cos_phone_vs_fp32": round(float((Z8 * Z32).sum(1).mean()), 5),
     "vision_bin_MB": round(os.path.getsize(f"{VIS}/vision.bin") / 1e6, 2), "n_test": int(len(lab)), "n_tomato": int(tom.sum())}
# not-sure gate for single-view phone inference: keep ~80% of known validation photos
sv = scores(Ztr[sp["val_idx"]])[:, :NC - 1].max(1)
t80 = float(np.quantile(sv, 0.20)); V["not_sure"] = round(t80, 3); json.dump(V, open(f"{VIS}/vision.json", "w"), ensure_ascii=False)
sk = scores(Z8[kn])[:, :NC - 1]; ans = sk.max(1) >= t80
R["not_sure_gate"] = {"threshold": round(t80, 3), "known_answered": round(float(ans.mean()), 3), "accuracy_when_answered": round(float((sk.argmax(1)[ans] == lab[kn][ans]).mean()), 3)}
# 20 real test photos for the emulator: 2 per tomato class + 4 other crops; reference = same JPEG, PIL framing, phone weights
pick = []
for c in sorted(os.listdir(f"{PD}/test")):
    fs = sorted(glob.glob(f"{PD}/test/{c}/*"))
    if c.startswith("Tomato"): pick += [(c, f) for f in fs[:2]]
    elif c in ("Corn rust leaf", "Potato leaf late blight", "Bell_pepper leaf spot", "grape leaf"): pick += [(c, fs[0])]
ref = []
for k, (c, f) in enumerate(pick):
    try:
        im = ImageOps.exif_transpose(Image.open(f)).convert("RGB"); im.thumbnail((640, 640)); dst = f"{RES}/test_photos/p{k:02d}.jpg"; im.save(dst, quality=90)
        im = Image.open(dst).convert("RGB"); w, h = im.size; s = min(w, h)
        x = np.asarray(im.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s)).resize((256, 256), Image.BICUBIC), np.uint8)[None]
        sc = scores(emb(s8, x))[0]; b = int(sc.argmax())
        ref.append({"file": os.path.basename(dst), "true": c, "ref_label": names[b], "ref_score": round(float(sc[b]), 4), "ref_correct": names[b] == c})
    except Exception as e: print("skip", f, e)
json.dump(ref, open(f"{RES}/test_photos/reference.json", "w"), indent=1)
R["test_photos"] = {"n": len(ref), "python_correct": sum(r["ref_correct"] for r in ref)}
json.dump(R, open(f"{RES}/vision_check.json", "w"), indent=1); shutil.copy(f"{A}/results_fingerprints.json", f"{RES}/results_fingerprints_vm.json")
print(json.dumps(R))
