"""Export everything the phone app needs into one assets folder (pure data, read by the Java core).
Weights: big-endian tensor files (bag = int8 rows + per-row fp32 scale, the rest fp32), same int8 scheme as export_int8.py.
Usage: python3 export_phone.py <krishi_dir> <out_assets_dir>"""
import json, os, struct, sys, numpy as np, torch
K, OUT = sys.argv[1], sys.argv[2]; os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, f"{K}/brain"); sys.path.insert(0, os.environ.get("ENGINE_DIR", "/home/claude/agri_reason/v2"))

def write_tensors(path, sd):
    with open(path, "wb") as f:
        f.write(b"KRW1"); f.write(struct.pack(">i", len(sd)))
        for name, v in sd.items():
            v = v.detach().float().numpy() if torch.is_tensor(v) else v
            nb = name.encode(); f.write(struct.pack(">h", len(nb))); f.write(nb)
            if name == "bag.weight":       # int8 rows + fp32 scale per row
                sc = np.abs(v).max(1, keepdims=True) / 127 + 1e-12; q = np.clip(np.round(v / sc), -127, 127).astype(np.int8)
                f.write(struct.pack(">bi", 1, 2)); f.write(struct.pack(">ii", *v.shape)); f.write(q.tobytes()); f.write(sc.astype(">f4").tobytes())
            else:
                v = np.asarray(v, np.float32); f.write(struct.pack(">bi", 0, v.ndim)); f.write(struct.pack(f">{v.ndim}i", *v.shape)); f.write(v.astype(">f4").tobytes())

for name in ["AL", "DL"]:
    write_tensors(f"{OUT}/text_{name}.bin", torch.load(f"{K}/text/enc_{name}_0.pt")["state"])
ck = torch.load(f"{K}/freechat/free_intent.pt"); write_tensors(f"{OUT}/free_intent.bin", ck["state"])
json.dump({"intents": ck["intents"], "diseases": ck["diseases"]}, open(f"{OUT}/free_labels.json", "w"), ensure_ascii=False)

from brain import Brain
b = Brain(); c = b.core
kb = {"names": c.names, "crops": c.crops, "qids": c.qids, "options": [c.opts[q] for q in c.qids],
      "theta": [c.theta[q].tolist() for q in c.qids], "q_crop": c.q_crop,
      "params": {"tau": c.tau, "stop_p": c.stop_p, "max_q": float(c.max_q), "min_gain": c.min_gain, "final_min_p": c.final_min_p}}
json.dump(kb, open(f"{OUT}/doctor_kb.json", "w"))
meta = {d: {"crop": v["crop"], "names": v.get("names", {})} for d, v in b.kb["diseases"].items()}
json.dump({"diseases": meta, "questions": {q: v for q, v in b.kb["questions"].items()}}, open(f"{OUT}/kb_meta.json", "w"), ensure_ascii=False)
for f in ["slots.json", "voice/catalogue.json", "brain/advice.json", "brain/advice_i18n.json", "voice/app_phrases.json"]:
    open(f"{OUT}/{os.path.basename(f)}", "w").write(open(f"{K}/{f}").read())
import shutil
VIS = os.environ.get("VISION_DIR")                # vision.bin + vision.json from export_vision.py (photo diagnosis)
if VIS:
    for f in ["vision.bin", "vision.json"]: shutil.copy(f"{VIS}/{f}", f"{OUT}/{f}")

# ---- fact-token model + verified facts (FACTLM_DIR: factlm.json/.bin from factlm/export.py; FACTS: facts.jsonl)
FL = os.environ.get("FACTLM_DIR")
if FL:
    for f in ["factlm.json", "factlm.bin"]: shutil.copy(f"{FL}/{f}", f"{OUT}/{f}")
    vocab = set(json.load(open(f"{FL}/factlm.json", encoding="utf-8"))["items"]["ids"])
    src = os.environ.get("FACTS") or (f"{K}/facts/facts.jsonl" if os.path.exists(f"{K}/facts/facts.jsonl") else f"{K}/facts/seed_facts.jsonl")
    C = json.load(open(f"{K}/voice/catalogue.json", encoding="utf-8")); CODE = {"cultural": "c", "biological": "b", "chemical": "x"}
    facts = {}
    for line in open(src, encoding="utf-8"):
        f = json.loads(line)
        if f["id"] not in vocab: continue
        e = {"text": f["text"], "kind": f["kind"], "crop": f["crop"], "target": f.get("target"), "topic": f.get("topic"),
             "review": f.get("review"), "src": f["source"].get("doc"), "url": f["source"].get("url"), "page": f["source"].get("page")}
        # seed facts are the app's existing advice items: reuse their voice clips (and the colloquial first-step lines)
        parts = f["id"].split(".")
        if f.get("review") == "seed" and len(parts) == 4 and f.get("target"):
            t, cat, n = parts[1], parts[2], int(parts[3])
            if cat == "first" and f"adv_{t}" in C: e["clip"] = f"adv_{t}"; e["text"] = {L: C[f"adv_{t}"].get(L) or f["text"].get(L) for L in ["hi", "ta", "kn", "en"]}
            elif cat in CODE: e["clip"] = f"it_{t}_{CODE[cat]}{n - 1}"
        facts[f["id"]] = e                       # source quotes are NOT shipped (licence: cite, don't reproduce)
    names = {}
    tn = os.environ.get("TARGET_NAMES") or f"{K}/facts/target_names.json"
    if os.path.exists(tn):
        for t, r in json.load(open(tn, encoding="utf-8")).items(): names[t] = {L: (r.get(L) or [None])[0] for L in ["hi", "ta", "kn", "en"]}
    json.dump({"facts": facts, "targets": names}, open(f"{OUT}/facts.json", "w", encoding="utf-8"), ensure_ascii=False)
    print("facts", len(facts), "of", len(vocab) - 5, "model items; target names", len(names))

# ---- our own trained voice model (VOICE_DIR: voice.json, voice_am.bin, voice_voc.bin from voice/student/export.py)
VO = os.environ.get("VOICE_DIR")
if VO:
    for f in ["voice.json", "voice_am.bin", "voice_voc.bin"]: shutil.copy(f"{VO}/{f}", f"{OUT}/{f}")
# ---- offline speech recognizer (WHISPER_DIR: whisper_<lang>.bin/.json from speech/whisper/export_whisper.py); WHISPER_LANGS
WH = os.environ.get("WHISPER_DIR")
if WH:
    for L in os.environ.get("WHISPER_LANGS", "hi,ta,kn,en").split(","):
        for ext in ["bin", "json"]:
            p = f"{WH}/whisper_{L}.{ext}"
            if os.path.exists(p): shutil.copy(p, f"{OUT}/whisper_{L}.{ext}")
print("exported", sorted(os.listdir(OUT)))
