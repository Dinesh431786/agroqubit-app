"""VM side: upload results to s3://BUCKET/results/ every minute, run job.sh once, upload everything, power off (terminates)."""
import boto3, os, subprocess, threading, time
B = os.environ["BUCKET"]; s3 = boto3.client("s3"); OUT = "/opt/work/out"; seen = {}; PFX = os.environ.get("RESULTS", "results/")
def upload():
    for root, _, files in os.walk(OUT):
        for f in files:
            p = os.path.join(root, f); m = os.path.getmtime(p)
            if seen.get(p) != m:
                try: s3.upload_file(p, B, PFX + os.path.relpath(p, OUT)); seen[p] = m
                except Exception as e: print("upload failed", p, e, flush=True)
def uploader():
    while True: upload(); time.sleep(60)
os.makedirs(OUT, exist_ok=True)
threading.Thread(target=uploader, daemon=True).start()
with open(f"{OUT}/job.log", "w") as log:
    subprocess.run(["bash", "/home/claude/krishi/android/tools/job.sh"], stdout=log, stderr=subprocess.STDOUT)
upload(); time.sleep(5); upload()
subprocess.run(["shutdown", "-h", "now"])
