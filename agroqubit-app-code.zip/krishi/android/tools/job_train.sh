#!/bin/bash
# Version 2 training on one-time VMs. Works with a GPU (CPU=0: g6.xlarge, NVIDIA L4) or with CPUs only (CPU=1), and can be
# split over two VMs that run at the same time:
#   ROLE=main   A  teacher LLM (Gemma 4 26B-A4B, llama.cpp) -> verified facts -> local names -> farmer questions
#               B  fact-token model || photo model on Indian field photos
#               C  closed-world clips for the new sentences (human teacher voices)
#               D  app assets (+ the voice VM's models and ASR test clips) -> S3
#   ROLE=voice  V  Whisper candidates -> short-mode fine-tune -> phone export; our own voice model (acoustic + vocoder);
#                  ASR test clips -> S3, then a "voice_done" marker the main VM waits for
#   ROLE=all    everything on one VM (the original GPU plan)
# Resumable on a new VM (main): the teacher cache and every finished stage are kept in S3 (state/), so a spot
# interruption costs only the stage in progress.
# Env: BUCKET, RES (S3 prefix of this VM), PREV_APK (s3 key of the previous APK: existing clips), ROLE, CPU,
#      VOICE_RES (main: the voice VM's prefix), TARGET_TOTAL, TEACHER_FLAGS
set -x
export K=/home/claude/krishi OUTD=/opt/work/out W=/opt/work HOME=${HOME:-/root}
export PATH=/opt/venv/bin:$PATH PY=/opt/venv/bin/python3 TTS_MODELS=/home/claude/tts_models HF_HUB_ENABLE_HF_TRANSFER=1
export ROLE=${ROLE:-all} CPU=${CPU:-0} AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION:-ap-south-1}
NPROC=$(nproc); NCORE=$(lscpu -p=core 2>/dev/null | grep -v '^#' | sort -u | wc -l); [ "${NCORE:-0}" -gt 0 ] || NCORE=$NPROC
mkdir -p $OUTD $W
is_main() { [ "$ROLE" = all ] || [ "$ROLE" = main ]; }
is_voice() { [ "$ROLE" = all ] || [ "$ROLE" = voice ]; }
# AWS CLI for S3 (the Deep Learning AMI has it; plain Ubuntu does not): official v2 installer, no apt needed
command -v aws > /dev/null || ( cd /tmp && curl -sSL --retry 5 -o awscliv2.zip https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip \
  && python3 -c "import zipfile; zipfile.ZipFile('awscliv2.zip').extractall('.')" && chmod -R +x aws && ./aws/install > /dev/null )
step() { echo "$(date -u '+%F %T') [$ROLE] $*" | tee -a $OUTD/progress.txt; aws s3 cp $OUTD/progress.txt s3://$BUCKET/$RES/progress.txt --quiet || true; }
done_() { [ -f $W/.done_$1 ]; }
mark() { touch $W/.done_$1; step "stage $1 done"; }
put() { aws s3 cp "$1" s3://$BUCKET/$RES/$(basename $1) --quiet && step "uploaded $(basename $1) ($(du -h $1 | cut -f1))"; }
s3has() { aws s3 ls "s3://$BUCKET/$1" > /dev/null 2>&1; }
save_state() { aws s3 cp "$1" "s3://$BUCKET/$RES/state/$(basename $1)" --quiet; }     # a finished stage, for a resume on a new VM
get_state() { aws s3 cp "s3://$BUCKET/$RES/state/$1" "/tmp/$1" --quiet 2>/dev/null; }
shutdown -h +${CAP_MIN:-2100} "safety stop"           # hard cap on cost; a normal end shuts down much earlier
step "start: cpu=$CPU, $NPROC vCPU / $NCORE cores, $(free -g | awk '/Mem/{print $2}') GB RAM, disk $(df -h / | tail -1 | awk '{print $4}') free; $(nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader 2>/dev/null)"

# ---------------------------------------------------------------- 0. system + one Python env for every stage
if ! done_ setup; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -q > $OUTD/apt.log 2>&1
  apt-get install -y -q python3-venv python3-pip python3-dev poppler-utils ffmpeg libsndfile1 openjdk-17-jdk-headless unzip zip jq git cmake \
    build-essential libcurl4-openssl-dev libgomp1 >> $OUTD/apt.log 2>&1
  [ -x /opt/venv/bin/python3 ] || python3 -m venv /opt/venv
  pip install -q --upgrade pip > $OUTD/pip.log 2>&1
  if [ "$CPU" = 1 ]; then
    pip install -q torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu >> $OUTD/pip.log 2>&1   # torchvision too: timm needs it
  else
    pip install -q torch torchvision torchaudio >> $OUTD/pip.log 2>&1
    # the default wheel may need a newer NVIDIA driver than the AMI has: then take a CUDA 12.x build that matches the driver
    python3 -c "import torch; assert torch.cuda.is_available()" 2>> $OUTD/pip.log || for IDX in cu128 cu126 cu130; do
      pip install -q --force-reinstall torch torchvision torchaudio --index-url https://download.pytorch.org/whl/$IDX >> $OUTD/pip.log 2>&1 \
        && python3 -c "import torch; assert torch.cuda.is_available()" 2>> $OUTD/pip.log && { step "torch from $IDX"; break; }
    done
  fi
  pip freeze | grep -iE "^(torch|torchvision|torchaudio)==" > /opt/torch_pin.txt     # keep this torch build: later packages must not replace it
  pip install -q -c /opt/torch_pin.txt "transformers==4.57.6" numba soundfile scipy librosa numpy pandas pyarrow editdistance hf_transfer \
     indic_transliteration aiohttp pdfplumber beautifulsoup4 lxml boto3 "datasets<5" "huggingface_hub<1.0" onnx onnxruntime "timm==1.0.30" \
     indic-numtowords >> $OUTD/pip.log 2>&1 || step "pip (core) failed: see pip.log"
  pip install -q -c /opt/torch_pin.txt "coqui-tts==0.27.5" torchcodec >> $OUTD/pip.log 2>&1 || step "pip (teacher voice) failed: see pip.log"
  [ -f $K/facts/requirements.txt ] && pip install -q -c /opt/torch_pin.txt -r $K/facts/requirements.txt >> $OUTD/pip.log 2>&1
  python3 -c "import torch, transformers, TTS; print('torch', torch.__version__, 'cuda', torch.cuda.is_available(), 'threads', torch.get_num_threads())" >> $OUTD/progress.txt 2>&1 \
    || step "FAILED: python environment (see pip.log)"
  [ "$CPU" = 1 ] || python3 -c "import torch; assert torch.cuda.is_available()" || step "FAILED: CUDA torch"
  mark setup
fi
teacher_voices() {      # AI4Bharat Indic-TTS checkpoints (MIT): clips (main) and the voice model's corpus (voice)
  mkdir -p $TTS_MODELS && cd $TTS_MODELS && for L in hi ta kn en; do [ -f $L/fastpitch/best_model.pth ] || { curl -sSL --retry 5 -o $L.zip \
    https://github.com/AI4Bharat/Indic-TTS/releases/download/v1-checkpoints-release/$L.zip && unzip -q -o $L.zip && rm $L.zip; }; done
  python3 - <<'PY'
import glob, re
for f in glob.glob("/home/claude/tts_models/*/fastpitch/config.json"):
    d = f.rsplit("/", 1)[0]; s = open(f).read()
    s = re.sub(r'"speakers_file": *"[^"]*"', f'"speakers_file": "{d}/speakers.pth"', s); open(f, "w").write(s)
PY
  cd $K; step "teacher voices ready: $(ls $TTS_MODELS | tr '\n' ' ')"
}

# ---------------------------------------------------------------- teacher LLM server
LLM_REPO=unsloth/gemma-4-26B-A4B-it-GGUF LLM_FILE=gemma-4-26B-A4B-it-UD-Q4_K_M.gguf
LLM_FULL="--jinja -fa on --cache-type-k q8_0 --cache-type-v q8_0 --cache-reuse 256 --reasoning-budget 0"
LLM_MIN="--jinja"            # if a newer / older llama.cpp rejects a flag: plain server (f16 KV cache, so a smaller context)
llm_up() {   # $1 = label, $2 = command that tells if the server process is still alive; waits up to 30 min
  for i in $(seq 1 180); do
    curl -sf http://127.0.0.1:8080/health > /dev/null 2>&1 && { step "llm up ($1)"; return 0; }
    eval "$2" || return 1; sleep 10
  done; return 1
}
start_llm() {
  mkdir -p /opt/models
  [ -f /opt/models/$LLM_FILE ] || python3 -c "from huggingface_hub import hf_hub_download as d; d('$LLM_REPO', '$LLM_FILE', local_dir='/opt/models')" \
    > $OUTD/llm_download.log 2>&1 || step "model download failed (see llm_download.log)"
  step "teacher model: $(du -h /opt/models/$LLM_FILE 2>/dev/null | cut -f1)"
  if [ "$CPU" != 1 ] && command -v docker > /dev/null && docker info > /dev/null 2>&1; then
    for FL in FULL MIN; do
      [ $FL = FULL ] && FLAGS=$LLM_FULL || FLAGS=$LLM_MIN
      for CTX in 65536 49152 32768; do
        [ $FL = MIN ] && [ $CTX -gt 32768 ] && continue
        docker rm -f llm > /dev/null 2>&1
        docker run -d --name llm --gpus all -p 8080:8080 -v /opt/models:/models ghcr.io/ggml-org/llama.cpp:server-cuda \
          -m /models/$LLM_FILE --host 0.0.0.0 --port 8080 -ngl 99 -np 8 -c $CTX $FLAGS > $OUTD/llm_docker.log 2>&1
        if llm_up "docker, ctx $CTX, $FL flags" "docker ps -q -f name=llm | grep -q ."; then
          [ $FL = MIN ] && export TEACHER_FLAGS="${TEACHER_FLAGS:-} --no-think"; return 0
        fi
        docker logs llm > $OUTD/llm_server_${FL}_$CTX.log 2>&1; step "llm ctx $CTX ($FL flags) did not come up"
      done
    done
  fi
  # build llama.cpp from source: CPU (native: AVX-512 / AMX of this machine) or CUDA
  if [ ! -x /opt/llama.cpp/build/bin/llama-server ]; then
    export PATH=/usr/local/cuda/bin:$PATH
    rm -rf /opt/llama.cpp; git clone -q --depth 1 https://github.com/ggml-org/llama.cpp /opt/llama.cpp && cd /opt/llama.cpp \
      && cmake -B build -DCMAKE_BUILD_TYPE=Release $([ "$CPU" = 1 ] && echo "-DGGML_NATIVE=ON" || echo "-DGGML_CUDA=ON") > $OUTD/llm_build.log 2>&1 \
      && cmake --build build -j $NPROC --target llama-server >> $OUTD/llm_build.log 2>&1; cd $K
    step "llama.cpp build: $(ls /opt/llama.cpp/build/bin/llama-server 2>&1 | tail -1)"
  fi
  local DEV="-ngl 99"; [ "$CPU" = 1 ] && DEV="-t $NCORE -tb $NPROC"
  for FL in FULL MIN; do
    [ $FL = FULL ] && FLAGS=$LLM_FULL || FLAGS=$LLM_MIN
    for CTX in 65536 32768; do
      [ $FL = MIN ] && [ $CTX -gt 32768 ] && continue
      pkill -f llama-server; sleep 3
      nohup /opt/llama.cpp/build/bin/llama-server -m /opt/models/$LLM_FILE --host 127.0.0.1 --port 8080 $DEV -np 8 -c $CTX $FLAGS \
        > $OUTD/llm_server_src.log 2>&1 &
      if llm_up "source build, ctx $CTX, $FL flags" "pgrep -f llama-server > /dev/null"; then
        [ $FL = MIN ] && export TEACHER_FLAGS="${TEACHER_FLAGS:-} --no-think"; return 0
      fi
    done
  done
  return 1
}
stop_llm() { docker rm -f llm > /dev/null 2>&1; pkill -f llama-server; sleep 5; step "llm stopped"; }

# ================================================================ ROLE main
if is_main; then
cd $K
# resume on a new VM: finished stages and the teacher cache come back from S3
if ! done_ restored; then
  get_state facts_results.tgz && tar xzf /tmp/facts_results.tgz -C $K && mark facts
  get_state factlm_results.tgz && tar xzf /tmp/factlm_results.tgz -C $K && [ -f $K/factlm/runs/ship/export/factlm.bin ] && mark factlm
  get_state vision_results.tgz && tar xzf /tmp/vision_results.tgz -C /opt && [ -f /opt/v2vis/vision.bin ] && mark vision
  get_state clips.tar && mkdir -p /opt/pack && tar xf /tmp/clips.tar -C /opt && mark clips
  done_ facts || { mkdir -p $K/facts/work && aws s3 sync s3://$BUCKET/$RES/state/facts_work $K/facts/work --only-show-errors; }
  touch $W/.done_restored; step "restore: $(ls $W | tr '\n' ' ') teacher cache $(du -sh $K/facts/work 2>/dev/null | cut -f1)"
fi

if ! done_ facts; then
  python3 factlm/build_seed.py > $OUTD/build_seed.log 2>&1; step "seed tables: $(tail -1 $OUTD/build_seed.log | cut -c1-200)"
  # light CPU work while the teacher runs: Indian field photos (download + 256 px cache), the small text models, teacher voices
  ( mkdir -p /home/claude/weights && [ -f /home/claude/weights/mnv3.pth ] || curl -sSL -o /home/claude/weights/mnv3.pth \
      https://github.com/huggingface/pytorch-image-models/releases/download/v0.1-weights/mobilenetv3_large_100_ra-f55367f5.pth
    python3 $K/vision2/build_data.py /opt/v2data --max-per-label ${PHOTOS_PER_LABEL:-3000} > $OUTD/vision_data.log 2>&1
    step "photo data: $(tail -1 $OUTD/vision_data.log | cut -c1-300)" ) &
  PDATA=$!
  ( cd $K/text && for M in AL DL; do OMP_NUM_THREADS=2 python3 train_text2.py $M 0 > $OUTD/train_$M.log 2>&1; done
    cd $K/freechat && OMP_NUM_THREADS=2 python3 train_free.py > $OUTD/train_free.log 2>&1
    step "text models: AL $(grep -o 'single_top1[^,]*' $K/text/res_AL_0.json) DL $(grep -o 'single_top1[^,]*' $K/text/res_DL_0.json)" ) &
  ( teacher_voices ) &
  # the teacher cache goes to S3 every 20 min: a new VM continues where this one stopped
  ( while sleep 1200; do aws s3 sync $K/facts/work s3://$BUCKET/$RES/state/facts_work --only-show-errors; done ) & SYNC=$!
  start_llm || step "FAILED: teacher LLM did not start"
  [ "$CPU" = 1 ] && export TEACHER_FLAGS="${TEACHER_FLAGS:-} --timeout 2400"
  bash facts/run_vm.sh setup > $OUTD/facts_setup.log 2>&1
  bash facts/run_vm.sh check > $OUTD/facts_check.log 2>&1; step "teacher check: $(grep -iE 'tokens/s|tok/s' $OUTD/facts_check.log | tail -2 | tr '\n' ' ' | cut -c1-300)"
  TARGET_TOTAL=${TARGET_TOTAL:-60000} bash facts/run_vm.sh all > $OUTD/facts_all.log 2>&1
  wait $PDATA; bash facts/run_vm.sh names >> $OUTD/facts_all.log 2>&1     # names for photo-model pests too (photo data may finish after the names stage)
  step "facts: $(wc -l < facts/facts.jsonl) facts; questions: $(cat facts/questions/*.jsonl 2>/dev/null | wc -l)"
  kill $SYNC 2>/dev/null; aws s3 sync $K/facts/work s3://$BUCKET/$RES/state/facts_work --only-show-errors
  tar czf $OUTD/facts_results.tgz facts/facts.jsonl facts/target_names.json facts/questions facts/work/review_queue.csv facts/work/stats \
    facts/work/logs facts/work/*report*.json factlm/assets voice/lex_auto.json 2>/dev/null; put $OUTD/facts_results.tgz; save_state $OUTD/facts_results.tgz
  stop_llm
  wait
  mark facts
fi
# a resumed VM rebuilds only what the remaining stages need
done_ vision || [ -f /opt/v2data/meta.json ] || python3 $K/vision2/build_data.py /opt/v2data --max-per-label ${PHOTOS_PER_LABEL:-3000} > $OUTD/vision_data.log 2>&1
done_ clips || [ -f $TTS_MODELS/hi/fastpitch/best_model.pth ] || teacher_voices
[ -f $K/text/enc_AL_0.pt ] || ( cd $K/text && for M in AL DL; do python3 train_text2.py $M 0 > $OUTD/train_$M.log 2>&1; done; cd $K/freechat && python3 train_free.py > $OUTD/train_free.log 2>&1 )
base_assets() {   # models + facts for the phone, the closed-world sentence list, and the previous APK (its clips, pictures, photo model)
  [ -f factlm/runs/ship/export/factlm.bin ] || step "FAILED: no factlm export"
  rm -rf /opt/assets
  FACTLM_DIR=$K/factlm/runs/ship/export FACTS=$K/facts/facts.jsonl python3 android/tools/export_phone.py $K /opt/assets > $OUTD/export_phone.log 2>&1
  (cd voice && python3 closed_world.py /opt/assets $K/voice/segments.json > $OUTD/closed_world.log 2>&1); step "segments: $(tail -1 $OUTD/closed_world.log)"
  mkdir -p /opt/prev && aws s3 cp s3://$BUCKET/$PREV_APK /opt/prev/prev.apk --quiet && (cd /opt/prev && unzip -q -o prev.apk 'assets/voice/*' 'assets/pics/*' 'assets/vision.bin' 'assets/vision.json')
}

# ---------------------------------------------------------------- B. fact-token model || photo model
cd $K
HALF=$(( NPROC / 2 )); [ $HALF -gt 0 ] || HALF=1
if ! done_ factlm; then
  ( THREADS=$HALF bash factlm/vm_train.sh > $OUTD/factlm_train.log 2>&1
    python3 factlm/eval_independent.py factlm/runs/ship/export/factlm.json factlm/runs/ship/export/factlm.bin facts/facts.jsonl \
      factlm/data/test_independent.jsonl factlm/runs/ship/independent.json > factlm/runs/ship/independent.txt 2>&1
    step "factlm independent test: $(python3 -c "import json;r=json.load(open('factlm/runs/ship/independent.json'))['report'];print(r['all'],r['by_lang'])" 2>&1 | cut -c1-400)"
    tar czf $OUTD/factlm_results.tgz factlm/runs/ship/export factlm/runs/ship/*.json factlm/runs/ship/*.txt factlm/runs/eval/*.json factlm/runs/*.txt \
      factlm/runs/*.json factlm/runs/vm_train.log 2>/dev/null; put $OUTD/factlm_results.tgz
    [ -f factlm/runs/ship/export/factlm.bin ] && save_state $OUTD/factlm_results.tgz && mark factlm ) &
  PF=$!
fi
if ! done_ vision; then
  ( OMP_NUM_THREADS=$HALF python3 vision2/train.py /opt/v2data /opt/v2data/student.pt --epochs ${VISION_EPOCHS:-18} --workers 2 > $OUTD/vision_train.log 2>&1 \
      && OMP_NUM_THREADS=$HALF python3 vision2/export_check.py /opt/v2data /opt/v2data/student.pt /opt/v2vis /opt/v2res > $OUTD/vision_check.log 2>&1 \
      && step "photo model: $(tail -1 $OUTD/vision_check.log | cut -c1-600)" \
      || step "photo model FAILED (see vision_train.log / vision_check.log); the previous model is kept"
    tar czf $OUTD/vision_results.tgz -C /opt v2vis v2res v2data/meta.json v2data/report.json 2>/dev/null; put $OUTD/vision_results.tgz
    [ -f /opt/v2vis/vision.bin ] && save_state $OUTD/vision_results.tgz && mark vision ) &
  PVIS=$!
fi
wait $PF 2>/dev/null; wait $PVIS 2>/dev/null

# ---------------------------------------------------------------- C. app assets (models + facts) and the clips for new sentences
if ! done_ clips; then
  base_assets
  for V in f m; do mkdir -p /opt/pack/pack_$V; cp -rn /opt/prev/assets/voice/$V/* /opt/pack/pack_$V/ 2>/dev/null; done
  # all 8 (voice, language) renders at once; each gets its share of the CPUs (GPU: they share the one GPU)
  T8=$(( NPROC / 8 )); [ $T8 -gt 0 ] || T8=1; pids=""
  for V in female male; do for L in hi ta kn en; do
    (cd voice && OMP_NUM_THREADS=$T8 TTS_CUDA=$([ "$CPU" = 1 ] && echo 0 || echo 1) SPEAKER=$V PACK_OUT=/opt/pack/pack_${V:0:1} LANGS=$L BITRATE=16k \
      python3 render_segments.py $K/voice/segments.json > $OUTD/render_${V}_$L.log 2>&1) & pids="$pids $!"
  done; done
  for p in $pids; do wait $p; done
  step "clips: f $(find /opt/pack/pack_f -name '*.ogg' | wc -l), m $(find /opt/pack/pack_m -name '*.ogg' | wc -l)"
  tar cf $OUTD/clips.tar -C /opt pack && save_state $OUTD/clips.tar && rm -f $OUTD/clips.tar
  mark clips
fi
fi   # is_main

# ================================================================ ROLE voice: Whisper, our own voice model, ASR test clips
if is_voice && ! done_ voice; then
  cd $K
  [ -f $TTS_MODELS/hi/fastpitch/best_model.pth ] || teacher_voices
  python3 speech/whisper/select_finetune.py --work /opt/wsp --langs hi,ta,kn,en --stages data > $OUTD/whisper_data.log 2>&1; step "whisper data: $(tail -1 $OUTD/whisper_data.log | cut -c1-200)"
  # texts for the voice model's corpus: app sentences (default) + facts and farmer questions (if this VM has them) + FLEURS transcripts
  mkdir -p /opt/texts /opt/vocab
  python3 - <<'PY'
import json, glob, os, random
random.seed(0); T = {L: [] for L in ["hi", "ta", "kn", "en"]}
if os.path.exists("/home/claude/krishi/facts/facts.jsonl"):
    for l in open("/home/claude/krishi/facts/facts.jsonl", encoding="utf-8"):
        f = json.loads(l)
        for L in T:
            if f["text"].get(L): T[L].append(f["text"][L])
for p in ["/home/claude/krishi/facts/questions/train.jsonl", "/home/claude/krishi/factlm/data/seed_train.jsonl", "/home/claude/krishi/data/free_questions_train.jsonl"]:
    if os.path.exists(p):
        for l in open(p, encoding="utf-8"):
            q = json.loads(l); t = q.get("q") or q.get("text")
            if q.get("lang") in T and q.get("script", "native") == "native" and t: T[q["lang"]].append(t)
for L in T:
    for p in glob.glob(f"/opt/wsp/data/{L}/train.jsonl"):
        for l in open(p, encoding="utf-8"): T[L].append(json.loads(l).get("text", ""))
for L, xs in T.items():
    xs = [x.strip() for x in dict.fromkeys(xs) if x and x.strip()]; random.shuffle(xs)
    open(f"/opt/texts/{L}.txt", "w", encoding="utf-8").write("\n".join(xs) + "\n"); print(L, len(xs))
with open("/opt/vocab/farmer_texts.jsonl", "w", encoding="utf-8") as o:      # the speech recognizer's restricted token set
    for L, xs in T.items():
        for x in xs: o.write(json.dumps({"text": x, "lang": L}, ensure_ascii=False) + "\n")
PY
  step "voice corpus texts: $(wc -l /opt/texts/*.txt | tr '\n' ' ')"
  # Whisper first (all CPUs), then the voice model
  if [ "$CPU" = 1 ]; then WH="--batch 16 --max-steps ${WHISPER_STEPS:-800} --eval-every 200 --eval-limit 300 --dev-limit 200 --eval-batch 16"; else WH="--batch 16"; fi
  python3 speech/whisper/select_finetune.py --work /opt/wsp --langs hi,ta,kn,en --stages eval,finetune,export,javacheck,report $WH \
    --vocab-text data/text_train.jsonl --vocab-text data/free_questions_train.jsonl --vocab-text voice/catalogue.json --vocab-text /opt/vocab/farmer_texts.jsonl \
    > $OUTD/whisper_run.log 2>&1; step "whisper: $(tail -3 $OUTD/whisper_run.log | tr '\n' ' ' | cut -c1-400)"
  tar czf $OUTD/whisper_results.tgz -C /opt/wsp export report.json 2>/dev/null; put $OUTD/whisper_results.tgz
  mkdir -p /opt/kv && touch /opt/kv/.done_setup /opt/kv/.done_teacher           # env + teacher checkpoints are ready (above)
  if [ "$CPU" = 1 ]; then
    VX="AM_PRESET=small VOC_PRESET=small HOURS=${VOICE_HOURS:-1} AM_BUDGET_H=${AM_H:-6} VOC_BUDGET_H=${VOC_H:-6} FT_BUDGET_H=${FT_H:-1} AM_THREADS=$(( NPROC * 3 / 8 )) VOC_THREADS=$(( NPROC * 5 / 8 )) VOC_PRETRAIN=${VOC_PRETRAIN:-1500} VDEV=cpu"
  else
    VX="HOURS=${VOICE_HOURS:-6} AM_BUDGET_H=${AM_H:-5} VOC_BUDGET_H=${VOC_H:-5} FT_BUDGET_H=1"
  fi
  env K=$K W=/opt/kv PY=$PY TEXTS=default,/opt/texts $VX bash voice/student/run_vm.sh > $OUTD/voice_run.log 2>&1
  step "voice: $(tail -2 /opt/kv/progress.txt | tr '\n' ' ' | cut -c1-400)"
  tar czf $OUTD/voice_results.tgz -C /opt/kv out/export out/eval progress.txt logs 2>/dev/null; put $OUTD/voice_results.tgz
  # speech test clips for the phone test: 3 real FLEURS test utterances + 3 teacher-voiced farmer questions per language
  python3 - <<'PY'
import json, os, random, numpy as np, soundfile as sf
random.seed(3); out = "/opt/asr_test"; os.makedirs(out, exist_ok=True); man = []
for L in ["hi", "ta", "kn", "en"]:
    j = f"/opt/wsp/data/{L}/test.jsonl"; a = f"/opt/wsp/data/{L}/test.i16"
    if os.path.exists(j) and os.path.exists(a):
        rows = [json.loads(l) for l in open(j, encoding="utf-8")]; pcm = np.memmap(a, dtype=np.int16, mode="r")
        for r in random.sample([r for r in rows if 32000 < r["n"] < 160000], 3):
            f = f"fleurs_{L}_{r['id']}.wav"; sf.write(f"{out}/{f}", np.asarray(pcm[r["offset"]:r["offset"] + r["n"]]), 16000, subtype="PCM_16")
            man.append({"file": f, "lang": L, "text": r["text"], "kind": "fleurs_real_speech"})
    try:
        import sys; sys.path.insert(0, "/home/claude/krishi/voice")
        from indic_tts import say
        from scipy.signal import resample_poly
        qs = [json.loads(l) for l in open("/home/claude/krishi/factlm/data/test_independent.jsonl", encoding="utf-8")]
        for i, q in enumerate([q for q in qs if q["lang"] == L and q["script"] == "native"][:3]):
            w, sr = say(q["q"], L, "male"); w = resample_poly(np.asarray(w, np.float32), 16000, sr)
            f = f"teacher_{L}_{i}.wav"; sf.write(f"{out}/{f}", (np.clip(w, -1, 1) * 32767).astype(np.int16), 16000, subtype="PCM_16")
            man.append({"file": f, "lang": L, "text": q["q"], "kind": "teacher_voice_question"})
    except Exception as e: print("teacher clips failed", e)
json.dump(man, open(f"{out}/manifest.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1); print(len(man), "asr test clips")
PY
  tar czf $OUTD/asr_test.tgz -C /opt asr_test && put $OUTD/asr_test.tgz
  mark voice
  if [ "$ROLE" = voice ]; then
    cp /opt/kv/progress.txt $OUTD/voice_progress.txt 2>/dev/null; tar czf $OUTD/voice_logs.tgz -C $OUTD --exclude='*.tar' --exclude='*.tgz' . ; put $OUTD/voice_logs.tgz
    echo done > $OUTD/voice_done && put $OUTD/voice_done
    step "FINISHED (voice VM). Shutting down."; sleep 20; shutdown -h now; exit 0
  fi
fi

# ================================================================ D. app assets + clip packs + ASR test clips -> S3 (main)
if is_main; then
  cd $K
  if [ "$ROLE" = main ] && [ -n "$VOICE_RES" ]; then      # the voice VM's models: wait for them (at most WAIT_VOICE_H hours)
    for i in $(seq 1 $(( ${WAIT_VOICE_H:-12} * 12 ))); do s3has "$VOICE_RES/voice_done" && break; [ $i = 1 ] && step "waiting for the voice VM"; sleep 300; done
    for f in voice_results.tgz whisper_results.tgz asr_test.tgz; do aws s3 cp s3://$BUCKET/$VOICE_RES/$f /tmp/$f --quiet || step "missing $VOICE_RES/$f"; done
    mkdir -p /opt/kv /opt/wsp; tar xzf /tmp/voice_results.tgz -C /opt/kv 2>/dev/null; tar xzf /tmp/whisper_results.tgz -C /opt/wsp 2>/dev/null; tar xzf /tmp/asr_test.tgz -C /opt 2>/dev/null
  fi
  [ -f /opt/assets/facts.json ] && [ -f /opt/prev/prev.apk ] || base_assets          # (a resumed VM)
  ASSETS=/opt/assets
  cp /opt/kv/out/export/voice.json /opt/kv/out/export/voice_am.bin /opt/kv/out/export/voice_voc.bin $ASSETS/ 2>/dev/null
  for L in hi ta kn en; do cp /opt/wsp/export/whisper_$L.bin /opt/wsp/export/whisper_$L.json $ASSETS/ 2>/dev/null; done
  if [ -f /opt/v2vis/vision.bin ] && done_ vision; then cp /opt/v2vis/vision.bin /opt/v2vis/vision.json $ASSETS/; mkdir -p /opt/test_photos && cp /opt/v2res/test_photos/* /opt/test_photos/
  else cp /opt/prev/assets/vision.bin /opt/prev/assets/vision.json $ASSETS/ 2>/dev/null; fi
  cp -r /opt/prev/assets/pics $ASSETS/ 2>/dev/null
  mkdir -p $ASSETS/voice && rm -rf $ASSETS/voice/f $ASSETS/voice/m && cp -r /opt/pack/pack_f $ASSETS/voice/f && cp -r /opt/pack/pack_m $ASSETS/voice/m
  cp $K/voice/segments.json $OUTD/segments.json
  mkdir -p /opt/pt && cp $K/text/enc_AL_0.pt $K/text/enc_DL_0.pt $K/freechat/free_intent.pt $K/voice/segments.json /opt/pt/
  step "app assets: $(du -sh $ASSETS | cut -f1); $(ls $ASSETS | tr '\n' ' ' | cut -c1-400)"
  tar cf $OUTD/app_assets.tar -C /opt assets $( [ -d /opt/asr_test ] && echo asr_test ) pt $( [ -d /opt/test_photos ] && echo test_photos ) && put $OUTD/app_assets.tar
  cp /opt/kv/progress.txt /opt/wsp/report.json $OUTD/ 2>/dev/null; tar czf $OUTD/train_logs.tgz -C $OUTD --exclude='*.tar' --exclude='*.tgz' . ; put $OUTD/train_logs.tgz
  echo done > $OUTD/main_done && put $OUTD/main_done
  step "FINISHED (main). Shutting down."
  sleep 20; shutdown -h now
fi
