"""Build the code overlay for the one-time VMs: every file of the repo that is new or changed compared with the code
archives already in the temporary bucket, so only the difference has to be uploaded.

  python3 make_overlay.py manifest <out.json>                 # local path -> sha256[:12] of the files a VM needs
  python3 make_overlay.py build <remote.json> <out.tar.xz>    # remote.json: path -> sha256[:12] already in S3 (paths
                                                              # relative to /home/claude, e.g. krishi/factlm/model.py)
  python3 make_overlay.py since "2026-10-11 16:00" <out.tar.xz>   # every file changed after that time instead
  python3 make_overlay.py chunks <file> <dir> [13600]         # base64 chunks for the upload
Generated files (facts, questions, clips, segments, exports, runs) and large binaries are never included: the VMs
rebuild them."""
import base64, hashlib, json, lzma, os, re, sys, tarfile

HOME = "/home/claude"
ROOTS = ["krishi", "agri_reason/v2"]
SKIP_DIRS = {"__pycache__"}
SKIP_DIR_PATHS = {"krishi/factlm/runs", "krishi/factlm/export", "krishi/factlm/results", "krishi/facts/work", "krishi/facts/questions",
                  "krishi/facts/tests", "krishi/android/build", "krishi/aws_results", "krishi/android/test/appstubs"}
SKIP_EXT = {".pt", ".bin", ".wav", ".opus", ".ogg", ".mp3", ".npz", ".npy", ".onnx", ".png", ".jpg", ".log", ".md", ".pth", ".tar", ".tgz", ".xz", ".zip", ".apk"}
SKIP_NAMES = {"segments.json", "facts.jsonl", "target_names.json", "lex_auto.json", "mock_teacher.py", "seed_facts.jsonl",
              "compile_app.sh", "make_overlay.py", "vm_userdata.sh"}
SKIP_RE = [re.compile(r"^krishi/factlm/data/seed_"), re.compile(r"^krishi/voice/pack_"), re.compile(r"vision_quant_eval.*\.json$")]
MAX_BYTES = 2_000_000


def wanted(rel):
    parts = rel.split("/")
    if any(p in SKIP_DIRS for p in parts[:-1]) or any(rel.startswith(d + "/") for d in SKIP_DIR_PATHS): return False
    name = parts[-1]
    if name in SKIP_NAMES or os.path.splitext(name)[1].lower() in SKIP_EXT: return False
    return not any(r.search(rel) for r in SKIP_RE)


def local_manifest():
    out = {}
    for r in ROOTS:
        for root, dirs, files in os.walk(os.path.join(HOME, r)):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and os.path.relpath(os.path.join(root, d), HOME) not in SKIP_DIR_PATHS]
            for f in files:
                p = os.path.join(root, f); rel = os.path.relpath(p, HOME)
                if wanted(rel) and os.path.getsize(p) <= MAX_BYTES:
                    out[rel] = hashlib.sha256(open(p, "rb").read()).hexdigest()[:12]
    return out


def main():
    cmd = sys.argv[1]
    if cmd == "manifest":
        m = local_manifest(); json.dump(m, open(sys.argv[2], "w"), indent=0, sort_keys=True); print(len(m), "files")
    elif cmd == "build":
        remote = json.load(open(sys.argv[2])); m = local_manifest()
        todo = sorted(p for p, h in m.items() if remote.get(p) != h)
        with lzma.open(sys.argv[3], "wb", preset=9 | lzma.PRESET_EXTREME) as xz, tarfile.open(fileobj=xz, mode="w") as t:
            for p in todo:
                ti = t.gettarinfo(os.path.join(HOME, p), arcname=p); ti.uid = ti.gid = 0; ti.uname = ti.gname = "root"
                with open(os.path.join(HOME, p), "rb") as f: t.addfile(ti, f)
        print(len(todo), "files ->", sys.argv[3], os.path.getsize(sys.argv[3]), "bytes"); print("\n".join(todo))
    elif cmd == "since":            # every wanted file changed after a time (the creation time of the archives already in S3)
        import datetime
        cut = datetime.datetime.strptime(sys.argv[2], "%Y-%m-%d %H:%M").timestamp(); m = local_manifest()
        todo = sorted(p for p in m if os.path.getmtime(os.path.join(HOME, p)) > cut)
        with lzma.open(sys.argv[3], "wb", preset=9 | lzma.PRESET_EXTREME) as xz, tarfile.open(fileobj=xz, mode="w") as t:
            for p in todo:
                ti = t.gettarinfo(os.path.join(HOME, p), arcname=p); ti.uid = ti.gid = 0; ti.uname = ti.gname = "root"
                with open(os.path.join(HOME, p), "rb") as f: t.addfile(ti, f)
        print(len(todo), "files ->", sys.argv[3], os.path.getsize(sys.argv[3]), "bytes")
    elif cmd == "chunks":
        b = base64.b64encode(open(sys.argv[2], "rb").read()).decode(); n = int(sys.argv[4]) if len(sys.argv) > 4 else 13600
        os.makedirs(sys.argv[3], exist_ok=True)
        parts = [b[i:i + n] for i in range(0, len(b), n)]
        for i, s in enumerate(parts): open(os.path.join(sys.argv[3], f"part_{i:03d}.b64"), "w").write(s)
        print(len(parts), "chunks of", n, "chars; sha256", hashlib.sha256(open(sys.argv[2], "rb").read()).hexdigest())


if __name__ == "__main__":
    main()
