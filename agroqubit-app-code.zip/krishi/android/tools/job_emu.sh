#!/bin/bash
# CPU VM with nested virtualisation (c8i.2xlarge): build the APK from the GPU job's app assets and test it on a 2 GB
# Android 11 emulator (full) and Android 7 (smoke): Java == Python parity with the trained fact-token model, farmers'
# free questions, our own voice model on the phone (real-time factor), our offline speech recognizer on real speech.
# Env: BUCKET, RES (results prefix), GPU_RES (GPU job prefix with app_assets.tar), PHOTOS_KEY (s3 key of test_photos.tar)
set -x
export K=/home/claude/krishi OUTD=/opt/work/out SDK=/opt/android-sdk
export ANDROID_SDK_ROOT=$SDK ANDROID_HOME=$SDK ANDROID_AVD_HOME=/opt/avd PATH=$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:$SDK/emulator:$PATH
mkdir -p $OUTD /opt/avd
export AWS_DEFAULT_REGION=${AWS_DEFAULT_REGION:-ap-south-1}
# AWS CLI for the S3 uploads (the Deep Learning AMI has it; plain Ubuntu does not): official v2 installer, no apt needed
command -v aws > /dev/null || ( cd /tmp && curl -sSL --retry 5 -o awscliv2.zip https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip \
  && python3 -c "import zipfile; zipfile.ZipFile('awscliv2.zip').extractall('.')" && chmod -R +x aws && ./aws/install > /dev/null )
step() { echo "$(date -u '+%F %T') $*" | tee -a $OUTD/progress.txt; aws s3 cp $OUTD/progress.txt s3://$BUCKET/$RES/progress.txt --quiet || true; }
put() { aws s3 cp "$1" s3://$BUCKET/$RES/$(basename $1) --quiet && step "uploaded $(basename $1) ($(du -h $1 | cut -f1))"; }
waitfor() { for i in $(seq 1 ${2:-360}); do grep -q "$1" $OUTD/progress.txt && return 0; sleep 10; done; return 1; }
shutdown -h +300 "safety stop after 5 h"
step "start; $(nproc) vCPU; $(cat /proc/cpuinfo | grep -c vmx) vmx"
export DEBIAN_FRONTEND=noninteractive; apt-get update -q > $OUTD/apt.log 2>&1
apt-get install -y -q openjdk-17-jdk-headless unzip zip git python3-venv python3-pip libpulse0 libgl1 libnss3 ffmpeg \
  libxcomposite1 libxcursor1 libxi6 libxtst6 libxdamage1 libxrandr2 libasound2t64 libxkbfile1 libbsd0 cpu-checker >> $OUTD/apt.log 2>&1
step "apt done; $(kvm-ok 2>&1 | tail -1)"
( mkdir -p $SDK/cmdline-tools && cd /tmp && curl -sSL -o clt.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip \
  && unzip -q clt.zip -d $SDK/cmdline-tools && mv $SDK/cmdline-tools/cmdline-tools $SDK/cmdline-tools/latest \
  && yes | sdkmanager --licenses > /dev/null \
  && sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" "emulator" "system-images;android-30;google_apis;x86_64" \
  && step sdk_done && sdkmanager "system-images;android-24;default;x86_64" && step sdk_old_done ) > $OUTD/sdk.log 2>&1 &
python3 -m venv /opt/venv && . /opt/venv/bin/activate
pip install -q --upgrade pip; pip install -q torch --index-url https://download.pytorch.org/whl/cpu > $OUTD/pip.log 2>&1
pip install -q numpy scipy pillow boto3 indic_transliteration soundfile >> $OUTD/pip.log 2>&1
step pip_done

# ---------- assets from the GPU job (models, facts, clips, vision, pics) + the exact text models in the APK
aws s3 cp s3://$BUCKET/$GPU_RES/app_assets.tar /opt/app_assets.tar --quiet && tar xf /opt/app_assets.tar -C /opt   # -> /opt/assets, /opt/asr_test, /opt/pt
cp /opt/pt/enc_AL_0.pt /opt/pt/enc_DL_0.pt $K/text/ && cp /opt/pt/free_intent.pt $K/freechat/ && cp /opt/pt/segments.json $K/voice/segments.json
mkdir -p $OUTD/test_photos
if [ -d /opt/test_photos ]; then cp /opt/test_photos/* $OUTD/test_photos/      # field-photo model: test photos of all four crops from the GPU job
else aws s3 cp s3://$BUCKET/$PHOTOS_KEY /opt/test_photos.tar --quiet && tar xf /opt/test_photos.tar -C $OUTD/test_photos --strip-components=1; fi
step "assets: $(du -sh /opt/assets | cut -f1); clips f $(find /opt/assets/voice/f -name '*.ogg' | wc -l) m $(find /opt/assets/voice/m -name '*.ogg' | wc -l); photos $(ls $OUTD/test_photos | wc -l); asr clips $(ls /opt/asr_test/*.wav 2>/dev/null | wc -l)"
export KRISHI_FACTLM=/opt/assets

# ---------- Java == Python on the trained models (300 conversations, voice coverage)
python3 $K/android/tools/make_parity.py $K /opt/parity.json 300 > $OUTD/parity_py.log 2>&1
mkdir -p /opt/jb && javac -nowarn -encoding UTF-8 -d /opt/jb $(find $K/android/src -name "*.java") $K/android/test/*.java $K/android/test/in/krishi/doctor/*.java > $OUTD/javac_core.log 2>&1
java -Xmx1g -cp /opt/jb ChatParity /opt/assets /opt/parity.json $K/voice/segments.json > $OUTD/java_parity.txt 2>&1
step "java parity: $(tail -4 $OUTD/java_parity.txt | tr '\n' ' ')"
java -Xmx1g -cp /opt/jb PhotoTurn /opt/assets $OUTD/test_photos > $OUTD/photo_turn.txt 2>&1; step "photo turn (JVM): $(tail -2 $OUTD/photo_turn.txt | tr '\n' ' ')"

# ---------- APKs: all languages, plus one per language (that language's clips + speech model; others spoken by our voice model)
waitfor sdk_done 240
bash $K/android/tools/build_apk.sh $K/android /opt/assets $OUTD/krishi-doctor.apk > $OUTD/build.log 2>&1; step "apk: $(ls -la $OUTD/krishi-doctor.apk 2>&1)"
for L in hi ta kn en; do
  A=/opt/assets_$L; rm -rf $A; mkdir -p $A/voice/f $A/voice/m
  for f in /opt/assets/*; do b=$(basename $f); case $b in voice|whisper_*) ;; *) cp -al $f $A/$b ;; esac; done
  cp -r /opt/assets/voice/f/$L $A/voice/f/ && cp -r /opt/assets/voice/m/$L $A/voice/m/
  cp /opt/assets/whisper_$L.* $A/ 2>/dev/null
  bash $K/android/tools/build_apk.sh $K/android $A $OUTD/krishi-doctor-$L.apk > $OUTD/build_$L.log 2>&1
done
step "language apks: $(ls -la $OUTD/krishi-doctor-*.apk | awk '{print $5, $9}' | tr '\n' ' ')"
put $OUTD/krishi-doctor.apk; for L in hi ta kn en; do put $OUTD/krishi-doctor-$L.apk; done

# ---------- Android 11, 2 GB
echo no | avdmanager create avd -n k30 -k "system-images;android-30;google_apis;x86_64" -d pixel_4 --force > $OUTD/avd.log 2>&1
printf "hw.ramSize=2048\nhw.keyboard=no\ndisk.dataPartition.size=6G\nhw.audioOutput=yes\n" >> /opt/avd/k30.avd/config.ini
QEMU_AUDIO_DRV=none nohup emulator -avd k30 -no-window -no-snapshot -no-boot-anim -gpu swiftshader_indirect -memory 2048 -cores 2 -accel on > $OUTD/emulator.log 2>&1 &
timeout 900 adb wait-for-device; for i in $(seq 1 120); do [ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ] && break; sleep 5; done
step "emulator booted: $(adb shell getprop ro.build.version.release | tr -d '\r') api $(adb shell getprop ro.build.version.sdk | tr -d '\r')"
for s in window_animation_scale transition_animation_scale animator_duration_scale; do adb shell settings put global $s 0; done
adb install -r $OUTD/krishi-doctor.apk > $OUTD/install.log 2>&1; step "install: $(tail -1 $OUTD/install.log)"
mkdir -p $OUTD/emu30 && APK=$OUTD/krishi-doctor.apk SEGMENTS=$K/voice/segments.json PHOTOS=$OUTD/test_photos ASR_DIR=/opt/asr_test \
  timeout 5400 python3 $K/android/tools/emu_test.py $K $OUTD/emu30 > $OUTD/emu30.log 2>&1
step "emulator test (Android 11, 2GB): $(tail -1 $OUTD/emu30.log | cut -c1-1500)"
tar czf $OUTD/emu30.tgz -C $OUTD emu30 emu30.log java_parity.txt parity_py.log; put $OUTD/emu30.tgz

# ---------- Android 7 (API 24) smoke with the Hindi APK
adb emu kill; sleep 8; waitfor sdk_old_done 120
echo no | avdmanager create avd -n k24 -k "system-images;android-24;default;x86_64" -d pixel --force >> $OUTD/avd.log 2>&1
printf "hw.ramSize=2048\nhw.keyboard=no\ndisk.dataPartition.size=4G\n" >> /opt/avd/k24.avd/config.ini
QEMU_AUDIO_DRV=none nohup emulator -avd k24 -no-window -no-snapshot -no-boot-anim -gpu swiftshader_indirect -memory 2048 -cores 2 -accel on > $OUTD/emulator24.log 2>&1 &
timeout 900 adb wait-for-device; for i in $(seq 1 120); do [ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ] && break; sleep 5; done
for i in $(seq 1 30); do adb shell pm path android > /dev/null 2>&1 && break; sleep 5; done; sleep 20
timeout 600 adb install --no-streaming -r $OUTD/krishi-doctor-hi.apk > $OUTD/install24.log 2>&1 || timeout 600 adb install -r $OUTD/krishi-doctor-hi.apk >> $OUTD/install24.log 2>&1
step "install android 7: $(tail -1 $OUTD/install24.log)"
mkdir -p $OUTD/emu24 && SMOKE=1 APK=$OUTD/krishi-doctor-hi.apk SEGMENTS=$K/voice/segments.json PHOTOS=$OUTD/test_photos ASR_DIR=/opt/asr_test \
  timeout 2400 python3 $K/android/tools/emu_test.py $K $OUTD/emu24 > $OUTD/emu24.log 2>&1
step "android 7 smoke: $(tail -1 $OUTD/emu24.log | cut -c1-900)"
tar czf $OUTD/emu24.tgz -C $OUTD emu24 emu24.log; put $OUTD/emu24.tgz
step "FINISHED (emulator job)"; sleep 20; shutdown -h now
