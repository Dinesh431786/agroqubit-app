"""Photo model for the phone, with no ML runtime: the ONNX fingerprint net becomes a tiny op list + one weights file.
  vision.json : op list (conv / hardswish / relu / hardsigmoid / add / mean / mul / gap / gemm / l2norm / affine),
                fingerprint labels, mapping to the app's diseases, the 'not sure' threshold
  vision.bin  : KRW1 tensors; conv + gemm weights int8 per output channel (+ fp32 scale; MSE-searched clipping),
                depthwise + stem convs fp16, biases + fingerprints fp32. 4.6 MB; PlantDoc known top-1 unchanged vs fp32
Fingerprints: several per disease (k-means sub-centroids of training photos: early/late stage, different backgrounds);
a photo's score for a disease is its best match. Usage: python3 export_vision.py <model.onnx> <protos.npz> <out_dir> [int8|fp32]"""
import json, os, struct, sys, numpy as np, onnx
from onnx import numpy_helper

APP = {"Tomato Early blight leaf": "tomato_early_blight", "Tomato Septoria leaf spot": "tomato_septoria_leaf_spot",
       "Tomato leaf bacterial spot": "tomato_bacterial_leaf_spot", "Tomato leaf yellow virus": "tomato_leaf_curl",
       "Tomato leaf mosaic virus": "tomato_mosaic", "Tomato leaf late blight": "tomato_late_blight",
       "Tomato mold leaf": "tomato_leaf_mold", "Tomato leaf": "tomato_healthy"}
NOT_SURE = 0.586        # calibrated on PlantDoc val in agri_vision (answers ~78% of known photos)


def quant_rows(w):
    """int8 per output channel; the clipping range per row is searched (50-100% of max|w|) to minimise squared error."""
    W = w.reshape(w.shape[0], -1).astype(np.float32); bq = bs = be = None
    for r in np.linspace(0.5, 1.0, 21):
        sc = np.abs(W).max(1, keepdims=True) * r / 127 + 1e-12; q = np.clip(np.round(W / sc), -127, 127)
        err = ((W - q * sc) ** 2).sum(1, keepdims=True)
        if bq is None: bq, bs, be = q, sc, err
        else: m = err < be; bq = np.where(m, q, bq); bs = np.where(m, sc, bs); be = np.where(m, err, be)
    return bq.astype(np.int8), bs.astype(np.float32)


def write_krw1(path, tensors):
    with open(path, "wb") as f:
        f.write(b"KRW1"); f.write(struct.pack(">i", len(tensors)))
        for name, (kind, v) in tensors.items():
            nb = name.encode(); f.write(struct.pack(">h", len(nb))); f.write(nb)
            if kind == "f16":
                v = np.asarray(v, np.float16); f.write(struct.pack(">bi", 2, v.ndim)); f.write(struct.pack(f">{v.ndim}i", *v.shape)); f.write(v.astype(">f2").tobytes())
            elif kind == "q8":
                q, sc = v; f.write(struct.pack(">bi", 1, 2)); f.write(struct.pack(">ii", *q.shape)); f.write(q.tobytes()); f.write(sc.astype(">f4").tobytes())
            else:
                v = np.asarray(v, np.float32); f.write(struct.pack(">bi", 0, v.ndim)); f.write(struct.pack(f">{v.ndim}i", *v.shape)); f.write(v.astype(">f4").tobytes())


def convert(src, mode="int8"):
    m = onnx.load(src); g = m.graph
    init = {i.name: numpy_helper.to_array(i) for i in g.initializer}
    prog, tensors, deq = [], {}, {}
    l2_src = None
    for n in g.node:
        a = {x.name: onnx.helper.get_attribute_value(x) for x in n.attribute}; I, O, t = list(n.input), list(n.output), n.op_type
        if t in ("Constant", "Shape", "Expand", "Clip"): continue           # parts of the final L2 normalisation
        if t == "Sub" and I[1] in init:
            prog.append({"op": "affine", "in": I[0], "out": O[0], "scale": [1.0] * 3, "shift": (-init[I[1]].reshape(-1)).tolist()})
        elif t == "Div" and I[1] in init:
            prog.append({"op": "affine", "in": I[0], "out": O[0], "scale": (1.0 / init[I[1]].reshape(-1)).tolist(), "shift": [0.0] * 3})
        elif t == "Div":                                                       # x / expand(clip(reduceL2(x)))
            prog.append({"op": "l2norm", "in": l2_src, "out": O[0]})
        elif t == "ReduceL2":
            l2_src = I[0]
        elif t == "Conv":
            W = init[I[1]]; B = init[I[2]] if len(I) > 2 else np.zeros(W.shape[0], np.float32)
            assert a.get("dilations", [1, 1]) == [1, 1] and a["kernel_shape"][0] == a["kernel_shape"][1]
            p = a.get("pads", [0, 0, 0, 0]); assert p[0] == p[1] == p[2] == p[3]
            wn = f"w{len(tensors)}"; bn = f"b{len(tensors)}"
            if mode == "int8" and (a.get("group", 1) > 1 or W.shape[1] == 3):    # depthwise + stem: fp16 (int8 hurts them, they are tiny)
                tensors[wn] = ("f16", W.reshape(W.shape[0], -1)); deq[I[1]] = W.astype(np.float16).astype(np.float32)
            elif mode == "int8":
                q, sc = quant_rows(W); tensors[wn] = ("q8", (q, sc)); deq[I[1]] = (q.astype(np.float32) * sc).reshape(W.shape)
            else:
                tensors[wn] = ("f32", W.reshape(W.shape[0], -1)); deq[I[1]] = W
            tensors[bn] = ("f32", B)
            prog.append({"op": "conv", "in": I[0], "out": O[0], "w": wn, "b": bn, "cout": int(W.shape[0]), "cin": int(W.shape[1] * a.get("group", 1)),
                         "k": int(a["kernel_shape"][0]), "stride": int(a["strides"][0]), "pad": int(p[0]), "group": int(a.get("group", 1))})
        elif t == "Gemm":
            assert a.get("transB", 0) == 1
            W = init[I[1]]; B = init[I[2]]; wn = f"w{len(tensors)}"; bn = f"b{len(tensors)}"
            if mode == "int8":
                q, sc = quant_rows(W); tensors[wn] = ("q8", (q, sc)); deq[I[1]] = q.astype(np.float32) * sc
            else:
                tensors[wn] = ("f32", W); deq[I[1]] = W
            tensors[bn] = ("f32", B)
            prog.append({"op": "gemm", "in": I[0], "out": O[0], "w": wn, "b": bn, "cout": int(W.shape[0]), "cin": int(W.shape[1])})
        elif t == "HardSwish": prog.append({"op": "hswish", "in": I[0], "out": O[0]})
        elif t == "Relu": prog.append({"op": "relu", "in": I[0], "out": O[0]})
        elif t == "HardSigmoid": prog.append({"op": "hsig", "in": I[0], "out": O[0], "alpha": float(a.get("alpha", 0.2)), "beta": float(a.get("beta", 0.5))})
        elif t == "Add": prog.append({"op": "add", "in": I[0], "in2": I[1], "out": O[0]})
        elif t == "Mul": prog.append({"op": "mul", "in": I[0], "in2": I[1], "out": O[0]})
        elif t == "ReduceMean":
            assert list(a["axes"]) in ([2, 3], [-2, -1]) and a.get("keepdims", 1) == 1, a
            prog.append({"op": "gap", "in": I[0], "out": O[0]})
        elif t == "GlobalAveragePool": prog.append({"op": "gap", "in": I[0], "out": O[0]})
        elif t == "Flatten": prog.append({"op": "alias", "in": I[0], "out": O[0]})
        else: raise SystemExit(f"unsupported op {t}")
    return m, prog, tensors, deq


if __name__ == "__main__":
    # protos.npz: P [n, 256] unit fingerprints (several per disease), cls [n] class index, names [classes]
    src, protos, out = sys.argv[1:4]; mode = sys.argv[4] if len(sys.argv) > 4 else "int8"
    MAP = json.load(open(sys.argv[5])) if len(sys.argv) > 5 else {"app": APP}     # vision2: label -> app disease + label meta
    os.makedirs(out, exist_ok=True)
    m, prog, tensors, deq = convert(src, mode)
    z = np.load(protos, allow_pickle=True); P = z["P"].astype(np.float32); P /= np.linalg.norm(P, axis=1, keepdims=True)
    names = [str(n) for n in z["names"]]; cls = [int(c) for c in z["cls"]]
    tensors["fingerprints"] = ("f32", P)
    write_krw1(f"{out}/vision.bin", tensors)
    json.dump({"input": m.graph.input[0].name, "output": m.graph.output[0].name, "size": 224, "resize": 256, "tta_flip": False,
               "not_sure": NOT_SURE, "labels": names, "proto_class": cls, "app": MAP["app"], "meta": MAP.get("meta"), "prog": prog, "weights": mode},
              open(f"{out}/vision.json", "w"), ensure_ascii=False)
    print("ops", len(prog), "tensors", len(tensors), "fingerprints", len(P), "bin MB", round(os.path.getsize(f"{out}/vision.bin") / 1e6, 2))
