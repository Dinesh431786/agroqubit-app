#!/bin/bash
# Quick rebuild + retest on one VM (about 45 min): reuses the voice clips and the photo model from a previous full build
# (job.sh) by unpacking that build's APK, retrains only the small text models (deterministic, 3 min), rebuilds the APK
# from the current code and runs the same emulator tests (2 GB Android 11 + Android 7).
# Needs: PREV_APK (path to the previous build's APK), PREV_PHOTOS (its test_photos folder with reference.json).
set -x
export K=/home/claude/krishi OUTD=/opt/work/out SDK=/opt/android-sdk
export ANDROID_SDK_ROOT=$SDK ANDROID_HOME=$SDK ANDROID_AVD_HOME=/opt/avd PATH=$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:$SDK/emulator:$PATH
mkdir -p $OUTD /opt/avd
step() { echo "$(date -u +%H:%M:%S) $*" | tee -a $OUTD/progress.txt; }
waitfor() { for i in $(seq 1 ${2:-360}); do grep -q "$1" $OUTD/progress.txt && return 0; sleep 10; done; return 1; }
step start; nproc; free -g; ls -la /dev/kvm
apt-get install -y openjdk-17-jdk-headless unzip zip git python3-venv python3-pip libpulse0 libgl1 libnss3 \
  libxcomposite1 libxcursor1 libxi6 libxtst6 libxdamage1 libxrandr2 libasound2t64 libxkbfile1 libbsd0 cpu-checker > $OUTD/apt.log 2>&1
kvm-ok > $OUTD/kvm.txt 2>&1; step "apt done; $(cat $OUTD/kvm.txt | tail -1)"
( mkdir -p $SDK/cmdline-tools && cd /tmp && curl -sSL -o clt.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip \
  && unzip -q clt.zip -d $SDK/cmdline-tools && mv $SDK/cmdline-tools/cmdline-tools $SDK/cmdline-tools/latest \
  && yes | sdkmanager --licenses > /dev/null \
  && sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" "emulator" "system-images;android-30;google_apis;x86_64" \
  && step sdk_done && sdkmanager "system-images;android-24;default;x86_64" && step sdk_old_done ) > $OUTD/sdk.log 2>&1 &
python3 -m venv /opt/venv && . /opt/venv/bin/activate
pip install -q --upgrade pip
pip install -q torch --index-url https://download.pytorch.org/whl/cpu > $OUTD/pip.log 2>&1
pip install -q numpy scipy pillow boto3 indic_transliteration >> $OUTD/pip.log 2>&1
step pip_done

# ---------- text models (same scripts, same seeds -> same models), assets, parity (+ voice coverage)
cd $K/text; for M in AL DL; do OMP_NUM_THREADS=8 python3 train_text2.py $M 0 > $OUTD/train_$M.log 2>&1; done
step "text models trained: AL $(grep -o 'single_top1[^,]*' res_AL_0.json) DL $(grep -o 'single_top1[^,]*' res_DL_0.json)"
cd $K/freechat && OMP_NUM_THREADS=8 python3 train_free.py > $OUTD/train_free.log 2>&1 && python3 eval_freechat.py > $OUTD/eval_free.txt 2>&1; cp results_freechat.json $OUTD/ 2>/dev/null
ASSETS=/opt/assets; rm -rf $ASSETS; python3 $K/android/tools/export_phone.py $K $ASSETS > $OUTD/export.log 2>&1
mkdir -p /opt/prev && cd /opt/prev && unzip -q -o $PREV_APK 'assets/voice/*' 'assets/pics/*' 'assets/vision.bin' 'assets/vision.json'
cp -r /opt/prev/assets/voice /opt/prev/assets/pics /opt/prev/assets/vision.bin /opt/prev/assets/vision.json $ASSETS/
step "reused from previous build: $(find $ASSETS/voice -name '*.ogg' | wc -l) clips, $(ls -la $ASSETS/vision.bin | awk '{print $5}') B photo model"
cd $K/voice && python3 closed_world.py $ASSETS $K/voice/segments.json > $OUTD/closed_world.log 2>&1; cp $K/voice/segments.json $OUTD/
python3 $K/android/tools/make_parity.py $K /opt/parity.json 300 > $OUTD/parity_py.log 2>&1
mkdir -p /opt/jb && javac -nowarn -encoding UTF-8 -d /opt/jb $(find $K/android/src $K/android/test -name "*.java") > $OUTD/javac_core.log 2>&1
java -Xmx1g -cp /opt/jb ChatParity $ASSETS /opt/parity.json $K/voice/segments.json > $OUTD/java_parity.txt 2>&1; step "java parity: $(tail -3 $OUTD/java_parity.txt | tr '\n' ' ')"
mkdir -p $OUTD/test_photos && cp $PREV_PHOTOS/* $OUTD/test_photos/

# ---------- build, Android 11 (2 GB) test
waitfor sdk_done 240
bash $K/android/tools/build_apk.sh $K/android $ASSETS $OUTD/krishi-doctor.apk > $OUTD/build.log 2>&1; step "apk: $(ls -la $OUTD/krishi-doctor.apk 2>&1)"
echo no | avdmanager create avd -n k30 -k "system-images;android-30;google_apis;x86_64" -d pixel_4 --force > $OUTD/avd.log 2>&1
printf "hw.ramSize=2048\nhw.keyboard=no\ndisk.dataPartition.size=3G\nhw.audioOutput=yes\n" >> /opt/avd/k30.avd/config.ini
QEMU_AUDIO_DRV=none nohup emulator -avd k30 -no-window -no-snapshot -no-boot-anim -gpu swiftshader_indirect -memory 2048 -cores 2 -accel on > $OUTD/emulator.log 2>&1 &
timeout 900 adb wait-for-device; for i in $(seq 1 120); do [ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ] && break; sleep 5; done
step "emulator booted: $(adb shell getprop ro.build.version.release | tr -d '\r') api $(adb shell getprop ro.build.version.sdk | tr -d '\r')"
for s in window_animation_scale transition_animation_scale animator_duration_scale; do adb shell settings put global $s 0; done
adb install -r $OUTD/krishi-doctor.apk > $OUTD/install.log 2>&1; step "install: $(tail -1 $OUTD/install.log)"
mkdir -p $OUTD/emu30 && APK=$OUTD/krishi-doctor.apk SEGMENTS=$K/voice/segments.json PHOTOS=$OUTD/test_photos timeout 3600 python3 $K/android/tools/emu_test.py $K $OUTD/emu30 > $OUTD/emu30.log 2>&1
step "emulator test (Android 11, 2GB): $(tail -1 $OUTD/emu30.log | cut -c1-900)"

# ---------- Android 7 (API 24)
adb emu kill; sleep 8; waitfor sdk_old_done 120
echo no | avdmanager create avd -n k24 -k "system-images;android-24;default;x86_64" -d pixel --force >> $OUTD/avd.log 2>&1
printf "hw.ramSize=2048\nhw.keyboard=no\n" >> /opt/avd/k24.avd/config.ini
QEMU_AUDIO_DRV=none nohup emulator -avd k24 -no-window -no-snapshot -no-boot-anim -gpu swiftshader_indirect -memory 2048 -cores 2 -accel on > $OUTD/emulator24.log 2>&1 &
timeout 900 adb wait-for-device; for i in $(seq 1 120); do [ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ] && break; sleep 5; done
for i in $(seq 1 30); do adb shell pm path android > /dev/null 2>&1 && break; sleep 5; done; sleep 20
timeout 300 adb install --no-streaming -r $OUTD/krishi-doctor.apk > $OUTD/install24.log 2>&1 || timeout 300 adb install -r $OUTD/krishi-doctor.apk >> $OUTD/install24.log 2>&1
step "install android 7: $(tail -1 $OUTD/install24.log)"
mkdir -p $OUTD/emu24 && SMOKE=1 APK=$OUTD/krishi-doctor.apk SEGMENTS=$K/voice/segments.json PHOTOS=$OUTD/test_photos timeout 1800 python3 $K/android/tools/emu_test.py $K $OUTD/emu24 > $OUTD/emu24.log 2>&1
step "android 7 smoke: $(tail -1 $OUTD/emu24.log | cut -c1-700)"
step FINISHED
