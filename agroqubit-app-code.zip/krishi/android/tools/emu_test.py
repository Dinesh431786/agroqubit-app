"""Drive the installed app on the emulator like a farmer and check it.
 A) simulated farmers: for every disease x language, a truthful farmer talks to the app (typed sentences from the
    independent test set + chip taps). The SAME inputs go through the Python reference Chat; replies must match.
 B) real UI: an English conversation typed with the on-screen keyboard and chips tapped by coordinates; screenshots.
 C) photos: real PlantDoc test photos pushed to the phone; the app's on-device answer vs the Python reference; latency.
 D) voice: every sentence the app can say has a clip in the APK (both voices); full spoken answers play to the end
    with no decoder errors (also on Android 7).
Usage: python3 emu_test.py <krishi_dir> <out_dir>   (env: APK, SEGMENTS, PHOTOS, SMOKE=1 for the old-Android run)"""
import base64, json, os, random, re, subprocess, sys, time, zipfile
K, OUT = sys.argv[1], sys.argv[2]; os.makedirs(OUT, exist_ok=True)
PKG = "in.krishi.doctor"; random.seed(11)
os.environ["KRISHI_TEXT"] = "q8"; os.environ["KRISHI_FREE_CK"] = f"{K}/freechat/free_intent_q8.pt"
sys.path.insert(0, f"{K}/brain"); sys.path.insert(0, f"{K}/freechat"); sys.path.insert(0, f"{K}/text")
from chat import Chat
SKIP = ["pic_rice", "pic_chilli", "pic_groundnut"]

def adb(*a, check=False, timeout=60):
    return subprocess.run(["adb", *a], capture_output=True, text=True, timeout=timeout, check=check).stdout
def shell(cmd, timeout=60): return adb("shell", cmd, timeout=timeout)
def logs():
    out = []
    for l in adb("logcat", "-d", "-s", "KRISHI:I", "-v", "raw").splitlines():
        l = l.strip()
        if l.startswith("{"):
            try: out.append(json.loads(l))
            except Exception: pass
    return out
def app_lines(): return [x for x in logs() if x.get("who") == "app"]
def voice_lines(): return [x for x in logs() if x.get("who") == "voice"]
def last_t():
    a = app_lines(); return a[-1]["t"] if a else -1
def wait_reply(after_t, timeout=25):
    """Latest app reply logged after time after_t (the app's own clock), once replies stop arriving."""
    t = time.time()
    while time.time() - t < timeout:
        a = [x for x in app_lines() if x["t"] > after_t]
        if a: time.sleep(0.3); a = [x for x in app_lines() if x["t"] > after_t]; return a[-1], a
        time.sleep(0.4)
    return None, []
def bc(cmd, **ex):
    args = ["am", "broadcast", "-a", f"{PKG}.TEST", "--es", "cmd", cmd]
    for k, v in ex.items(): args += ["--es", k, v]
    shell(" ".join(args))
def b64(s): return base64.b64encode(s.encode()).decode()
def screenshot(name):
    png = f"{OUT}/{name}.png"
    with open(png, "wb") as f: f.write(subprocess.run(["adb", "exec-out", "screencap", "-p"], capture_output=True).stdout)
    return png

KB = json.load(open(f"/home/claude/agri_reason/v2/knowledge_v2.json"))
rows = [json.loads(l) for l in open(f"{K}/data/text_test.jsonl")]
ANS = {L: {a: [r["text"] for r in rows if r["lang"] == L and r["slots"] == [a]] for a in ["ans_yes", "ans_no"]} for L in ["hi", "ta", "kn", "en"]}
SYMPT = {L: {} for L in ["hi", "ta", "kn", "en"]}
for r in rows:
    if r["lang"] in SYMPT and len(r["slots"]) == 1: SYMPT[r["lang"]].setdefault(r["slots"][0], []).append(r["text"])

def opening(d, L):
    p = KB["diseases"][d].get("p", {}); good = [s for s, v in p.items() if v >= 0.8 and s in SYMPT[L]]
    if good: return random.choice(SYMPT[L][random.choice(good)])
    crop = KB["diseases"][d]["crop"]; return random.choice(SYMPT[L].get(f"crop_{crop}", ["help"]))

def decide(d, reply, chat_py):
    """Truthful farmer action for the app's question: ('tap', option) or ('text', sentence)."""
    q, crop = reply.get("qid"), KB["diseases"][d]["crop"]
    if q == "__crop__": return ("tap", crop)
    if q == "__confirm__": return ("tap", "yes" if reply.get("disease") == d else "no")
    opts = chat_py.brain.core.opts[q]
    if q.startswith("pic_"): return ("tap", d if d in opts else "none")
    if q == "part":
        T = chat_py.brain.core.theta[q][chat_py.brain.core.names.index(d)]; return ("tap", opts[int(T.argmax())])
    truth = KB["diseases"][d].get("p", {}).get(q, 0.05) >= 0.5
    if random.random() < 0.5: return ("tap", "yes" if truth else "no")
    return ("text", random.choice(ANS[chat_py.lang]["ans_yes" if truth else "ans_no"]))

def converse(d, L, results):
    bc("new"); time.sleep(0.6); n0 = last_t()
    py = Chat(L, skip=SKIP); turns = []; act = ("text", opening(d, L)); correct = None; match = True
    for t in range(8):
        n = last_t()
        if act[0] == "text": bc("text", b64=b64(act[1])); r_py = py.turn(text=act[1])
        else: bc("tap", opt=act[1]); r_py = py.turn(tap=act[1])
        r, _ = wait_reply(n)
        if r is None: turns.append({"act": act, "error": "no reply"}); match = False; break
        same = r.get("type") == r_py["type"] and r.get("qid") == r_py.get("qid") and r.get("disease") == r_py.get("disease")
        match &= same
        turns.append({"act": act, "app": {k: r.get(k) for k in ("type", "qid", "disease", "action", "confidence", "ms")}, "py": {k: r_py.get(k) for k in ("type", "qid", "disease")}, "same": same})
        if r["type"] in ("diagnosis", "not_sure", "referral"): correct = r.get("disease") == d; break
        if r["type"] in ("free_answer", "fact_answer") and not r.get("qid"): act = ("text", opening(d, L)); continue
        act = decide(d, r, py)
    results.append({"disease": d, "lang": L, "correct": bool(correct), "answered": correct is not None and turns[-1]["app"]["type"] == "diagnosis",
                    "parity": match, "turns": turns})

def ui_nodes():
    x = adb("exec-out", "uiautomator", "dump", "/dev/tty", timeout=40)
    nodes = []
    for m in re.finditer(r'<node [^>]*?text="([^"]*)"[^>]*?content-desc="([^"]*)"[^>]*?bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"', x):
        t, cd, a, b, c, e = m.groups(); nodes.append({"text": t, "desc": cd, "x": (int(a) + int(c)) // 2, "y": (int(b) + int(e)) // 2})
    return nodes
def tap_desc(desc):
    for n in ui_nodes():
        if n["desc"] == desc: shell(f"input tap {n['x']} {n['y']}"); return True
    return False

APK = os.environ.get("APK", "/opt/work/out/krishi-doctor.apk"); PH = os.environ.get("PHOTOS", "/opt/work/out/test_photos")
SEGS = os.environ.get("SEGMENTS", f"{K}/voice/segments.json"); DEV = f"/sdcard/Android/data/{PKG}/files/test"

def voice_pack_check():
    """Closed-world voice: every sentence id the app can say must be in the APK for both voices."""
    if not (os.path.exists(APK) and os.path.exists(SEGS)): return None
    names = set(zipfile.ZipFile(APK).namelist()); seg = json.load(open(SEGS))
    missing = [f"{v}/{l}/{i}" for v in "fm" for l in seg for i in seg[l] if f"assets/voice/{v}/{l}/{i}.ogg" not in names]
    sizes = [zi.file_size for zi in zipfile.ZipFile(APK).infolist() if zi.filename.startswith("assets/voice/")]
    return {"sentences_per_voice": sum(len(seg[l]) for l in seg), "clips_in_apk": len(sizes), "missing": len(missing), "examples": missing[:8], "voice_MB": round(sum(sizes) / 1e6, 2)}

def send_photo(path, chunk=None):
    """Photo bytes go to the app as base64 broadcast chunks: works on every Android version, no storage permission."""
    chunk = chunk or (3000 if os.environ.get("SMOKE") == "1" else 60000)    # old adbd (Android 7) has small command payloads
    b = base64.b64encode(open(path, "rb").read()).decode(); parts = [b[i:i + chunk] for i in range(0, len(b), chunk)]
    for k, p in enumerate(parts): bc("photochunk", idx=str(k), n=str(len(parts)), b64=p)

def photo_tests(limit=None):
    ref = json.load(open(f"{PH}/reference.json"))[:limit]
    out = []
    for i, r in enumerate(ref):
        bc("new"); time.sleep(0.8); n = last_t(); send_photo(f"{PH}/{r['file']}")
        rep, lines = wait_reply(n, timeout=60); time.sleep(0.5); lines = [x for x in app_lines() if x["t"] > n]
        vis = next((x for x in lines if x.get("type") == "vision"), None); rep = next((x for x in reversed(lines) if x.get("type") != "vision"), None)
        out.append({"file": r["file"], "true": r["true"], "python": r["ref_label"], "python_score": r["ref_score"], "app": vis and vis.get("label"),
                    "app_score": vis and vis.get("score"), "ms": vis and vis.get("ms"), "reply": rep and {k: rep.get(k) for k in ("type", "qid", "disease", "note", "clips")}})
        if i in (0, 3, 8): time.sleep(1); screenshot(f"09_photo_{i:02d}")
    ms = [o["ms"] for o in out if o["ms"] is not None]
    summ = {"photos": len(out), "same_answer_as_python": sum(o["app"] == o["python"] for o in out), "app_correct": sum(o["app"] == o["true"] for o in out),
            "python_correct": sum(o["python"] == o["true"] for o in out), "first_photo_ms": ms[0] if ms else None,
            "ms_mean_after_first": round(sum(ms[1:]) / max(1, len(ms) - 1)) if len(ms) > 1 else None, "ms_max": max(ms) if ms else None}
    json.dump(out, open(f"{OUT}/photo_tests.json", "w"), ensure_ascii=False, indent=1)
    return summ

FREEQ = {"hi": "धान में हर साल झोंका रोग आता है, पहले से कैसे बचाएं?", "ta": "நெல்லுல குலை நோய் வராம தடுக்க வழி சொல்லுங்க",
         "kn": "ಭತ್ತದಲ್ಲಿ ಬೆಂಕಿ ರೋಗ ತಡೆಯೋಕೆ ಮುಂಚೆನೇ ಏನು ಮಾಡ್ಬೇಕು", "en": "any organic solution for tomato early blight? i dont want to use chemicals"}
def spoken_answers(langs):
    """Voice ON: a free question per language; the whole verified answer must be spoken clip by clip to the end."""
    bc("voiceon"); res = {}
    for L in langs:
        bc("lang", lang=L); time.sleep(1.5); bc("new"); time.sleep(6); n = last_t(); bc("text", b64=b64(FREEQ[L]))
        r, _ = wait_reply(n, timeout=30); t0 = r["t"] if r else n; done = None
        for _ in range(150):
            v = [x for x in voice_lines() if x["t"] > t0]
            done = next((x for x in v if x.get("event") == "done"), None)
            if done or any(x.get("event") in ("clip_error", "clip_missing") for x in v): break
            time.sleep(0.5)
        v = [x for x in voice_lines() if x["t"] > t0]
        res[L] = {"action": r and r.get("action"), "clips": r and len(r.get("clips") or []), "played": done and done.get("played"),
                  "spoken_seconds": round((done["t"] - t0) / 1000, 1) if done else None, "errors": [x for x in v if x.get("event") != "done"][:3]}
        screenshot(f"10_spoken_{L}")
    bc("voiceoff"); return res

# ---- E) free questions on every topic (fact-token model), F) our trained voice model, G) our offline speech recognizer
FACTQ = {"en": ["how much urea for tomato per acre", "what to do for stem borer in paddy", "when should I sow groundnut",
                "chilli leaves curling due to thrips what to spray", "what is the market price of tomato today", "how much mancozeb should i use"],
         "hi": ["टमाटर में एक एकड़ में कितना यूरिया डालें", "धान में तना छेदक का इलाज बताओ", "मूंगफली की बुवाई कब करें",
                "मिर्च में थ्रिप्स के लिए क्या छिड़कें", "आज टमाटर का मंडी भाव क्या है", "मैंकोजेब कितना डालना है"],
         "ta": ["தக்காளிக்கு ஏக்கருக்கு எவ்வளவு யூரியா போடணும்", "நெல்லுல தண்டுத் துளைப்பான் வந்திருக்கு என்ன பண்றது", "நிலக்கடலை எப்போ விதைக்கணும்",
                "மிளகாய்ல இலைப்பேன் வந்திருக்கு என்ன தெளிக்கணும்", "இன்னைக்கு தக்காளி மார்க்கெட் விலை என்ன", "மேன்கோசெப் எவ்வளவு போடணும்"],
         "kn": ["ಟೊಮೇಟೊಗೆ ಎಕರೆಗೆ ಎಷ್ಟು ಯೂರಿಯಾ ಹಾಕ್ಬೇಕು", "ಭತ್ತದಲ್ಲಿ ಕಾಂಡ ಕೊರಕ ಬಂದಿದೆ ಏನು ಮಾಡ್ಬೇಕು", "ಶೇಂಗಾ ಯಾವಾಗ ಬಿತ್ತನೆ ಮಾಡ್ಬೇಕು",
                "ಮೆಣಸಿನಕಾಯಿಗೆ ಥ್ರಿಪ್ಸ್ ಬಂದಿದೆ ಏನು ಸಿಂಪಡಿಸ್ಬೇಕು", "ಇವತ್ತು ಟೊಮೇಟೊ ಮಾರುಕಟ್ಟೆ ಬೆಲೆ ಎಷ್ಟು", "ಮ್ಯಾಂಕೋಜೆಬ್ ಎಷ್ಟು ಹಾಕ್ಬೇಕು"]}
def fact_tests():
    """Each question in a fresh chat: the app's reply must equal the Python reference (same fact ids), clips must exist."""
    out = []
    for L, qs in FACTQ.items():
        bc("lang", lang=L); time.sleep(1)
        for q in qs:
            bc("new"); time.sleep(0.6); n = last_t(); bc("text", b64=b64(q)); py = Chat(L, skip=SKIP); r_py = py.turn(text=q)
            r, _ = wait_reply(n)
            out.append({"lang": L, "q": q, "app": r and {k: r.get(k) for k in ("type", "action", "qid", "disease", "facts", "ms", "say")},
                        "py": {k: r_py.get(k) for k in ("type", "action", "qid", "disease", "facts")},
                        "same": bool(r) and r.get("type") == r_py["type"] and (r.get("facts") or []) == (r_py.get("facts") or []) and r.get("qid") == r_py.get("qid")})
        screenshot(f"11_facts_{L}")
    json.dump(out, open(f"{OUT}/fact_tests.json", "w"), ensure_ascii=False, indent=1)
    from collections import Counter
    return {"questions": len(out), "same_as_python": sum(o["same"] for o in out), "types": dict(Counter((o["app"] or {}).get("type") for o in out)),
            "with_facts": sum(bool((o["app"] or {}).get("facts")) for o in out), "ms_max": max(((o["app"] or {}).get("ms") or 0) for o in out)}

TTSQ = {"hi": "मूंगफली में जिप्सम दो सौ किलो प्रति एकड़ डालिए।", "ta": "நிலக்கடலைக்கு ஏக்கருக்கு இருநூறு கிலோ ஜிப்சம் போடுங்க.",
        "kn": "ಶೇಂಗಾಗೆ ಎಕರೆಗೆ ಇನ್ನೂರು ಕಿಲೋ ಜಿಪ್ಸಮ್ ಹಾಕ್ರಿ.", "en": "Apply two hundred kilos of gypsum per acre to groundnut."}
def tts_tests(langs=("hi", "ta", "kn", "en")):
    """Our trained voice model on the phone: synthesis time vs audio length (real-time factor), and playback to the end."""
    res = {}
    for L in langs:
        bc("lang", lang=L); time.sleep(1.5); n = max([x["t"] for x in voice_lines()] or [-1]); bc("tts", b64=b64(TTSQ[L])); ev = None
        for _ in range(240):
            v = [x for x in voice_lines() if x["t"] > n]; ev = next((x for x in v if x.get("event") in ("tts", "tts_error", "tts_play_error")), None)
            if ev: break
            time.sleep(0.5)
        res[L] = ev and {k: ev.get(k) for k in ("event", "ms", "sec", "err")}
        if ev and ev.get("sec"): res[L]["rtf"] = round(ev["ms"] / 1000 / ev["sec"], 2)
        time.sleep((ev or {}).get("sec") or 1)
    return res

def cer(a, b):
    a = re.sub(r"[\s.,!?।]+", "", (a or "").lower()); b = re.sub(r"[\s.,!?।]+", "", (b or "").lower())
    if not b: return None
    d = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        p, d[0] = d[0], i
        for j, cb in enumerate(b, 1): p, d[j] = d[j], min(d[j] + 1, d[j - 1] + 1, p + (ca != cb))
    return round(d[len(b)] / len(b), 3)
def asr_tests():
    """Our offline recognizer on the phone: WAV clips (manifest.json: [{file, lang, text}]) -> Whisper -> a chat turn."""
    D = os.environ.get("ASR_DIR")
    if not D or not os.path.exists(f"{D}/manifest.json"): return None
    man = json.load(open(f"{D}/manifest.json", encoding="utf-8")); out = []; chunk = 3000 if os.environ.get("SMOKE") == "1" else 60000
    have = {n.split("whisper_")[1].split(".")[0] for n in zipfile.ZipFile(APK).namelist() if n.startswith("assets/whisper_") and n.endswith(".bin")}
    man = [m for m in man if m["lang"] in have]
    for m in man:
        bc("lang", lang=m["lang"]); time.sleep(1.2); bc("new"); time.sleep(0.6); n = last_t()
        b = base64.b64encode(open(f"{D}/{m['file']}", "rb").read()).decode(); parts = [b[i:i + chunk] for i in range(0, len(b), chunk)]
        for k, p in enumerate(parts): bc("asrchunk", idx=str(k), n=str(len(parts)), b64=p)
        w = None
        for _ in range(240):
            w = next((x for x in app_lines() if x["t"] > n and x.get("type") in ("whisper", "whisper_error")), None)
            if w: break
            time.sleep(0.5)
        time.sleep(2); rep = next((x for x in reversed(app_lines()) if x["t"] > n and x.get("type") not in ("whisper", "whisper_error")), None)
        out.append({**m, "heard": w and w.get("text"), "cer": cer(w and w.get("text"), m["text"]), "ms": w and w.get("ms"), "audio_s": w and w.get("audio_s"),
                    "enc_ms": w and w.get("enc_ms"), "dec_ms": w and w.get("dec_ms"), "reply": rep and rep.get("type"), "err": w and w.get("err")})
    json.dump(out, open(f"{OUT}/asr_tests.json", "w"), ensure_ascii=False, indent=1)
    by = {}
    for L in sorted({o["lang"] for o in out}):
        o = [x for x in out if x["lang"] == L and x["cer"] is not None]
        by[L] = {"clips": len(o), "cer_mean": round(sum(x["cer"] for x in o) / max(1, len(o)), 3),
                 "rtf_mean": round(sum(x["ms"] / 1000 / x["audio_s"] for x in o if x["ms"] and x["audio_s"]) / max(1, len(o)), 2)}
    return by

def main():
    R = {}
    # ---- start / memory
    adb("logcat", "-G", "16M"); adb("logcat", "-c"); shell(f"am force-stop {PKG}")
    st = shell(f"am start -W -n {PKG}/.MainActivity"); R["am_start"] = st.strip()
    for _ in range(60):
        if any(x.get("who") == "loaded" for x in logs()): break
        time.sleep(0.5)
    R["model_load"] = next((x for x in logs() if x.get("who") == "loaded"), None)
    time.sleep(2); screenshot("01_start_hindi"); R["voice_pack"] = voice_pack_check()
    SMOKE = os.environ.get("SMOKE") == "1"
    if SMOKE:   # quick check on an old Android version: start, one conversation per language, screenshot
        res = []
        for L in ["hi", "ta", "kn", "en"]:
            bc("lang", lang=L); time.sleep(1)
            for d in ["tomato_leaf_curl", "rice_blast", "groundnut_rust"]: converse(d, L, res)
            screenshot(f"smoke_{L}")
        R["sim"] = {"conversations": len(res), "parity_with_python": sum(x.get("parity", False) for x in res), "correct": sum(x.get("correct", False) for x in res)}
        try: R["photos"] = photo_tests(limit=6)
        except Exception as e: R["photos"] = repr(e)
        try: R["spoken"] = spoken_answers(["hi", "en"])
        except Exception as e: R["spoken"] = repr(e)
        try: R["tts"] = tts_tests(("hi", "en"))
        except Exception as e: R["tts"] = repr(e)
        try: R["asr"] = asr_tests()
        except Exception as e: R["asr"] = repr(e)
        R["voice_errors"] = [x for x in voice_lines() if x.get("event") in ("clip_error", "clip_missing")][:5]
        lg = adb("logcat", "-d", "-v", "brief"); R["crashes"] = lg.count("FATAL EXCEPTION")
        R["meminfo"] = [l.strip() for l in shell(f"dumpsys meminfo {PKG}").splitlines() if "TOTAL" in l][:2]
        json.dump(R, open(f"{OUT}/emu_results.json", "w"), ensure_ascii=False, indent=1); print(json.dumps(R, ensure_ascii=False)[:2000]); return
    # ---- B) real UI, English: keyboard typing + chip taps by coordinates
    bc("lang", lang="en"); time.sleep(1.5)
    ui = []
    tap_desc("message"); time.sleep(0.5)
    shell("input text 'tomato%sleaves%sare%scurling%sand%sthe%splant%sis%sstunted'"); time.sleep(0.5)
    n = last_t(); tap_desc("send"); r, _ = wait_reply(n); ui.append(r); time.sleep(1.5); screenshot("02_en_first_question")
    for step in range(6):
        if r is None or r.get("type") != "question": break
        chips = [c for c in (r.get("chips") or [])]
        want = "tomato_leaf_curl" if r.get("qid", "").startswith("pic_") else ("yes" if r.get("qid") in ("leaf_curl_crinkle_stunt", "ctx_whiteflies") else ("leaf" if r.get("qid") == "part" else ("tomato" if r.get("qid") == "__crop__" else "no")))
        n = last_t()
        if not tap_desc("chip_" + want): ui.append({"error": f"chip_{want} not on screen", "chips": chips}); break
        r, _ = wait_reply(n); ui.append(r); time.sleep(1.2); screenshot(f"03_en_step{step}")
    R["ui_english"] = ui
    n = last_t(); tap_desc("mic"); time.sleep(3); R["mic"] = ([x for x in app_lines() if x["t"] > n] or [None])[-1]; screenshot("04_mic"); shell("input keyevent 4"); time.sleep(1)
    n = last_t(); tap_desc("photo"); time.sleep(3); R["camera_focus"] = shell("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -2").strip(); screenshot("05_camera"); shell("input keyevent 4"); time.sleep(1.5)
    shell(f"am start -n {PKG}/.MainActivity"); time.sleep(1)
    # free question + photo hook in Tamil / Kannada for screenshots
    bc("lang", lang="ta"); time.sleep(1); n = last_t(); bc("text", b64=b64("நெல்லுல குலை நோய்க்கு இயற்கை மருந்து என்ன")); r, _ = wait_reply(n); R["free_ta"] = r; time.sleep(1); screenshot("06_ta_free_question")
    bc("lang", lang="kn"); time.sleep(1); n = last_t(); bc("text", b64=b64("ಶೇಂಗಾ ಎಲೆ ಕೆಳಗೆ ಕಿತ್ತಳೆ ಬಣ್ಣದ ಗುಳ್ಳೆ ಇದೆ")); r, _ = wait_reply(n); R["kn_first"] = r; time.sleep(1); screenshot("07_kn_question")
    # ---- C) photos, D) spoken answers
    try: R["photos"] = photo_tests()
    except Exception as e: R["photos"] = repr(e)
    R["meminfo_after_photos"] = [l.strip() for l in shell(f"dumpsys meminfo {PKG}").splitlines() if "TOTAL" in l or "Java Heap" in l or "Native Heap" in l][:4]
    try: R["spoken"] = spoken_answers(["hi", "ta", "kn", "en"])
    except Exception as e: R["spoken"] = repr(e)
    try: R["facts"] = fact_tests()
    except Exception as e: R["facts"] = repr(e)
    try: R["tts"] = tts_tests()
    except Exception as e: R["tts"] = repr(e)
    try: R["asr"] = asr_tests()
    except Exception as e: R["asr"] = repr(e)
    R["meminfo_after_voice"] = [l.strip() for l in shell(f"dumpsys meminfo {PKG}").splitlines() if "TOTAL" in l or "Java Heap" in l or "Native Heap" in l][:4]
    # ---- A) simulated farmers on every disease x language
    res = []; t0 = time.time()
    for L in ["hi", "ta", "kn", "en"]:
        bc("lang", lang=L); time.sleep(1)
        for d in KB["diseases"]:
            try: converse(d, L, res)
            except Exception as e: res.append({"disease": d, "lang": L, "error": repr(e)})
        screenshot(f"08_end_{L}")
    R["sim_minutes"] = round((time.time() - t0) / 60, 1)
    ok = [x for x in res if "error" not in x]
    R["sim"] = {"conversations": len(res), "errors": len(res) - len(ok), "parity_with_python": sum(x["parity"] for x in ok), "correct": sum(x["correct"] for x in ok),
                "by_lang": {L: sum(x["correct"] for x in ok if x["lang"] == L) for L in ["hi", "ta", "kn", "en"]},
                "turn_ms_max": max((t["app"].get("ms") or 0) for x in ok for t in x["turns"] if "app" in t),
                "turn_ms_mean": round(sum((t["app"].get("ms") or 0) for x in ok for t in x["turns"] if "app" in t) / max(1, sum(1 for x in ok for t in x["turns"] if "app" in t)), 2)}
    json.dump(res, open(f"{OUT}/sim_conversations.json", "w"), ensure_ascii=False, indent=1)
    R["meminfo"] = [l.strip() for l in shell(f"dumpsys meminfo {PKG}").splitlines() if "TOTAL" in l or "Java Heap" in l or "Native Heap" in l][:4]
    lg = adb("logcat", "-d", "-v", "brief"); R["crashes"] = lg.count("FATAL EXCEPTION")
    R["voice_errors"] = [x for x in voice_lines() if x.get("event") in ("clip_error", "clip_missing")]; R["clip_errors"] = len(R["voice_errors"])
    R["apk_bytes"] = os.path.getsize(os.environ.get("APK", "/opt/work/out/krishi-doctor.apk")) if os.path.exists(os.environ.get("APK", "/opt/work/out/krishi-doctor.apk")) else None
    open(f"{OUT}/logcat_tail.txt", "w").write("\n".join(lg.splitlines()[-400:]))
    json.dump(R, open(f"{OUT}/emu_results.json", "w"), ensure_ascii=False, indent=1)
    print(json.dumps({k: R.get(k) for k in ("model_load", "sim", "photos", "facts", "tts", "asr", "voice_pack", "clip_errors", "crashes", "meminfo")}, ensure_ascii=False))

if __name__ == "__main__": main()
