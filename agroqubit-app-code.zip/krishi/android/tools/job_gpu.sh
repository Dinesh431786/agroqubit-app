#!/bin/bash
# Everything on ONE GPU VM (g6.xlarge, NVIDIA L4): the original plan. The job itself is job_train.sh (it also runs on CPUs
# only, CPU=1, and can be split over two VMs, ROLE=main + ROLE=voice).
exec env ROLE=all CPU=0 bash "$(dirname "$0")/job_train.sh"
