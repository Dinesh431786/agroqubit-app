"""KRW1: the one weights container used by every on-phone model (vision, FactLM, voice, speech).

Big-endian layout: b"KRW1", int32 tensor count, then per tensor:
  int16 name length, UTF-8 name, int8 dtype, int32 ndim, int32[ndim] shape, data
  dtype 0 = fp32 | 1 = int8 rows: shape is always 2-D [rows, cols], data = rows*cols int8 then one fp32 scale per row
  dtype 2 = fp16
Java reader: android/src/in/krishi/doctor/Krw.java. Any weight with ndim >= 2 can be stored int8 (flattened to rows=shape[0]).
"""
import struct
import numpy as np


def quant_rows(w):
    """int8 per output row; the clipping range per row is searched (50-100% of max|w|) to minimise squared error."""
    W = np.asarray(w, np.float32).reshape(w.shape[0], -1); bq = bs = be = None
    for r in np.linspace(0.5, 1.0, 21):
        sc = np.abs(W).max(1, keepdims=True) * r / 127 + 1e-12; q = np.clip(np.round(W / sc), -127, 127)
        err = ((W - q * sc) ** 2).sum(1, keepdims=True)
        if bq is None: bq, bs, be = q, sc, err
        else: m = err < be; bq = np.where(m, q, bq); bs = np.where(m, sc, bs); be = np.where(m, err, be)
    return bq.astype(np.int8), bs.astype(np.float32).reshape(-1)


def q8(w): return ("q8", quant_rows(np.asarray(w, np.float32)))
def f16(w): return ("f16", np.asarray(w, np.float32))
def f32(w): return ("f32", np.asarray(w, np.float32))


def write_krw1(path, tensors):
    """tensors: {name: ("f32"|"f16", array) or ("q8", (int8 [rows, cols], fp32 [rows]))} (insertion order kept)."""
    with open(path, "wb") as f:
        f.write(b"KRW1"); f.write(struct.pack(">i", len(tensors)))
        for name, (kind, v) in tensors.items():
            nb = name.encode(); f.write(struct.pack(">h", len(nb))); f.write(nb)
            if kind == "f16":
                v = np.asarray(v, np.float16); f.write(struct.pack(">bi", 2, v.ndim)); f.write(struct.pack(f">{v.ndim}i", *v.shape)); f.write(v.astype(">f2").tobytes())
            elif kind == "q8":
                q, sc = v; q = np.asarray(q, np.int8).reshape(q.shape[0], -1)
                f.write(struct.pack(">bi", 1, 2)); f.write(struct.pack(">ii", *q.shape)); f.write(q.tobytes()); f.write(np.asarray(sc, ">f4").tobytes())
            else:
                v = np.asarray(v, np.float32); f.write(struct.pack(">bi", 0, v.ndim)); f.write(struct.pack(f">{v.ndim}i", *v.shape)); f.write(v.astype(">f4").tobytes())


def read_krw1(path):
    """Returns {name: float32 array} with int8 tensors dequantised (2-D [rows, cols]) - for tests and checks."""
    out = {}
    with open(path, "rb") as f:
        assert f.read(4) == b"KRW1"; n, = struct.unpack(">i", f.read(4))
        for _ in range(n):
            ln, = struct.unpack(">h", f.read(2)); name = f.read(ln).decode()
            dt, nd = struct.unpack(">bi", f.read(5)); sh = struct.unpack(f">{nd}i", f.read(4 * nd)); size = int(np.prod(sh)) if nd else 1
            if dt == 1:
                q = np.frombuffer(f.read(size), np.int8).reshape(sh); sc = np.frombuffer(f.read(4 * sh[0]), ">f4").astype(np.float32)
                out[name] = q.astype(np.float32) * sc[:, None]
            elif dt == 2:
                out[name] = np.frombuffer(f.read(2 * size), ">f2").astype(np.float32).reshape(sh)
            else:
                out[name] = np.frombuffer(f.read(4 * size), ">f4").astype(np.float32).reshape(sh)
    return out
