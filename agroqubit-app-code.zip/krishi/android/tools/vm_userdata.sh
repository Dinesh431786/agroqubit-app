#!/bin/bash
# EC2 user-data for the one-time VMs (no secrets: the instance profile gives S3 access to the temporary bucket only).
# Placeholders, filled in at launch: __BUCKET__ __REGION__ __KEYS__ (code archives in S3, applied in order),
# __JOB__ (job_gpu.sh | job_emu.sh), __ENV__ (extra exports, e.g. RES=results7 PREV_APK=results6/krishi-doctor.apk), __CAP__ (minutes).
# The machine powers off at the end of the job, or after __CAP__ minutes at most; shutdown behaviour "terminate" deletes it.
shutdown -h +__CAP__
exec > /var/log/krishi-boot.log 2>&1
set -x
export BUCKET=__BUCKET__ AWS_DEFAULT_REGION=__REGION__ __ENV__
command -v aws > /dev/null || ( cd /tmp && curl -sSL --retry 5 -o awscliv2.zip https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip \
  && python3 -c "import zipfile; zipfile.ZipFile('awscliv2.zip').extractall('.')" && chmod -R +x aws && ./aws/install > /dev/null )
mkdir -p /home/claude && cd /home/claude
for k in __KEYS__; do
  aws s3 cp "s3://$BUCKET/$k" "/tmp/code_$$" --only-show-errors && tar -xf "/tmp/code_$$" -C /home/claude && rm -f "/tmp/code_$$" || echo "MISSING $k"
done
( while sleep 600; do aws s3 cp /var/log/krishi-boot.log "s3://$BUCKET/$RES/boot.log" --only-show-errors; done ) &
bash /home/claude/krishi/android/tools/__JOB__
aws s3 cp /var/log/krishi-boot.log "s3://$BUCKET/$RES/boot.log" --only-show-errors
shutdown -h now
