package in.krishi.doctor;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Offline voice input with Whisper.java: the fallback when the phone's own recogniser has no offline model for the
 * farmer's language.
 *
 * <p>Records mono 16-bit PCM at 16 kHz with AudioRecord (VOICE_RECOGNITION source, falling back to MIC and to 48 /
 * 44.1 kHz with resampling). Energy endpointing on 30 ms frames against an adaptive noise floor: speech starts after
 * 90 ms above floor+10 dB (300 ms of pre-roll is kept); recording stops after {@link #silenceMs} of silence, after
 * {@link #maxSpeechMs} of speech, on {@link #stop()}, or (no speech at all) after {@link #noSpeechTimeoutMs}. Trailing
 * silence is trimmed, then Whisper runs in SHORT mode on a worker thread and the result is posted to the main thread.
 *
 * <p>The caller must already hold RECORD_AUDIO. The model (whisper_&lt;lang&gt;.bin/.json, about 40 MB) is loaded on
 * the worker thread the first time it is needed (preload() to do it early); only one language is kept in memory.
 * Call release() from onDestroy().
 */
public final class Listen {
    /** All callbacks run on the main thread. */
    public interface Callback {
        /** Microphone open, waiting for speech. */
        void onReady();
        /** Speech detected. */
        void onSpeech();
        /** Input level 0..1 for a meter (about 10 per second). */
        void onLevel(float level);
        /** Recording finished, recognising. */
        void onThinking();
        /**
         * Recognised text with a 0..1 confidence (exp(avg log-prob) x (1 - no-speech prob)). r carries avgLogProb,
         * noSpeechProb, compressionRatio, unreliable() and timings, so the app can reject garbage.
         */
        void onResult(String text, double confidence, Whisper.Result r);
        /** Nothing usable: "no_speech", "too_short", "cancelled". */
        void onNothing(String reason);
        void onError(Exception e);
    }

    static final String TAG = "Listen";
    static final int SR = 16000;

    // endpointing parameters (public so the app can tune them)
    public volatile int silenceMs = 800, maxSpeechMs = 12000, noSpeechTimeoutMs = 8000, preRollMs = 300, tailMs = 300;
    public volatile float startDb = 10f, keepDb = 6f, minSpeechDb = -55f;

    final Whisper.Opener res; final Callback cb;
    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService worker = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "whisper"); t.setDaemon(true); return t; });
    volatile String lang;
    Whisper model; String modelLang;               // touched only on the worker thread
    volatile Thread recThread;
    volatile boolean stopRequested, cancelled, busy, released;
    /** The last Whisper result (also when it was reported as onNothing), for logs. */
    public volatile Whisper.Result last;

    /** res opens the model files, e.g. {@code name -> getAssets().open(name)} (the same lambda the app gives Krishi). */
    public Listen(Whisper.Opener res, Callback cb) { this.res = res; this.cb = cb; }

    /** True if whisper_&lt;lang&gt;.json/.bin are among the app's assets. */
    public static boolean hasModel(Whisper.Opener res, String lang) {
        for (String ext : new String[]{".json", ".bin"}) {
            try (InputStream in = res.open(Whisper.assetStem(lang) + ext)) { if (in == null) return false; }
            catch (IOException e) { return false; }
        }
        return true;
    }

    /** Language for the next recognitions ("hi", "ta", "kn", "en"). */
    public void setLanguage(String lang) { this.lang = lang; }

    /** Loads the model for the current language on the worker thread (optional; start() does it too). */
    public void preload() {
        final String l = lang;
        if (l == null || released) return;
        worker.execute(() -> { try { modelFor(l); } catch (Throwable t) { Log.w(TAG, "preload " + l, t); } });
    }

    /** Starts listening. False if already listening/recognising, released, or no language is set. */
    public synchronized boolean start() {
        if (busy || released || lang == null) return false;
        busy = true; stopRequested = false; cancelled = false;
        final String l = lang;
        preload();
        Thread t = new Thread(() -> record(l), "listen-rec");
        recThread = t; t.start();
        return true;
    }

    /** Stops recording and recognises what was said so far (manual stop button). */
    public void stop() { stopRequested = true; }

    /** Stops without recognising. */
    public void cancel() { cancelled = true; stopRequested = true; }

    public boolean isBusy() { return busy; }

    /** Stops everything and frees the model; the object cannot be used afterwards. */
    public synchronized void release() {
        if (released) return;
        released = true; cancel();
        Thread t = recThread;
        if (t != null) try { t.join(500); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        worker.execute(() -> { if (model != null) model.trim(); model = null; modelLang = null; });
        worker.shutdown();
    }

    // ------------------------------------------------------------------ worker side
    Whisper modelFor(String l) throws IOException {
        if (model != null && l.equals(modelLang)) return model;
        model = null; modelLang = null;   // only one language in memory
        long t0 = SystemClock.elapsedRealtime();
        model = Whisper.fromRes(res, l); modelLang = l;
        Log.i(TAG, "whisper_" + l + " loaded in " + (SystemClock.elapsedRealtime() - t0) + " ms");
        return model;
    }

    void recognise(final String l, final float[] pcm, final int n) {
        try {
            Whisper w = modelFor(l);
            final Whisper.Result r = w.transcribe(pcm, n, false);
            last = r;
            // no transcript in logcat (privacy): sizes, scores and timings only
            Log.i(TAG, String.format(java.util.Locale.ROOT, "%s: %d tokens, avg_logprob %.2f, no_speech %.2f, %.1f s audio, mel %d / enc %d / dec %d ms",
                    l, r.tokens.length, r.avgLogProb, r.noSpeechProb, r.samples / 16000.0, r.melMs, r.encMs, r.decMs));
            if (cancelled) { post(() -> cb.onNothing("cancelled")); return; }
            if (r.text.isEmpty() || r.noSpeech()) post(() -> cb.onNothing("no_speech"));
            else post(() -> cb.onResult(r.text, r.confidence(), r));
        } catch (final Throwable t) {
            Log.w(TAG, "recognise", t);
            post(() -> cb.onError(t instanceof Exception ? (Exception) t : new RuntimeException(t)));
        } finally {
            busy = false;
        }
    }

    void post(Runnable r) { if (!released) main.post(r); }

    // ------------------------------------------------------------------ recording side
    static AudioRecord open(int[] rateOut) {
        int[] rates = {SR, 48000, 44100};
        int[] sources = {MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC};
        for (int rate : rates) {
            int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) continue;
            for (int src : sources) {
                AudioRecord r = null;
                try {
                    r = new AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, rate / 2 * 2));
                    if (r.getState() == AudioRecord.STATE_INITIALIZED) { rateOut[0] = rate; return r; }
                } catch (RuntimeException e) {
                    Log.w(TAG, "AudioRecord " + rate + " Hz, source " + src + ": " + e);
                }
                if (r != null) r.release();
            }
        }
        return null;
    }

    void record(final String l) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        int[] rate = {SR};
        AudioRecord rec = null;
        short[] pcm = null; int n = 0;
        boolean speech = false, handedOver = false;
        try {
            rec = open(rate);
            if (rec == null) throw new IllegalStateException("microphone unavailable (RECORD_AUDIO not granted, or in use)");
            final int sr = rate[0], frame = sr * 30 / 1000;
            final int maxSamples = (int) ((long) sr * (maxSpeechMs + preRollMs + silenceMs + 200) / 1000);
            pcm = new short[maxSamples + frame];
            short[] buf = new short[frame];
            rec.startRecording();
            if (rec.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("microphone busy");
            post(cb::onReady);
            final int preRoll = sr * preRollMs / 1000;
            float floor = Float.POSITIVE_INFINITY; int above = 0, speechStart = 0, lastVoiced = 0, voicedFrames = 0, frames = 0;
            long lastLevel = 0, t0 = SystemClock.elapsedRealtime();
            while (!stopRequested) {
                int got = 0;
                while (got < frame && !stopRequested) {
                    int k = rec.read(buf, got, frame - got);
                    if (k < 0) throw new IllegalStateException("AudioRecord.read error " + k);
                    got += k;
                }
                if (got < frame) break;
                frames++;
                double e = 0; for (int i = 0; i < frame; i++) e += (double) buf[i] * buf[i];
                float db = (float) (10 * Math.log10(e / frame / (32768.0 * 32768.0) + 1e-10));
                // noise floor: minimum of the first 150 ms, then follows quieter frames at once and creeps up
                // (about 3 dB/s) on frames that are not speech, so a changing background is tracked
                boolean voiced = db > Math.max(floor + keepDb, minSpeechDb - 5);
                if (frames <= 5 || db < floor) floor = Math.min(floor, db);
                else if (!speech || !voiced) floor += 0.1f;
                if (!speech) {
                    // keep only the pre-roll before speech starts
                    if (n + frame > preRoll + frame) { int drop = n + frame - preRoll - frame; System.arraycopy(pcm, drop, pcm, 0, n - drop); n -= drop; }
                    System.arraycopy(buf, 0, pcm, n, frame); n += frame;
                    above = frames > 5 && db > Math.max(floor + startDb, minSpeechDb) ? above + 1 : 0;
                    if (above >= 3) {
                        speech = true; speechStart = Math.max(0, n - 3 * frame); lastVoiced = n; voicedFrames = 3;
                        post(cb::onSpeech);
                    } else if (SystemClock.elapsedRealtime() - t0 > noSpeechTimeoutMs) break;
                } else {
                    if (n + frame > pcm.length) break;
                    System.arraycopy(buf, 0, pcm, n, frame); n += frame;
                    if (voiced) { lastVoiced = n; voicedFrames++; }
                    if ((long) (n - lastVoiced) * 1000 / sr >= silenceMs) break;
                    if ((long) (n - speechStart) * 1000 / sr >= maxSpeechMs) break;
                }
                long now = SystemClock.elapsedRealtime();
                if (now - lastLevel >= 100) {
                    lastLevel = now; final float lv = Math.max(0f, Math.min(1f, (db + 60f) / 50f));
                    post(() -> cb.onLevel(lv));
                }
            }
            rec.stop();
            if (cancelled) { post(() -> cb.onNothing("cancelled")); return; }
            if (!speech) { post(() -> cb.onNothing("no_speech")); return; }
            if (voicedFrames * 30 < 250) { post(() -> cb.onNothing("too_short")); return; }
            int end = Math.min(n, lastVoiced + sr * tailMs / 1000), peak = 1;
            for (int i = 0; i < end; i++) peak = Math.max(peak, Math.abs((int) pcm[i]));
            // quiet microphones: bring the peak up to about -6 dBFS (at most +20 dB); louder input is left alone
            float gain = peak < 8192 ? Math.min(10f, 16384f / peak) : 1f;
            float[] x = new float[end];
            for (int i = 0; i < end; i++) x[i] = pcm[i] * gain / 32768f;
            if (sr != SR) x = resample(x, sr, SR);
            final float[] audio = x;
            post(cb::onThinking);
            handedOver = true;
            worker.execute(() -> recognise(l, audio, audio.length));
        } catch (final Throwable t) {
            Log.w(TAG, "record", t);
            post(() -> cb.onError(t instanceof Exception ? (Exception) t : new RuntimeException(t)));
        } finally {
            if (rec != null) {
                try { if (rec.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) rec.stop(); } catch (RuntimeException ignored) { }
                rec.release();
            }
            recThread = null;
            if (!handedOver) busy = false;
        }
    }

    /**
     * Polyphase windowed-sinc resampler (cutoff 0.45 x the lower rate, 32 Hann-windowed taps, unity DC gain), for the
     * 48 / 44.1 kHz fallback: 48 kHz -> 16 kHz uses 1 phase, 44.1 kHz -> 16 kHz 160 phases.
     */
    static float[] resample(float[] x, int from, int to) {
        if (from == to) return x;
        int g = gcd(from, to), L = to / g, M = from / g, half = 16, taps = 2 * half;
        double fc = 0.45 * Math.min(1.0, (double) to / from);
        double[][] h = new double[L][taps];
        for (int p = 0; p < L; p++) {
            double frac = (double) p / L, sum = 0;
            for (int j = 0; j < taps; j++) {
                double t = (j - half + 1) - frac;
                double s = Math.abs(t) < 1e-12 ? 2 * fc : Math.sin(2 * Math.PI * fc * t) / (Math.PI * t);
                double w = Math.abs(t) >= half ? 0 : 0.5 + 0.5 * Math.cos(Math.PI * t / half);
                h[p][j] = s * w; sum += h[p][j];
            }
            for (int j = 0; j < taps; j++) h[p][j] /= sum;
        }
        int n = (int) ((long) x.length * to / from);
        float[] y = new float[n];
        for (int i = 0; i < n; i++) {
            long pos = (long) i * M; int k0 = (int) (pos / L), p = (int) (pos % L);
            double acc = 0; double[] hp = h[p];
            for (int j = 0; j < taps; j++) { int k = k0 + j - half + 1; if (k >= 0 && k < x.length) acc += x[k] * hp[j]; }
            y[i] = (float) acc;
        }
        return y;
    }

    static int gcd(int a, int b) { while (b != 0) { int t = a % b; a = b; b = t; } return a; }
}
