package in.krishi.doctor;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.ExifInterface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** The whole app is this one chat screen: type / speak / take a photo / tap a chip; every reply is shown AND spoken
 *  (closed-world voice: all sentences pre-rendered with a human neural voice, played clip by clip). */
public class MainActivity extends Activity {
    static final String TAG = "KRISHI", TEST_ACTION = "in.krishi.doctor.TEST";
    static final String[] LANGS = {"hi", "ta", "kn", "en"}, LANG_BTN = {"हिं", "த", "ಕ", "EN"};
    static final int REQ_MIC = 1, REQ_CAM = 2, REQ_PICK = 3, REQ_AUDIO = 4, REQ_AUDIO_W = 5;
    static final Set<String> PIC_SKIP = new HashSet<>(Arrays.asList("pic_rice", "pic_chilli", "pic_groundnut"));  // no licensed photos yet
    static final int GREEN = 0xFF2E7D32, RED = 0xFFC62828, BG = 0xFFF3EFE4, ME = 0xFFDCF3D0, APP = 0xFFFFFFFF, INK = 0xFF1B1B1B, MUTED = 0xFF6B6B6B;

    final ExecutorService worker = Executors.newSingleThreadExecutor(); final Handler ui = new Handler(Looper.getMainLooper());
    Krishi krishi; Chat chat; String lang = "hi"; boolean voiceOn = true; String voice = "f";
    LinearLayout msgs, chips; ScrollView scroll; EditText input; TextView[] langViews = new TextView[4]; TextView speaker, title, mic;
    final ArrayDeque<String> clipQueue = new ArrayDeque<>(); MediaPlayer player; Writer transcript; long t0 = SystemClock.elapsedRealtime();
    final List<View> tiles = new ArrayList<>(); View waitBubble; volatile Krishi.Photo lastPhoto; SpeechRecognizer sr; boolean listening;
    final ByteArrayOutputStream testPhoto = new ByteArrayOutputStream(), testAudio = new ByteArrayOutputStream();
    final ExecutorService voiceExec = Executors.newSingleThreadExecutor(); AudioTrack track; int voiceGen;   // our trained voice
    Listen listen; Whisper testWhisper;                                                                      // offline speech input

    // ------------------------------------------------------------------ layout
    int dp(float v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }
    GradientDrawable round(int color, float r) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }
    TextView tv(String s, float sp, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); return t; }
    TextView circleBtn(String glyph, String desc, View.OnClickListener l) {
        TextView b = tv(glyph, 22, Color.WHITE); b.setGravity(Gravity.CENTER); b.setBackground(round(GREEN, 24)); b.setContentDescription(desc);
        b.setOnClickListener(l); b.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(48))); return b;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (b != null) lang = b.getString("lang", lang);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);

        LinearLayout bar = new LinearLayout(this); bar.setBackgroundColor(GREEN); bar.setPadding(dp(12), dp(10), dp(8), dp(10)); bar.setGravity(Gravity.CENTER_VERTICAL);
        title = tv("", 19, Color.WHITE); title.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        for (int i = 0; i < 4; i++) {
            final int li = i; TextView l = tv(LANG_BTN[i], 15, Color.WHITE); l.setPadding(dp(9), dp(5), dp(9), dp(5)); l.setContentDescription("lang_" + LANGS[i]);
            l.setOnClickListener(v -> setLang(LANGS[li], true)); langViews[i] = l; bar.addView(l);
        }
        speaker = tv("🔊", 18, Color.WHITE); speaker.setPadding(dp(8), dp(4), dp(4), dp(4)); speaker.setContentDescription("voice");
        speaker.setOnClickListener(v -> { voiceOn = !voiceOn; speaker.setText(voiceOn ? "🔊" : "🔇"); if (!voiceOn) stopVoice(); });
        speaker.setOnLongClickListener(v -> { voice = voice.equals("f") ? "m" : "f"; toast(voice.equals("f") ? "♀ voice" : "♂ voice"); return true; });
        bar.addView(speaker);
        TextView fresh = tv("↻", 20, Color.WHITE); fresh.setPadding(dp(10), dp(2), dp(4), dp(2)); fresh.setContentDescription("new_chat");
        fresh.setOnClickListener(v -> newChat()); bar.addView(fresh);
        root.addView(bar);

        scroll = new ScrollView(this); msgs = new LinearLayout(this); msgs.setOrientation(LinearLayout.VERTICAL); msgs.setPadding(dp(10), dp(8), dp(10), dp(8));
        scroll.addView(msgs); root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        chips = new LinearLayout(this); chips.setPadding(dp(6), dp(4), dp(6), dp(4)); hs.addView(chips); root.addView(hs);

        LinearLayout in = new LinearLayout(this); in.setGravity(Gravity.CENTER_VERTICAL); in.setPadding(dp(6), dp(6), dp(6), dp(8)); in.setBackgroundColor(0xFFE8E2D0);
        TextView cam = circleBtn("📷", "photo", v -> takePhoto()); cam.setOnLongClickListener(v -> { pickPhoto(); return true; }); in.addView(cam);
        input = new EditText(this); input.setTextSize(17); input.setSingleLine(false); input.setMaxLines(4); input.setTextColor(INK);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND); input.setBackground(round(Color.WHITE, 22)); input.setPadding(dp(14), dp(10), dp(14), dp(10));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1); ip.setMargins(dp(6), 0, dp(6), 0);
        in.addView(input, ip); input.setContentDescription("message");
        mic = circleBtn("🎤", "mic", v -> speak()); in.addView(mic);
        TextView send = circleBtn("➤", "send", v -> sendTyped()); ((LinearLayout.LayoutParams) send.getLayoutParams()).leftMargin = dp(6); in.addView(send);
        root.addView(in);
        setContentView(root);

        try { transcript = new OutputStreamWriter(new FileOutputStream(new File(getExternalFilesDir(null), "transcript.jsonl"), true), "UTF-8"); } catch (Exception e) { Log.w(TAG, e); }
        IntentFilter f = new IntentFilter(TEST_ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(testReceiver, f, 2 /* RECEIVER_EXPORTED */); else registerReceiver(testReceiver, f);
        setLang(lang, false);
        bubble(false, loadingText(), null);
        worker.execute(() -> {
            try {
                long s = SystemClock.elapsedRealtime(); krishi = new Krishi(name -> getAssets().open(name));
                long ms = SystemClock.elapsedRealtime() - s; ui.post(() -> { log("loaded", "ms", ms); msgs.removeAllViews(); newChat(); });
            } catch (Throwable e) { Log.e(TAG, "load failed", e); ui.post(() -> bubble(false, "Error: " + e, null)); }
        });
    }
    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); o.putString("lang", lang); }
    @Override protected void onDestroy() {
        super.onDestroy(); try { unregisterReceiver(testReceiver); } catch (Exception ignored) {}
        stopVoice(); if (sr != null) sr.destroy(); if (listen != null) listen.release(); worker.shutdown(); voiceExec.shutdown(); Vision.release(); Nn.release();
    }

    String loadingText() { return pick("लोड हो रहा है…", "தயாராகுது…", "ಸಿದ್ಧವಾಗ್ತಿದೆ…", "Getting ready…"); }
    String pick(String hi, String ta, String kn, String en) { switch (lang) { case "hi": return hi; case "ta": return ta; case "kn": return kn; default: return en; } }
    String said(String s) { return Krishi.forVoice(s, lang, voice); }       // Hindi verbs follow the chosen voice

    void setLang(String l, boolean restart) {
        lang = l;
        for (int i = 0; i < 4; i++) { boolean on = LANGS[i].equals(l); langViews[i].setBackground(on ? round(0x55FFFFFF, 12) : null); langViews[i].setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT); }
        title.setText(pick("🌱 फसल डॉक्टर", "🌱 பயிர் டாக்டர்", "🌱 ಬೆಳೆ ಡಾಕ್ಟರ್", "🌱 Crop Doctor"));
        input.setHint(pick("अपनी फसल की दिक्कत लिखिए या बोलिए…", "பயிர் பிரச்சனையை எழுதுங்க அல்லது சொல்லுங்க…", "ಬೆಳೆ ಸಮಸ್ಯೆ ಬರೀರಿ ಅಥವಾ ಹೇಳ್ರಿ…", "Type or say your crop problem…"));
        if (restart && krishi != null) newChat();
    }

    void newChat() {
        if (krishi == null) return;
        stopVoice(); msgs.removeAllViews(); chips.removeAllViews(); tiles.clear(); waitBubble = null; chat = new Chat(krishi, lang, PIC_SKIP);
        String hello = said(krishi.cat("greet", lang)); bubble(false, hello, null); play(Collections.singletonList("greet")); log("app", "type", "greet", "say", hello);
    }

    // ------------------------------------------------------------------ bubbles
    View bubble(boolean me, String text, Bitmap img) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setBackground(round(me ? ME : APP, 16));
        box.setPadding(dp(12), dp(9), dp(12), dp(9)); box.setElevation(me ? 0 : dp(1));
        if (img != null) { ImageView iv = new ImageView(this); iv.setImageBitmap(img); iv.setAdjustViewBounds(true); iv.setMaxHeight(dp(220)); box.addView(iv); }
        if (text != null) { TextView t = tv(text, 17, INK); t.setLineSpacing(0, 1.15f); t.setTextIsSelectable(true); box.addView(t); }
        add(box, me); return box;
    }
    void add(View v, boolean me) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = me ? Gravity.END : Gravity.START; lp.setMargins(me ? dp(48) : 0, dp(4), me ? 0 : dp(48), dp(4)); msgs.addView(v, lp);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
    void diagnosisCard(Chat.Reply r) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setBackground(round(APP, 16)); box.setPadding(dp(14), dp(12), dp(14), dp(12)); box.setElevation(dp(2));
        String[] parts = said(r.say).split("\n", 2);
        TextView label = tv(pick("सबसे ज़्यादा संभावना:", "பெரும்பாலும் இது:", "ಹೆಚ್ಚಾಗಿ ಇದು:", "Most likely:"), 14, MUTED); box.addView(label);
        TextView name = tv(parts[0], 21, GREEN); name.setTypeface(Typeface.DEFAULT_BOLD); box.addView(name);
        TextView conf = tv(pick("भरोसा", "நம்பிக்கை", "ವಿಶ್ವಾಸ", "Confidence") + ": " + Math.round(r.confidence * 100) + "%", 13, MUTED); box.addView(conf);
        if (parts.length > 1) { TextView adv = tv(parts[1], 17, INK); adv.setPadding(0, dp(8), 0, dp(4)); adv.setLineSpacing(0, 1.15f); box.addView(adv); }
        if (r.source != null) { TextView src = tv(pick("स्रोत", "ஆதாரம்", "ಮೂಲ", "Source") + ": NIPHM / DPPQS, Govt. of India", 12, MUTED); box.addView(src); }
        box.addView(callButton());
        add(box, false);
    }
    View callButton() {
        TextView call = tv("📞 KVK / " + pick("किसान कॉल सेंटर", "கிசான் கால் சென்டர்", "ಕಿಸಾನ್ ಕಾಲ್ ಸೆಂಟರ್", "Kisan Call Centre") + " 1800-180-1551", 15, Color.WHITE);
        call.setBackground(round(GREEN, 12)); call.setPadding(dp(12), dp(8), dp(12), dp(8)); call.setContentDescription("call_kcc");
        call.setOnClickListener(v -> { try { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:18001801551"))); } catch (Exception e) { toast("1800-180-1551"); } });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.topMargin = dp(8); call.setLayoutParams(lp);
        return call;
    }

    // ------------------------------------------------------------------ chips + picture grid
    void showChips(Chat.Reply r) {
        chips.removeAllViews(); disableTiles();
        if (r == null || r.qid == null || r.buttons.isEmpty()) return;
        List<String> opts = new ArrayList<>(r.buttons);
        if (r.qid.startsWith("pic_")) {
            List<String> withPic = new ArrayList<>(); for (String o : r.buttons) if (hasPic(o)) withPic.add(o);
            if (!withPic.isEmpty()) { picGrid(r.qid, withPic); opts.removeAll(withPic); }
        }
        if (!r.qid.equals("__crop__")) opts.add("__dont_know__");
        for (String o : opts) {
            String label = krishi.optionLabel(r.qid, o, lang);
            TextView t = tv(label, 16, GREEN); t.setBackground(round(Color.WHITE, 20)); t.setPadding(dp(16), dp(10), dp(16), dp(10));
            t.setContentDescription("chip_" + o); t.setOnClickListener(v -> tap(o, label));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(dp(4), dp(2), dp(4), dp(2));
            chips.addView(t, lp);
        }
    }
    /** Picture question: a 3-column grid card inside the chat, so every photo is visible without sideways scrolling. */
    void picGrid(String qid, List<String> opts) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setBackground(round(APP, 16)); card.setPadding(dp(6), dp(6), dp(6), dp(6));
        int tile = (getResources().getDisplayMetrics().widthPixels - dp(20) - dp(12) - dp(36)) / 3; LinearLayout row = null;
        for (int i = 0; i < opts.size(); i++) {
            if (i % 3 == 0) { row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); card.addView(row); }
            final String o = opts.get(i); final String label = krishi.optionLabel(qid, o, lang);
            LinearLayout t = new LinearLayout(this); t.setOrientation(LinearLayout.VERTICAL); t.setPadding(dp(3), dp(3), dp(3), dp(3));
            ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setImageBitmap(loadPic(o)); iv.setBackground(round(0xFFEDEDED, 8));
            t.addView(iv, new LinearLayout.LayoutParams(tile, tile));
            TextView l = tv(label, 12, INK); l.setMaxLines(2); l.setMaxWidth(tile); t.addView(l);
            t.setContentDescription("chip_" + o); t.setOnClickListener(v -> { disableTiles(); tap(o, label); }); tiles.add(t);
            row.addView(t, new LinearLayout.LayoutParams(tile + dp(6), ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0, dp(4), 0, dp(4));
        msgs.addView(card, lp); scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
    void disableTiles() { for (View t : tiles) { t.setOnClickListener(null); t.setClickable(false); t.setAlpha(0.55f); t.setContentDescription(null); } tiles.clear(); }
    boolean hasPic(String o) { try { getAssets().open("pics/" + o + ".jpg").close(); return true; } catch (IOException e) { return false; } }
    Bitmap loadPic(String disease) {
        try (InputStream in = getAssets().open("pics/" + disease + ".jpg")) { return BitmapFactory.decodeStream(in); } catch (IOException e) { return null; }
    }

    // ------------------------------------------------------------------ turns
    void sendTyped() {
        String s = input.getText().toString().trim(); if (s.isEmpty() || krishi == null) return;
        input.setText(""); userText(s, false);
    }
    void userText(String s, boolean viaVoice) {
        if (krishi == null || chat == null) return;
        bubble(true, (viaVoice ? "🎤 " : "") + s, null); log("farmer", "text", s, "voice", viaVoice);
        run(() -> chat.turn(s, null));
    }
    void tap(String opt, String label) {
        if (chat == null || chat.lastQ == null) return;
        bubble(true, label, null); log("farmer", "tap", opt); run(() -> chat.turn(null, opt));
    }
    void run(Callable<Chat.Reply> c) {
        chips.removeAllViews(); final Chat cur = chat;
        worker.execute(() -> {
            try {
                long s = System.nanoTime(); Chat.Reply r = c.call(); double ms = (System.nanoTime() - s) / 1e6;
                ui.post(() -> { if (cur == chat) show(r, ms); });
            } catch (Throwable e) { Log.e(TAG, "turn failed", e); ui.post(() -> bubble(false, "Error: " + e, null)); }
        });
    }
    void show(Chat.Reply r, double ms) {
        if (waitBubble != null) { msgs.removeView(waitBubble); waitBubble = null; }
        Krishi.Photo ph = lastPhoto; lastPhoto = null;
        if (ph != null) log("app", "type", "vision", "label", ph.label, "score", Math.round(ph.score * 1000) / 1000.0, "disease", ph.disease, "ms", Math.round(ph.ms));
        if (r.note != null) bubble(false, said(r.note), null);
        if ("diagnosis".equals(r.type)) diagnosisCard(r);
        else { View b = bubble(false, said(r.say), null); if ("not_sure".equals(r.type) || "referral".equals(r.type) || "helpline".equals(r.action) || "refer_kcc".equals(r.action)) ((LinearLayout) b).addView(callButton()); }
        showChips(r); play(r.clips);
        log("app", "type", r.type, "qid", r.qid, "disease", r.disease, "action", r.action, "confidence", r.confidence, "note", r.note, "say", r.say, "ms", ms, "chips", r.buttons, "clips", r.clips, "facts", r.facts);
    }

    // ------------------------------------------------------------------ voice out (pre-rendered human voice clips)
    int played;
    void play(List<String> ids) {
        stopVoice(); if (!voiceOn) return;
        for (String id : ids) clipQueue.add(id); played = 0; next();
    }
    void next() {
        String id = clipQueue.poll();
        if (id == null) { if (played > 0) log("voice", "event", "done", "played", played); played = 0; return; }
        played++;
        AssetFileDescriptor fd;
        try { fd = getAssets().openFd("voice/" + voice + "/" + lang + "/" + id + ".ogg"); } catch (IOException e) { speakText(id, null); return; }
        try {
            player = new MediaPlayer(); player.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength()); fd.close();
            player.setOnCompletionListener(m -> { m.release(); if (player == m) player = null; next(); });
            player.setOnErrorListener((m, w, e) -> { log("voice", "event", "clip_error", "clip", id, "what", w); m.release(); if (player == m) player = null; next(); return true; });
            player.prepare(); player.start();
        } catch (Exception e) { log("voice", "event", "clip_missing", "clip", id, "err", String.valueOf(e)); next(); }
    }
    void stopVoice() {
        clipQueue.clear(); voiceGen++;
        if (player != null) { try { player.stop(); } catch (Exception ignored) {} player.release(); player = null; }
        if (track != null) { try { track.stop(); } catch (Exception ignored) {} track.release(); track = null; }
    }

    /** No pre-rendered clip for this id (e.g. a fact added after the build): OUR OWN TRAINED VOICE MODEL says the sentence,
     *  in the same voice as the clips. text != null: speak that text instead of a clip's sentence (test hook). */
    void speakText(String id, String text) {
        String t = text != null ? text : (krishi == null ? null : krishi.clipText(id, lang));
        if (t == null || t.trim().isEmpty()) { log("voice", "event", "clip_missing", "clip", id); next(); return; }
        final String say = said(t), l = lang, spk = voice.equals("m") ? "male" : "female"; final int gen = voiceGen;
        voiceExec.execute(() -> {
            long s0 = SystemClock.elapsedRealtime(); float[] pcm = null; String err = null; int sr = 16000;
            try { Speak sp = krishi.speak(); if (sp != null) { pcm = sp.synth(say, l, spk); sr = sp.sampleRate(); } else err = "no voice model"; }
            catch (Throwable e) { err = String.valueOf(e); }
            final long ms = SystemClock.elapsedRealtime() - s0; final float[] p = pcm; final String er = err; final int rate = sr;
            ui.post(() -> {
                if (gen != voiceGen) return;                                   // stopped meanwhile
                if (p == null || p.length == 0) { log("voice", "event", "tts_error", "clip", id, "err", er); next(); return; }
                log("voice", "event", "tts", "clip", id, "ms", ms, "sec", Math.round(p.length * 100.0 / rate) / 100.0);
                playPcm(p, rate);
            });
        });
    }
    void playPcm(float[] p, int rate) {
        short[] s16 = new short[p.length]; for (int i = 0; i < p.length; i++) s16[i] = (short) Math.max(-32767, Math.min(32767, Math.round(p[i] * 32767)));
        try {
            AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, s16.length * 2, AudioTrack.MODE_STATIC);
            t.write(s16, 0, s16.length); track = t; final int gen = voiceGen;
            t.setNotificationMarkerPosition(Math.max(1, s16.length - 1));
            t.setPlaybackPositionUpdateListener(new AudioTrack.OnPlaybackPositionUpdateListener() {
                @Override public void onMarkerReached(AudioTrack a) { if (gen != voiceGen) return; a.release(); if (track == a) track = null; next(); }
                @Override public void onPeriodicNotification(AudioTrack a) {}
            });
            t.play();
        } catch (Exception e) { log("voice", "event", "tts_play_error", "err", String.valueOf(e)); next(); }
    }

    // ------------------------------------------------------------------ voice in: on-device recogniser (offline), else the phone's voice typing
    boolean micOk() { return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED; }
    boolean whisperOk() { return Listen.hasModel(name -> getAssets().open(name), lang); }
    void speak() {
        if (listening) { if (sr != null) sr.stopListening(); if (listen != null) listen.stop(); setListening(false); return; }
        stopVoice();
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                if (SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return; }
                    listenOnDevice(); return;
                }
            } catch (Throwable t) { Log.w(TAG, "on-device recogniser", t); }
        }
        offlineOrIntent();
    }
    /** The phone has no offline recogniser for this language: our own Whisper model, else the system's voice typing. */
    void offlineOrIntent() {
        if (whisperOk()) { if (!micOk()) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO_W); return; } listenWhisper(); }
        else speakIntent();
    }
    @Override public void onRequestPermissionsResult(int req, String[] p, int[] g) {
        boolean ok = g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED;
        if (req == REQ_AUDIO) { if (ok) listenOnDevice(); else speakIntent(); }
        if (req == REQ_AUDIO_W) { if (ok) listenWhisper(); else speakIntent(); }
    }
    void listenWhisper() {
        try {
            if (listen == null) listen = new Listen(name -> getAssets().open(name), listenCb);
            listen.setLanguage(lang);
            if (listen.start()) { setListening(true); log("app", "type", "listening", "mode", "whisper"); } else speakIntent();
        } catch (Throwable t) { Log.w(TAG, t); setListening(false); speakIntent(); }
    }
    void dropWait() { if (waitBubble != null) { msgs.removeView(waitBubble); waitBubble = null; } }
    final Listen.Callback listenCb = new Listen.Callback() {
        @Override public void onReady() {} @Override public void onSpeech() {} @Override public void onLevel(float level) {}
        @Override public void onThinking() { setListening(false); waitBubble = bubble(false, "🎤 …", null); }
        @Override public void onResult(String text, double conf, Whisper.Result r) {
            setListening(false); dropWait();
            log("app", "type", "whisper", "text", text, "conf", Math.round(conf * 1000) / 1000.0, "ms", r.totalMs(), "unreliable", r.unreliable());
            if (text == null || text.trim().isEmpty() || r.unreliable()) didntHear(); else userText(text.trim(), true);
        }
        @Override public void onNothing(String reason) { setListening(false); dropWait(); log("app", "type", "whisper_nothing", "reason", reason); didntHear(); }
        @Override public void onError(Exception e) { setListening(false); dropWait(); log("app", "type", "whisper_error", "err", String.valueOf(e)); speakIntent(); }
    };
    void setListening(boolean on) { listening = on; mic.setText(on ? "■" : "🎤"); mic.setBackground(round(on ? RED : GREEN, 24)); }
    void listenOnDevice() {
        try {
            if (sr == null) { sr = SpeechRecognizer.createOnDeviceSpeechRecognizer(this); sr.setRecognitionListener(listener); }
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang + "-IN");
            sr.startListening(i); setListening(true); log("app", "type", "listening", "mode", "on_device");
        } catch (Throwable t) { Log.w(TAG, t); setListening(false); offlineOrIntent(); }
    }
    final RecognitionListener listener = new RecognitionListener() {
        @Override public void onResults(Bundle b) {
            setListening(false); ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (r != null && !r.isEmpty() && !r.get(0).trim().isEmpty()) userText(r.get(0), true); else didntHear();
        }
        @Override public void onError(int e) {
            setListening(false); log("app", "type", "mic_error", "code", e);
            if (e == 12 || e == 13 || e == 5 || e == 10) offlineOrIntent(); else didntHear();   // language not on device / client / busy -> our Whisper / voice typing
        }
        @Override public void onReadyForSpeech(Bundle b) {} @Override public void onBeginningOfSpeech() {} @Override public void onRmsChanged(float v) {}
        @Override public void onBufferReceived(byte[] b) {} @Override public void onEndOfSpeech() {} @Override public void onPartialResults(Bundle b) {} @Override public void onEvent(int t, Bundle b) {}
    };
    void didntHear() { String m = said(krishi.cat("didnt_hear", lang)); bubble(false, m, null); play(Collections.singletonList("didnt_hear")); log("app", "type", "didnt_hear", "say", m); }
    void speakIntent() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang + "-IN"); i.putExtra("android.speech.extra.PREFER_OFFLINE", true);
        try { startActivityForResult(i, REQ_MIC); log("app", "type", "listening", "mode", "system_voice_typing"); }
        catch (ActivityNotFoundException e) {
            String m = said(krishi.phrase("mic_unavailable", lang)); bubble(false, m, null); play(Collections.singletonList("mic_unavailable")); log("app", "type", "mic_unavailable", "say", m);
        }
    }

    // ------------------------------------------------------------------ photo: camera (full resolution via PhotoProvider) or gallery (long-press)
    void takePhoto() {
        File f = PhotoProvider.file(this); f.delete();
        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cam.putExtra(MediaStore.EXTRA_OUTPUT, Uri.parse("content://" + PhotoProvider.AUTH + "/photo.jpg"));
        cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(cam, REQ_CAM); log("app", "type", "camera_open"); } catch (ActivityNotFoundException e) { pickPhoto(); }
    }
    void pickPhoto() {
        Intent p = new Intent(Intent.ACTION_GET_CONTENT); p.setType("image/*");
        try { startActivityForResult(p, REQ_PICK); } catch (ActivityNotFoundException e) { toast("No camera / gallery"); }
    }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK) return;
        if (req == REQ_MIC && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) userText(r.get(0), true);
        } else if (req == REQ_CAM) {
            Bitmap bm = null; File f = PhotoProvider.file(this);
            try {
                if (f.length() > 0) bm = decodeFile(f.getPath());
                else if (data != null && data.getExtras() != null && data.getExtras().get("data") instanceof Bitmap) bm = (Bitmap) data.getExtras().get("data");   // thumbnail-only camera apps
            } catch (Throwable e) { Log.w(TAG, e); }
            photoAdded(bm, "camera");
        } else if (req == REQ_PICK && data != null && data.getData() != null) {
            Bitmap bm = null; try { bm = decodeUri(data.getData()); } catch (Throwable e) { Log.w(TAG, e); }
            photoAdded(bm, "gallery");
        }
    }
    static int sample(int w, int h) { int s = 1; while (Math.min(w, h) / (s * 2) >= 512) s *= 2; return s; }   // keep >= 512 px for a clean 256 px resize
    static Bitmap decodeFile(String path) {
        BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true; BitmapFactory.decodeFile(path, o);
        o.inSampleSize = sample(o.outWidth, o.outHeight); o.inJustDecodeBounds = false;
        int or = 1; try { or = new ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1); } catch (Exception ignored) {}
        return rotate(BitmapFactory.decodeFile(path, o), or);
    }
    Bitmap decodeUri(Uri u) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        o.inSampleSize = sample(o.outWidth, o.outHeight); o.inJustDecodeBounds = false; Bitmap b;
        try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o); }
        int or = 1;
        if (Build.VERSION.SDK_INT >= 24) try (InputStream in = getContentResolver().openInputStream(u)) { or = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1); } catch (Exception ignored) {}
        return rotate(b, or);
    }
    static Bitmap rotate(Bitmap b, int orientation) {
        int deg = orientation == 6 ? 90 : orientation == 3 ? 180 : orientation == 8 ? 270 : 0;
        if (b == null || deg == 0) return b;
        Matrix m = new Matrix(); m.postRotate(deg); return Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
    }
    /** Same framing as training: centre square -> 256 x 256 -> centre 224 x 224, RGB 0..255, channel-first. */
    static float[] toChw(Bitmap src) {
        int w = src.getWidth(), h = src.getHeight(), s = Math.min(w, h);
        Bitmap cur = Bitmap.createBitmap(src, (w - s) / 2, (h - s) / 2, s, s);
        while (cur.getWidth() >= 512) cur = Bitmap.createScaledBitmap(cur, cur.getWidth() / 2, cur.getHeight() / 2, true);   // step down: no aliasing
        Bitmap b = Bitmap.createScaledBitmap(cur, 256, 256, true);
        int n = 224 * 224; int[] px = new int[n]; b.getPixels(px, 0, 224, 16, 16, 224, 224); float[] x = new float[3 * n];
        for (int i = 0; i < n; i++) { int c = px[i]; x[i] = (c >> 16) & 255; x[n + i] = (c >> 8) & 255; x[2 * n + i] = c & 255; }
        return x;
    }
    void photoAdded(Bitmap bm, String from) {
        if (bm == null) { toast(pick("फोटो नहीं मिली", "போட்டோ கிடைக்கல", "ಫೋಟೋ ಸಿಗಲಿಲ್ಲ", "No photo")); return; }
        if (krishi == null || chat == null) return;
        int w = bm.getWidth(), h = bm.getHeight(); float k = Math.min(1f, 640f / Math.max(w, h));
        bubble(true, null, k < 1 ? Bitmap.createScaledBitmap(bm, Math.round(w * k), Math.round(h * k), true) : bm); log("farmer", "photo", from, "w", w, "h", h);
        stopVoice(); waitBubble = bubble(false, said(pick("फोटो देख रही हूँ…", "போட்டோவைப் பார்க்கிறேன்…", "ಫೋಟೋ ನೋಡ್ತಿದೀನಿ…", "Looking at the photo…")), null);
        final Bitmap src = bm;
        run(() -> { Krishi.Photo ph = krishi.photo(toChw(src)); lastPhoto = ph; return chat.photo(ph); });
    }

    // ------------------------------------------------------------------ test hook (adb shell am broadcast -a in.krishi.doctor.TEST ...)
    final BroadcastReceiver testReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String cmd = i.getStringExtra("cmd"); if (cmd == null) return;
            switch (cmd) {
                case "text": userText(new String(Base64.decode(i.getStringExtra("b64"), Base64.DEFAULT), java.nio.charset.StandardCharsets.UTF_8), false); break;
                case "voice": userText(new String(Base64.decode(i.getStringExtra("b64"), Base64.DEFAULT), java.nio.charset.StandardCharsets.UTF_8), true); break;
                case "tap": { String o = i.getStringExtra("opt"); tap(o, krishi.optionLabel(chat.lastQ == null ? "" : chat.lastQ, o, lang)); break; }
                case "lang": setLang(i.getStringExtra("lang"), true); break;
                case "voiceoff": voiceOn = false; speaker.setText("🔇"); stopVoice(); break;
                case "voiceon": voiceOn = true; speaker.setText("🔊"); break;
                case "male": voice = "m"; break;
                case "female": voice = "f"; break;
                case "photo": { String p = i.getStringExtra("path"); photoAdded(p != null ? decodeFile(p) : null, "test"); break; }
                case "photochunk": {   // test photos arrive as base64 chunks (no storage permission needed on any Android version)
                    int idx = Integer.parseInt(i.getStringExtra("idx")), n = Integer.parseInt(i.getStringExtra("n"));
                    if (idx == 0) testPhoto.reset();
                    byte[] part = Base64.decode(i.getStringExtra("b64"), Base64.DEFAULT); testPhoto.write(part, 0, part.length);
                    if (idx == n - 1) {
                        File f = new File(getCacheDir(), "test_photo.jpg");
                        try (FileOutputStream o = new FileOutputStream(f)) { testPhoto.writeTo(o); } catch (IOException e) { Log.w(TAG, e); }
                        photoAdded(decodeFile(f.getPath()), "test");
                    }
                    break;
                }
                case "asrchunk": {     // test speech: 16 kHz mono 16-bit PCM WAV in base64 chunks -> our Whisper -> a farmer turn
                    int idx = Integer.parseInt(i.getStringExtra("idx")), n = Integer.parseInt(i.getStringExtra("n"));
                    if (idx == 0) testAudio.reset();
                    byte[] part = Base64.decode(i.getStringExtra("b64"), Base64.DEFAULT); testAudio.write(part, 0, part.length);
                    if (idx == n - 1) { final byte[] wav = testAudio.toByteArray(); final String l = lang; worker.execute(() -> testAsr(wav, l)); }
                    break;
                }
                case "tts": { stopVoice(); voiceOn = true; speakText("test", new String(Base64.decode(i.getStringExtra("b64"), Base64.DEFAULT), java.nio.charset.StandardCharsets.UTF_8)); break; }
                case "mic": speak(); break;
                case "new": newChat(); break;
            }
        }
    };
    /** Test hook body: run our Whisper on a WAV (16 kHz mono PCM16) exactly as Listen does, then use the text as a turn. */
    void testAsr(byte[] wav, String l) {
        try {
            if (testWhisper == null || !testWhisper.lang.equals(l)) testWhisper = Whisper.fromRes(name -> getAssets().open(name), l);
            int off = 44;
            for (int j = 12; j + 8 <= wav.length; ) {
                String id = new String(wav, j, 4, "US-ASCII"); int sz = (wav[j + 4] & 255) | (wav[j + 5] & 255) << 8 | (wav[j + 6] & 255) << 16 | (wav[j + 7] & 255) << 24;
                if (id.equals("data")) { off = j + 8; break; }
                j += 8 + sz;
            }
            int n = (wav.length - off) / 2; float[] pcm = new float[n];
            for (int j = 0; j < n; j++) pcm[j] = (short) ((wav[off + 2 * j] & 255) | (wav[off + 2 * j + 1] << 8)) / 32768f;
            long s0 = SystemClock.elapsedRealtime(); Whisper.Result r = testWhisper.transcribe(pcm, n, false); long ms = SystemClock.elapsedRealtime() - s0;
            ui.post(() -> {
                log("app", "type", "whisper", "text", r.text, "conf", Math.round(r.confidence() * 1000) / 1000.0, "ms", ms, "audio_s", Math.round(n / 160.0) / 100.0,
                    "enc_ms", r.encMs, "dec_ms", r.decMs, "unreliable", r.unreliable());
                if (r.text != null && !r.text.trim().isEmpty()) userText(r.text.trim(), true); else didntHear();
            });
        } catch (Throwable e) { Log.e(TAG, "test asr", e); ui.post(() -> log("app", "type", "whisper_error", "err", String.valueOf(e))); }
    }

    void log(String who, Object... kv) {
        StringBuilder b = new StringBuilder("{\"who\":\"").append(who).append("\",\"t\":").append(SystemClock.elapsedRealtime() - t0).append(",\"lang\":\"").append(lang).append('"');
        for (int i = 0; i + 1 < kv.length; i += 2) b.append(",\"").append(kv[i]).append("\":").append(js(kv[i + 1]));
        String line = b.append('}').toString(); Log.i(TAG, line);
        try { if (transcript != null) { transcript.write(line + "\n"); transcript.flush(); } } catch (IOException ignored) {}
    }
    static String js(Object o) {
        if (o == null) return "null";
        if (o instanceof Number || o instanceof Boolean) return o.toString();
        if (o instanceof List) { StringBuilder b = new StringBuilder("["); for (Object x : (List<?>) o) { if (b.length() > 1) b.append(','); b.append(js(x)); } return b.append(']').toString(); }
        String s = o.toString(); StringBuilder b = new StringBuilder("\"");
        for (char ch : s.toCharArray()) { if (ch == '"' || ch == '\\') b.append('\\').append(ch); else if (ch == '\n') b.append("\\n"); else if (ch < 0x20) b.append(' '); else b.append(ch); }
        return b.append('"').toString();
    }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
