#!/bin/sh
# FactLM Java/Python parity test. Usage: sh android/test/factlm/run_parity.sh [case dir] [--ckpt factlm/runs/seed/best.pt]
set -e
cd "$(dirname "$0")/../../.."          # repo root
OUT=${1:-/tmp/factlm_case}
[ $# -gt 0 ] && shift
python3 android/test/factlm/make_factlm_case.py "$OUT" "$@"
mkdir -p "$OUT/classes"
javac -nowarn -encoding UTF-8 --release 8 -d "$OUT/classes" android/src/in/krishi/doctor/Krw.java android/src/in/krishi/doctor/Nn.java \
  android/src/in/krishi/doctor/Json.java android/src/in/krishi/doctor/TextModel.java android/src/in/krishi/doctor/FactLM.java \
  android/src/in/krishi/doctor/FactLMKernels.java \
  android/test/factlm/FactLMTest.java
DIRS="$OUT/random $OUT/tiny"
[ -d "$OUT/trained" ] && DIRS="$DIRS $OUT/trained"
# -XX:ActiveProcessorCount=4 lets the kernel pool start 4 workers even on a 2-core sandbox (timings then oversubscribe)
java -XX:ActiveProcessorCount=4 -cp "$OUT/classes" FactLMTest $DIRS
