import in.krishi.doctor.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * FactLM parity: Java FactLM vs PyTorch on the same exported weights (make_factlm_case.py writes factlm.json/.bin + ref.json).
 * Pass = identical item sequences for every case and max |logit diff| < 1e-3. Also checks scores, slots, target head,
 * and times answer() with 1 and 4 worker threads.   java -cp <classes> FactLMTest <case dir> [<case dir> ...]
 */
@SuppressWarnings("unchecked")
public class FactLMTest {
    static String read(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return new String(b.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    public static void main(String[] args) throws Exception {
        boolean all = true;
        for (String dir : args) all &= run(new File(dir));
        System.out.println(all ? "FACTLM PARITY OK" : "FACTLM PARITY FAIL");
        Nn.release();
        if (!all) System.exit(1);
    }

    static boolean run(File dir) throws Exception {
        long t0 = System.nanoTime();
        FactLM m = FactLM.load(dir);
        double loadMs = (System.nanoTime() - t0) / 1e6;
        List<Object> cases = (List<Object>) ((Map<String, Object>) Json.parse(read(new File(dir, "ref.json")))).get("cases");
        double maxLogit = 0, maxScore = 0, maxSlot = 0, maxTgt = 0; int same = 0, sameTarget = 0, n = 0; List<String> bad = new ArrayList<>();
        for (Object o : cases) {
            Map<String, Object> c = (Map<String, Object>) o; n++;
            String text = (String) c.get("text"), crop = (String) c.get("crop"), target = (String) c.get("target");
            FactLM.Result r = m.answer(text, crop, target);
            List<Object> items = (List<Object>) c.get("items"), scores = (List<Object>) c.get("scores"), logits = (List<Object>) c.get("logits");
            boolean eq = items.size() == r.items.size();
            for (int i = 0; eq && i < items.size(); i++) eq = items.get(i).equals(r.items.get(i));
            if (eq) same++; else bad.add(text.length() > 40 ? text.substring(0, 40) + "..." : text);
            int steps = Math.min(logits.size(), r.logits.length);
            for (int s = 0; s < steps; s++) {
                List<Object> row = (List<Object>) logits.get(s);
                for (int i = 0; i < row.size(); i++) maxLogit = Math.max(maxLogit, Math.abs(((Double) row.get(i)) - r.logits[s][i]));
            }
            for (int i = 0; i < Math.min(scores.size(), r.scores.length); i++) maxScore = Math.max(maxScore, Math.abs((Double) scores.get(i) - r.scores[i]));
            double[] sl = m.slots(text); List<Object> rs = (List<Object>) c.get("slots");
            for (int i = 0; i < sl.length; i++) maxSlot = Math.max(maxSlot, Math.abs(sl[i] - (Double) rs.get(i)));
            Object tp = c.get("target_pred");
            if (Objects.equals(tp, r.target)) sameTarget++;
            maxTgt = Math.max(maxTgt, Math.abs((Double) c.get("target_prob") - r.targetScore));
        }
        boolean ok = same == n && maxLogit < 1e-3;
        System.out.printf(Locale.ROOT, "%s: load %.0f ms | %d/%d identical item sequences | max |logit diff| %.2e | max |score diff| %.2e | "
                + "max |slot diff| %.2e | target head %d/%d same (max |p diff| %.2e) -> %s%n", dir.getName(), loadMs, same, n, maxLogit, maxScore,
                maxSlot, sameTarget, n, maxTgt, ok ? "OK" : "FAIL " + bad);
        // speed: 1 and 4 worker threads, every case answered 5 times after warm-up. With 1 thread all work runs on this
        // thread, so its CPU time is also reported (wall time is inflated when other processes share the CPU).
        java.lang.management.ThreadMXBean mx = java.lang.management.ManagementFactory.getThreadMXBean();
        for (int th : new int[]{1, 4}) {
            FactLM.threads(th);
            for (int w = 0; w < 3; w++) for (Object o : cases) { Map<String, Object> c = (Map<String, Object>) o; m.answer((String) c.get("text"), (String) c.get("crop"), (String) c.get("target")); }
            long t = System.nanoTime(), cpu = mx.getCurrentThreadCpuTime(); int k = 0; double worst = 0; int steps = 0;
            for (int rep = 0; rep < 5; rep++) for (Object o : cases) {
                Map<String, Object> c = (Map<String, Object>) o;
                FactLM.Result r = m.answer((String) c.get("text"), (String) c.get("crop"), (String) c.get("target")); k++; worst = Math.max(worst, r.ms); steps += r.items.size();
            }
            double wall = (System.nanoTime() - t) / 1e6 / k, cpuMs = (mx.getCurrentThreadCpuTime() - cpu) / 1e6 / k;
            System.out.printf(Locale.ROOT, "  %d thread(s): %.2f ms / question wall%s (mean of %d, worst %.1f ms, %.1f decoder steps)%n", th, wall,
                    th == 1 ? String.format(Locale.ROOT, ", %.2f ms CPU", cpuMs) : "", k, worst, steps / (double) k);
        }
        FactLM.threads(4);
        return ok;
    }
}
