"""FactLM Java/Python parity cases.

Exports two models with factlm/export.py and writes reference outputs computed by PyTorch on the SAME exported weights
(int8 tensors dequantised), for ~50 questions: 4 languages, native/romanized/code-mixed, empty, punctuation-only,
very long (truncation), and different app contexts (crop known, disease confirmed, unknown crop/target).
  <out>/random/   random-init model (full size: d=160, NB=2^16, 4+2 layers)
  <out>/tiny/     tiny model (d=64, NB=2^12, 2+1 layers) trained ~80 steps on the seed data
  <out>/<model>/ref.json: per case items, scores, raw logits per step, slots, target head
Optional: --ckpt factlm/runs/seed/best.pt adds <out>/trained/ (the smoke-trained model).

  python3 android/test/factlm/make_factlm_case.py /tmp/factlm_case
Then compile and run FactLMTest.java (see run_parity.sh).
"""
import json
import os
import random
import sys

import torch

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "factlm"))
import facts_lib as FL  # noqa: E402
from export import export, load_exported  # noqa: E402
from model import DEFAULT_CFG, FactLM, load_checkpoint  # noqa: E402

LONG = ("मेरे खेत में टमाटर की फसल है और पिछले दो हफ्ते से लगातार बारिश हो रही है पत्तियों पर भूरे धब्बे आ रहे हैं जिनमें गोल गोल छल्ले "
        "दिख रहे हैं नीचे की पत्तियां पीली होकर गिर रही हैं पड़ोसी ने बताया कि यह अगेती झुलसा हो सकता है मैंने पहले नीम का तेल डाला था "
        "पर कोई फायदा नहीं हुआ अब मुझे बताइए कि कौन सी दवा कितनी मात्रा में डालूं और कब डालूं ताकि फसल बच जाए")
CASES = [
    ("धान में झोंका रोग लग गया है, क्या दवाई डालूं?", None, None),
    ("धान में झोंका रोग लग गया है, क्या दवाई डालूं?", "rice", "rice_blast"),
    ("झोंका रोग के लिए ट्राइसाइक्लाजोल कितना ग्राम प्रति लीटर डालें?", None, None),
    ("झोंका रोग के लिए ट्राइसाइक्लाजोल कितना ग्राम प्रति लीटर डालें?", "rice", "rice_blast"),
    ("टमाटर के पत्ते मुड़ रहे है सिकुड़ गए, क्या करें भाई", "tomato", None),
    ("मिर्ची पे सफेद पाउडर जैसा जम गया पत्तों पे, इलाज बताओ", None, None),
    ("मूंगफली में टिक्का रोग का कोई देसी उपाय?", "groundnut", None),
    ("आज मैच कौन जीतेगा", None, None),
    ("கடலை செடில துரு நோய் வந்திருக்கு மருந்து சொல்லுங்க", None, None),
    ("கடலை துரு நோய் மருந்து ஏக்கருக்கு எவ்வளவு", "groundnut", "groundnut_rust"),
    ("தக்காளி இலை சுருண்டு போகுது, என்ன பண்றது?", "tomato", "tomato_leaf_curl"),
    ("நெல்லுல துங்ரோ வராம தடுக்க என்ன செய்யணும்", None, None),
    ("ஒரு ஜோக் சொல்லு", None, None),
    ("ಭತ್ತಕ್ಕೆ ಬೆಂಕಿ ರೋಗ ಬಂದಿದೆ ಏನು ಔಷಧಿ ಹೊಡಿಬೇಕು", None, None),
    ("ಮೆಣಸಿನಕಾಯಿ ಬೂದಿ ರೋಗ ತಡೆಗಟ್ಟುವ ವಿಧಾನ", "chilli", None),
    ("ಒಂದು ಟ್ಯಾಂಕ್‌ಗೆ ಎಷ್ಟು ಔಷಧಿ ಹಾಕಬೇಕು", "chilli", "chilli_powdery_mildew"),
    ("ನಾಳೆ ಮಳೆ ಬರುತ್ತಾ", None, None),
    ("groundnut rust treatment pls", None, None),
    ("how many grams tricyclazole per litre for rice blast", "rice", "rice_blast"),
    ("tomato leaves have brown spots with concentric rings like target board", None, None),
    ("organic remedy for leaf curl in tomato?", "tomato", None),
    ("how to prevent late blight next season", "tomato", "tomato_late_blight"),
    ("crop insurance claim process", None, None),
    ("dhan me jhonka rog lag gaya kya spray karu", None, None),
    ("mungfali tikka ke liye ek acre me kitni dawa", "groundnut", "groundnut_late_leaf_spot"),
    ("mirchi safed powder me chhachh spray kar sakte hai", None, None),
    ("tamatar me patta marod rog se kaise bache", None, None),
    ("kal barish hogi kya", None, None),
    ("kadalai la thuru noi vandhuchu marundhu sollunga", None, None),
    ("kulai noi ku tricyclazole litre ku evlo gram", "rice", "rice_blast"),
    ("thakkali pin karugal mazhai kaalathula varama thadukka", "tomato", None),
    ("bore adikudhu edhavadhu pesu", None, None),
    ("bhattakke benki roga bandide yenu spray maadbeku", None, None),
    ("menasinakai gidakke boodi roga, aushadhi yenu", "chilli", None),
    ("shenga ge tukku roga bandide parihara heli", "groundnut", "groundnut_rust"),
    ("tomato में leaf curl है, कौन सा medicine spray करें?", None, None),
    ("நெல் blast க்கு spray dose என்ன", "rice", "rice_blast"),
    ("ಟೊಮೆಟೊ early blight ಗೆ organic ಔಷಧಿ", "tomato", None),
    ("", None, None),
    ("", "tomato", "tomato_early_blight"),
    ("???!!! ... ।।", None, None),
    ("   ", "rice", None),
    ("1800 180 1551", None, None),
    (LONG, None, None),
    (LONG, "tomato", "tomato_early_blight"),
    (" ".join(["dhan"] * 45 + ["jhonka", "rog", "dawa"]), None, None),
    ("cotton me sundi lag gayi kya dale", "cotton", None),
    ("what medicine for this disease", None, "rice_unknown_disease"),
    ("TOMATO LEAF CURL!!! Whitefly??", "tomato", None),
    ("Hello 🙏 मिर्च के पत्ते पीले 🌶️", None, None),
    ("groundnut rust spray dose per acre", "groundnut", "groundnut_late_leaf_spot"),     # names another disease: dose gate
    ("tomato late blight mancozeb kitna dalna hai", "tomato", "tomato_early_blight"),
]


def reference(model, cases):
    out = []
    for text, crop, target in cases:
        bt = model.make_batch([text], crops=[crop], targets=[target])
        g = model.generate(bt, return_logits=True)[0]
        slots, tdist = model.heads(model.make_batch([text]))
        _, td = model.heads(bt)
        tp, ti = td[0].max(-1)
        lg = g["logits"]
        margins = []
        with torch.no_grad():
            mem, valid = model.encode(bt)
            base = model.gated_allowed(mem, valid, bt["crop"], bt["target"], bt.get("lexgate"))[0]
        for s, it in enumerate(g["item_idx"]):          # top-1 vs top-2 margin among allowed items (near-tie check)
            l = torch.tensor(lg[s])
            allowed = base.clone()
            for k in g["item_idx"][:s]:
                allowed[k] = False
            if s == 0:
                allowed[0] = False
            v = torch.sort(l[allowed], descending=True).values
            margins.append(float(v[0] - v[1]) if len(v) > 1 else 1e9)
        out.append({"text": text, "crop": crop, "target": target, "items": g["items"], "scores": g["scores"],
                    "logits": [[float(x) for x in row] for row in lg], "min_margin": min(margins),
                    "slots": [float(x) for x in slots[0]], "target_pred": model.meta["ctx_targets"][int(ti)] if int(ti) >= 2 else None,
                    "target_prob": float(tp), "lexgate": bool(bt["lexgate"][0]) if "lexgate" in bt else False})
    return out


def write_case(model, d, facts):
    os.makedirs(d, exist_ok=True)
    export(model, d, "factlm", facts, {"slot_threshold": 0.5})
    ref_model, _ = load_exported(os.path.join(d, "factlm.json"), os.path.join(d, "factlm.bin"))
    ref = reference(ref_model, CASES)
    json.dump({"cases": ref}, open(os.path.join(d, "ref.json"), "w", encoding="utf-8"), ensure_ascii=False)
    n_ctrl = sum(1 for c in ref if c["items"] and c["items"][-1] in FL.STOP)
    kinds = {}
    for c in ref:
        for x in c["items"]:
            k = x if x in FL.STOP else ("target-less dose" if x == "rice.weed.dose.1" else "general" if x.startswith("general.") else "fact")
            kinds[k] = kinds.get(k, 0) + 1
    gated = sum(1 for c in ref if c["target_pred"] and c["target_pred"] != c["target"])
    kinds["dose gate fired"] = gated
    kinds["name guard fired"] = sum(1 for c in ref if c.get("lexgate"))
    print(f"{d}: {len(ref)} cases, {os.path.getsize(os.path.join(d, 'factlm.bin')) / 1e6:.1f} MB, min top-2 margin "
          f"{min(c['min_margin'] for c in ref):.2e}, {n_ctrl} end with a control token; items output {kinds}")


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/factlm_case"
    ckpt = sys.argv[sys.argv.index("--ckpt") + 1] if "--ckpt" in sys.argv else None
    torch.manual_seed(0)
    random.seed(0)
    facts = FL.load_facts(os.path.join(ROOT, "facts", "seed_facts.jsonl"))
    app = json.load(open(os.path.join(ROOT, "factlm", "assets", "app_diseases.json")))
    items = FL.Items(facts, targets=list(app))
    meta = items.meta_json()
    meta["app_crops"] = app
    slots = list(json.load(open(os.path.join(ROOT, "slots.json"))))
    # 1) random-init, full size, plus two synthetic facts that exercise the other mask paths: a target-less dose fact
    #    (allowed only without a confirmed target) and a 'general' fact (allowed for every crop); both get a high bias
    #    so that they are actually picked when allowed. Rules 7-8 are off so the plain argmax path is compared too.
    syn = [dict(facts[0], id="rice.weed.dose.1", crop="rice", topic="weed", target=None, kind="dose", requires_confirmed=True, order=0),
           dict(facts[1], id="general.pesticide_safety.info.1", crop="general", topic="pesticide_safety", target=None, kind="info",
                requires_confirmed=False, order=0)]   # different texts and biases: no exact logit ties
    items_r = FL.Items(facts + syn, targets=list(app))
    meta_r = items_r.meta_json()
    meta_r["app_crops"] = app
    m = FactLM(dict(DEFAULT_CFG, min_first_prob=0.0, text_crop_min=0.0), meta_r, slots).eval()
    m.init_items_from_text(items_r.fact)
    with torch.no_grad():
        m.items_b.normal_(0, 0.5)
        for x, b in (("rice.weed.dose.1", 4.0), ("general.pesticide_safety.info.1", 3.3)):
            m.items_b[meta_r["ids"].index(x)] = b
        m.target_head.bias[0] += 1.0          # target head says <none> for some inputs, so the dose gate fires only sometimes
        for name, p in m.named_parameters():
            if name.endswith(("ln1.weight", "ln2.weight", "ln3.weight", "_ln.weight")):
                p.normal_(1.0, 0.1)
    write_case(m, os.path.join(out, "random"), facts + syn)
    # 2) tiny model trained ~80 steps on the seed data (also exercises train.py end to end)
    sys.path.insert(0, os.path.join(ROOT, "factlm"))
    import train as TR
    tdir = os.path.join(out, "tiny_run")
    TR.main(["--out", tdir, "--max-steps", "80", "--eval-every", "80", "--d", "64", "--heads", "4", "--ffn", "256",
             "--enc-layers", "2", "--dec-layers", "1", "--nb", "4096", "--threads", "1", "--aux-every", "2", "--warmup", "20"])
    tm, _ = load_checkpoint(os.path.join(tdir, "best.pt"))
    write_case(tm, os.path.join(out, "tiny"), facts)
    if ckpt:
        cm, _ = load_checkpoint(ckpt)
        write_case(cm, os.path.join(out, "trained"), facts)


if __name__ == "__main__":
    main()
