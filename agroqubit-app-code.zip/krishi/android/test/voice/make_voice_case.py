"""KrishiVoice Java-parity cases (SpeakTest.java reads them).

For each model it writes <out>/<name>/{voice.json, voice_am.bin, voice_voc.bin, refs.krw, cases.json}:
  random  : full-size (base) AM + vocoder, random init (duration bias set so speech runs ~5 frames/token)
  trained : the tiny model from the CPU smoke training (or any --am/--voc checkpoints)
References are computed by PyTorch with the EXPORTED weights (int8/fp16 dequantised), one thread, float32:
token ids, durations, log-durations, pitch, mel [T][80] and the vocoder waveform of that mel (first sentence), and the
full infer.synth() output of the whole text, for one text per language and speaker, plus a ~3 s sentence for speed. cases.json also has normalisation cases (text.py).
Usage: python3 make_voice_case.py <out_dir> [--am runs/am_smoke/final.pt --voc runs/voc_smoke/final.pt]
"""
import argparse, json, os, sys
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
KRISHI = os.path.dirname(os.path.dirname(os.path.dirname(HERE)))          # android/test/voice -> krishi
sys.path.insert(0, os.path.join(KRISHI, "android", "tools"))
sys.path.insert(0, os.path.join(KRISHI, "voice", "student"))
import text as T
from krw import write_krw1, f32
from export import export, load_exported, load_checkpoints
from model_am import AcousticModel, AMConfig
from model_voc import Vocoder, VocConfig
from infer import synth as py_synth

SENTENCES = [  # (lang, speaker, raw text) - one per language/speaker, digits and punctuation included
    ("hi", "female", "नमस्ते जी। मैंकोज़ेब पचहत्तर परसेंट, दो सौ लीटर पानी में मिलाइए।"),
    ("hi", "male", "किसान कॉल सेंटर का नंबर 1800 है।"),
    ("ta", "female", "வணக்கம்ங்க. ஒரு ஏக்கருக்கு இருநூறு லிட்டர் தண்ணீர் போதும்."),
    ("ta", "male", "இலையில் பழுப்பு புள்ளிகள் இருக்கா?"),
    ("kn", "female", "ನಮಸ್ಕಾರ್ರಿ. ನಿಮ್ ಬೆಳೆ ಯಾವುದು?"),
    ("kn", "male", "ಎರಡು ಗ್ರಾಂ ಪುಡಿಯನ್ನ ಒಂದು ಲೀಟರ್ ನೀರಿಗೆ ಹಾಕಿ."),
    ("en", "female", "Spray 2.5 grams per litre of water in the evening, okay?"),
    ("en", "male", "Please call the KVK for help!"),
]
SPEED_TEXT = ("hi", "female", "पत्तियों पर भूरे धब्बे हैं, तो शाम को दवाई छिड़किए")  # ~3 s


def fuzz_strings(n=300, seed=7):
    """Random mixed-script strings for normaliser parity: letters/marks of all scripts, digits of 4 systems, mapped and
    unmapped punctuation, zero-width marks, accents, nukta forms, emoji (surrogate pairs in Java), odd spacing."""
    import random
    rng = random.Random(seed)
    pool = (list("कखगज़ड़फ़क़ािीुूेैोौंँः्ऋअआइनमस्तेजी") + ["\u0915\u093c", "\u0958"] + list("அஆஇகஙசஞடணதநபமயரலவழளறனாிீுூெேைொோௌ்ஜஷஸஹ")
            + list("ಅಆಇಕಖಗಚಜಟಡಣತದನಪಬಮಯರಲವಶಸಹಳಾಿೀುೂೆೇೈೊೋೌ್ಂಃ") + list("abcXYZéÉçñÜß") + list("0123456789०१२३४५६७८९௦௧௨௩௪௫௬௭௮௯೦೧೨೩೪೫೬೭೮೯")
            + list(".,?!;:—–()[]{}'‘’`|।॥…¿¡؟-/@#%&*+=\"<>_~") + [" ", "  ", "\t", "\n", "\u00a0", "\u200c", "\u200d", "\u200b", "\ufeff", "\u00ad", "🌾", "👍🏽", "©", "ﬁ"])
    out = []
    for i in range(n):
        lang = T.LANGS[i % 4]; k = rng.randint(0, 40)
        out.append((lang, "".join(rng.choice(pool) for _ in range(k))))
    return out


def random_models(seed=0):
    torch.manual_seed(seed)
    am = AcousticModel(AMConfig.preset("base")).eval(); voc = Vocoder(VocConfig.preset("base")).eval()
    with torch.no_grad():
        am.dur.out.weight.mul_(0.05); am.dur.out.bias.fill_(float(np.log1p(4.6)))   # ~4.6 frames per token
        am.pitch.out.weight.mul_(0.3)
    stats = {v: (float(np.log(200.0 if v % 2 == 0 else 120.0)), 0.2) for v in range(8)}
    return am, voc, stats


def make(out, am, voc, stats, extra):
    os.makedirs(out, exist_ok=True)
    sizes = export(am, voc, out, stats, quant=True, extra=extra)
    amq, vocq, j = load_exported(out)               # the phone's exact weights
    torch.set_num_threads(1)
    refs, cases = {}, {"synth": [], "norm": []}
    for lang, t in list(T.TEST_STRINGS) + fuzz_strings():
        n = T.normalize(t, lang); cases["norm"].append({"lang": lang, "text": t, "norm": n, "sentences": T.split_sentences(n),
                                                        "ids": [T.encode(s) for s in T.split_sentences(n)]})
    items = [(l, s, t, False) for l, s, t in SENTENCES] + [(*SPEED_TEXT, True)]
    for i, (lang, spk, raw, speed) in enumerate(items):
        sent = T.split_sentences(T.normalize(raw, lang))[0 if not speed else 0]
        ids = T.encode(sent); li, vi = T.lang_id(lang), T.voice_id(lang, spk)
        with torch.no_grad():
            mel, dur, logd, pitch = amq.infer(ids, li, vi)
            wav = vocq.infer(mel)
        p = f"c{i}."
        refs[p + "ids"] = f32(np.asarray(ids, np.float32)); refs[p + "dur"] = f32(dur.astype(np.float32))
        refs[p + "logd"] = f32(logd); refs[p + "pitch"] = f32(pitch); refs[p + "mel"] = f32(mel); refs[p + "wav"] = f32(wav)
        with torch.no_grad(): refs[p + "synth"] = f32(py_synth(amq, vocq, raw, lang, spk))   # full text: all sentences, gaps, peak, padding
        cases["synth"].append({"i": i, "lang": lang, "speaker": spk, "raw": raw, "sentence": sent, "frames": int(dur.sum()),
                               "seconds": round(len(wav) / 16000, 3), "speed_case": speed})
        print(f"  {lang} {spk}: {len(ids)} tokens -> {int(dur.sum())} frames ({len(wav) / 16000:.2f} s){'  [speed case]' if speed else ''}")
    write_krw1(os.path.join(out, "refs.krw"), refs)
    json.dump(cases, open(os.path.join(out, "cases.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{out}: AM {am.n_params() / 1e6:.2f}M + vocoder {voc.n_params() / 1e6:.2f}M params, files", {k: f"{v / 1e6:.2f} MB" for k, v in sizes.items()})


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("out"); ap.add_argument("--am", default=""); ap.add_argument("--voc", default="")
    a = ap.parse_args()
    am, voc, stats = random_models()
    make(os.path.join(a.out, "random"), am, voc, stats, {"note": "random init (parity/speed test only)"})
    if a.am and a.voc:
        am, voc, stats, info = load_checkpoints(a.am, a.voc)
        make(os.path.join(a.out, "trained"), am, voc, stats, {"source": info, "note": "tiny CPU smoke model"})
    else:
        print("no --am/--voc given: only the random-init case was written")


if __name__ == "__main__":
    main()
