package in.krishi.doctor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.*;

/**
 * KrishiVoice Java vs PyTorch parity + speed (cases from make_voice_case.py).
 *   java -Xmx1g -cp <classes> in.krishi.doctor.SpeakTest <case_dir> [<case_dir> ...]
 * Per case dir: text normalisation / sentence split / token ids identical to text.py; durations identical; mel max abs
 * diff (pass < 1e-3); vocoder waveform max abs diff on the Python mel; RTF of the ~3 s sentence with 1 and 4 threads
 * (acoustic model and vocoder timed separately). Writes java_<i>.wav next to the case. Exit 1 on any failure.
 */
public class SpeakTest {
    static int fails = 0;

    static void setThreads(int n) {
        Nn.release();
        if (n <= 1) { Nn.pool(); Nn.threads = 1; return; }
        Nn.pool = Executors.newFixedThreadPool(n, r -> { Thread t = new Thread(r, "nn"); t.setDaemon(true); return t; });
        Nn.threads = n;
    }

    static double maxAbs(float[] a, float[] b) {
        if (a.length != b.length) return Double.POSITIVE_INFINITY;
        double m = 0; for (int i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i] - b[i])); return m;
    }

    static int[] ints(float[] f) { int[] r = new int[f.length]; for (int i = 0; i < f.length; i++) r[i] = Math.round(f[i]); return r; }

    @SuppressWarnings("unchecked")
    static void runCase(File dir) throws Exception {
        System.out.println("== " + dir);
        Speak s = new Speak(dir);
        Map<String, Object> cases = (Map<String, Object>) Json.parse(new String(Files.readAllBytes(new File(dir, "cases.json").toPath()), StandardCharsets.UTF_8));
        Map<String, Krw.T> ref = Krw.read(new File(dir, "refs.krw"));
        // 1. text front end
        int nOk = 0, nAll = 0;
        for (Object o : (List<Object>) cases.get("norm")) {
            Map<String, Object> c = (Map<String, Object>) o; String lang = (String) c.get("lang"); nAll++;
            String n = s.normalize((String) c.get("text"), lang); List<String> sent = s.sentences(n);
            boolean ok = n.equals(c.get("norm")) && sent.equals(c.get("sentences"));
            List<Object> ids = (List<Object>) c.get("ids");
            for (int k = 0; ok && k < sent.size(); k++) {
                int[] a = s.encode(sent.get(k)); List<Object> b = (List<Object>) ids.get(k); ok = a.length == b.size();
                for (int q = 0; ok && q < a.length; q++) ok = a[q] == ((Number) b.get(q)).intValue();
            }
            if (ok) nOk++; else { fails++; System.out.println("  NORM MISMATCH " + lang + " " + c.get("text") + "\n    java   [" + n + "]\n    python [" + c.get("norm") + "]"); }
        }
        System.out.printf("  text normalisation: %d/%d identical to Python%n", nOk, nAll);
        // 2. acoustic model + vocoder parity
        setThreads(Math.min(4, Runtime.getRuntime().availableProcessors()));
        double worstMel = 0, worstWav = 0, worstChain = 0, worstFull = 0; int durMismatch = 0, durTokens = 0; Map<String, Object> speedCase = null;
        for (Object o : (List<Object>) cases.get("synth")) {
            Map<String, Object> c = (Map<String, Object>) o; int i = ((Number) c.get("i")).intValue(); String p = "c" + i + ".";
            String lang = (String) c.get("lang"), spk = (String) c.get("speaker");
            List<String> sents = s.sentences(s.normalize((String) c.get("raw"), lang));
            int[] ids = s.encode(sents.get(0)), rids = ints(ref.get(p + "ids").floats());
            if (!Arrays.equals(ids, rids)) { fails++; System.out.println("  TOKEN MISMATCH case " + i); continue; }
            int li = s.langId(lang), vi = s.voiceId(lang, spk);
            Object[] dbg = new Object[3];
            float[] mel = s.acoustic(ids, li, vi, 1f, null, dbg);
            int[] dur = (int[]) dbg[0], rdur = ints(ref.get(p + "dur").floats());
            int dm = 0; for (int k = 0; k < Math.min(dur.length, rdur.length); k++) if (dur[k] != rdur[k]) dm++;
            durMismatch += dm; durTokens += rdur.length;
            double dLogd = maxAbs((float[]) dbg[1], ref.get(p + "logd").floats()), dPitch = maxAbs((float[]) dbg[2], ref.get(p + "pitch").floats());
            float[] rmel = ref.get(p + "mel").floats();
            if (dm > 0) mel = s.acoustic(ids, li, vi, 1f, rdur, null);       // compare the mel with the reference durations
            double dMel = maxAbs(mel, rmel); worstMel = Math.max(worstMel, dMel);
            int T = rmel.length / s.nMels;
            float[] wav = s.vocode(rmel, T); double dWav = maxAbs(wav, ref.get(p + "wav").floats()); worstWav = Math.max(worstWav, dWav);
            float[] chain = s.vocode(mel, T); double dChain = maxAbs(chain, ref.get(p + "wav").floats()); worstChain = Math.max(worstChain, dChain);
            System.out.printf("  case %d %s/%s: %d tokens, %d frames | durations %s | logd %.1e pitch %.1e | mel max|diff| %.2e | wav (Python mel) %.2e, full chain %.2e%n",
                    i, lang, spk, ids.length, T, dm == 0 ? "identical" : (dm + " differ"), dLogd, dPitch, dMel, dWav, dChain);
            float[] full = s.synth((String) c.get("raw"), lang, spk); double dFull = maxAbs(full, ref.get(p + "synth").floats());
            if (dm == 0) worstFull = Math.max(worstFull, dFull);
            System.out.printf("      synth(whole text, %d sentence(s)): %.2f s, max|diff| vs infer.synth %.2e%n", sents.size(), full.length / (float) s.sampleRate(), dFull);
            Speak.writeWav(new File(dir, "java_" + i + ".wav"), full, s.sampleRate());
            if (Boolean.TRUE.equals(c.get("speed_case"))) speedCase = c;
        }
        boolean pass = worstMel < 1e-3;
        if (!pass) fails++;
        System.out.printf("  PARITY %s: worst mel %.2e (limit 1e-3), worst wav %.2e, worst chain wav %.2e, worst full synth %.2e, durations differ %d/%d tokens%n",
                pass ? "OK" : "FAIL", worstMel, worstWav, worstChain, worstFull, durMismatch, durTokens);
        // 3. speed of the ~3 s sentence
        if (speedCase != null) {
            String lang = (String) speedCase.get("lang"), spk = (String) speedCase.get("speaker");
            int[] ids = s.encode(s.sentences(s.normalize((String) speedCase.get("raw"), lang)).get(0));
            int li = s.langId(lang), vi = s.voiceId(lang, spk);
            for (int th : new int[]{1, 2, 4}) {
                setThreads(th); int R = 7; long[] tam = new long[R], tvo = new long[R]; float sec = 0;
                for (int rep = 0; rep < R; rep++) {
                    long t0 = System.nanoTime(); float[] mel = s.acoustic(ids, li, vi, 1f, null, null); long t1 = System.nanoTime();
                    float[] w = s.vocode(mel, mel.length / s.nMels); long t2 = System.nanoTime();
                    tam[rep] = t1 - t0; tvo[rep] = t2 - t1; sec = w.length / (float) s.sampleRate();
                }
                Arrays.sort(tam, 1, R); Arrays.sort(tvo, 1, R);                         // run 0 = warm-up; median of the rest
                double am = tam[1 + (R - 1) / 2] / 1e9, voc = tvo[1 + (R - 1) / 2] / 1e9;
                System.out.printf("  SPEED %d thread(s): %.2f s audio -> acoustic %.3f s + vocoder %.3f s = %.3f s, RTF %.3f (median of %d; cpus available: %d)%n",
                        th, sec, am, voc, am + voc, (am + voc) / sec, R - 1, Runtime.getRuntime().availableProcessors());
            }
        }
    }

    public static void main(String[] args) throws Exception {
        for (String a : args) runCase(new File(a));
        Nn.release();
        System.out.println(fails == 0 ? "ALL OK" : ("FAILURES: " + fails));
        System.exit(fails == 0 ? 0 : 1);
    }
}
