#!/bin/bash
# KrishiVoice Java parity + speed test.
#   bash android/test/voice/run.sh                          # random-init full-size model only
#   bash android/test/voice/run.sh runs/am/final.pt runs/voc/final.pt     # + a trained model
# Env: OUT_CASE (default /tmp/kv_case), PY (python with torch).
set -euo pipefail
K=$(cd "$(dirname "$0")/../../.." && pwd); OUT=${OUT_CASE:-/tmp/kv_case}; PY=${PY:-python3}; CLS=$OUT/classes
if [ $# -ge 2 ]; then $PY $K/android/test/voice/make_voice_case.py $OUT --am "$1" --voc "$2"; else $PY $K/android/test/voice/make_voice_case.py $OUT; fi
mkdir -p $CLS
D=$K/android/src/in/krishi/doctor
javac -nowarn -encoding UTF-8 --release 8 -d $CLS $D/Krw.java $D/Nn.java $D/Json.java $D/Speak.java $D/SpeakText.java $D/SpeakOps.java $K/android/test/voice/SpeakTest.java
CASES=$OUT/random; [ -d $OUT/trained ] && CASES="$OUT/trained $CASES"
java -Xmx1g -cp $CLS in.krishi.doctor.SpeakTest $CASES
