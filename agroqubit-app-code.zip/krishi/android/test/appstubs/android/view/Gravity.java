/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.view;
public class Gravity { public static final int CENTER = 17, CENTER_VERTICAL = 16, START = 8388611, END = 8388613; }
