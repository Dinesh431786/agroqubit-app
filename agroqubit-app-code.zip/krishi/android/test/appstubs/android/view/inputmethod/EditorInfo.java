/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.view.inputmethod;
public class EditorInfo { public static final int IME_ACTION_SEND = 4; }
