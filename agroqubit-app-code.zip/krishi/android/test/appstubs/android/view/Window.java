/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.view;
public abstract class Window { public void setSoftInputMode(int m) { } }
