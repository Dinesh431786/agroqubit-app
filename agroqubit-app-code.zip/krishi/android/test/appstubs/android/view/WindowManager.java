/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.view;
public interface WindowManager { class LayoutParams { public static final int SOFT_INPUT_ADJUST_RESIZE = 16; } }
