/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.view;
public class View {
    public static final int FOCUS_DOWN = 130;
    public interface OnClickListener { void onClick(View v); }
    public interface OnLongClickListener { boolean onLongClick(View v); }
    public View(android.content.Context c) { }
    public void setOnClickListener(OnClickListener l) { } public void setOnLongClickListener(OnLongClickListener l) { }
    public void setBackground(android.graphics.drawable.Drawable d) { } public void setBackgroundColor(int c) { }
    public void setContentDescription(CharSequence s) { } public void setLayoutParams(ViewGroup.LayoutParams p) { } public ViewGroup.LayoutParams getLayoutParams() { return null; }
    public void setPadding(int l, int t, int r, int b) { } public void setElevation(float e) { } public void setClickable(boolean c) { } public void setAlpha(float a) { }
    public boolean post(Runnable r) { return true; }
}
