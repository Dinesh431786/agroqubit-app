/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.view;
public abstract class ViewGroup extends View {
    public ViewGroup(android.content.Context c) { super(c); }
    public static class LayoutParams { public static final int MATCH_PARENT = -1, WRAP_CONTENT = -2; public int width, height; public LayoutParams(int w, int h) { } }
    public static class MarginLayoutParams extends LayoutParams { public int leftMargin, topMargin, rightMargin, bottomMargin;
        public MarginLayoutParams(int w, int h) { super(w, h); } public void setMargins(int l, int t, int r, int b) { } }
    public void addView(View v) { } public void addView(View v, LayoutParams p) { } public void removeAllViews() { } public void removeView(View v) { }
}
