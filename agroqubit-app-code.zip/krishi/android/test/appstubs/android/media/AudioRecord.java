/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.media;
public class AudioRecord {
    public static final int STATE_UNINITIALIZED = 0, STATE_INITIALIZED = 1, RECORDSTATE_STOPPED = 1, RECORDSTATE_RECORDING = 3;
    public static final int SUCCESS = 0, ERROR = -1, ERROR_BAD_VALUE = -2, ERROR_INVALID_OPERATION = -3, ERROR_DEAD_OBJECT = -6;
    public AudioRecord(int src, int rate, int ch, int fmt, int bytes) throws IllegalArgumentException { }
    public static int getMinBufferSize(int rate, int ch, int fmt) { return 0; }
    public int getState() { return 0; } public int getRecordingState() { return 0; } public int getSampleRate() { return 0; }
    public void startRecording() throws IllegalStateException { } public void stop() throws IllegalStateException { } public void release() { }
    public int read(short[] a, int off, int n) { return 0; }
}
