/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.media;
public class AudioManager { public static final int STREAM_MUSIC = 3; }
