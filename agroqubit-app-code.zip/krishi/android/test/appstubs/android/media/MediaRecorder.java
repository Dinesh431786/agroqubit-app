/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.media;
public class MediaRecorder { public final class AudioSource { private AudioSource() { } public static final int DEFAULT = 0, MIC = 1, VOICE_RECOGNITION = 6; } }
