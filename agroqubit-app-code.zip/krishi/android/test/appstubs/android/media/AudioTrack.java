/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.media;
public class AudioTrack {
    public static final int MODE_STATIC = 0, MODE_STREAM = 1;
    public interface OnPlaybackPositionUpdateListener { void onMarkerReached(AudioTrack t); void onPeriodicNotification(AudioTrack t); }
    public AudioTrack(int stream, int rate, int ch, int fmt, int bytes, int mode) throws IllegalArgumentException { }
    public int write(short[] a, int off, int n) { return n; } public int setNotificationMarkerPosition(int p) { return 0; }
    public void setPlaybackPositionUpdateListener(OnPlaybackPositionUpdateListener l) { }
    public void play() throws IllegalStateException { } public void stop() throws IllegalStateException { } public void release() { }
}
