/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.media;
public final class AudioFormat { public static final int ENCODING_PCM_16BIT = 2, ENCODING_PCM_FLOAT = 4, CHANNEL_IN_MONO = 16, CHANNEL_IN_STEREO = 12, CHANNEL_OUT_MONO = 4; }
