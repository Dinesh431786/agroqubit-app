/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.media;
public class MediaPlayer {
    public interface OnCompletionListener { void onCompletion(MediaPlayer mp); }
    public interface OnErrorListener { boolean onError(MediaPlayer mp, int what, int extra); }
    public void setDataSource(java.io.FileDescriptor fd, long off, long len) throws java.io.IOException { }
    public void setOnCompletionListener(OnCompletionListener l) { } public void setOnErrorListener(OnErrorListener l) { }
    public void prepare() throws java.io.IOException { } public void start() { } public void stop() { } public void release() { }
}
