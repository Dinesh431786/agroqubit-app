/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.media;
public class ExifInterface {
    public static final String TAG_ORIENTATION = "Orientation";
    public ExifInterface(String path) throws java.io.IOException { } public ExifInterface(java.io.InputStream in) throws java.io.IOException { }
    public int getAttributeInt(String tag, int def) { return def; }
}
