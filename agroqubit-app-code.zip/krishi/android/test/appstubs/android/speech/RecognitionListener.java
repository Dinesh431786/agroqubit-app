/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.speech;
public interface RecognitionListener {
    void onReadyForSpeech(android.os.Bundle b); void onBeginningOfSpeech(); void onRmsChanged(float v); void onBufferReceived(byte[] b);
    void onEndOfSpeech(); void onError(int e); void onResults(android.os.Bundle b); void onPartialResults(android.os.Bundle b); void onEvent(int t, android.os.Bundle b);
}
