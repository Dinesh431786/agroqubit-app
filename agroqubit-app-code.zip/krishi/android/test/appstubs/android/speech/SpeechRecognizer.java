/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.speech;
public class SpeechRecognizer {
    public static final String RESULTS_RECOGNITION = "results_recognition";
    public static boolean isOnDeviceRecognitionAvailable(android.content.Context c) { return false; }
    public static SpeechRecognizer createOnDeviceSpeechRecognizer(android.content.Context c) { return null; }
    public void setRecognitionListener(RecognitionListener l) { } public void startListening(android.content.Intent i) { }
    public void stopListening() { } public void destroy() { }
}
