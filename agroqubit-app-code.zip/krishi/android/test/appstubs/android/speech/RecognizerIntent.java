/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.speech;
public class RecognizerIntent {
    public static final String ACTION_RECOGNIZE_SPEECH = "android.speech.action.RECOGNIZE_SPEECH", EXTRA_LANGUAGE_MODEL = "android.speech.extra.LANGUAGE_MODEL",
        LANGUAGE_MODEL_FREE_FORM = "free_form", EXTRA_LANGUAGE = "android.speech.extra.LANGUAGE", EXTRA_RESULTS = "android.speech.extra.RESULTS";
}
