/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.text;
public interface InputType { int TYPE_CLASS_TEXT = 1, TYPE_TEXT_FLAG_MULTI_LINE = 131072, TYPE_TEXT_FLAG_CAP_SENTENCES = 16384; }
