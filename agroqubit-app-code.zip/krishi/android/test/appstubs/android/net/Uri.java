/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.net;
public abstract class Uri implements android.os.Parcelable { public static Uri parse(String s) { return null; } public abstract String getLastPathSegment(); }
