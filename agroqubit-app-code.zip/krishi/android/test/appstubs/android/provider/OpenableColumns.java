/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.provider;
public interface OpenableColumns { String DISPLAY_NAME = "_display_name", SIZE = "_size"; }
