/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.provider;
public final class MediaStore { public static final String ACTION_IMAGE_CAPTURE = "android.media.action.IMAGE_CAPTURE", EXTRA_OUTPUT = "output"; }
