/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.content;
public abstract class BroadcastReceiver { public abstract void onReceive(Context c, Intent i); }
