/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.content;
public class ContentResolver { public final java.io.InputStream openInputStream(android.net.Uri u) throws java.io.FileNotFoundException { return null; } }
