/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.content;
import java.util.ArrayList;
public class Intent implements android.os.Parcelable {
    public static final String ACTION_DIAL = "android.intent.action.DIAL", ACTION_GET_CONTENT = "android.intent.action.GET_CONTENT";
    public static final int FLAG_GRANT_READ_URI_PERMISSION = 1, FLAG_GRANT_WRITE_URI_PERMISSION = 2;
    public Intent() { } public Intent(String action) { } public Intent(String action, android.net.Uri uri) { }
    public Intent putExtra(String k, String v) { return this; } public Intent putExtra(String k, boolean v) { return this; }
    public Intent putExtra(String k, int v) { return this; } public Intent putExtra(String k, android.os.Parcelable v) { return this; }
    public Intent addFlags(int f) { return this; } public Intent setType(String t) { return this; }
    public String getStringExtra(String k) { return null; } public ArrayList<String> getStringArrayListExtra(String k) { return null; }
    public android.os.Bundle getExtras() { return null; } public android.net.Uri getData() { return null; }
}
