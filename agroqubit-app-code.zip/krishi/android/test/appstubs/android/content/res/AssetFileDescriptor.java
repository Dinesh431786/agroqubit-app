/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.content.res;
public class AssetFileDescriptor implements java.io.Closeable {
    public java.io.FileDescriptor getFileDescriptor() { return null; } public long getStartOffset() { return 0; } public long getLength() { return 0; }
    public void close() throws java.io.IOException { }
}
