/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.content.res;
public final class AssetManager {
    public final java.io.InputStream open(String name) throws java.io.IOException { return null; }
    public final AssetFileDescriptor openFd(String name) throws java.io.IOException { return null; }
}
