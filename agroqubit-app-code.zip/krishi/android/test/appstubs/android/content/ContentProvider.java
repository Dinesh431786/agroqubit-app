/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.content;
public abstract class ContentProvider {
    public final Context getContext() { return null; }
    public abstract boolean onCreate();
    public android.os.ParcelFileDescriptor openFile(android.net.Uri uri, String mode) throws java.io.FileNotFoundException { return null; }
    public abstract String getType(android.net.Uri uri);
    public abstract android.database.Cursor query(android.net.Uri uri, String[] p, String s, String[] a, String o);
    public abstract android.net.Uri insert(android.net.Uri uri, ContentValues v);
    public abstract int delete(android.net.Uri uri, String s, String[] a);
    public abstract int update(android.net.Uri uri, ContentValues v, String s, String[] a);
}
