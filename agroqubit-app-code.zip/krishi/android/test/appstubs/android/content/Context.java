/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.content;
import java.io.File;
public abstract class Context {
    public abstract android.content.res.AssetManager getAssets();
    public abstract android.content.res.Resources getResources();
    public abstract ContentResolver getContentResolver();
    public abstract File getCacheDir();
    public abstract File getExternalFilesDir(String type);
    public abstract Intent registerReceiver(BroadcastReceiver r, IntentFilter f);
    public abstract Intent registerReceiver(BroadcastReceiver r, IntentFilter f, int flags);
    public abstract void unregisterReceiver(BroadcastReceiver r);
    public abstract void startActivity(Intent i);
    public abstract int checkSelfPermission(String p);
}
