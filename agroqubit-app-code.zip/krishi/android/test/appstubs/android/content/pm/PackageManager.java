/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.content.pm;
public abstract class PackageManager { public static final int PERMISSION_GRANTED = 0, PERMISSION_DENIED = -1; }
