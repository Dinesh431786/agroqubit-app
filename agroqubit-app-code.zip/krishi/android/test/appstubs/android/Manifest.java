/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android;
public final class Manifest { public static final class permission { public static final String RECORD_AUDIO = "android.permission.RECORD_AUDIO", CAMERA = "android.permission.CAMERA"; } }
