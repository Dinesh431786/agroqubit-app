/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.os;
public final class SystemClock { public static long elapsedRealtime() { return 0; } }
