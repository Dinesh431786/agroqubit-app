/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.os;
public class Process { public static final int THREAD_PRIORITY_URGENT_AUDIO = -19, THREAD_PRIORITY_AUDIO = -16; public static final void setThreadPriority(int p) { } }
