/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.os;
public final class Bundle {
    public String getString(String k) { return null; } public String getString(String k, String d) { return d; } public void putString(String k, String v) { }
    public java.util.ArrayList<String> getStringArrayList(String k) { return null; } public Object get(String k) { return null; }
}
