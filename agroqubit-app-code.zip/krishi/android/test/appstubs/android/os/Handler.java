/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.os;
public class Handler { public Handler(Looper l) { } public final boolean post(Runnable r) { return true; } public final boolean postDelayed(Runnable r, long ms) { return true; } }
