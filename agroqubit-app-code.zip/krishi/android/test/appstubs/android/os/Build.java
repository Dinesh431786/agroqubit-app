/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.os;
public class Build { public static class VERSION { public static final int SDK_INT = 34; } }
