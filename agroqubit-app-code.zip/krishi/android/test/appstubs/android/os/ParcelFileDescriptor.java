/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.os;
public class ParcelFileDescriptor { public static ParcelFileDescriptor open(java.io.File f, int mode) throws java.io.FileNotFoundException { return null; } public static int parseMode(String m) { return 0; } }
