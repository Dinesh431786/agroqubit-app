/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.database;
public class MatrixCursor implements Cursor { public MatrixCursor(String[] cols) { } public void addRow(Object[] row) { } public void close() { } }
