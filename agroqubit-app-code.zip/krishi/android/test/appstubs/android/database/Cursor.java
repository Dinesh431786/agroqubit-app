/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.database;
public interface Cursor extends java.io.Closeable { }
