/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.widget;
public class LinearLayout extends android.view.ViewGroup {
    public static final int HORIZONTAL = 0, VERTICAL = 1;
    public LinearLayout(android.content.Context c) { super(c); }
    public void setOrientation(int o) { } public void setGravity(int g) { }
    public static class LayoutParams extends android.view.ViewGroup.MarginLayoutParams { public int gravity; public float weight;
        public LayoutParams(int w, int h) { super(w, h); } public LayoutParams(int w, int h, float weight) { super(w, h); } }
}
