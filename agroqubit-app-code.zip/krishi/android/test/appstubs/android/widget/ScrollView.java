/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.widget;
public class ScrollView extends FrameLayout { public ScrollView(android.content.Context c) { super(c); } public boolean fullScroll(int d) { return true; } }
