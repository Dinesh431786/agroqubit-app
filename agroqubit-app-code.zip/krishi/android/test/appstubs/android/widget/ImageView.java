/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.widget;
public class ImageView extends android.view.View {
    public enum ScaleType { CENTER_CROP, FIT_CENTER }
    public ImageView(android.content.Context c) { super(c); }
    public void setImageBitmap(android.graphics.Bitmap b) { } public void setAdjustViewBounds(boolean b) { } public void setMaxHeight(int h) { } public void setScaleType(ScaleType t) { }
}
