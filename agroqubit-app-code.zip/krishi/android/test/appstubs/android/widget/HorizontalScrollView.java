/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.widget;
public class HorizontalScrollView extends FrameLayout { public HorizontalScrollView(android.content.Context c) { super(c); } public void setHorizontalScrollBarEnabled(boolean b) { } }
