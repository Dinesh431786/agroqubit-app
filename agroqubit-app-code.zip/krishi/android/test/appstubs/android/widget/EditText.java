/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.widget;
public class EditText extends TextView { public EditText(android.content.Context c) { super(c); } @Override public android.text.Editable getText() { return null; } }
