/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.widget;
public class TextView extends android.view.View {
    public TextView(android.content.Context c) { super(c); }
    public void setText(CharSequence s) { } public CharSequence getText() { return null; } public void setTextSize(float sp) { } public void setTextColor(int c) { }
    public void setGravity(int g) { } public void setTypeface(android.graphics.Typeface t) { } public void setHint(CharSequence s) { }
    public void setLineSpacing(float add, float mult) { } public void setTextIsSelectable(boolean b) { } public void setMaxLines(int n) { } public void setMaxWidth(int w) { }
    public void setSingleLine(boolean b) { } public void setInputType(int t) { } public void setImeOptions(int o) { }
}
