/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.widget;
public class Toast { public static final int LENGTH_SHORT = 0, LENGTH_LONG = 1; public static Toast makeText(android.content.Context c, CharSequence s, int d) { return new Toast(); } public void show() { } }
