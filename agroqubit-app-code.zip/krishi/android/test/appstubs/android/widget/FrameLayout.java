/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.widget;
public class FrameLayout extends android.view.ViewGroup { public FrameLayout(android.content.Context c) { super(c); } }
