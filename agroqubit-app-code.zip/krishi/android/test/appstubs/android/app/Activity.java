/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.app;
import android.content.*;
public class Activity extends Context {
    public static final int RESULT_OK = -1, RESULT_CANCELED = 0;
    protected void onCreate(android.os.Bundle b) { } protected void onSaveInstanceState(android.os.Bundle o) { } protected void onDestroy() { }
    protected void onActivityResult(int req, int res, Intent data) { }
    public void onRequestPermissionsResult(int req, String[] p, int[] g) { }
    public android.view.Window getWindow() { return null; }
    public void setContentView(android.view.View v) { }
    public void startActivityForResult(Intent i, int req) { }
    public final void requestPermissions(String[] p, int req) { }
    @Override public android.content.res.AssetManager getAssets() { return null; }
    @Override public android.content.res.Resources getResources() { return null; }
    @Override public ContentResolver getContentResolver() { return null; }
    @Override public java.io.File getCacheDir() { return null; }
    @Override public java.io.File getExternalFilesDir(String type) { return null; }
    @Override public Intent registerReceiver(BroadcastReceiver r, IntentFilter f) { return null; }
    @Override public Intent registerReceiver(BroadcastReceiver r, IntentFilter f, int flags) { return null; }
    @Override public void unregisterReceiver(BroadcastReceiver r) { }
    @Override public void startActivity(Intent i) { }
    @Override public int checkSelfPermission(String p) { return 0; }
}
