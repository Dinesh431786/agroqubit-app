/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.graphics.drawable;
public class GradientDrawable extends Drawable { public void setColor(int c) { } public void setCornerRadius(float r) { } }
