/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.graphics;
public final class Bitmap {
    public int getWidth() { return 0; } public int getHeight() { return 0; }
    public void getPixels(int[] px, int offset, int stride, int x, int y, int w, int h) { }
    public static Bitmap createBitmap(Bitmap b, int x, int y, int w, int h) { return null; }
    public static Bitmap createBitmap(Bitmap b, int x, int y, int w, int h, Matrix m, boolean filter) { return null; }
    public static Bitmap createScaledBitmap(Bitmap b, int w, int h, boolean filter) { return null; }
}
