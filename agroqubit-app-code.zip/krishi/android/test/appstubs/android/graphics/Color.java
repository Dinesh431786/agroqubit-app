/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.graphics;
public class Color { public static final int WHITE = 0xFFFFFFFF, BLACK = 0xFF000000; }
