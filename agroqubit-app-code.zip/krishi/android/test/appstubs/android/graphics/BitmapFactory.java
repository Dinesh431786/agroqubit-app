/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.graphics;
public class BitmapFactory {
    public static class Options { public boolean inJustDecodeBounds; public int inSampleSize, outWidth, outHeight; }
    public static Bitmap decodeStream(java.io.InputStream in) { return null; }
    public static Bitmap decodeStream(java.io.InputStream in, Rect pad, Options o) { return null; }
    public static Bitmap decodeFile(String path, Options o) { return null; }
    public static Bitmap decodeFile(String path) { return null; }
}
