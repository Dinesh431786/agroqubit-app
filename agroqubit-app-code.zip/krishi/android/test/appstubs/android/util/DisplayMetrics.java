/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.util;
public class DisplayMetrics { public int widthPixels, heightPixels; public float density; }
