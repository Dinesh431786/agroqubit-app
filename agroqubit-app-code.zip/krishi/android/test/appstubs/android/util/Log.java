/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.util;
public final class Log {
    public static int i(String t, String m) { return 0; } public static int w(String t, String m) { return 0; } public static int w(String t, String m, Throwable e) { return 0; }
    public static int w(String t, Throwable e) { return 0; } public static int e(String t, String m, Throwable e) { return 0; } public static int e(String t, String m) { return 0; }
}
