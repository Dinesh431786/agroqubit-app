/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.util;
public class TypedValue { public static final int COMPLEX_UNIT_DIP = 1; public static float applyDimension(int unit, float v, DisplayMetrics m) { return v; } }
