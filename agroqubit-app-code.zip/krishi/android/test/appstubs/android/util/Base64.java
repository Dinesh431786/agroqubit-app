/* Compile-only stub of the Android SDK class: lets javac check the app code without android.jar. Never shipped. */
package android.util;
public class Base64 { public static final int DEFAULT = 0; public static byte[] decode(String s, int flags) { return new byte[0]; } }
