package in.krishi.doctor;
/** Test-only access to the individual models. */
public final class TextModelProbe {
    final Krishi k; public TextModelProbe(Krishi k) { this.k = k; }
    public double[][] all(String t) { double[][] f = k.free.freeHeads(t); return new double[][]{k.AL.slotProbs(t), k.DL.slotProbsMil(t), f[0], f[1]}; }
}
