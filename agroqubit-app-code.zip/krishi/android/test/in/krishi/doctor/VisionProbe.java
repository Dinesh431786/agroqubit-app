package in.krishi.doctor;

import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.util.*;

/** Desktop check: Java Vision embeddings vs onnxruntime (same int8/fp16 weights) on real PlantDoc test photos. */
public final class VisionProbe {
    public static void main(String[] a) throws Exception {
        Vision v; try (InputStream in = new FileInputStream(a[0] + "/vision.bin")) { v = new Vision(in, new String(Files.readAllBytes(Paths.get(a[0] + "/vision.json")), "UTF-8")); }
        ByteBuffer X = ByteBuffer.wrap(Files.readAllBytes(Paths.get(a[1]))).order(ByteOrder.LITTLE_ENDIAN);
        ByteBuffer R = ByteBuffer.wrap(Files.readAllBytes(Paths.get(a[2]))).order(ByteOrder.LITTLE_ENDIAN);
        int n = Integer.parseInt(a[3]), sz = 3 * 224 * 224; double worst = 1, sum = 0; int same = 0; long t = 0;
        for (int i = 0; i < n; i++) {
            float[] x = new float[sz]; for (int j = 0; j < sz; j++) x[j] = X.getFloat((i * sz + j) * 4);
            long s = System.nanoTime(); float[] z = v.embed(x); if (i > 0) t += System.nanoTime() - s;
            double c = 0; float[] r = new float[256]; for (int j = 0; j < 256; j++) { r[j] = R.getFloat((i * 256 + j) * 4); c += z[j] * r[j]; }
            worst = Math.min(worst, c); sum += c;
            if (argmax(v.scores(z)) == argmax(v.scores(r))) same++;
        }
        System.out.printf("photos=%d meanCos=%.6f worstCos=%.6f sameTop1=%d/%d javaMsPerPhoto=%.1f threads=%d%n", n, sum / n, worst, same, n, t / 1e6 / Math.max(1, n - 1), Vision.threads);
        Vision.release();
        if (worst < 0.999 || same != n) { System.out.println("VISION PARITY FAILED"); System.exit(1); }
        System.out.println("VISION PARITY OK");
    }
    static int argmax(double[] s) { int b = 0; for (int i = 1; i < s.length; i++) if (s[i] > s[b]) b = i; return b; }
}
