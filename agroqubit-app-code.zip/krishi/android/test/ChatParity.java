import in.krishi.doctor.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Replays Python reference (make_parity.py) through the Java port: probabilities and whole conversations must match. */
@SuppressWarnings("unchecked")
public class ChatParity {
    public static void main(String[] a) throws Exception {
        String dir = a[0];
        Krishi k = new Krishi(name -> new FileInputStream(dir + "/" + name));
        Map<String, Object> ref = (Map<String, Object>) Json.parse(new String(Files.readAllBytes(Paths.get(a[1])), "UTF-8"));
        // 1) probabilities
        TextModelProbe probe = new TextModelProbe(k);
        double worst = 0; int n = 0;
        for (Object o : (List<Object>) ref.get("probs")) {
            Map<String, Object> p = (Map<String, Object>) o; String t = (String) p.get("text");
            double[][] got = probe.all(t);
            String[] keys = {"AL", "DL", "intent", "dis"};
            for (int j = 0; j < 4; j++) {
                List<Object> e = (List<Object>) p.get(keys[j]);
                for (int i = 0; i < e.size(); i++) worst = Math.max(worst, Math.abs(got[j][i] - (Double) e.get(i)));
            }
            n++;
        }
        System.out.printf("probabilities: %d sentences, max |diff| = %.2e%n", n, worst);
        // 2) conversations
        int turns = 0, ok = 0, convOk = 0; double postWorst = 0; long t0 = System.nanoTime(); List<String> fails = new ArrayList<>();
        Map<String, Object> segs = a.length > 2 ? (Map<String, Object>) Json.parse(new String(Files.readAllBytes(Paths.get(a[2])), "UTF-8")) : null;
        int clips = 0; Set<String> missing = new TreeSet<>();
        for (Object o : (List<Object>) ref.get("convs")) {
            Map<String, Object> c = (Map<String, Object>) o; String lang = (String) c.get("lang");
            Chat chat = new Chat(k, lang, new HashSet<>((List<String>) (List<?>) c.get("skip"))); boolean all = true;
            for (Object to : (List<Object>) c.get("turns")) {
                Map<String, Object> t = (Map<String, Object>) to; turns++;
                Chat.Reply r = chat.turn((String) t.get("text"), (String) t.get("tap"));
                if (segs != null) for (String id : r.clips) { clips++; if (!((Map<String, Object>) segs.get(lang)).containsKey(id)) missing.add(lang + "/" + id); }
                boolean same = r.type.equals(t.get("type")) && Objects.equals(r.qid, t.get("qid")) && Objects.equals(r.disease, t.get("disease"))
                        && Objects.equals(r.action, t.get("action")) && (t.get("say") == null || r.say.equals(t.get("say")))
                        && (t.get("confidence") == null || Math.abs(r.confidence - (Double) t.get("confidence")) < 1e-9)
                        && (t.get("facts") == null || r.facts.equals(t.get("facts")));
                List<Object> post = (List<Object>) t.get("post");
                if (post != null && chat.brain.st != null) for (int d = 0; d < post.size(); d++) postWorst = Math.max(postWorst, Math.abs(chat.brain.st.post[d] - (Double) post.get(d)));
                if (same) ok++; else { all = false; if (fails.size() < 8) fails.add(lang + " | " + (t.get("text") != null ? t.get("text") : "tap:" + t.get("tap")) + " | java=" + r + " | py=" + t.get("type") + "/" + t.get("qid") + "/" + t.get("disease") + "/" + t.get("action") + ": " + t.get("say")); break; }
            }
            if (all) convOk++;
        }
        double ms = (System.nanoTime() - t0) / 1e6;
        System.out.printf("conversations: %d/%d identical, turns %d/%d, max posterior diff %.2e, %.2f ms/turn%n",
                convOk, ((List<Object>) ref.get("convs")).size(), ok, turns, postWorst, ms / turns);
        for (String f : fails) System.out.println("MISMATCH " + f);
        if (segs != null) System.out.printf("voice: %d clips played, %d distinct missing %s%n", clips, missing.size(), missing.size() > 20 ? new ArrayList<>(missing).subList(0, 20) : missing);
        System.out.println(worst < 1e-4 && convOk == ((List<Object>) ref.get("convs")).size() && missing.isEmpty() ? "PARITY OK" : "PARITY FAILED");
    }
}
