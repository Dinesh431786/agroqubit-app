import in.krishi.doctor.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Field-photo model on the JVM: each test JPEG (256 px, written by vision2/export_check.py) is decoded, centre-cropped to
 *  224 like the app, scored by Vision.java and compared with the Python reference; then the full photo turn runs. */
@SuppressWarnings("unchecked")
public class PhotoTurn {
    public static void main(String[] a) throws Exception {
        String dir = a[0], photos = a[1]; Krishi k = new Krishi(name -> new FileInputStream(dir + "/" + name));
        List<Object> ref = (List<Object>) Json.parse(new String(Files.readAllBytes(Paths.get(photos, "reference.json")), "UTF-8"));
        int same = 0, n = 0; double worst = 0; Map<String, Integer> types = new TreeMap<>();
        for (Object o : ref) {
            Map<String, Object> r = (Map<String, Object>) o; BufferedImage im = ImageIO.read(new File(photos, (String) r.get("file")));
            int S = im.getWidth(), off = (S - 224) / 2; float[] x = new float[3 * 224 * 224];
            for (int y = 0; y < 224; y++) for (int xx = 0; xx < 224; xx++) {
                int p = im.getRGB(xx + off, y + off);
                x[y * 224 + xx] = (p >> 16) & 255; x[224 * 224 + y * 224 + xx] = (p >> 8) & 255; x[2 * 224 * 224 + y * 224 + xx] = p & 255;
            }
            Krishi.Photo ph = k.photo(x); n++;
            boolean eq = ph.label.equals(r.get("ref_label")); if (eq) same++;
            worst = Math.max(worst, Math.abs(ph.score - (Double) r.get("ref_score")));
            Chat chat = new Chat(k, n % 2 == 0 ? "hi" : "en", new HashSet<String>()); Chat.Reply rep = chat.photo(ph);
            types.merge(rep.type + (rep.note != null ? "+note" : ""), 1, Integer::sum);
            System.out.println((eq ? "same " : "DIFF ") + r.get("true") + " -> java " + ph + " kind=" + ph.kind + " | py " + r.get("ref_label") + " " + r.get("ref_score")
                    + " | reply " + rep.type + " | note " + (rep.note == null ? "-" : rep.note.replace("\n", " / ")) + " | clips " + rep.clips);
        }
        boolean synth = synthetic(k, dir);
        Vision.release(); Nn.release();
        System.out.printf("photos %d, same label as Python %d, max |score diff| %.4f, replies %s%n", n, same, worst, types);
        System.out.println(same == n && synth ? "PHOTO TURN OK" : !synth ? "PHOTO TURN: synthetic pest-photo check FAILED"
                : "PHOTO TURN: label differences (JPEG decoders differ slightly)");
    }

    /** Photo classes the test photos may not cover, built by hand: one fact-bank pest, a class showing two pests,
     *  another crop and a healthy leaf. Checks the reply shape (facts of both pests, names in the note, clip order). */
    static boolean synthetic(Krishi k, String dir) throws Exception {
        File fjf = new File(dir, "facts.json"); if (!fjf.exists()) { System.out.println("synthetic: no facts.json, skipped"); return true; }
        Map<String, Object> facts = (Map<String, Object>) ((Map<String, Object>) Json.parse(new String(Files.readAllBytes(fjf.toPath()), "UTF-8"))).get("facts");
        Map<String, List<String>> byCrop = new TreeMap<>();
        for (Object o : facts.values()) {
            Map<String, Object> f = (Map<String, Object>) o; String t = (String) f.get("target");
            if (t != null && "first".equals(f.get("kind"))) { List<String> l = byCrop.computeIfAbsent((String) f.get("crop"), c -> new ArrayList<>()); if (!l.contains(t)) l.add(t); }
        }
        String crop = null; for (Map.Entry<String, List<String>> e : byCrop.entrySet()) if (e.getValue().size() >= 2) { crop = e.getKey(); break; }
        if (crop == null) { System.out.println("synthetic: fewer than two targets with facts, skipped"); return true; }
        String t1 = byCrop.get(crop).get(0), t2 = byCrop.get(crop).get(1); boolean ok = true;
        for (String lang : new String[]{"en", "hi"}) {
            Krishi.Photo one = new Krishi.Photo(); one.label = "synthetic_one"; one.score = 1; one.crop = crop; one.kind = "pest"; one.target = t1; one.targets.add(t1);
            Chat.Reply r1 = new Chat(k, lang, new HashSet<String>()).photo(one);
            boolean ok1 = "fact_answer".equals(r1.type) && r1.clips.subList(0, 2).equals(Arrays.asList("photo_looks_like", "name_" + t1))
                    && !r1.clips.subList(2, r1.clips.size()).contains("name_" + t1) && !r1.facts.isEmpty();
            Krishi.Photo two = new Krishi.Photo(); two.label = "synthetic_two"; two.score = 1; two.crop = crop; two.kind = "pest"; two.target = t1; two.targets.add(t1); two.targets.add(t2);
            Chat.Reply r2 = new Chat(k, lang, new HashSet<String>()).photo(two);
            boolean f1 = false, f2 = false; for (String f : r2.facts) { f1 |= t1.equals(k.factTarget(f)); f2 |= t2.equals(k.factTarget(f)); }
            boolean ok2 = "fact_answer".equals(r2.type) && r2.clips.subList(0, 3).equals(Arrays.asList("photo_looks_like", "name_" + t1, "name_" + t2)) && f1 && f2
                    && r2.note.contains(k.targetName(t1, lang)) && r2.note.contains(k.targetName(t2, lang));
            Krishi.Photo oth = new Krishi.Photo(); oth.label = "other_crop"; oth.score = 1; oth.kind = "other";
            Chat.Reply r3 = new Chat(k, lang, new HashSet<String>()).photo(oth);
            Krishi.Photo hl = new Krishi.Photo(); hl.label = crop + "_healthy"; hl.score = 1; hl.crop = crop; hl.kind = "healthy";
            Chat.Reply r4 = new Chat(k, lang, new HashSet<String>()).photo(hl);
            boolean ok3 = r3.note != null && r3.clips.get(0).startsWith("photo_"), ok4 = r4.note != null && r4.clips.get(0).equals("photo_healthy");
            System.out.println("synthetic " + lang + ": one pest " + (ok1 ? "ok" : "BAD") + " " + r1.clips + " | two pests " + (ok2 ? "ok" : "BAD") + " " + r2.clips
                    + " note '" + r2.note + "' | other crop " + (ok3 ? "ok" : "BAD") + " " + r3.clips + " | healthy " + (ok4 ? "ok" : "BAD") + " " + r4.clips);
            ok &= ok1 && ok2 && ok3 && ok4;
        }
        return ok;
    }
}
