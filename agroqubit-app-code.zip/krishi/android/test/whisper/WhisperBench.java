import in.krishi.doctor.*;
import java.io.*;
import java.util.*;

/**
 * Speed of Whisper.java on synthetic speech-like audio: log-mel, encoder, decoder ms/token, SHORT and FULL mode.
 * Thread count = Nn's pool = min(4, availableProcessors): run with -XX:ActiveProcessorCount=1 or =4.
 * Usage: java -cp CLASSES:. WhisperBench MODEL.bin MODEL.json [seconds=5] [tokens=32] [--nn] [--short-only] [--reps=3]
 */
public class WhisperBench {
    static float[] synth(double secs) {
        int n = (int) (secs * 16000); float[] x = new float[n]; Random r = new Random(7);
        for (int i = 0; i < n; i++) {
            double t = i / 16000.0, env = 0.5 + 0.5 * Math.sin(2 * Math.PI * 3.7 * t);
            x[i] = (float) (0.2 * env * (Math.sin(2 * Math.PI * 180 * t) + 0.4 * Math.sin(2 * Math.PI * 720 * t + 0.3 * Math.sin(2 * Math.PI * 5 * t)))
                    + 0.01 * r.nextGaussian());
        }
        return x;
    }
    static double median(List<Double> v) { Collections.sort(v); return v.get(v.size() / 2); }

    public static void main(String[] a) throws Exception {
        Whisper w = Whisper.load(new File(a[0]), new File(a[1]));
        double secs = a.length > 2 && !a[2].startsWith("--") ? Double.parseDouble(a[2]) : 5;
        int tokens = a.length > 3 && !a[3].startsWith("--") ? Integer.parseInt(a[3]) : 32, reps = 3;
        boolean shortOnly = false;
        for (String s : a) {
            if (s.equals("--nn")) Whisper.nnKernels = true;
            if (s.equals("--short-only")) shortOnly = true;
            if (s.startsWith("--reps=")) reps = Integer.parseInt(s.substring(7));
        }
        int threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
        float[] pcm = synth(secs);
        // warm-up (JIT): one short pass + a few decoder steps
        w.transcribe(synth(2), 32000, false, 8);
        w.transcribe(pcm, pcm.length, false, 8);
        StringBuilder json = new StringBuilder("{");
        for (boolean full : new boolean[]{false, true}) {
            if (full && shortOnly) continue;
            int frames = full ? 3000 : w.shortFrames(pcm.length), T = frames / 2, R = full ? 1 : reps;
            List<Double> mel = new ArrayList<>(), enc = new ArrayList<>(), dec = new ArrayList<>(), first = new ArrayList<>();
            for (int r = 0; r < R; r++) {
                long t0 = System.nanoTime();
                float[] m = w.logMel(pcm, pcm.length, frames);
                long t1 = System.nanoTime();
                float[] e = w.encode(m, frames);
                long t2 = System.nanoTime();
                w.greedy(e, T, 1, false, null);                        // cross K/V + prompt + first token
                long t3 = System.nanoTime();
                w.greedy(e, T, tokens, false, null);
                long t4 = System.nanoTime();
                mel.add((t1 - t0) / 1e6); enc.add((t2 - t1) / 1e6); first.add((t3 - t2) / 1e6);
                dec.add(((t4 - t3) - (t3 - t2)) / 1e6 / Math.max(1, tokens - 1));
            }
            double ml = median(mel), en = median(enc), fi = median(first), pt = median(dec);
            String mode = full ? "full" : "short";
            System.out.printf(Locale.ROOT, "%-5s %d thr  %.1f s audio, %d frames, %d positions | mel %.0f ms | encoder %.0f ms | decoder setup+1st %.0f ms, %.1f ms/token | total for 30 tokens %.2f s%s%n",
                    mode, threads, secs, frames, T, ml, en, fi, pt, (ml + en + fi + 29 * pt) / 1000, Whisper.nnKernels ? " [Nn kernels]" : "");
            json.append(String.format(Locale.ROOT, "%s\"%s\":{\"threads\":%d,\"seconds\":%.1f,\"mel_ms\":%.1f,\"enc_ms\":%.1f,\"dec_first_ms\":%.1f,\"dec_ms_per_token\":%.2f,\"total_30tok_s\":%.3f}",
                    json.length() > 1 ? "," : "", mode, threads, secs, ml, en, fi, pt, (ml + en + fi + 29 * pt) / 1000));
        }
        System.out.println(json.append("}"));
        Nn.release();
    }
}
