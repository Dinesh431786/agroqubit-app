package android.media;

/**
 * Test double of android.media.AudioRecord (same public signatures and constants as the SDK) used to compile and
 * exercise Listen.java on a plain JVM. It "records" FAKE_AUDIO (floats at FAKE_RATE Hz) and advances the virtual
 * clock in android.os.SystemClock by the duration read. Never shipped in the APK.
 */
public class AudioRecord {
    public static final int STATE_UNINITIALIZED = 0, STATE_INITIALIZED = 1;
    public static final int RECORDSTATE_STOPPED = 1, RECORDSTATE_RECORDING = 3;
    public static final int SUCCESS = 0, ERROR = -1, ERROR_BAD_VALUE = -2, ERROR_INVALID_OPERATION = -3, ERROR_DEAD_OBJECT = -6;

    // ---- test hooks
    public static volatile float[] FAKE_AUDIO = new float[0];
    public static volatile int FAKE_RATE = 16000;
    public static volatile int OPENED = 0, RELEASED = 0;
    /** Runs once when the virtual clock passes AT_MS (e.g. a manual stop). */
    public static volatile long AT_MS = -1; public static volatile Runnable AT;

    final int rate; int pos, state, recState = RECORDSTATE_STOPPED; double clockFrac;

    public AudioRecord(int audioSource, int sampleRateInHz, int channelConfig, int audioFormat, int bufferSizeInBytes) throws IllegalArgumentException {
        rate = sampleRateInHz;
        state = sampleRateInHz == FAKE_RATE && bufferSizeInBytes > 0 ? STATE_INITIALIZED : STATE_UNINITIALIZED;
        OPENED++;
    }
    public static int getMinBufferSize(int sampleRateInHz, int channelConfig, int audioFormat) { return sampleRateInHz / 10 * 2; }
    public int getState() { return state; }
    public int getRecordingState() { return recState; }
    public int getSampleRate() { return rate; }
    public void startRecording() throws IllegalStateException {
        if (state != STATE_INITIALIZED) throw new IllegalStateException("not initialised");
        recState = RECORDSTATE_RECORDING;
    }
    public void stop() throws IllegalStateException { recState = RECORDSTATE_STOPPED; }
    public void release() { recState = RECORDSTATE_STOPPED; state = STATE_UNINITIALIZED; RELEASED++; }
    public int read(short[] audioData, int offsetInShorts, int sizeInShorts) {
        if (recState != RECORDSTATE_RECORDING) return ERROR_INVALID_OPERATION;
        float[] a = FAKE_AUDIO;
        for (int i = 0; i < sizeInShorts; i++, pos++) {
            float v = pos < a.length ? a[pos] : 0f;
            audioData[offsetInShorts + i] = (short) Math.max(-32768, Math.min(32767, Math.round(v * 32767)));
        }
        clockFrac += sizeInShorts * 1000.0 / rate;
        long ms = (long) clockFrac; clockFrac -= ms;
        android.os.SystemClock.advance(ms);
        Runnable at = AT;
        if (at != null && AT_MS >= 0 && android.os.SystemClock.elapsedRealtime() >= AT_MS) { AT = null; at.run(); }
        return sizeInShorts;
    }
}
