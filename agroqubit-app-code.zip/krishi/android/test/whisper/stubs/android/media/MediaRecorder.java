package android.media;
/** Compile-time stub (SDK constants). */
public class MediaRecorder {
    public final class AudioSource {
        private AudioSource() { }
        public static final int DEFAULT = 0, MIC = 1, VOICE_RECOGNITION = 6, VOICE_COMMUNICATION = 7, UNPROCESSED = 9;
    }
}
