package android.media;
/** Compile-time stub (SDK constants). */
public final class AudioFormat {
    public static final int ENCODING_PCM_16BIT = 2, ENCODING_PCM_FLOAT = 4;
    public static final int CHANNEL_IN_MONO = 16, CHANNEL_IN_STEREO = 12;
}
