package android.os;
/** Compile-time stub (SDK constants). */
public class Process {
    public static final int THREAD_PRIORITY_DEFAULT = 0, THREAD_PRIORITY_BACKGROUND = 10, THREAD_PRIORITY_AUDIO = -16, THREAD_PRIORITY_URGENT_AUDIO = -19;
    public static final void setThreadPriority(int priority) throws IllegalArgumentException, SecurityException { }
}
