package android.os;
/** Test double: runs posted work at once on the calling thread. */
public class Handler {
    public Handler(Looper looper) { }
    public final boolean post(Runnable r) { r.run(); return true; }
    public final boolean postDelayed(Runnable r, long delayMillis) { r.run(); return true; }
}
