package android.os;
/** Test double: a virtual clock advanced by the fake AudioRecord (so endpointing tests run fast and deterministic). */
public final class SystemClock {
    static long now = 0;
    public static synchronized long elapsedRealtime() { return now; }
    public static synchronized void advance(long ms) { now += ms; }
}
