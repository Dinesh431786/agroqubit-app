import android.media.AudioRecord;
import android.os.SystemClock;
import in.krishi.doctor.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Listen.java on a plain JVM: the android.* test doubles in stubs/ play synthetic audio through a fake AudioRecord on a
 * virtual clock. Checks endpointing (start on speech, stop after 0.8 s silence, 12 s cap, 8 s no-speech timeout,
 * manual stop, cancel, too-short blip), the 48 kHz fallback + resampler, the hand-off to Whisper and resource release.
 * Usage (see README): javac -cp ... stubs + core + Listen.java + ListenTest.java; java ListenTest MODEL_DIR (whisper_hi.*)
 */
public class ListenTest {
    static final Random R = new Random(5);
    static float[] noise(double secs, double db, int sr) {
        float[] x = new float[(int) (secs * sr)]; double a = Math.pow(10, db / 20);
        for (int i = 0; i < x.length; i++) x[i] = (float) (a * R.nextGaussian());
        return x;
    }
    /** Syllable-like bursts (harmonic tone with a 4 Hz envelope) at about `db` dBFS RMS over a -60 dB noise floor. */
    static float[] speech(double secs, double db, int sr) {
        float[] x = noise(secs, -60, sr); double a = Math.pow(10, db / 20) * 1.6;
        for (int i = 0; i < x.length; i++) {
            double t = (double) i / sr, env = 0.35 + 0.65 * Math.abs(Math.sin(Math.PI * 4 * t));
            x[i] += (float) (a * env * (Math.sin(2 * Math.PI * 170 * t) + 0.5 * Math.sin(2 * Math.PI * 340 * t) + 0.25 * Math.sin(2 * Math.PI * 1020 * t)) / 1.75);
        }
        return x;
    }
    static float[] cat(float[]... parts) {
        int n = 0; for (float[] p : parts) n += p.length;
        float[] y = new float[n]; int o = 0; for (float[] p : parts) { System.arraycopy(p, 0, y, o, p.length); o += p.length; }
        return y;
    }

    static final class Rec implements Listen.Callback {
        final List<String> events = Collections.synchronizedList(new ArrayList<String>());
        final CountDownLatch done = new CountDownLatch(1); volatile long endMs = -1; volatile String outcome;
        void ev(String e) { events.add(e + "@" + SystemClock.elapsedRealtime()); }
        public void onReady() { ev("ready"); }
        public void onSpeech() { ev("speech"); }
        public void onLevel(float level) { }
        public void onThinking() { ev("thinking"); endMs = SystemClock.elapsedRealtime(); }
        public void onResult(String text, double confidence, Whisper.Result r) { ev("result"); outcome = "result"; done.countDown(); }
        public void onNothing(String reason) { ev("nothing:" + reason); outcome = "nothing:" + reason; if (endMs < 0) endMs = SystemClock.elapsedRealtime(); done.countDown(); }
        public void onError(Exception e) { ev("error:" + e); outcome = "error"; done.countDown(); }
    }

    static int fails = 0;
    static void check(String name, boolean ok, String detail) {
        System.out.printf("  %-4s %s %s%n", ok ? "ok" : "FAIL", name, detail);
        if (!ok) fails++;
    }

    /** Runs one scenario; returns the recogniser (for .last). */
    static Object[] run(Whisper.Opener res, String name, float[] audio, int rate, long atMs, String action) throws Exception {
        AudioRecord.FAKE_AUDIO = audio; AudioRecord.FAKE_RATE = rate;
        int opened0 = AudioRecord.OPENED, released0 = AudioRecord.RELEASED;
        long t0 = SystemClock.elapsedRealtime();
        Rec cb = new Rec(); final Listen l = new Listen(res, cb); l.setLanguage("hi");
        if (action != null) {
            AudioRecord.AT_MS = t0 + atMs;
            AudioRecord.AT = action.equals("stop") ? (Runnable) l::stop : (Runnable) l::cancel;
        } else { AudioRecord.AT = null; AudioRecord.AT_MS = -1; }
        long w0 = System.nanoTime();
        boolean started = l.start();
        boolean finished = cb.done.await(300, TimeUnit.SECONDS);
        Thread.sleep(50);
        l.release();
        System.out.printf("%s: %s (wall %.1f s) events %s%n", name, cb.outcome, (System.nanoTime() - w0) / 1e9, cb.events);
        check(name + " started+finished", started && finished, "");
        int opened = AudioRecord.OPENED - opened0, released = AudioRecord.RELEASED - released0;
        check(name + " AudioRecord released", opened == released && opened >= 1, opened + " opened / " + released + " released");
        return new Object[]{cb, l, (cb.endMs - t0) / 1000.0};
    }

    public static void main(String[] a) throws Exception {
        final File dir = new File(a[0]);
        Whisper.Opener res = name -> new FileInputStream(new File(dir, name));
        check("hasModel(hi)", Listen.hasModel(res, "hi"), "");
        check("hasModel(xx) false", !Listen.hasModel(res, "xx"), "");
        int sr = 16000;

        Object[] o = run(res, "speech 2.5 s then silence", cat(noise(1.0, -60, sr), speech(2.5, -22, sr), noise(4.0, -60, sr)), sr, -1, null);
        Rec cb = (Rec) o[0]; Whisper.Result r = ((Listen) o[1]).last; double end = (double) o[2];
        check("stops ~0.8 s after speech", Math.abs(end - (1.0 + 2.5 + 0.8)) < 0.15, String.format("stopped at %.2f s (expected 4.30)", end));
        check("audio = pre-roll + speech + tail", r != null && Math.abs(r.samples / 16000.0 - (0.24 + 2.5 + 0.3)) < 0.12,
                r == null ? "no result" : String.format("%.2f s sent to Whisper (expected ~3.04)", r.samples / 16000.0));
        check("events in order", cb.events.size() >= 3 && cb.events.get(0).startsWith("ready") && cb.events.get(1).startsWith("speech")
                && cb.events.get(2).startsWith("thinking"), "");

        o = run(res, "background noise only", noise(12.0, -50, sr), sr, -1, null);
        cb = (Rec) o[0]; end = (double) o[2];
        check("no-speech timeout ~8 s", "nothing:no_speech".equals(cb.outcome) && Math.abs(end - 8.0) < 0.2, String.format("%s at %.2f s", cb.outcome, end));

        o = run(res, "20 s of speech", cat(noise(0.5, -60, sr), speech(20, -22, sr)), sr, -1, null);
        r = ((Listen) o[1]).last; end = (double) o[2];
        check("12 s cap", Math.abs(end - (0.5 + 12.0)) < 0.1 && r != null && Math.abs(r.samples / 16000.0 - 12.24) < 0.1,
                String.format("stopped at %.2f s, %.2f s sent", end, r == null ? -1 : r.samples / 16000.0));

        o = run(res, "manual stop", cat(noise(1.0, -60, sr), speech(5, -22, sr)), sr, 2500, "stop");
        r = ((Listen) o[1]).last; end = (double) o[2];
        check("manual stop at 2.5 s", Math.abs(end - 2.5) < 0.1 && r != null && Math.abs(r.samples / 16000.0 - (0.24 + 1.5)) < 0.12,
                String.format("stopped at %.2f s, %.2f s sent", end, r == null ? -1 : r.samples / 16000.0));

        o = run(res, "cancel", cat(noise(1.0, -60, sr), speech(5, -22, sr)), sr, 2000, "cancel");
        check("cancel -> nothing", "nothing:cancelled".equals(((Rec) o[0]).outcome) && ((Listen) o[1]).last == null, ((Rec) o[0]).outcome);

        o = run(res, "120 ms blip", cat(noise(1.0, -60, sr), speech(0.12, -20, sr), noise(3.0, -60, sr)), sr, -1, null);
        check("blip -> too_short", "nothing:too_short".equals(((Rec) o[0]).outcome), ((Rec) o[0]).outcome);

        int sr48 = 48000;
        o = run(res, "48 kHz fallback", cat(noise(1.0, -60, sr48), speech(2.0, -22, sr48), noise(3.0, -60, sr48)), sr48, -1, null);
        r = ((Listen) o[1]).last;
        check("48 kHz -> 16 kHz", r != null && Math.abs(r.samples / 16000.0 - (0.24 + 2.0 + 0.3)) < 0.12,
                r == null ? "no result" : String.format("%.2f s at 16 kHz sent (expected ~2.54)", r.samples / 16000.0));

        // resampler: a 1 kHz tone at 44.1 kHz keeps its amplitude and frequency at 16 kHz; 9 kHz (above Nyquist) is removed
        float[] x = new float[44100]; float[] z = new float[44100];
        for (int i = 0; i < x.length; i++) { x[i] = (float) Math.sin(2 * Math.PI * 1000 * i / 44100.0); z[i] = (float) Math.sin(2 * Math.PI * 9000 * i / 44100.0); }
        float[] y = resample(x, 44100, 16000), yz = resample(z, 44100, 16000);
        double err = 0, rz = 0;
        for (int i = 100; i < y.length - 100; i++) { err = Math.max(err, Math.abs(y[i] - Math.sin(2 * Math.PI * 1000 * i / 16000.0))); rz = Math.max(rz, Math.abs(yz[i])); }
        check("resampler 44.1k->16k", y.length == 16000 && err < 0.02 && rz < 0.05, String.format("1 kHz max err %.4f, 9 kHz leak %.4f", err, rz));

        System.out.println(fails == 0 ? "LISTEN OK" : "LISTEN FAIL (" + fails + ")");
        Nn.release();
        System.exit(fails == 0 ? 0 : 1);
    }

    static float[] resample(float[] x, int from, int to) throws Exception {
        java.lang.reflect.Method m = Listen.class.getDeclaredMethod("resample", float[].class, int.class, int.class);
        m.setAccessible(true);
        return (float[]) m.invoke(null, x, from, to);
    }
}
