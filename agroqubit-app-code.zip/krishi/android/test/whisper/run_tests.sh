#!/bin/bash
# All local Whisper tests (no GPU, no network): Python reference -> Java parity, kernel identity, Listen on the JVM, speed.
# Usage: android/test/whisper/run_tests.sh [WORK_DIR]      (about 10 min on 2 CPUs, < 2 GB RAM)
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../../.." && pwd)
W=${1:-/tmp/whisper_tests}
A=$ROOT/android
mkdir -p "$W/cls" "$W/lcls"
echo "== 1. reference case (random-init Whisper-tiny, synthetic vocab, HF transformers)"
python3 "$A/test/whisper/make_whisper_case.py" "$W/case"
echo "== 2. compile (Java 8 language level)"
CORE="$A/src/in/krishi/doctor"
CORE_SRC="$CORE/Whisper.java $CORE/WhisperMath.java $CORE/Nn.java $CORE/Krw.java $CORE/Json.java"
javac -nowarn -encoding UTF-8 --release 8 -d "$W/cls" $CORE_SRC "$A"/test/whisper/Whisper*.java
javac -nowarn -encoding UTF-8 --release 8 -d "$W/lcls" $(find "$A/test/whisper/stubs" -name '*.java') \
  $CORE_SRC "$A/app/src/in/krishi/doctor/Listen.java" "$A/test/whisper/ListenTest.java"
echo "== 3. WhisperMath kernels == Nn kernels (bit-identical)"
java -Xmx1g -cp "$W/cls" WhisperMathTest
echo "== 4. Whisper.java vs transformers"
java -Xmx1500m -cp "$W/cls" WhisperTest "$W/case"
echo "== 5. Listen.java endpointing / resampling / hand-off (android.* test doubles)"
java -Xmx1g -cp "$W/lcls" ListenTest "$W/case" 2>&1 | grep -v '^I/Listen'
echo "== 6. speed, 5 s of audio (full vocabulary, then restricted vocabulary)"
for t in 1 4; do
  java -Xmx1g -XX:ActiveProcessorCount=$t -cp "$W/cls" WhisperBench "$W/case/whisper_hi.bin" "$W/case/whisper_hi.json" 5 32
  java -Xmx1g -XX:ActiveProcessorCount=$t -cp "$W/cls" WhisperBench "$W/case/whisper_hi_r.bin" "$W/case/whisper_hi_r.json" 5 32 --short-only
done
