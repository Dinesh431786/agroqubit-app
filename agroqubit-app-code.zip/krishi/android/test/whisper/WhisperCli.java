import in.krishi.doctor.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Transcribes audio files with Whisper.java (SHORT mode unless --full). One JSON line per file.
 * Files: .wav (PCM 16-bit or float32, any channels/rate; mixed to mono, resampled linearly to 16 kHz) or .f32 (raw
 * float32 little-endian, 16 kHz mono).
 * Usage: java -cp CLASSES:. WhisperCli MODEL.bin MODEL.json [--full] [--max-new N] [--nn] FILE...
 */
public class WhisperCli {
    static float[] readF32(File f) throws IOException {
        byte[] b = readAll(f); float[] x = new float[b.length / 4];
        ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(x);
        return x;
    }
    static byte[] readAll(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n); return o.toByteArray();
        }
    }
    static float[] readWav(File f) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(readAll(f)).order(ByteOrder.LITTLE_ENDIAN);
        if (b.getInt(0) != 0x46464952 || b.getInt(8) != 0x45564157) throw new IOException("not a RIFF/WAVE file: " + f);
        int pos = 12, fmt = 0, ch = 0, sr = 0, bits = 0, dataOff = -1, dataLen = 0;
        while (pos + 8 <= b.limit()) {
            int id = b.getInt(pos), len = b.getInt(pos + 4);
            if (id == 0x20746d66) { fmt = b.getShort(pos + 8) & 0xffff; ch = b.getShort(pos + 10); sr = b.getInt(pos + 12); bits = b.getShort(pos + 22); }
            else if (id == 0x61746164) { dataOff = pos + 8; dataLen = Math.min(len, b.limit() - dataOff); break; }
            pos += 8 + len + (len & 1);
        }
        if (dataOff < 0 || ch < 1) throw new IOException("no data chunk: " + f);
        if (fmt == 0xFFFE) fmt = bits == 32 ? 3 : 1;
        int bps = bits / 8, frames = dataLen / (bps * ch);
        float[] x = new float[frames];
        for (int i = 0; i < frames; i++) {
            double s = 0;
            for (int c = 0; c < ch; c++) {
                int o = dataOff + (i * ch + c) * bps;
                if (fmt == 3 && bits == 32) s += b.getFloat(o);
                else if (bits == 16) s += b.getShort(o) / 32768.0;
                else if (bits == 24) s += (((b.get(o) & 0xff) | ((b.get(o + 1) & 0xff) << 8) | (b.get(o + 2) << 16))) / 8388608.0;
                else if (bits == 32) s += b.getInt(o) / 2147483648.0;
                else if (bits == 8) s += ((b.get(o) & 0xff) - 128) / 128.0;
                else throw new IOException("unsupported wav: format " + fmt + ", " + bits + " bits");
            }
            x[i] = (float) (s / ch);
        }
        if (sr == 16000) return x;
        int n = (int) ((long) frames * 16000 / sr); float[] y = new float[n];
        for (int i = 0; i < n; i++) { double p = (double) i * sr / 16000; int k = (int) p; double fr = p - k; y[i] = (float) (x[Math.min(k, frames - 1)] * (1 - fr) + x[Math.min(k + 1, frames - 1)] * fr); }
        return y;
    }
    static String esc(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '"' || c == '\\') b.append('\\').append(c);
            else if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
            else b.append(c);
        }
        return b.toString();
    }

    public static void main(String[] a) throws Exception {
        PrintStream out = new PrintStream(new FileOutputStream(FileDescriptor.out), true, "UTF-8");
        Whisper w = Whisper.load(new File(a[0]), new File(a[1]));
        boolean full = false; int maxNew = w.maxNewTokens; List<String> files = new ArrayList<>();
        for (int i = 2; i < a.length; i++) {
            if (a[i].equals("--full")) full = true;
            else if (a[i].equals("--nn")) Whisper.nnKernels = true;
            else if (a[i].equals("--max-new")) maxNew = Integer.parseInt(a[++i]);
            else files.add(a[i]);
        }
        for (String fn : files) {
            File f = new File(fn);
            float[] pcm = fn.endsWith(".f32") ? readF32(f) : readWav(f);
            long t0 = System.nanoTime();
            Whisper.Result r = w.transcribe(pcm, pcm.length, full, maxNew);
            long ms = (System.nanoTime() - t0) / 1_000_000;
            StringBuilder toks = new StringBuilder();
            for (int i = 0; i < r.tokens.length; i++) toks.append(i > 0 ? "," : "").append(r.tokens[i]);
            out.printf(Locale.ROOT, "{\"file\":\"%s\",\"text\":\"%s\",\"tokens\":[%s],\"avg_logprob\":%.4f,\"no_speech\":%.4f,\"compression_ratio\":%.3f,"
                            + "\"confidence\":%.3f,\"unreliable\":%s,\"seconds\":%.2f,\"ms\":%d,\"mel_ms\":%d,\"enc_ms\":%d,\"dec_ms\":%d}%n",
                    esc(fn), esc(r.text), toks, r.avgLogProb, r.noSpeechProb, r.compressionRatio, r.confidence(), r.unreliable(),
                    pcm.length / 16000.0, ms, r.melMs, r.encMs, r.decMs);
        }
        Nn.release();
    }
}
