import in.krishi.doctor.*;
import java.util.*;

/**
 * WhisperMath (blocked kernels) must give exactly the same floats as the shared Nn kernels it replaces:
 * linear (int8 and float weights, tails in rows and time), attention (plain, causal with KV-cache offset), conv k3.
 * Usage: java -cp CLASSES:. WhisperMathTest
 */
public class WhisperMathTest {
    static Random R = new Random(3);
    static Krw.T q8(int rows, int cols) {
        Krw.T t = new Krw.T(); t.rows = rows; t.cols = cols; t.shape = new int[]{rows, cols};
        t.q = new byte[rows * cols]; t.sc = new float[rows];
        for (int i = 0; i < t.q.length; i++) t.q[i] = (byte) (R.nextInt(255) - 127);
        for (int i = 0; i < rows; i++) t.sc[i] = 0.001f + R.nextFloat() * 0.01f;
        return t;
    }
    static Krw.T f32(int rows, int cols) {
        Krw.T t = new Krw.T(); t.rows = rows; t.cols = cols; t.shape = new int[]{rows, cols};
        t.f = rnd(rows * cols); return t;
    }
    static float[] rnd(int n) { float[] a = new float[n]; for (int i = 0; i < n; i++) a[i] = (float) R.nextGaussian(); return a; }
    static int diffs(float[] a, float[] b) {
        if (a.length != b.length) return Integer.MAX_VALUE;
        int n = 0; for (int i = 0; i < a.length; i++) if (Float.floatToIntBits(a[i]) != Float.floatToIntBits(b[i]) && !(a[i] == 0f && b[i] == 0f)) n++;
        return n;
    }
    public static void main(String[] a) {
        int bad = 0, cases = 0;
        int[][] shapes = {{1, 384, 384}, {2, 51867, 64}, {4, 1152, 384}, {7, 13, 29}, {8, 384, 1536}, {37, 1536, 384}, {250, 384, 384}, {33, 6, 10}};
        for (int[] s : shapes) {
            int T = s[0], out = s[1], in = s[2];
            float[] x = rnd(T * in), b = rnd(out);
            for (int kind = 0; kind < 2; kind++) {
                Krw.T W = kind == 0 ? q8(out, in) : f32(out, in);
                for (float[] bias : new float[][]{b, null}) {
                    int d = diffs(WhisperMath.linear(W, bias, x, T), Nn.linear(W, bias, x, T)); cases++;
                    if (d != 0) { bad++; System.out.printf("linear T=%d out=%d in=%d %s bias=%s: %d values differ%n", T, out, in, kind == 0 ? "int8" : "f32", bias != null, d); }
                }
            }
        }
        int[][] att = {{250, 250, 384, 6, 0}, {1, 97, 384, 6, 1}, {4, 4, 384, 6, 1}, {5, 9, 24, 4, 1}, {3, 7, 24, 4, 0}};
        for (int[] s : att) {
            int Tq = s[0], Tk = s[1], d = s[2], h = s[3]; boolean causal = s[4] == 1;
            float[] q = rnd(Tq * d), k = rnd(Tk * d), v = rnd(Tk * d);
            int df = diffs(WhisperMath.attention(q, k, v, Tq, Tk, d, h, causal), Nn.attention(q, k, v, Tq, Tk, d, h, causal, null)); cases++;
            if (df != 0) { bad++; System.out.printf("attention Tq=%d Tk=%d causal=%s: %d values differ%n", Tq, Tk, causal, df); }
        }
        for (int[] s : new int[][]{{80, 384, 70, 1}, {384, 384, 70, 2}, {5, 8, 9, 2}, {5, 8, 10, 1}}) {
            int cin = s[0], cout = s[1], T = s[2], stride = s[3];
            Krw.T W = f32(cout, cin * 3); float[] b = rnd(cout), xc = rnd(cin * T);
            float[] ref = Nn.conv1d(xc, cin, T, W, b, cout, 3, stride, 1, 1, 1);    // [cout][Tout]
            int Tout = Nn.convOut(T, 3, stride, 1, 1);
            float[] mine = WhisperMath.conv3(xc, cin, T, true, stride, W, b);        // [Tout][cout]
            float[] xt = Nn.transpose(xc, cin, T);                                   // token-major input
            float[] mine2 = WhisperMath.conv3(xt, cin, T, false, stride, W, b);
            int df = diffs(Nn.transpose(mine, Tout, cout), ref) + diffs(Nn.transpose(mine2, Tout, cout), ref); cases++;
            if (df != 0) { bad++; System.out.printf("conv3 cin=%d cout=%d T=%d stride=%d: %d values differ%n", cin, cout, T, stride, df); }
        }
        float[] g = rnd(10000), g2 = g.clone(); WhisperMath.gelu(g); Nn.gelu(g2); cases++;
        if (diffs(g, g2) != 0) { bad++; System.out.println("gelu differs"); }
        System.out.println(bad == 0 ? "WHISPERMATH OK (" + cases + " cases bit-identical to Nn)" : "WHISPERMATH FAIL " + bad + "/" + cases);
        Nn.release();
        if (bad != 0) System.exit(1);
    }
}
