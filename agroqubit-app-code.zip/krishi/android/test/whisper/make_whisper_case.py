#!/usr/bin/env python3
"""Reference outputs for android/test/whisper/WhisperTest.java (Whisper.java vs Hugging Face transformers).

Random-init Whisper-tiny (d_model 384, 4+4 layers, 6 heads, vocab 51865, 1500/448 positions) with a synthetic BPE
vocab (same id layout as openai/whisper-tiny). Weights are perturbed (LayerNorm gains/biases, sharper q/k, wider
token embedding) so attention is not uniform and greedy argmax gaps are large. The model is exported with
speech/whisper/export_whisper.py and the HF reference is computed with the *exported* weights loaded back
(dequantised int8 / fp16), so the Java comparison isolates the implementation; the int8 effect is reported apart.
suppress_tokens / begin_suppress_tokens get the unsuppressed first-step winners added, so suppression must work.

A second export of the same weights with a restricted vocabulary (tokens of a few synthetic sentences + the 256
byte tokens + specials; --keep-text in export_whisper.py) is checked against the HF model with the other logits masked.

Synthetic audio: tone (harmonics + 4 Hz envelope), white noise, chirp, a 0.7 s burst, digital silence, and a 31 s
signal (log-mel truncation only). For each: HF log-mel (WhisperFeatureExtractor), encoder states (full = HF
WhisperEncoder; short = whisper_common.encode, checked equal to HF in full mode), raw first-step logits after the
forced prefix, 20 greedy steps (manual loop with Whisper suppression; checked against model.generate), and an
end-to-end greedy decode with stop at eot (max 96) for the transcribe() path.

Usage: python android/test/whisper/make_whisper_case.py OUT_DIR      (about 2 min, < 1.5 GB RAM)
"""
import json, os, sys, time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "speech", "whisper"))
sys.path.insert(0, os.path.join(ROOT, "android", "tools"))
import whisper_common as wc  # noqa: E402
import export_whisper as ex  # noqa: E402
from krw import write_krw1, f32  # noqa: E402

SR = 16000
STEPS = 20


def audio_cases():
    rng = np.random.default_rng(1)
    t = lambda s: np.arange(int(s * SR)) / SR  # noqa: E731
    c = {}
    x = t(5.0)
    env = 0.55 + 0.45 * np.sin(2 * np.pi * 4 * x)
    c["tone5s"] = 0.3 * env * (np.sin(2 * np.pi * 220 * x) + 0.5 * np.sin(2 * np.pi * 440 * x) + 0.25 * np.sin(2 * np.pi * 1320 * x))
    c["noise3s"] = 0.05 * rng.standard_normal(int(3.2 * SR))
    x = t(7.3)
    c["chirp7s"] = 0.25 * np.sin(2 * np.pi * (100 * x + 0.5 * (6000 - 100) / 7.3 * x * x)) + 0.01 * rng.standard_normal(len(x))
    x = t(0.7)
    c["burst07"] = 0.4 * np.sin(2 * np.pi * 300 * x) * (np.abs(x - 0.35) < 0.2)
    c["silence2s"] = np.zeros(2 * SR)
    x = t(31.0)
    c["long31s"] = 0.2 * np.sin(2 * np.pi * 180 * x) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.5 * x)) + 0.02 * rng.standard_normal(len(x))
    return {k: v.astype(np.float32) for k, v in c.items()}


FULL = ["tone5s", "noise3s", "chirp7s"]          # encoder / decoder parity in the 30 s window
SHORT = ["tone5s", "noise3s", "chirp7s", "burst07", "silence2s"]
MEL_ONLY = ["long31s"]


def perturb(model, seed=0):
    g = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for name, p in model.named_parameters():
            if "layer_norm" in name and name.endswith("weight"):
                p.copy_(1 + 0.2 * torch.randn(p.shape, generator=g))
            elif "layer_norm" in name and name.endswith("bias"):
                p.copy_(0.1 * torch.randn(p.shape, generator=g))
            elif name.endswith("bias"):
                p.copy_(0.05 * torch.randn(p.shape, generator=g))
            elif ("q_proj" in name or "k_proj" in name) and name.endswith("weight"):
                p.copy_(0.06 * torch.randn(p.shape, generator=g))
            elif ("fc1" in name or "fc2" in name) and name.endswith("weight"):
                p.copy_(0.04 * torch.randn(p.shape, generator=g))
            elif name.endswith("embed_tokens.weight"):
                p.copy_(0.1 * torch.randn(p.shape, generator=g))
            elif "decoder.embed_positions" in name:
                p.copy_(0.05 * torch.randn(p.shape, generator=g))


@torch.no_grad()
def raw_prompt_logits(model, enc, prompt, sot_index=0):
    out = model.model.decoder(input_ids=torch.tensor([prompt]), encoder_hidden_states=enc)
    lg = model.proj_out(out.last_hidden_state)[0].float()
    return lg[-1], lg[sot_index]


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/whisper_case"
    os.makedirs(out, exist_ok=True)
    torch.set_num_threads(2)
    t0 = time.time()
    from transformers import WhisperFeatureExtractor, WhisperForConditionalGeneration
    tok = wc.build_synthetic_tokenizer(os.path.join(out, "tok"))
    torch.manual_seed(0)
    model = WhisperForConditionalGeneration(wc.tiny_config()).eval()
    perturb(model)
    gen = wc.synthetic_generation_config(tok)
    model.generation_config = gen
    fp32 = WhisperForConditionalGeneration(wc.tiny_config()).eval()
    fp32.load_state_dict(model.state_dict())
    lang = "hi"
    prompt = wc.decoder_prompt(gen, tok, lang, "hf")
    sp = wc.special_ids(gen, tok, lang)

    # 1) weights -> KRW1, reload the exact phone weights into the HF model
    bp = os.path.join(out, f"whisper_{lang}.bin")
    ex.export_weights(model, bp)
    ex.load_exported_into(model, bp)
    fe = WhisperFeatureExtractor()
    A = audio_cases()

    def hf_mel(x):
        return fe(x, sampling_rate=SR, return_tensors="pt").input_features  # [1, 80, 3000]

    # 2) make suppression matter: suppress the raw first-step winner, begin-suppress the next one
    mel0 = hf_mel(A["tone5s"])
    with torch.no_grad():
        enc0 = model.model.encoder(mel0).last_hidden_state
    last, _ = raw_prompt_logits(model, enc0, prompt)
    order = torch.argsort(last, descending=True).tolist()
    sup_extra = [t for t in order if t < sp["eot"]][:1]
    bsup_extra = [t for t in order if t < sp["eot"] and t not in sup_extra][:1]
    gen.suppress_tokens = sorted(set(gen.suppress_tokens) | set(sup_extra))
    gen.begin_suppress_tokens = list(gen.begin_suppress_tokens) + bsup_extra
    jp = os.path.join(out, f"whisper_{lang}.json")
    ex.export_meta(model, tok, gen, lang, jp, prompt=prompt, info={"source": "random-init test model"})
    vb, _ = wc.vocab_bytes(tok, 51865)

    T = {}
    meta = {"lang": lang, "prompt": prompt, "steps": STEPS, "cases": [], "suppress_extra": sup_extra,
            "begin_suppress_extra": bsup_extra}
    dec_kw = dict(suppress=gen.suppress_tokens, begin_suppress=gen.begin_suppress_tokens, eot=sp["eot"],
                  no_speech=sp["no_speech"])
    min_gap = 1e9
    gen_check = []
    for name, x in A.items():
        cm = {"name": name, "samples": int(len(x)), "full": name in FULL, "short": name in SHORT}
        T[f"{name}.pcm"] = f32(x)
        mel = hf_mel(x)
        T[f"{name}.mel_full"] = f32(mel[0].numpy())
        F_ = wc.short_frames(len(x))
        cm["frames_short"] = F_
        T[f"{name}.mel_short"] = f32(mel[0, :, :F_].numpy())
        for mode in ("full", "short"):
            if not cm[mode]:
                continue
            with torch.no_grad():
                if mode == "full":
                    enc = model.model.encoder(mel).last_hidden_state
                    mine, _ = wc.encode(model, mel)
                    cm["self_check_full_encode"] = float((mine - enc).abs().max())
                else:
                    enc, _ = wc.encode(model, mel[:, :, :F_].contiguous())
            T[f"{name}.enc_{mode}"] = f32(enc[0].numpy())
            last, at_sot = raw_prompt_logits(model, enc, prompt, 0)
            T[f"{name}.logits_{mode}"] = f32(last.numpy())
            g = wc.greedy(model, enc, None, prompt, max_new=STEPS, stop_at_eot=False, **dec_kw)
            ids = g["raw"][0]
            T[f"{name}.ids_{mode}"] = f32(np.asarray(ids, np.float32))
            # smallest top-1/top-2 gap along the greedy path (robustness of the argmax comparison)
            lg = last.clone()
            with torch.no_grad():
                seq = list(prompt)
                for step, tid in enumerate(ids):
                    l2 = lg.clone()
                    l2[gen.suppress_tokens] = float("-inf")
                    if step == 0:
                        l2[gen.begin_suppress_tokens] = float("-inf")
                    top = torch.topk(l2, 2).values
                    min_gap = min(min_gap, float(top[0] - top[1]))
                    seq.append(tid)
                    o = model.model.decoder(input_ids=torch.tensor([seq]), encoder_hidden_states=enc)
                    lg = model.proj_out(o.last_hidden_state[0, -1]).float()
            e2e = wc.greedy(model, enc, None, prompt, max_new=96, stop_at_eot=True, **dec_kw)
            cm[mode] = {"ids": ids, "text20": wc.detok(ids, vb, sp["eot"]), "avg_logprob20": g["avg_logprob"][0],
                        "no_speech": g["no_speech_prob"][0], "e2e_ids": e2e["ids"][0],
                        "e2e_text": wc.detok(e2e["ids"][0], vb, sp["eot"]), "e2e_avg_logprob": e2e["avg_logprob"][0],
                        "e2e_no_speech": e2e["no_speech_prob"][0], "e2e_steps": len(e2e["raw"][0])}
            if mode == "full":
                # the manual loop must agree with transformers' own generate()
                with torch.no_grad():
                    gi = model.generate(input_features=mel, language=lang, task="transcribe", max_new_tokens=STEPS,
                                        do_sample=False, num_beams=1)[0].tolist()
                gi = gi[len(prompt):] if gi[: len(prompt)] == prompt else gi
                k = min(len(gi), len(ids))
                gen_check.append({"case": name, "generate": gi, "agree_prefix": gi[:k] == ids[:k], "compared": k})
                # quantisation effect (fp32 original vs exported weights), info only
                with torch.no_grad():
                    e32 = fp32.model.encoder(mel).last_hidden_state
                    l32, _ = raw_prompt_logits(fp32, e32, prompt)
                g32 = wc.greedy(fp32, e32, None, prompt, max_new=STEPS, stop_at_eot=False, **dec_kw)
                cm["int8_effect"] = {"enc_max_abs": float((e32 - enc).abs().max()), "enc_rms": float((e32 - enc).pow(2).mean().sqrt()),
                                     "logits_max_abs": float((l32 - last).abs().max()),
                                     "greedy_same": g32["raw"][0] == ids}
        meta["cases"].append(cm)
        print(f"[case] {name}: {len(x) / SR:.2f} s, short frames {F_}", flush=True)
    meta["min_top2_gap"] = min_gap
    meta["generate_check"] = gen_check

    # 3) restricted vocabulary: same weights, only kept rows exported; reference = HF logits with the rest masked
    texts = ["".join(wc.SYN_WORDS[i::3]) for i in range(3)] + ["पत्ते पीले हैं", "the rice leaf has yellow spots"]
    keep = wc.keep_ids(tok, texts, list(prompt) + [sp["eot"], sp["no_speech"]], 51865)
    ex.export(model, tok, gen, lang, out, name=f"whisper_{lang}_r", prompt=prompt, keep=keep)
    allowed = torch.zeros(51865, dtype=torch.bool)
    allowed[keep] = True
    rmeta = {"kept": len(keep), "cases": []}
    for name in ["tone5s", "burst07", "silence2s"]:
        x = A[name]
        F_ = wc.short_frames(len(x))
        mel = hf_mel(x)[:, :, :F_].contiguous()
        with torch.no_grad():
            enc, _ = wc.encode(model, mel)
        last, _ = raw_prompt_logits(model, enc, prompt, 0)
        last = last.masked_fill(~allowed, float("-inf"))
        T[f"r.{name}.logits_short"] = f32(np.where(np.isfinite(last.numpy()), last.numpy(), -1e30).astype(np.float32))
        g = wc.greedy(model, enc, None, prompt, max_new=STEPS, stop_at_eot=False, allowed=allowed, **dec_kw)
        e2e = wc.greedy(model, enc, None, prompt, max_new=96, stop_at_eot=True, allowed=allowed, **dec_kw)
        rmeta["cases"].append({"name": name, "ids": g["raw"][0], "text20": wc.detok(g["raw"][0], vb, sp["eot"]),
                               "avg_logprob20": g["avg_logprob"][0], "no_speech": g["no_speech_prob"][0],
                               "e2e_ids": e2e["ids"][0], "e2e_text": wc.detok(e2e["ids"][0], vb, sp["eot"]),
                               "e2e_avg_logprob": e2e["avg_logprob"][0], "e2e_no_speech": e2e["no_speech_prob"][0]})
    meta["restricted"] = rmeta
    print(f"[case] restricted vocabulary: {len(keep)} of 51865 tokens, "
          f"{os.path.getsize(os.path.join(out, f'whisper_{lang}_r.bin')) / 1e6:.1f} MB", flush=True)
    write_krw1(os.path.join(out, "case.krw"), T)
    with open(os.path.join(out, "case.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)
    print(json.dumps({"out": out, "min_top2_gap": round(min_gap, 4), "generate_agrees": all(g["agree_prefix"] for g in gen_check),
                      "seconds": round(time.time() - t0, 1)}))


if __name__ == "__main__":
    main()
