import in.krishi.doctor.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Whisper.java vs Hugging Face transformers (reference written by make_whisper_case.py).
 * Checks: log-mel (full 3000 frames and short), encoder states from the HF mel (isolates the encoder) and from the Java
 * mel (end to end), raw first-step logits after the forced prefix, 20 greedy ids with suppression (must be identical),
 * text, avg log-prob, no-speech prob, and the transcribe() path (stop at eot, max 96 tokens).
 * Usage: java -cp CLASSES:. WhisperTest CASE_DIR
 */
@SuppressWarnings("unchecked")
public class WhisperTest {
    static double maxd(float[] a, float[] b) {
        if (a.length != b.length) return 1e9;
        double m = 0; for (int i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i] - b[i])); return m;
    }
    static int[] ints(List<Object> l) { int[] a = new int[l.size()]; for (int i = 0; i < a.length; i++) a[i] = ((Number) l.get(i)).intValue(); return a; }
    static int[] ints(float[] f) { int[] a = new int[f.length]; for (int i = 0; i < a.length; i++) a[i] = Math.round(f[i]); return a; }
    static String read(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[1 << 16]; int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n); return new String(b.toByteArray(), StandardCharsets.UTF_8);
        }
    }
    static boolean ok = true; static double worstMel, worstEncA, worstEncB, worstLogits, worstLp, worstNs;
    static void check(String what, boolean pass) { if (!pass) { ok = false; System.out.println("  FAIL " + what); } }

    public static void main(String[] args) throws Exception {
        File dir = new File(args[0]);
        long t0 = System.nanoTime();
        Whisper w = Whisper.load(new File(dir, "whisper_hi.bin"), new File(dir, "whisper_hi.json"));
        System.out.printf("model loaded in %d ms (%d threads available)%n", (System.nanoTime() - t0) / 1_000_000, Runtime.getRuntime().availableProcessors());
        Map<String, Krw.T> t = Krw.read(new File(dir, "case.krw"));
        Map<String, Object> meta = (Map<String, Object>) Json.parse(read(new File(dir, "case.json")));
        int steps = ((Number) meta.get("steps")).intValue(), idsChecked = 0, idsSame = 0, e2eChecked = 0, e2eSame = 0;
        for (Object o : (List<Object>) meta.get("cases")) {
            Map<String, Object> c = (Map<String, Object>) o; String name = (String) c.get("name");
            float[] pcm = t.get(name + ".pcm").f; int n = pcm.length, F = ((Number) c.get("frames_short")).intValue();
            check(name + " shortFrames " + w.shortFrames(n) + " != " + F, w.shortFrames(n) == F);
            long a0 = System.nanoTime();
            float[] melFull = w.logMel(pcm, n, 3000);
            long a1 = System.nanoTime();
            float[] melShort = w.logMel(pcm, n, F);
            double dmf = maxd(melFull, t.get(name + ".mel_full").f), dms = maxd(melShort, t.get(name + ".mel_short").f);
            worstMel = Math.max(worstMel, Math.max(dmf, dms));
            System.out.printf("%-10s %6.2f s  mel full %.2e  short(%d) %.2e  (%d ms)%n", name, n / 16000.0, dmf, F, dms, (a1 - a0) / 1_000_000);
            check(name + " log-mel", dmf < 1e-3 && dms < 1e-3);
            for (String mode : new String[]{"full", "short"}) {
                if (!(c.get(mode) instanceof Map)) continue;
                Map<String, Object> ref = (Map<String, Object>) c.get(mode);
                boolean full = mode.equals("full"); int frames = full ? 3000 : F, T = frames / 2;
                float[] encRef = t.get(name + ".enc_" + mode).f;
                long b0 = System.nanoTime();
                float[] encA = w.encode(t.get(name + ".mel_" + mode).f, frames);
                long b1 = System.nanoTime();
                float[] encB = w.encode(full ? melFull : melShort, frames);
                double da = maxd(encA, encRef), db = maxd(encB, encRef);
                worstEncA = Math.max(worstEncA, da); worstEncB = Math.max(worstEncB, db);
                float[] lg = w.firstLogits(encA, T);
                double dl = maxd(lg, t.get(name + ".logits_" + mode).f); worstLogits = Math.max(worstLogits, dl);
                Whisper.Result r = new Whisper.Result();
                long c0 = System.nanoTime();
                int[] ids = w.greedy(encB, T, steps, false, r);
                long c1 = System.nanoTime();
                int[] want = ints(t.get(name + ".ids_" + mode).f);
                boolean same = Arrays.equals(ids, want); idsChecked++; if (same) idsSame++;
                String text = w.detokenize(ids, ids.length);
                double dlp = Math.abs(r.avgLogProb - ((Number) ref.get("avg_logprob20")).doubleValue());
                double dns = Math.abs(r.noSpeechProb - ((Number) ref.get("no_speech")).doubleValue());
                worstLp = Math.max(worstLp, dlp); worstNs = Math.max(worstNs, dns);
                System.out.printf("   %-5s enc(HF mel) %.2e  enc(Java mel) %.2e  logits %.2e  greedy %s  text %s  avg_logprob %.1e  no_speech %.1e  (enc %d ms, %d steps %d ms)%n",
                        mode, da, db, dl, same ? "same" : "DIFF", text.equals(ref.get("text20")) ? "same" : "DIFF", dlp, dns,
                        (b1 - b0) / 1_000_000, steps, (c1 - c0) / 1_000_000);
                if (!same) System.out.println("     java " + Arrays.toString(ids) + "\n     ref  " + Arrays.toString(want));
                check(name + "/" + mode + " encoder < 1e-3", da < 1e-3 && db < 1e-3);
                check(name + "/" + mode + " greedy ids", same);
                check(name + "/" + mode + " text", text.equals(ref.get("text20")));
                check(name + "/" + mode + " avg logprob", dlp < 1e-3);
                check(name + "/" + mode + " no-speech prob", dns < 1e-4);
                if (!full || name.equals("tone5s")) {     // transcribe() path: stop at eot, max 96 tokens
                    Whisper.Result e = w.transcribe(pcm, n, full);
                    int[] we = ints((List<Object>) ref.get("e2e_ids"));
                    boolean s2 = Arrays.equals(e.tokens, we) && e.text.equals(ref.get("e2e_text"))
                            && Math.abs(e.avgLogProb - ((Number) ref.get("e2e_avg_logprob")).doubleValue()) < 1e-3
                            && Math.abs(e.noSpeechProb - ((Number) ref.get("e2e_no_speech")).doubleValue()) < 1e-4;
                    e2eChecked++; if (s2) e2eSame++;
                    System.out.printf("   %-5s transcribe(): %d tokens %s, mel %d ms, enc %d ms, dec %d ms, conf %.3f%n", mode, e.tokens.length,
                            s2 ? "same" : "DIFF", e.melMs, e.encMs, e.decMs, e.confidence());
                    check(name + "/" + mode + " transcribe()", s2);
                }
            }
        }
        Map<String, Object> rm = (Map<String, Object>) meta.get("restricted");
        if (rm != null) {
            Whisper wr = Whisper.load(new File(dir, "whisper_hi_r.bin"), new File(dir, "whisper_hi_r.json"));
            System.out.printf("%nrestricted vocabulary: %d rows (of %d)%n", wr.rows, wr.vocab);
            check("restricted rows", wr.rows == ((Number) rm.get("kept")).intValue());
            for (Object o : (List<Object>) rm.get("cases")) {
                Map<String, Object> c = (Map<String, Object>) o; String name = (String) c.get("name");
                float[] pcm = t.get(name + ".pcm").f; int n = pcm.length, F = wr.shortFrames(n), T = F / 2;
                float[] enc = wr.encode(t.get(name + ".mel_short").f, F);
                float[] lg = wr.firstLogits(enc, T), ref = t.get("r." + name + ".logits_short").f;
                double dl = 0; boolean pattern = true;
                for (int i = 0; i < lg.length; i++) {
                    boolean kept = ref[i] > -1e29f;
                    if (kept != (lg[i] != Float.NEGATIVE_INFINITY)) pattern = false;
                    else if (kept) dl = Math.max(dl, Math.abs(lg[i] - ref[i]));
                }
                Whisper.Result r = new Whisper.Result();
                int[] ids = wr.greedy(enc, T, steps, false, r);
                boolean same = Arrays.equals(ids, ints((List<Object>) c.get("ids")));
                boolean txt = wr.detokenize(ids, ids.length).equals(c.get("text20"));
                double dlp = Math.abs(r.avgLogProb - ((Number) c.get("avg_logprob20")).doubleValue());
                double dns = Math.abs(r.noSpeechProb - ((Number) c.get("no_speech")).doubleValue());
                Whisper.Result e = wr.transcribe(pcm, n, false);
                boolean s2 = Arrays.equals(e.tokens, ints((List<Object>) c.get("e2e_ids"))) && e.text.equals(c.get("e2e_text"))
                        && Math.abs(e.avgLogProb - ((Number) c.get("e2e_avg_logprob")).doubleValue()) < 1e-3
                        && Math.abs(e.noSpeechProb - ((Number) c.get("e2e_no_speech")).doubleValue()) < 1e-4;
                idsChecked++; if (same) idsSame++; e2eChecked++; if (s2) e2eSame++;
                System.out.printf("   %-10s short logits %.2e (mask %s)  greedy %s  text %s  avg_logprob %.1e  no_speech %.1e  transcribe() %s (%d tokens, dec %d ms)%n",
                        name, dl, pattern ? "same" : "DIFF", same ? "same" : "DIFF", txt ? "same" : "DIFF", dlp, dns, s2 ? "same" : "DIFF", e.tokens.length, e.decMs);
                check(name + " restricted", pattern && dl < 1e-3 && same && txt && dlp < 1e-3 && dns < 1e-4 && s2);
            }
        }
        System.out.printf("%nworst: log-mel %.2e | encoder (HF mel) %.2e | encoder (Java mel) %.2e | first logits %.2e | avg_logprob %.1e | no_speech %.1e%n",
                worstMel, worstEncA, worstEncB, worstLogits, worstLp, worstNs);
        System.out.printf("greedy 20-step ids identical: %d/%d | transcribe() identical: %d/%d | min top-2 gap in reference %.4f%n",
                idsSame, idsChecked, e2eSame, e2eChecked, ((Number) meta.get("min_top2_gap")).doubleValue());
        System.out.println(ok ? "WHISPER OK" : "WHISPER FAIL");
        Nn.release();
        if (!ok) System.exit(1);
    }
}
