import in.krishi.doctor.*;
import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.util.*;

/** Photo path: Java belief after a photo == Python brain.add_photo_scores; plus the full photo turn on real PlantDoc photos. */
@SuppressWarnings("unchecked")
public class PhotoParity {
    public static void main(String[] a) throws Exception {
        String dir = a[0]; Krishi k = new Krishi(name -> new FileInputStream(dir + "/" + name));
        List<Object> cases = (List<Object>) Json.parse(new String(Files.readAllBytes(Paths.get(a[1])), "UTF-8")); double worst = 0;
        for (Object o : cases) {
            Map<String, Object> c = (Map<String, Object>) o; Map<String, Double> cos = new HashMap<>();
            for (Map.Entry<String, Object> e : ((Map<String, Object>) c.get("cos")).entrySet()) cos.put(e.getKey(), (Double) e.getValue());
            Brain b = new Chat(k, "en", new HashSet<String>()).brain; b.setCrop("tomato"); b.addPhotoScores(cos);
            List<Object> pa = (List<Object>) c.get("post_tomato"); for (int d = 0; d < pa.size(); d++) worst = Math.max(worst, Math.abs(b.st.post[d] - (Double) pa.get(d)));
            Brain b2 = new Chat(k, "en", new HashSet<String>()).brain; b2.addPhotoScores(cos);
            List<Object> pb = (List<Object>) c.get("post_nocrop"); for (int d = 0; d < pb.size(); d++) worst = Math.max(worst, Math.abs(b2.st.post[d] - (Double) pb.get(d)));
        }
        System.out.printf("photo belief parity: %d cases, max posterior diff %.2e%n", cases.size(), worst);
        ByteBuffer X = ByteBuffer.wrap(Files.readAllBytes(Paths.get(a[2]))).order(ByteOrder.LITTLE_ENDIAN); int sz = 3 * 224 * 224;
        for (int i = 0; i < Integer.parseInt(a[3]); i++) {
            float[] x = new float[sz]; for (int j = 0; j < sz; j++) x[j] = X.getFloat((i * sz + j) * 4);
            Krishi.Photo ph = k.photo(x); Chat chat = new Chat(k, i % 2 == 0 ? "hi" : "en", new HashSet<String>());
            Chat.Reply r = chat.photo(ph);
            System.out.println(ph + " | note=" + r.note.replace("\n", " / ") + " | reply=" + r + " | clips=" + r.clips);
        }
        Vision.release();
        System.out.println(worst < 1e-9 ? "PHOTO PARITY OK" : "PHOTO PARITY FAILED");
    }
}
