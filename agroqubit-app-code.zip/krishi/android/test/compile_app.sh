#!/bin/sh
# Compile-check the app code (MainActivity, Listen, PhotoProvider + the core) on a plain JDK, against compile-only
# stubs of the Android classes it uses (test/appstubs), at the Java 8 level like tools/build_apk.sh (which uses android.jar).
set -e
cd "$(dirname "$0")/.."
OUT=${1:-/tmp/app_compile}; rm -rf "$OUT"; mkdir -p "$OUT"
javac -nowarn --release 8 -encoding UTF-8 -d "$OUT" $(find test/appstubs -name "*.java") $(find src -name "*.java") $(find app/src -name "*.java")
echo "APP COMPILE OK"
