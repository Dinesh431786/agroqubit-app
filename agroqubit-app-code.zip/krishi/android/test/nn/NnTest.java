import in.krishi.doctor.*;
import java.io.*;
import java.util.*;
public class NnTest {
    static double maxd(float[] a, float[] b) { double m = 0; for (int i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i] - b[i])); if (a.length != b.length) m = 1e9; return m; }
    public static void main(String[] a) throws Exception {
        Map<String, Krw.T> t = Krw.read(new File(a[0]));
        float[] x = t.get("lin.x").f; Map<String, Double> r = new LinkedHashMap<>();
        r.put("linear f32", maxd(Nn.linear(t.get("lin.W"), t.get("lin.b").f, x, 5), t.get("lin.y").f));
        r.put("linear q8", maxd(Nn.linear(t.get("lin.Wq"), t.get("lin.b").f, x, 5), t.get("lin.yq").f));
        float[] y = x.clone(); Nn.layerNorm(y, 5, 33, t.get("ln.g").f, t.get("ln.b").f, 1e-5f); Nn.gelu(y); r.put("layernorm+gelu", maxd(y, t.get("ln.y").f));
        r.put("attention", maxd(Nn.attention(t.get("att.q").f, t.get("att.k").f, t.get("att.v").f, 3, 7, 24, 4, false, null), t.get("att.y").f));
        r.put("attention causal", maxd(Nn.attention(t.get("att.q").f, t.get("att.k").f, t.get("att.v").f, 3, 7, 24, 4, true, null), t.get("att.yc").f));
        r.put("conv1d", maxd(Nn.conv1d(t.get("conv.x").f, 6, 19, t.get("conv.W"), t.get("conv.b").f, 4, 5, 2, 3, 2, 2), t.get("conv.y").f));
        r.put("convT", maxd(Nn.convTranspose1d(t.get("conv.x").f, 6, 19, t.get("convt.W"), t.get("conv.b").f, 4, 4, 2, 1, 1, 1, 2), t.get("convt.y").f));
        boolean ok = true; for (Map.Entry<String, Double> e : r.entrySet()) { System.out.printf("%-18s max|diff| %.2e%n", e.getKey(), e.getValue()); ok &= e.getValue() < 1e-4; }
        System.out.println(ok ? "NN OK" : "NN FAIL"); Nn.release();
    }
}
