import sys, numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "tools"); from krw import write_krw1, q8, f32
torch.manual_seed(0); rng = np.random.default_rng(0); T = {}
def put(n, a): T[n] = f32(a); return a
# linear f32 and q8
x = rng.standard_normal((5, 33)).astype(np.float32); W = rng.standard_normal((17, 33)).astype(np.float32); b = rng.standard_normal(17).astype(np.float32)
put("lin.x", x); put("lin.W", W); put("lin.b", b); T["lin.Wq"] = q8(W)
put("lin.y", x @ W.T + b)
from krw import quant_rows; q, sc = quant_rows(W); put("lin.yq", x @ (q.astype(np.float32) * sc[:, None]).T + b)
# layernorm + gelu
g = rng.standard_normal(33).astype(np.float32); bb = rng.standard_normal(33).astype(np.float32); put("ln.g", g); put("ln.b", bb)
put("ln.y", F.gelu(F.layer_norm(torch.tensor(x), (33,), torch.tensor(g), torch.tensor(bb), 1e-5)).numpy())
# attention, causal with cache offset
d, H, Tq, Tk = 24, 4, 3, 7
qq = rng.standard_normal((Tq, d)).astype(np.float32); kk = rng.standard_normal((Tk, d)).astype(np.float32); vv = rng.standard_normal((Tk, d)).astype(np.float32)
put("att.q", qq); put("att.k", kk); put("att.v", vv)
def mha(q, k, v, causal):
    qh = torch.tensor(q).view(-1, H, d // H).transpose(0, 1); kh = torch.tensor(k).view(-1, H, d // H).transpose(0, 1); vh = torch.tensor(v).view(-1, H, d // H).transpose(0, 1)
    s = qh @ kh.transpose(1, 2) / (d // H) ** 0.5
    if causal:
        m = torch.ones(Tq, Tk, dtype=torch.bool).tril(Tk - Tq); s = s.masked_fill(~m, float("-inf"))
    return (s.softmax(-1) @ vh).transpose(0, 1).reshape(-1, d).numpy()
put("att.y", mha(qq, kk, vv, False)); put("att.yc", mha(qq, kk, vv, True))
# conv1d with groups/dilation/stride/padding
cin, cout, L, k = 6, 4, 19, 5
xc = rng.standard_normal((cin, L)).astype(np.float32); Wc = rng.standard_normal((cout, cin // 2, k)).astype(np.float32); bc = rng.standard_normal(cout).astype(np.float32)
put("conv.x", xc); T["conv.W"] = f32(Wc.reshape(cout, -1)); put("conv.b", bc)
put("conv.y", F.conv1d(torch.tensor(xc)[None], torch.tensor(Wc), torch.tensor(bc), stride=2, padding=3, dilation=2, groups=2)[0].numpy())
# conv transpose
Wt = rng.standard_normal((cin, cout // 2, 4)).astype(np.float32); T["convt.W"] = f32(Wt.reshape(cin, -1))
put("convt.y", F.conv_transpose1d(torch.tensor(xc)[None], torch.tensor(Wt), torch.tensor(bc), stride=2, padding=1, output_padding=1, groups=2, dilation=1)[0].numpy())
write_krw1(sys.argv[1], T); print("ok", len(T))
