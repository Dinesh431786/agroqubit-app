"""Krishi brain: one Bayesian belief over diseases, updated by evidence from ANY modality in the shared meaning space.
 - photo  -> vision fingerprints (cosine) for diseases that have a vision class
 - speech -> SpeechEncoder -> slot probabilities          (no ASR)
 - text   -> TextEncoder (A+D) -> slot probabilities       (Hindi/Tamil/Kannada/English, native or romanised)
Free statements = soft 'mention' evidence; replies to the current question = soft yes/no/don't-know or multi-choice.
Answers come only from verified content; when unsure it refers to KVK / Kisan Call Centre."""
import json, sys, numpy as np
sys.path.insert(0, "/home/claude/agri_reason/v2"); from engine_v2 import load_kb, KCC

K = "/home/claude/krishi"
SLOTS = list(json.load(open(f"{K}/slots.json"))); SI = {s: i for i, s in enumerate(SLOTS)}
CROPS = ["rice", "tomato", "chilli", "groundnut"]
PART_SLOTS = {"leaf": "part_leaf", "stem_or_sheath": "part_stem_or_sheath", "grain_or_fruit": "part_grain_or_fruit",
              "whole_plant_yellow_stunted": "part_whole_plant_yellow_stunted"}

class Brain:
    def __init__(self, tau=0.12, max_q=4, mention_thr=0.5, skip=()):
        self.core = load_kb("/home/claude/agri_reason/v2/knowledge_v2.json", tau=tau, max_q=max_q); self.kb = self.core.kb
        self.mention_thr = mention_thr; self.skip = set(skip); self.reset()   # skip: questions the device can't show (e.g. picture grids without photos)
    def reset(self):
        self.st = None; self.crop = None; self.pending = None; self.cos = None; self.log = []
    # ---------- evidence ----------
    def _ensure(self):
        if self.st is None: self.st = self.core.start(self.crop, self.cos)
    def set_crop(self, crop):
        self.crop = crop; self.st = self.core.start(crop, self.cos); self.log.append(("crop", crop))
    def add_photo_scores(self, cos_by_disease):   # dict disease -> cosine (diseases without a vision class get the mean)
        names = self.core.names; vals = [cos_by_disease[n] for n in names if n in cos_by_disease]; fill = float(np.mean(vals)) if vals else 0.0
        self.cos = np.array([cos_by_disease.get(n, fill) for n in names]); asked = self.st["asked"] if self.st else []
        post_before = self.st["post"].copy() if self.st else None
        self.st = self.core.start(self.crop, self.cos)
        if post_before is not None:   # keep evidence gathered so far (multiply in the old likelihood ratio)
            prior = self.core.start(self.crop, None)["post"]; lr = np.where(prior > 0, post_before / np.maximum(prior, 1e-12), 0)
            p = self.st["post"] * lr; self.st["post"] = p / p.sum(); self.st["asked"] = asked
        self.log.append(("photo", None))
    def _mult(self, L):
        p = self.st["post"] * np.maximum(L, 1e-6); self.st["post"] = p / p.sum()
    def hear(self, slot_probs):
        """Evidence from one utterance (speech or text), as probabilities over the shared slots."""
        P = dict(zip(SLOTS, np.asarray(slot_probs, float)))
        # 1) crop
        crop_p = {c: P[f"crop_{c}"] for c in CROPS}; c = max(crop_p, key=crop_p.get)
        if c != self.crop and crop_p[c] >= (0.5 if self.crop is None else 0.9):   # switching an already-set crop needs strong evidence
            asked, post = (self.st["asked"], self.st["post"]) if self.st else ([], None); self.set_crop(c)
        self._ensure(); act = None
        # 2) reply to the pending question
        q = self.pending
        if q == "__crop__":
            if self.crop is not None: act = "answered"          # the crop was named (handled in step 1)
        elif q is not None:
            opts = self.core.opts[q]; T = self.core.theta[q]
            if opts == ["yes", "no"]:
                py, pn, pd = P["ans_yes"], P["ans_no"], P["ans_dont_know"]
                if q in SI: py = max(py, P[q])              # restating the symptom counts as 'yes'
                s = py + pn + pd
                if s > 0.3:
                    py, pn = py / max(s, 1), pn / max(s, 1); self._mult(py * T[:, 0] + pn * T[:, 1] + (1 - py - pn)); self.st["asked"].append(q)
                    self.st["answers"][q] = "yes" if py > pn and py > pd else ("no" if pn > pd else "dont_know"); act = "answered"
            elif q == "part":
                pp = np.array([P[PART_SLOTS[o]] for o in opts]); s = pp.sum()
                if s > 0.3 or P["ans_dont_know"] > 0.5:
                    pp = pp / max(s, 1); self._mult(T @ pp + (1 - pp.sum())); self.st["asked"].append(q); act = "answered"
        # 3) free mentions of symptoms / context / plant part (positive evidence only)
        for qq in self.core.qids:
            if qq in SI and qq != q and qq not in self.st["asked"] and P[qq] >= self.mention_thr:
                self._mult((1 - P[qq]) + P[qq] * self.core.theta[qq][:, 0]); self.st["asked"].append(qq); self.st["answers"][qq] = "said"
        if "part" not in self.st["asked"] and q != "part":
            pp = np.array([P[PART_SLOTS[o]] for o in self.core.opts["part"]])
            if pp.max() >= self.mention_thr: self._mult(self.core.theta["part"] @ (pp / max(pp.sum(), 1)) + (1 - min(pp.sum(), 1))); self.st["asked"].append("part")
        if act == "answered": self.pending = None
        # 4) requests
        if P["req_expert"] >= 0.5: return "refer"
        if P["req_repeat"] >= 0.5 and self.pending: return "repeat"
        if P["req_treatment"] >= 0.5: return "treat"
        return act or "statement"
    def answer_choice(self, q, option_index):      # taps (picture grid / part buttons)
        self._ensure(); self.core.answer(self.st, q, option_index)
        if self.pending == q: self.pending = None
    # ---------- dialogue ----------
    def next_question(self):
        self._ensure()
        if self.crop is None: self.pending = "__crop__"; return "__crop__"
        q, g = self.core.next_question(self.st, self.skip); self.pending = q; return q
    def result(self):
        self._ensure(); r = self.core.result(self.st); r["crop"] = self.crop
        if r["status"] != "ok": r["advice"] = f"Not sure. Please show the plant to your KVK or call Kisan Call Centre {KCC} (free, 6 AM-10 PM)."
        return r
    def question_text(self, q, lang="en"):
        C = _colloq()
        if C and f"q_{q}" in C: return C[f"q_{q}"][lang]          # spoken village register (same text the voice says)
        if q == "__crop__": return {"en": "Which crop?", "hi": "कौन सी फसल है?", "ta": "எந்த பயிர்?", "kn": "ಯಾವ ಬೆಳೆ?"}[lang]
        if q == "part": return {"en": "Where is the problem: leaf, stem, grain/fruit, or the whole plant?", "hi": "समस्या कहाँ है: पत्ती, तना, दाना/फल, या पूरा पौधा?",
                                "ta": "பிரச்சனை எங்கே: இலை, தண்டு, மணி/காய், அல்லது முழு செடி?", "kn": "ಸಮಸ್ಯೆ ಎಲ್ಲಿದೆ: ಎಲೆ, ಕಾಂಡ, ಕಾಳು/ಕಾಯಿ, ಅಥವಾ ಇಡೀ ಗಿಡ?"}[lang]
        if q.startswith("pic_"): return {"en": "Tap the photo that looks most like your plant", "hi": "जो फोटो आपके पौधे जैसी दिखे उसे छुएँ",
                                         "ta": "உங்கள் செடி போல இருக்கும் படத்தைத் தொடுங்கள்", "kn": "ನಿಮ್ಮ ಗಿಡದಂತೆ ಕಾಣುವ ಫೋಟೋ ಒತ್ತಿ"}[lang]
        return self.kb["questions"][q][lang]

_C = None
def _colloq():
    global _C
    if _C is None:
        import os
        p = "/home/claude/krishi/voice/catalogue.json"; _C = json.load(open(p)) if os.path.exists(p) else {}
    return _C
