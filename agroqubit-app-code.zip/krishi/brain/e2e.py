"""End-to-end multimodal test. A simulated farmer with a true disease talks to the brain using REAL held-out inputs:
independent test sentences (typed, any script) or their audio by 13 unseen voices (+ noise), plus PlantDoc test photos
for tomato. The farmer answers truthfully per the symptom table with 15% mistakes. We compare against an 'oracle'
that understands every utterance perfectly, to see how much accuracy the perception layer loses."""
import json, sys, random, numpy as np, torch
sys.path.insert(0, "/home/claude/krishi/brain"); sys.path.insert(0, "/home/claude/krishi/text"); sys.path.insert(0, "/home/claude/krishi/speech")
from brain import Brain, SLOTS, SI, PART_SLOTS
from textenc import TextEncoder, pack, pack_windows, mil_logits
from speechenc import SpeechEncoder, logmel, HOP
torch.set_num_threads(2); K = "/home/claude/krishi"; import os
TEXT_MODELS = [("AL", False), ("DL", True)] if os.environ.get("KRISHI_TEXT", "lexicon") == "lexicon" else [("A", False), ("D", True)]
MODE = sys.argv[1]; SEEDS = int(sys.argv[2]) if len(sys.argv) > 2 else 3; SPEECH_CK = sys.argv[3] if len(sys.argv) > 3 else f"{K}/speech/speech_enc_0.pt"
# ---------------- perception ----------------
te_text = [json.loads(l) for l in open(f"{K}/data/text_test.jsonl")]
tr_norm = {l.strip() for l in open(f"{K}/data/text_train.jsonl")}
def text_model_probs(texts):
    out = []
    for name, mil in TEXT_MODELS:
        ck = torch.load(f"{K}/text/enc_{name}_0.pt"); n = TextEncoder(len(SLOTS)); n.load_state_dict(ck["state"]); n.eval()
        with torch.no_grad():
            if mil: i, o, w, h = pack_windows(texts); out.append(torch.sigmoid(mil_logits(n, i, o, w, len(texts))).numpy())
            else: i, o = pack(texts); out.append(torch.sigmoid(n.slot_logits(n.embed(i, o))).numpy())
    return (out[0] + out[1]) / 2
SPD = dict(np.load(f"{K}/speech/test.npz")); SPM = json.load(open(f"{K}/speech/test_meta.json")); OFF = np.concatenate([[0], np.cumsum(SPD["lens"])])
def speech_probs(cond, seed=0):
    protos = torch.load(f"{K}/text/enc_A_0.pt")["state"]["slots"]
    sd = torch.load(SPEECH_CK)["state"]; nph = sd["ctc.weight"].shape[0] - 1 if "ctc.weight" in sd else 0
    net = SpeechEncoder(protos, n_phon=nph); net.load_state_dict(sd); net.eval(); rng = np.random.default_rng(seed); P = []
    for i0 in range(0, len(SPM), 32):
        xs = []
        for i in range(i0, min(i0 + 32, len(SPM))):
            x = SPD["audio"][OFF[i]:OFF[i+1]].astype(np.float32)
            if cond != "clean":
                kind, snr = cond.split("@"); w = rng.standard_normal(len(x)).astype(np.float32)
                if kind != "white":
                    f = np.fft.rfft(w); fr = np.arange(len(f)) + 1; w = np.fft.irfft(f / fr ** (0.5 if kind == "pink" else 1.0), len(x)).astype(np.float32); w /= w.std() + 1e-8
                x = x + w * np.sqrt((x ** 2).mean()) / 10 ** (float(snr) / 20)
            xs.append(x)
        n = max(len(x) for x in xs); X = np.zeros((len(xs), n), np.float32); M = np.zeros((len(xs), n // HOP + 1), bool)
        for k, x in enumerate(xs): X[k, :len(x)] = x; M[k, :len(x) // HOP + 1] = True
        with torch.no_grad(): mel = logmel(torch.tensor(X)); P.append(torch.sigmoid(net.slot_logits(net(mel, torch.tensor(M[:, :mel.shape[2]])))).numpy())
    return np.concatenate(P)
# utterance pool for this run: (slots, lang, probs)
if MODE == "text":
    pool = [(r["slots"], r["lang"], p) for r, p in zip(te_text, text_model_probs([r["text"] for r in te_text]))]
elif MODE.startswith("speech"):
    cond = MODE.split(":")[1]; TAGP = sys.argv[4] if len(sys.argv) > 4 else ""
    Pd = speech_probs(cond); Pp = np.load(f"{K}/speech/test_p2m{TAGP}_{cond.replace('@', '')}.npy")
    pool = [(m["slots"], m["lang"], p) for m, p in zip(SPM, 0.3 * Pd + 0.7 * Pp)]
elif MODE == "oracle":
    def onehot(sl): v = np.zeros(len(SLOTS)); v[[SI[s] for s in sl]] = 1; return v
    pool = [(r["slots"], r["lang"], onehot(r["slots"])) for r in te_text]
langs = sorted({l for _, l, _ in pool})
# ---------------- photos (tomato) ----------------
V = "/home/claude/agri_vision"; C = "/home/claude/data/cache"
classes = json.load(open(f"{C}/classes.json")); E = np.load(f"{V}/embeddings.npz")
fpn = json.load(open(f"{V}/fingerprints_base.json")) + ["Tomato leaf yellow virus"]
FP = np.vstack([np.load(f"{V}/fingerprints_base.npy"), np.load(f"{V}/fp_new_disease.npy")]).astype(np.float32)
yte = np.load(f"{C}/test.npz")["y"]
# ---------------- simulation ----------------
def run(seed, use_photo):
    rng = random.Random(seed); npr = np.random.default_rng(seed); b = Brain(); names = b.core.names; FE = 0.1
    th = {q: b.core.theta[q] for q in b.core.qids}
    def clean_dist(q, d):
        T = th[q][d].copy(); K_ = len(T)
        if K_ == 2: T = (T - FE) / (1 - 2 * FE)
        elif q == "part": T = (T - FE / K_) / (1 - FE)
        T = np.clip(T, 1e-9, None); return T / T.sum()
    res = []; turns = []
    for d, name in enumerate(names):
        crop = b.core.crops[d]
        for rep in range(6):
            lang = rng.choice(langs); b.reset()
            if use_photo and b.kb["diseases"][name].get("vision_class"):
                vc = b.kb["diseases"][name]["vision_class"]; ids = np.where(yte == classes.index(vc))[0]
                s = E["Zte"][rng.choice(list(ids))] @ FP.T
                b.add_photo_scores({n: float(s[fpn.index(b.kb["diseases"][n]["vision_class"])]) for n in names if b.kb["diseases"][n].get("vision_class")})
            # opening: crop + (maybe) one true symptom, said in the farmer's language
            strong = [q for q in b.core.qids if q in SI and q not in ("healthy",) and th[q][d][0] >= 0.6]
            good = {f"crop_{crop}"} | set(strong)
            cands = [u for u in pool if u[1] == lang and f"crop_{crop}" in u[0] and set(u[0]) <= good]
            if cands: b.hear(rng.choice(cands)[2])
            else:
                cc = [u for u in pool if u[1] == lang and u[0] == [f"crop_{crop}"]] or [u for u in pool if u[0] == [f"crop_{crop}"]]
                b.hear(rng.choice(cc)[2])
            if b.crop != crop: b.set_crop(crop)     # app fallback: farmer taps the crop icon
            nt = 0
            for _ in range(8):
                q = b.next_question()
                if q is None: break
                nt += 1
                if q.startswith("pic_"):
                    opts = b.core.opts[q]; k = (opts.index(name) if name in opts else len(opts) - 1) if npr.random() < 0.6 else npr.integers(len(opts)); b.answer_choice(q, int(k)); continue
                dist = clean_dist(q, d); k = int(npr.choice(len(dist), p=dist))
                if npr.random() < 0.15: k = int(npr.integers(len(dist)))
                if q == "part": want = [PART_SLOTS[b.core.opts[q][k]]]
                else: want = ["ans_yes"] if k == 0 else ["ans_no"]
                cands = [u for u in pool if u[1] == lang and u[0] == want] or [u for u in pool if u[0] == want]
                before = len(b.st["asked"]); b.hear(rng.choice(cands)[2])
                if len(b.st["asked"]) == before: b.pending = None; b.st["asked"].append(q)   # not understood -> skip question
            r = b.result(); res.append((r["top"][0][0] == name, r["status"] == "ok", crop)); turns.append(nt)
    return res, turns
out = {}
for use_photo in ([False, True]):
    acc = []; ans = []; T = []; per = {}
    for s in range(SEEDS):
        r, t = run(s, use_photo); acc.append(np.mean([x[0] for x in r])); ans.append(np.mean([x[1] for x in r])); T += t
        for x in r: per.setdefault(x[2], []).append(x[0])
    out["with_tomato_photo" if use_photo else "no_photo"] = dict(top1=round(float(np.mean(acc)), 3), top1_sd=round(float(np.std(acc)), 3),
        answered=round(float(np.mean(ans)), 3), avg_turns=round(float(np.mean(T)), 2), by_crop={c: round(float(np.mean(v)), 3) for c, v in per.items()})
print(MODE, json.dumps(out)); json.dump(out, open(f"{K}/brain/e2e_{MODE.replace(':', '_').replace('@', '')}{sys.argv[4] if len(sys.argv) > 4 else ''}.json", "w"), indent=1)
