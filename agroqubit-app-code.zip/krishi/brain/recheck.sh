cd /home/claude/krishi/brain
python3 e2e.py oracle 3 > rc_oracle.log 2>&1
python3 e2e.py text 3 > rc_text.log 2>&1
python3 e2e.py "speech:clean" 3 /home/claude/krishi/speech/speech_enc_v2.pt _v2 > rc_sclean.log 2>&1
python3 e2e.py "speech:pink@10" 3 /home/claude/krishi/speech/speech_enc_v2.pt _v2 > rc_spink.log 2>&1
echo DONE > rc_done.log
