"""Scripted demo using ONLY held-out test inputs (independent sentences; audio from unseen voices)."""
import json, sys, random, numpy as np
sys.path.insert(0, "."); from chat import Chat, SpeechUnderstanding
K = "/home/claude/krishi"; random.seed(3)
te = [json.loads(l) for l in open(f"{K}/data/text_test.jsonl")]
SPD = dict(np.load(f"{K}/speech/test.npz")); SPM = json.load(open(f"{K}/speech/test_meta.json")); OFF = np.concatenate([[0], np.cumsum(SPD["lens"])])
def text_of(lang, slots): c = [r for r in te if r["lang"] == lang and sorted(r["slots"]) == sorted(slots)]; return random.choice(c)["text"] if c else None
def clip_of(lang, slots):
    c = [i for i, m in enumerate(SPM) if m["lang"] == lang and sorted(m["slots"]) == sorted(slots)]
    if not c: return None, None
    i = random.choice(c); return SPD["audio"][OFF[i]:OFF[i+1]].astype(np.float32), SPM[i]
def truth(q, disease, chat):   # what a farmer with this disease would honestly say
    th = chat.brain.core.theta[q][chat.brain.core.names.index(disease)]
    if q == "part": return ["part_" + chat.brain.core.opts[q][int(np.argmax(th))]]
    return ["ans_yes"] if th[0] > 0.5 else ["ans_no"]
SP = SpeechUnderstanding(enc=sys.argv[1] if len(sys.argv) > 1 else f"{K}/speech/speech_enc_0.pt", p2m=sys.argv[2] if len(sys.argv) > 2 else f"{K}/speech/phon2meaning.pt")
for lang, disease, mode, opening in [("ta", "rice_blast", "voice", ["crop_rice", "eye_shaped_grey_centre"]), ("hi", "tomato_leaf_curl", "text", ["crop_tomato", "leaf_curl_crinkle_stunt"]),
                                     ("kn", "groundnut_rust", "voice", ["crop_groundnut"])]:
    c = Chat(lang, speech=SP); print(f"\n===== {lang.upper()} farmer, true disease: {disease}, speaks by {mode} =====")
    def say(slots):
        if mode == "voice":
            a, m = clip_of(lang, slots)
            if a is not None: print(f"  FARMER (voice, unseen speaker '{m['voice']}'): {m['text']}"); return c.turn(audio=a)
            if len(slots) > 1: return say(slots[:1])
        t = text_of(lang, slots) or text_of(lang + "-Latn", slots)
        if t is None and len(slots) > 1: return say(slots[:1])        # no such sentence in the test set: say only the crop
        print(f"  FARMER (typed): {t}"); return c.turn(text=t)
    out = say(opening)
    for _ in range(6):
        if out["type"] != "question": break
        print(f"  APP: {out['say']}" + (f"   [heard phonemes: {out.get('heard_phonemes','')[:40]}]" if out.get("heard_phonemes") else ""))
        q = out["qid"]
        if q == "__crop__": out = c.turn(tap=c.brain.core.crops[c.brain.core.names.index(disease)]); print("  FARMER taps crop"); continue
        if q.startswith("pic_"): out = c.turn(tap=disease); print("  FARMER taps the matching photo"); continue
        out = say(truth(q, disease, c))
    print(f"  APP RESULT: {out['type']}", {k: out[k] for k in ("local_name", "disease", "confidence") if k in out})
    print(f"  APP SAYS: {out['say']}")
    if out.get("source"): print(f"  SOURCE: {out['source']}")
