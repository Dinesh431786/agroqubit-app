"""Krishi chat: the one-screen conversation loop. Every turn accepts text (any script), voice (audio array) or a photo,
updates ONE belief, and replies in the farmer's language with a question, a verified answer, or a referral."""
import json, re, sys, numpy as np, torch
sys.path.insert(0, "/home/claude/krishi/brain"); sys.path.insert(0, "/home/claude/krishi/text"); sys.path.insert(0, "/home/claude/krishi/speech")
from brain import Brain, SLOTS, _colloq
from textenc import TextEncoder, pack, pack_windows, mil_logits
K = "/home/claude/krishi"; import os
TEXT_MODELS = {"lexicon": [("AL", False), ("DL", True)], "q8": [("ALq8", False), ("DLq8", True)]}.get(os.environ.get("KRISHI_TEXT", "lexicon"), [("A", False), ("D", True)]); ADV = json.load(open(f"{K}/brain/advice.json"))
I18N = json.load(open(f"{K}/brain/advice_i18n.json", encoding="utf-8"))

class TextUnderstanding:
    def __init__(self):
        self.m = []
        for name, mil in TEXT_MODELS:
            ck = torch.load(f"{K}/text/enc_{name}_0.pt"); n = TextEncoder(len(SLOTS)); n.load_state_dict(ck["state"]); n.eval(); self.m.append((n, mil))
    @torch.no_grad()
    def __call__(self, text):
        out = []
        for n, mil in self.m:
            if mil: i, o, w, h = pack_windows([text]); out.append(torch.sigmoid(mil_logits(n, i, o, w, 1)).numpy()[0])
            else: i, o = pack([text]); out.append(torch.sigmoid(n.slot_logits(n.embed(i, o))).numpy()[0])
        return (out[0] + out[1]) / 2

class SpeechUnderstanding:
    """audio -> phonemes (shared multilingual CTC) -> meaning; fused with the direct speech->meaning head."""
    def __init__(self, enc=f"{K}/speech/speech_enc_0.pt", p2m=f"{K}/speech/phon2meaning.pt"):
        from speechenc import SpeechEncoder, logmel, HOP; import train_phon2meaning_lib as P
        self.logmel, self.HOP, self.P = logmel, HOP, P
        protos = torch.load(f"{K}/text/enc_A_0.pt")["state"]["slots"]; sd = torch.load(enc)["state"]
        self.net = SpeechEncoder(protos, n_phon=sd["ctc.weight"].shape[0] - 1); self.net.load_state_dict(sd); self.net.eval()
        self.p2m = TextEncoder(len(SLOTS)); self.p2m.load_state_dict(torch.load(p2m)["state"]); self.p2m.eval()
        self.vocab = json.load(open(f"{K}/speech/train_phon.json"))["vocab"]
    @torch.no_grad()
    def __call__(self, audio):
        x = torch.tensor(audio[None].astype(np.float32)); mel = self.logmel(x); M = torch.ones(1, mel.shape[2], dtype=torch.bool)
        z, h = self.net(mel, M, return_frames=True); direct = torch.sigmoid(self.net.slot_logits(z)).numpy()[0]
        ids = self.net.ctc(h).argmax(1)[0].tolist(); s = []; prev = 0
        for t in ids:
            if t != prev and t != 0: s.append(self.vocab[t - 1])
            prev = t
        i, o = self.P.pk(["".join(s)]); viaph = torch.sigmoid(self.p2m.slot_logits(self.p2m.embed(i, o))).numpy()[0]
        return 0.3 * direct + 0.7 * viaph, "".join(s)

FACTLM_DIR = os.environ.get("KRISHI_FACTLM")   # folder with the phone's factlm.json + factlm.bin + facts.json
SIDE_MIN = 0.6; CROPS = ["rice", "tomato", "chilli", "groundnut"]
_PHR = None
def _phr():
    global _PHR
    if _PHR is None: _PHR = json.load(open(f"{K}/voice/app_phrases.json", encoding="utf-8"))
    return _PHR
def _sentence(t):
    r = re.sub(r"[ \t\n\x0b\f\r]+$", "", t); c = r[-1] if r else " "
    return r if c in ".।!?" else r + "."

class FactBrain:
    """The fact-token model (factlm/) loaded from the exported phone weights (int8 dequantised = what Java runs)."""
    def __init__(self, d):
        sys.path.insert(0, f"{K}/factlm"); sys.path.insert(0, f"{K}/android/tools")
        from export import load_exported
        self.m, self.j = load_exported(f"{d}/factlm.json", f"{d}/factlm.bin")
        fj = json.load(open(f"{d}/facts.json", encoding="utf-8")); self.facts = fj["facts"]; self.targets = fj.get("targets") or {}
    @torch.no_grad()
    def answer(self, text, crop, target):
        bt = self.m.make_batch([text], crops=[crop], targets=[target]); g = self.m.generate(bt)[0]
        _, td = self.m.heads(bt); tp, ti = td[0].max(-1)
        return g["items"], g["scores"], (self.m.meta["ctx_targets"][int(ti)] if int(ti) >= 2 else None), float(tp)
    def facts_of(self, t, kind): return [i for i, f in self.facts.items() if f.get("target") == t and f.get("kind") == kind]

class Chat:
    def __init__(self, lang="hi", speech=None, skip=()):
        self.lang = lang; self.brain = Brain(skip=skip); self.text = TextUnderstanding(); self.speech = speech; self.last_q = None
        self.free = None; self.diagnosed = None; self.pending_dose = False
        self.fb = FactBrain(FACTLM_DIR) if FACTLM_DIR else None; self.topic = None; self.confirm_target = None; self.pending_text = None

    # ---------------- free questions: fact-token model (same logic as Chat.java) ----------------
    def _tname(self, t):
        C = _colloq()
        if f"name_{t}" in C: return C[f"name_{t}"].get(self.lang) or t
        n = self.fb.targets.get(t)
        v = (n.get(self.lang) or n.get("en")) if n else None
        return v if v is not None else t.replace("_", " ")
    def _ftext(self, f): t = self.fb.facts[f]["text"]; return t.get(self.lang) or t["en"]
    def _fact_reply(self, facts, ctl):
        L = self.lang; PH = I18N["phrases"]; target = next((self.fb.facts[f]["target"] for f in facts if self.fb.facts[f].get("target")), None)
        say = []; out = {"type": "fact_answer", "action": "answer", "facts": list(facts), "disease": target}
        if target: say.append(_sentence(self._tname(target)))
        dose = False
        for f in facts:
            if self.fb.facts[f]["kind"] == "dose" and not dose: dose = True; say.append(PH["dose_intro"][L])
            say.append(_sentence(self._ftext(f)))
        if dose: say.append(PH["dose_caution"][L])
        if ctl == "<NOT_SURE>": say.append(_colloq()["generic_kvk"][L])
        out["say"] = " ".join(say); out["source"] = self.fb.facts[facts[0]].get("src")
        if target and self.diagnosed is None: self.topic = target
        return out
    def _fact_turn(self, text, side):
        items, scores, tname, tp = self.fb.answer(text, self.brain.crop, self.diagnosed)
        facts = [i for i in items if not i.startswith("<")]; ctl = items[-1] if items and items[-1].startswith("<") else None
        if facts: return None if (side and scores[0] < SIDE_MIN) else self._fact_reply(facts, ctl)
        if side or ctl in (None, "<ASK>", "<END>"): return None
        if ctl == "<NOT_SURE>": return {"type": "referral", "action": "not_covered", "say": _phr()["not_covered"][self.lang]}
        if ctl == "<WHICH_CROP>":
            if self.brain.crop is not None: return None
            self.pending_text = text; self.last_q = "__crop__"
            return {"type": "question", "qid": "__crop__", "say": self.brain.question_text("__crop__", self.lang), "buttons": list(CROPS)}
        t = tname if (tname is not None and tp >= 0.5) else self.topic
        if t is None or not self.fb.facts_of(t, "dose"): return None
        self.confirm_target = t; self.pending_text = text; self.last_q = "__confirm__"
        return {"type": "question", "qid": "__confirm__", "disease": t, "buttons": ["yes", "no"],
                "say": _sentence(self._tname(t)) + " " + _phr()["confirm_q"][self.lang]}
    def _confirmed(self, yes):
        t, text = self.confirm_target, self.pending_text; self.confirm_target = None; self.pending_text = None; self.last_q = None
        if not yes: return self._ask()
        self.diagnosed = t
        r = self._fact_turn(text, False)
        if r is not None and r["type"] == "fact_answer": return r
        d = self.fb.facts_of(t, "dose")
        return self._fact_reply(d if d else self.fb.facts_of(t, "first"), None)
    @staticmethod
    def _crop_said(P):
        best, bv = None, 0.5
        for c in CROPS:
            v = P[SLOTS.index("crop_" + c)]
            if v >= bv: bv, best = v, c
        return best
    def _free(self, text):
        """Typed free questions ("organic remedy?", "how to prevent?", "dose?") get verified answers; everything else
        (symptom talk, yes/no replies) goes to the diagnosis brain."""
        if self.free is None:
            sys.path.insert(0, f"{K}/freechat"); from freechat import FreeChat; self.free = FreeChat(); self.free.tu = self.text
            self.free.SL = list(json.load(open(f"{K}/slots.json")))
        if self.pending_dose:                     # farmer was asked to confirm the disease before a dose
            P = self.text(text); self.pending_dose = False
            if P[SLOTS.index("ans_yes")] > 0.5:
                return self.free.answer(self.pending_text, self.lang, known_disease=self.diagnosed, confirmed=True)
            return None                           # not confirmed -> continue with diagnosis instead of giving a dose
        r = self.free.answer(text, self.lang, known_disease=self.diagnosed)
        if r["action"] == "confirm_disease": self.pending_dose = True; self.pending_text = text
        if r["action"].startswith("answer_") and self.diagnosed is None: self.diagnosed = r["disease"]   # topic of the chat
        return r if r["action"] not in ("clarify", "start_diagnosis") else None
    def _ask(self):
        q = self.brain.next_question()
        if q is None: return self._conclude()
        self.last_q = q; return {"type": "question", "qid": q, "say": self.brain.question_text(q, self.lang),
                                 "buttons": self.brain.core.opts[q] if q != "__crop__" else ["rice", "tomato", "chilli", "groundnut"]}
    def _conclude(self):
        r = self.brain.result(); name, p = r["top"][0]
        if r["status"] != "ok": return {"type": "not_sure", "say": ADV["generic"][self.lang], "top3": r["top"]}
        a = ADV["advice"].get(name); nm = _colloq().get(f"name_{name}", {}).get(self.lang) or self.brain.kb["diseases"][name].get("names", {}).get(self.lang, name.replace("_", " "))
        self.diagnosed = name
        return {"type": "diagnosis", "disease": name, "confidence": round(p, 2), "local_name": nm,
                "say": (_colloq().get(f"adv_{name}", a["first"])[self.lang] if a else _colloq().get("generic_kvk", ADV["generic"])[self.lang]), "source": a["source"] if a else None,
                "more": {k: a[k] for k in ("cultural", "biological", "chemical_examples")} if a else None, "always": ADV["generic"][self.lang]}
    def turn(self, text=None, audio=None, photo_scores=None, tap=None):
        if photo_scores is not None: self.brain.add_photo_scores(photo_scores)
        if tap is not None:
            if self.last_q == "__confirm__": return self._confirmed(tap == "yes")
            if self.last_q == "__crop__":
                self.brain.set_crop(tap)
                if self.pending_text is not None:
                    t = self.pending_text; self.pending_text = None; self.last_q = None
                    r = self._fact_turn(t, False)
                    if r is not None: return r
            else: self.brain.answer_choice(self.last_q, self.brain.core.opts[self.last_q].index(tap))
            return self._ask()
        heard = None
        SYM = [i for i, n in enumerate(SLOTS) if not n.startswith(("crop_", "ans_", "req_"))]
        if text is not None and self.fb is not None:
            P = self.text(text); Y, N, DK = (SLOTS.index(s) for s in ("ans_yes", "ans_no", "ans_dont_know"))
            if self.last_q == "__confirm__":
                if P[Y] > 0.5: return self._confirmed(True)
                if P[N] > 0.5: return self._confirmed(False)
                self.last_q = None; self.confirm_target = None; self.pending_text = None      # something else: a new message
            if self.last_q == "__crop__" and self.pending_text is not None:
                c = self._crop_said(P)
                if c is not None:
                    self.brain.set_crop(c); t = self.pending_text; self.pending_text = None; self.last_q = None
                    r = self._fact_turn(t, False)
                    return r if r is not None else self._ask()
                self.pending_text = None
            if self.last_q is None or self.diagnosed:
                # symptom talk always goes to the diagnosis questions first (never answer straight from one description)
                r = None if (self.diagnosed is None and P[SYM].max() > 0.5) else self._fact_turn(text, False)
                if r is not None: return r
            elif self.last_q != "__crop__" and P[SYM].max() < 0.5 and P[Y] < 0.5 and P[N] < 0.5 and P[DK] < 0.5:
                r = self._fact_turn(text, True)                   # a side question during the diagnosis: answer, then ask again
                if r is not None:
                    r["say"] = r["say"] + "\n" + self.brain.question_text(self.last_q, self.lang); r["qid"] = self.last_q
                    r["buttons"] = list(self.brain.core.opts[self.last_q]); return r
        elif text is not None and (self.last_q is None or self.diagnosed or self.pending_dose):
            # symptom talk always goes to the diagnosis questions first (never answer straight from one description)
            r = None if (self.diagnosed is None and not self.pending_dose and self.text(text)[SYM].max() > 0.5) else self._free(text)
            if r is not None: return {"type": "free_answer", **r}
        if text is not None: P = self.text(text)
        elif audio is not None: P, heard = self.speech(audio)
        else: return self._ask()
        act = self.brain.hear(P)
        if act == "refer": return {"type": "referral", "say": ADV["generic"][self.lang]}
        if act == "treat": return self._conclude()
        if act == "repeat" and self.last_q: return {"type": "question", "qid": self.last_q, "say": self.brain.question_text(self.last_q, self.lang)}
        out = self._ask()
        if heard is not None: out["heard_phonemes"] = heard
        return out
