# Research notes: what is new in Krishi Doctor, and why

Goal: an offline crop doctor that works on a 2 GB phone. It answers by text, voice and photo, in Hindi, Tamil, Kannada and English, sounds human, and is accurate. The app has no cloud and never generates free text.

The ideas below are each one design move. They are measured in this repo and backed by outside sources (listed at the end). Sections 1–6 are version 1 (the tested APK). Sections 7–12 are version 2: the code is complete and parity-tested here; the training and the accuracy numbers come from the one-time training run (CPU VMs, or one GPU VM).

---

## 1. Closed-world voice: TTS moves to build time

**Problem.** Human-quality neural TTS models (FastPitch/VITS, F5-style flow models such as AI4Bharat IndicF5 at 0.4 B parameters) are far too heavy for a 2 GB phone. Small on-device TTS sounds robotic. Speech vendors also report that numbers and long codes are where synthetic speech sounds most unnatural. They report that callers start talking over the system after about one second of silence.

**Observation.** This app never generates text. Every sentence it can say is a verified sentence that exists at build time:

- questions
- disease names
- government IPM advice items
- fixed phrases

The set is closed: **153 sentences per language** today.

**Method** (`voice/closed_world.py`, `voice/verbalize.py`, `voice/render_segments.py`):

1. **Enumerate** every sayable sentence with the same clip ids the Java app plays. Types of id:
   - `q_*` questions
   - `name_*` disease names
   - `it_<disease>_<c|b|x><i>` IPM items
   - `ph_*` answer phrases
   - photo / mic phrases
2. **Verbalize** for speech while the screen keeps label text. Medicine names go into native script, numbers become words, and the helpline is read digit by digit. For example:
   - "mancozeb 75% WG, 200 लीटर" is spoken as "मैंकोज़ेब पचहत्तर परसेंट डब्ल्यू जी … दो सौ लीटर".
   - Hindi first-person verbs follow the speaker ("पूछती हूँ" for the female voice, "पूछता हूँ" for the male one).
   - Rendering fails if anything unreadable is left.
3. **Render** every sentence with a human neural voice (AI4Bharat Indic-TTS, female and male), one sentence at a time with natural pauses. The result is 16 kHz Opus at 16 kbps, about 2 KB per second.
4. **On the phone**, each answer is a list of clip ids and plays immediately. There is no TTS model in RAM and no synthesis delay.

**Checked.**

- In 300 scripted conversations (2,080 turns, Java), every reply was covered by a clip: 4,885 clips played, 0 missing.
- The emulator test checks that every sentence id exists in the APK for both voices, and that full answers play to the end.

**Limit.** A new sentence needs a re-render. That is a build step that takes minutes, not a model on the phone.

**Next.** Clone a local KVK officer's voice, with permission, using a few minutes of recording. IndicF5 needs consent and a transcript of the reference clip, and it runs on the build server. This gives a "district voice" at the same zero cost on the phone.

## 2. Photo diagnosis with no ML runtime: pure-Java interpreter, mixed int8/fp16, lazy load

**Problem.** ONNX Runtime or TFLite add native libraries of 10–20 MB per CPU architecture and need Gradle/AndroidX. Plain post-training int8 (static, activations too) dropped this MobileNetV3 from 61% to 49% top-1, which is known to happen with hard-swish and depthwise layers. The quantization literature says PTQ is "often sufficient" at 8 bits, but not for every architecture.

**Method.**

- `android/tools/export_vision.py` turns the ONNX graph, with BatchNorm already folded, into a 143-op list.
- `Vision.java` runs that list in plain Java (about 250 lines).
- **Weight-only** int8 per output channel for pointwise and head layers, with the clipping range per channel searched to minimise squared error.
- fp16 for depthwise and stem layers, which are tiny and sensitive.
- Activations stay fp32.
- The model is loaded only on the first photo, so text-only users never pay for it.

**Checked.**

- Java vs onnxruntime: cosine 1.000000 and 12/12 same answer on real PlantDoc photos.
- On the phone emulators: **147–209 ms per photo** (Android 11, 2 cores) and 150–162 ms (Android 7). 17 of 20 real test photos got the same answer as Python; the 3 differences are near-ties from different image resizing.
- int8-mixed vs fp32 on the held-out test set: known-disease top-1 is the same or better on both training runs (62.2% vs 62.2%; 62.2% vs 60.9%). Size drops from 18 MB to **4.8 MB**.

## 3. Several fingerprints per disease: tested, but no reliable gain yet

**Idea.** Diseases are fingerprints: unit vectors scored by cosine, so a new disease can be added from a few KVK photos without retraining. One mean vector per disease blurs early vs late stages and different backgrounds. So each disease keeps up to 4 k-means sub-centroids of its training embeddings, computed with the phone's own int8 weights in single view. A disease's score is its best match. This adds about 100 KB.

**Checked on two independent training runs** (held-out PlantDoc test set, phone weights, 69 tomato photos):

| Training run | Known top-1, one / several | Tomato top-1, one / several | Tomato top-3, one / several |
|---|---|---|---|
| Workspace model | 62.6% / **63.9%** | 40.6% / **46.4%** | 76.8% / **79.7%** |
| VM rebuild (same recipe, shipped) | **62.2%** / 60.4% | **44.9%** / 43.5% | **78.3%** / 73.9% |

**Verdict.** The gains go in opposite directions between runs. One tomato photo is 1.4 points, so the effect is inside the noise of a small test set. The current APK ships several fingerprints per disease. The next build will switch back to one per disease unless a larger, Indian field photo set shows a gain.

## 4. One belief for every input: photo as prior, questions by information gain

- Text, voice-typed text and taps become probabilities over 38 meaning slots.
- A confident tomato-leaf photo sets the crop and becomes the **prior** of the Bayesian belief, with softmax over cosines at τ = 0.12.
- The question engine then asks only what the photo could not tell, choosing by expected information gain.
- Because the photo's top-3 is right about 80% of the time, two or three questions usually pick the right one.

**Checked.** End-to-end simulation with held-out typed sentences: tomato accuracy is 72% without a photo and **82% with one**, with fewer questions (3.2 down to 2.8).

**Sweep** (`max_q`, `stop_p`). Allowing 5–6 questions instead of 4 changed accuracy by only about 1–3 points, which is inside the noise. The limit is the quality of the evidence (photos, symptom data), not the number of questions. The defaults were kept so the test set is not over-tuned.

## 5. Voice input: use the phone's own offline recogniser first

**Finding.**

- Android 12+ (API 31) has `SpeechRecognizer.createOnDeviceSpeechRecognizer()`, which runs locally with no network. Hindi has been validated with real speakers.
- `isOnDeviceRecognitionAvailable()` must be checked first; some phones crash without that check.
- Older phones get the system voice-typing screen, with `PREFER_OFFLINE`.

**Our own speech model.** It reaches 79% meaning accuracy on synthetic voices. On real people its phoneme error is still 58.9% after adding 10 h of real speech, so it is not shipped yet.

**Next.** IndicVoices (AI4Bharat, about 7,300 hours of real speech) on a GPU, then reuse the same closed-world trick in the other direction: closed-set keyword spotting for yes/no and crop/part names.

## 6. What did not help, or is not proven

- **Flip test-time augmentation** for photos: no gain in single view (62.2% vs 61.3%). Removed, which halves photo time.
- **More questions**: see section 4.
- **SIGReg (LeJEPA) in supervised fine-tuning**: neutral (earlier work).
- **Results are from simulation and public data.** Native speakers need to review the voice. An agronomist needs to review the symptom table. A field pilot with KVKs is the real test.

---

# Version 2

## 7. Fact-token model: chat like an LLM, but every token is a verified fact

**Problem.** Farmers ask anything ("which medicine for leaf curl, organic only", "how much per acre", "is it the rain?"). A small on-device LLM (0.5–1 B parameters) is too heavy for a 2 GB phone in four languages, and it can invent a dose. Retrieval (pick the nearest passage) cannot combine facts, cannot ask back, and does not know when to refuse.

**Method** (`factlm/`, `FactLM.java`). A small encoder-decoder transformer (int8, 13 MB) reads the question in any script, romanized or code-mixed, plus two context tokens (crop, confirmed disease). Its decoder **generates a short sequence of fact ids**: the output vocabulary is the verified fact bank plus five control tokens: `<END>`, `<ASK>` (start the diagnosis questions), `<CONFIRM>` (confirm the disease before doses), `<WHICH_CROP>` and `<NOT_SURE>` (send to KVK / KCC 1800-180-1551). The farmer sees and hears the verified sentence of each fact in their language. The model can combine facts in new ways, but it cannot produce a sentence that is not in the bank.

**Closest prior work.** Generative retrieval (DSI, Tay et al. 2022) trains a transformer to output document ids. Here the ids are atomic facts, the decoder composes several of them, control tokens let it ask or refuse, and hard decoding rules (section 9) make doses safe. It runs in pure Java with no ML runtime.

**Checked here.**

- Java == PyTorch on 52 hard questions (4 languages, romanized, code-mixed, empty, emoji, 48 words, conflicting context) for 3 models: identical item sequences 52/52; max logit difference 5e-6.
- Speed on a desktop core: about 11 ms per question (1 thread, trained seed model).
- The in-app chat (Java) gives the same replies as the Python reference in 120/120 simulated conversations, and in 80/80 with a rehearsal fact bank that adds new pests, names and facts; every spoken sentence has a clip.
- Independent test (160 hand-written questions, section 11 of DATASETS.md): the seed-only model scores 42.5%, because the 75 seed facts cover only 8 of the 122 fact questions. The model trained on the full bank is measured on the training run.

## 8. Build-time teacher, phone-time students

Everything heavy runs once, on temporary build VMs (CPU only, or one GPU), and never on the phone:

| Teacher (VM only) | Student or table (phone) |
|---|---|
| Gemma 4 26B-A4B (Apache-2.0) reads 14 government / university documents | verified fact bank: a fact is kept only if its quote is verbatim in the source and its numbers are in the quote |
| the same LLM writes ~60k farmer questions in 4 languages | fact-token model (13 MB) |
| AI4Bharat Indic-TTS (human voices, MIT) | clips for every fixed sentence and fact, plus our own small voice model |
| open Whisper-tiny checkpoints + FLEURS | our fine-tuned Whisper-tiny per language |
| ImageNet MobileNetV3 + Indian field photos | photo fingerprint model (4.7 MB) |

The teacher's mistakes are filtered by checks that do not trust the teacher (verbatim quotes, numbers, banned-pesticide list, script and number checks on translations). What is left is marked `review: auto` for an agronomist and native speakers.

## 9. Three independent locks on doses

A chemical dose is the one answer that can do harm. It is shown only if all three agree:

1. **Table rule.** A dose fact needs the disease the farmer confirmed (`ctx.target`); otherwise the model can only say `<CONFIRM>`.
2. **Model gate.** If the model's target head says the question names a different disease, doses are masked.
3. **Name guard (new, deterministic).** If the question contains a local name of another disease (any of the 4 languages and scripts, whole words, names unique to one disease) and none of the confirmed one, doses are masked.

The v1 smoke run had 0.6% wrong doses on the context test, all from romanized names the target head missed; lock 3 targets exactly that case. Locks 2 and 3 are in both Python and Java and in the parity test (the guard fires on 2 of the 52 parity questions, with identical results).

## 10. Our own voice model behind the closed-world clips

**Why both.** Clips (section 1) give a human voice with zero compute, but only for sentences known at build time. Facts added later and new pest names would be silent. So every known sentence keeps its clip, and anything else is spoken by our own small voice model in the same voice.

**Method** (`voice/student/`, `Speak.java`). A FastPitch-style acoustic model (9.3 M parameters, alignment learned, one model for 4 languages × 2 speakers) and a Vocos-style vocoder (3.6 M, 16 kHz), both distilled from the Indic-TTS teacher on a teacher-rendered corpus (facts, questions, app sentences, FLEURS transcripts). Weights are int8; the runtime is pure Java.

**Checked here.** Java == PyTorch (mel 1.7e-6, waveform 1.6e-7, durations 0/318 different). Real-time factor 0.34 on one desktop core (full-size model; speed only, random weights). Quality vs the teacher (mel L1, MCD) and on-phone speed are measured on the training / emulator runs.

## 11. Our own offline speech recognizer: Whisper-tiny, short context, restricted vocabulary

**Why.** Android's on-device recognizer exists only on Android 12+ with the language pack installed. Older and cheaper phones need their own.

**Method** (`speech/whisper/`, `Whisper.java`, `Listen.java`). Per language, the best open Whisper-tiny checkpoint (by dev CER, open licence only) is fine-tuned in **short mode**: the encoder sees only the real audio frames, not a padded 30 s window. The output vocabulary is restricted to tokens farmers' sentences use. int8, pure Java, energy-based end of speech.

**Checked here.**

- Java == Hugging Face transformers: greedy ids identical 11/11, full transcription identical 9/9, kernels bit-identical to the shared `Nn` kernels.
- 5 s of audio on one desktop core: **2.2 s in short mode vs 17.0 s with the 30 s window** (encoder 1.3 s vs 14.8 s); 1.6 s with the restricted vocabulary.
- Size: 19.5 MB per language (int8, restricted vocabulary).
- Accuracy (CER on FLEURS test, real speakers) is measured on the training run.

## 12. Indian field photos for all four crops

The v1 photo model knew only tomato (PlantDoc). Version 2 uses the same phone network (MobileNetV3 fingerprints, pure Java) trained on Indian and Bangladeshi field photos of rice, groundnut and chilli plus PlantDoc tomato (DATASETS.md section 12), with three changes:

- an `other_crop` class, so a photo of another crop gets "this does not look like one of my four crops" instead of a wrong disease;
- each label carries its crop, kind (disease / pest / healthy) and app target, so a pest photo (e.g. rice hispa) leads straight to that pest's verified facts, and a photo of another of the four crops starts a new consultation;
- scores are compared within the photo's crop.

Checked here: the full pipeline (data → training → int8 export → Java) runs end to end on a small stand-in set, and Java gives the same label as Python on 6/6 photos. Per-crop accuracy is measured on the training run.

---

## Sources

- Android on-device recogniser in practice (Hindi, offline, API 31+, availability check): https://hackernoon.com/testing-androids-on-device-speech-recognition-with-hindi-english-code-switching
- Android `RecognizerIntent` reference: https://developer.android.com/reference/android/speech/RecognizerIntent
- Android supported media formats (Opus decoder Android 5.0+, Ogg container): https://developer.android.com/media/platform/supported-formats
- IndicF5 (MIT, 0.4 B, 11 Indian languages, voice cloning with permission, 1,417 h): https://huggingface.co/ai4bharat/IndicF5
- Choosing Indic TTS (numerals sound synthetic; about 1 s silence and callers interrupt): https://www.gnani.ai/resources/blogs/how-to-choose-the-right-tts-engine-for-indic-languages
- A White Paper on Neural Network Quantization (PTQ vs QAT): https://arxiv.org/abs/2106.08295
- Meta-learning guided pruning for few-shot plant pathology on edge devices (78% smaller, 92.3% accuracy kept, 7 FPS on Raspberry Pi 4): https://arxiv.org/abs/2601.02353
- IndicVoices (AI4Bharat, real Indian-language speech): https://arxiv.org/abs/2403.01926
- PlantDoc dataset (CC-BY-4.0): https://github.com/pratikkayal/PlantDoc-Dataset
- AI4Bharat Indic-TTS checkpoints (MIT): https://github.com/AI4Bharat/Indic-TTS
- MobileNetV3 ImageNet weights (timm, Apache-2.0): https://github.com/huggingface/pytorch-image-models
- Transformer Memory as a Differentiable Search Index (generative retrieval of document ids): https://arxiv.org/abs/2202.06991
- Gemma 4 (Apache-2.0): https://rits.shanghai.nyu.edu/ai/google-releases-gemma-4-frontier-open-models-under-apache-2-0/
- Google FLEURS (CC-BY-4.0): https://huggingface.co/datasets/google/fleurs
- OpenAI Whisper (MIT): https://github.com/openai/whisper
