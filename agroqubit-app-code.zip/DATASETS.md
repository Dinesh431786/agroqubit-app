# Datasets: what was used, how it was made, and how it was split

This card covers every dataset used to build and test Krishi-JEPA. It records where each came from, its
licence, how it was created, its size, the train/test split, the leakage checks, and what is real versus
synthetic. Exact counts are in `dataset_stats.json`.

**The short version:**

- **Real:** the field photos (PlantDoc) and the expert knowledge (ICAR, TNAU, NIPHM/DPPQS, IRRI, AAU, COL sources).
- **Synthetic but written independently:** the farmer sentences, written by two separate writers who never saw each other's work.
- **Synthetic:** all speech, generated with espeak-ng.
- **Real speech (AWS only):** Google FLEURS read speech, used to measure the real-voice gap.
- **Not used:** real farmer recordings and Kisan Call Centre (KCC) transcripts.
- **Version 2 (sections 10–15)** adds, all built on the one-time build VMs: a verified fact bank extracted from 14
  government / university documents, ~60k teacher-written farmer questions, Indian field photos of rice, groundnut and
  chilli (plus tomato), real read speech (FLEURS) for the speech recognizer, and a teacher-voice corpus for our own
  voice model. Hugging Face is blocked in this workspace, so every download happens on the VM and every licence is
  recorded there.

---

## 1. Field photos: PlantDoc (real)

| Item | Detail |
|---|---|
| Source | PlantDoc (Singh et al., 2019), https://github.com/pratikkayal/PlantDoc-Dataset, cloned with git |
| Licence | CC-BY-4.0 (attribution required) |
| What it is | Real-world leaf photos from the internet, cluttered backgrounds, phone-like quality. **Not** lab images. |
| Size used | 27 classes (13 crops, 17 diseases and 10 healthy), 2,340 train / 236 test images |
| Dropped | "Tomato two spotted spider mites leaf" (2 train / 0 test images) |
| Preprocessing | EXIF-rotate, centre-crop to square, resize to 256 px, then a 224 px crop for the model |
| Splits | The official PlantDoc train/test split is kept. 10% of train per class is held out for validation (thresholds, calibration). |
| Held-out diseases | Part 1: *Tomato yellow leaf curl virus* (never trained on). M3: four diseases held out entirely (potato early blight, potato late blight, corn rust, tomato leaf curl) to test adding new diseases. |
| Pretrained start | MobileNetV3-Large ImageNet weights (timm, Apache-2.0), from a GitHub release |
| Known gaps | No rice, chilli, groundnut or cotton photos. The test set is small (±3–4 points of noise). Not Indian field photos. |

## 2. Farmer sentences, text (synthetic, written independently)

| Item | Training set | Test set |
|---|---|---|
| File | `data/text_train.jsonl` | `data/text_test.jsonl` |
| Written by | Writer 1: an AI agent briefed to write the way farmers phone a helpline | Writer 2: a **separate** AI agent, told never to open the training file, imitating farmers from UP/Bihar, the Tamil Nadu delta, North Karnataka and the Andhra border, with dialect and filler words |
| Sentences | 1,454 | 804 (791 after removing 13 exact overlaps) |
| Languages | hi 257, ta 257, kn 257, en 257, hi-Latn 142, ta-Latn 142, kn-Latn 142 | hi 130, ta 128, kn 131, en 126, hi-Latn 91, ta-Latn 93, kn-Latn 92 |
| Per meaning slot | 33 single-slot sentences per slot | 18 single-slot sentences per slot |
| Multi-meaning | 200 sentences with 2–3 slots | 120 |
| Avg. length | 5.8 words | 7.8 words (longer and more rambling) |
| Labels | Each sentence lists exactly the slots it expresses (38 slots in `slots.json`) | same |

**Labelling rules (both writers):**

- Single-slot sentences must not express a second slot by accident.
- No negated symptoms ("no white powder"), except in plain "no"-type answers.
- A plant-part slot is added only when the part is stated separately from the symptom.

**Leakage check:** after normalising case and punctuation, 13 test sentences were identical to training
sentences. They were short replies like "हां जी" and "ஆமா சார்", and all 13 were removed before testing.

**Generated during training only:**

- Random character edits (typing/recognition noise).
- Two-sentence concatenations, to teach multiple meanings in one turn.
- Casual romanised copies of the native-script sentences, made with `indic_transliteration` plus our
  spelling rules (schwa deletion, aa/a, ph/f, Tamil voicing). These are used for cross-script consistency training.

**Limits:** these sentences are written, not transcribed from real calls, so real farmers will use
words and dialects that aren't covered here. The next step is real KCC transcripts (data.gov.in;
licensing contact ndsap@gov.in) and field recordings.

## 3. Farmer speech (synthetic, espeak-ng)

| Item | Training | Test |
|---|---|---|
| Synthesiser | espeak-ng (GPL-3.0; bundled via the `espeakng-loader` PyPI package), voices hi / ta / kn / en-us | same |
| Sentences spoken | Training sentences in hi/ta/kn/en, plus 600 two-sentence mixes | **Test** sentences in hi/ta/kn/en (romanised rows can't be spoken) |
| Speakers | 26 voice variants: Andy, Annie, belinda, benjamin, caleb, david, ed, f1, f3, f5, grandpa, iven, john, klatt, klatt3, linda, m1, m2, m4, m5, m7, max, paul, rob, steph, travis | **13 different voices, never in training:** adam, anika, aunty, edward, f2, f4, grandma, ian, klatt2, m3, m6, m8, victor |
| Variation | 4 voices per sentence; speaking rate 110–210, pitch 25–75 (random) | 2 voices per sentence |
| Size | 6,512 clips, 5.96 h, avg 3.3 s | 1,030 clips, 1.0 h, avg 3.5 s |
| Extra (phoneme training only) | `train2`: 4,112 clips, 2.84 h. These are training sentences re-voiced, plus word-shuffled sentences (shuffled ones have no meaning label). | — |
| Audio | 16 kHz mono | same |
| Augmentation (train) | Gain ×0.3–1.5; added white/pink/brown noise at 3–30 dB with p=0.6–0.7; SpecAugment time/frequency masks; 25% telephone band-limit | — |
| Test conditions | — | clean; pink noise at 20 and 10 dB; brown noise at 5 dB; white noise at 5 dB |
| Phoneme targets | espeak-ng's own IPA transcription of each sentence (same G2P that produced the audio), stress marks removed; 59 symbols shared by all 4 languages | used only to measure phoneme error |
| Meaning targets | The text model's outputs on the transcript (soft slot probabilities plus its 256-d vector). **No hand labels on audio.** | Text labels, for scoring only |

**Limits:** synthetic speech is far cleaner and more regular than a farmer on a phone in a field, so
real-voice accuracy will be lower. Candidate public sources are AI4Bharat Kathbath (1,684 h, 12
languages; licence metadata is inconsistent, CC-BY-4.0 vs CC0) and IndicVoices, plus our own
recordings. Those would replace or add to this data on AWS.

## 3b. Real speech: Google FLEURS (real, used on AWS only)

| Item | Detail |
|---|---|
| Source | Google FLEURS (CC-BY-4.0), downloaded on the one-time AWS VM |
| Languages | hi_in, ta_in, kn_in, en_us |
| Used | 1,000 train + 200 test utterances per language (about 2.4–2.6 h train per language, ~10 h total) |
| Nature | Read Wikipedia sentences by native speakers, not farmers and not field noise |
| Splits | official FLEURS train/test, so test speakers are separate |
| Purpose | measure the synthetic-to-real gap and how much real data closes it (see README) |

## 3c. Farmer slang test and free questions (synthetic, independent writers)

- `data/text_slang_test.jsonl`: 632 dialect/slang sentences (UP/Bihar Hindi, Kongu/Madurai Tamil, North Karnataka Kannada, code-mixed), written by a separate writer. Used only for testing.
- `data/dialect_lexicon.json`: 34 concepts with local variants per language, used only as a training augmentation.
- `data/free_questions_{train,test}.jsonl`: 540 / 270 free questions with intent + disease labels, from different writers.

## 4. Knowledge base: diseases, symptoms and questions (expert sources)

| Item | Detail |
|---|---|
| File | `engine/knowledge_v2.json`, built by `build_kb.py` |
| Coverage | 4 crops, 25 diseases including healthy (rice 7, chilli 6, groundnut 4, tomato 8); 20 symptom questions, 4 field-context questions, a plant-part question and 4 picture grids |
| Symptom descriptions from | TNAU Agritech (paddy diseases, rice blast expert-system page, groundnut rust); Assam Agricultural University Rice Knowledge Bank; IRRI Rice Knowledge Bank (brown spot, sheath blight); NIPHM/DPPQS via Vikaspedia (chilli and tomato diseases); Commonwealth of Learning *Integrated Disease Management*, groundnut chapter (CC BY-SA 4.0). Each disease stores its source URL and a short quote. |
| Two tomato diseases | Late blight and leaf mould still use general descriptions; an ICAR/SAU source must be attached |
| Question style | Follows ICAR-IIRR's rice expert system: location/weather and crop details first, then field symptoms, then candidate images, then the remedy, with unmatched cases sent to an expert |
| Probabilities | P(farmer sees symptom \| disease) are **engineering estimates** (0.85–0.9 for the defining symptom, 0.05 when absent). No source publishes these numbers, so they **must be reviewed by an agronomist**. |
| Local disease names and questions | Hindi, Tamil and Kannada written by us. **Native-speaker review needed.** |
| Correction found while sourcing | NIPHM describes Indian tomato leaf curl as *downward* rolling and crinkling; our first draft said "upward", from non-Indian sources |

## 5. Advice cards: what the app says to do (government sources)

| Crop/disease | Source |
|---|---|
| Tomato (6 diseases) | *AESA based IPM – Tomato*, Package No. 18, DPPQS/NIPHM, Govt. of India |
| Chilli (5) | *AESA based IPM – Chillies/Capsicum*, Package No. 24, DPPQS/NIPHM/NCIPM |
| Groundnut (3) | *IPM Package for Groundnut* (2014), DPPQS/NCIPM/NIPHM |
| Rice blast | *Advisory on blast disease on rice crop*, DPPQS, MoA&FW, 22 July 2022 |
| Other rice diseases, healthy | No disease-specific source fetched yet, so the app gives the generic KVK / Kisan Call Centre advice |

- The app always lists cultural and biological steps first.
- Chemicals appear only as registered examples quoted from the source, with "confirm with KVK and the label".
- Some doses in the rice advisory were OCR-garbled, so no rice doses are given.

## 6. App voice-reply pack: closed-world voice (synthetic, human neural voice)

| Item | Detail |
|---|---|
| Content | **Every sentence the app can say**: 153 per language × 4 languages. This covers the greeting, fillers, all questions, 25 disease names, 15 first-step advice lines, every IPM advice item (cultural, biological and chemical examples), answer phrases, photo/mic phrases and the KVK/KCC referral. Listed by `voice/closed_world.py` from the app's own assets, with the same clip ids the Java app plays. |
| Speech text | `voice/verbalize.py`. Medicine and variety names are written out in native script, numbers become words ("200 लीटर" → "दो सौ लीटर"), percentages become "परसेंट", and the helpline is read digit by digit. Hindi first-person verbs follow the voice ("पूछती हूँ" female, "पूछता हूँ" male). Rendering fails if any Latin letters or digits would be left in the speech text. |
| Voices | **AI4Bharat Indic-TTS** (MIT; FastPitch + HiFi-GAN trained on the IndicTTS corpus of real native speakers), female and male. Rendered offline on the build VM one sentence at a time, joined with 0.28 s pauses. |
| Size | 1,224 clips (612 per voice), 16 kHz mono Opus at 16 kbps, **12.9 MB** for both voices. About 12–15 minutes of speech per language per voice. |
| Checks | All 300 parity conversations are fully voiced: 4,819 clips, 0 missing. Every sentence id exists in the APK for both voices. Full answers play to the end on Android 11 and Android 7, with 0 decoder errors. |

## 7. Test protocols

- **Photo model on the phone:** `android/tools/vision_check.py` uses the held-out PlantDoc test set with the phone's int8 weights in single view, and compares them with fp32. It also exports 20 real PlantDoc test photos and their Python answers. The emulator sends these photos to the app; the app's on-device answers are compared with Python and timed.

- **Text understanding:** trained on text_train (10% kept for threshold tuning), tested on the 791 independent test sentences; 3 seeds.
- **Speech understanding:** trained on speech_train (+ train2), tested on speech_test (unseen sentences and unseen voices), clean and noisy.
- **Vision:** official PlantDoc test split; new-disease tests use every photo of the held-out diseases. The new-disease bias is calibrated on seen validation photos only.
- **End-to-end diagnosis:** for each of the 25 diseases, 6 simulated farmers × 3 seeds. Each farmer:
  - opens with a real held-out sentence or clip in a random language;
  - answers each question truthfully according to the symptom table, but is wrong 15% of the time;
  - **says** that answer with a real held-out test sentence or clip;
  - for tomato, optionally adds a PlantDoc test photo of the true disease;
  - picks the right photo in a picture grid 60% of the time.

  Because the answers follow the same symptom table the engine uses, results are **optimistic**. A
  "perfect understanding" run gives the upper bound.
- **Leakage controls:** test sentences come from an independent writer; exact overlaps are removed;
  test voices are disjoint from training voices; vision thresholds are tuned only on the validation split.

## 8. Data we planned but could not use here

| Dataset | Why not | Plan |
|---|---|---|
| Kisan Call Centre transcripts (data.gov.in / AIKosh) | Domain blocked here; licence not stated on the page | Ask ndsap@gov.in; use for real farmer questions |
| AI4Bharat Kathbath / IndicVoices (speech) | Hugging Face blocked | Train the phoneme model on real voices (AWS) |
| ixrbhii 42-crop disease models (CC-BY-4.0) | Hugging Face blocked | Teacher for Indian-crop vision distillation |
| ICAR NIBPP image base (~4.97 lakh images) | Access terms unknown | Request access through ICAR-IASRI |
| Our own farmer recordings and field photos | Not collected yet | KVK pilot: 1–2 h of voice and photos per crop |

## 9. App speech register

- **Spoken village register (colloquial):** every app sentence was rewritten from textbook style into how farmers talk: Tamil "இருக்கா? சொல்லுங்க" (-ங்க), Kannada "ಇದೆಯಾ? ಹೇಳ್ರಿ" (-ರಿ), rural Hindi "जी, दवाई, पत्ते". Meaning, numbers and advice facts are unchanged, and all four languages now carry identical advice facts. Screen text and voice use the same script (`voice/catalogue.json`; the formal version is kept as `catalogue_formal.json`). Native-speaker review is still needed (see `voice/colloquial_notes.md`).

---

# Version 2 data (fact-token chat, own voice, own speech recognizer, Indian field photos)

## 10. Verified fact bank (`facts/`, real expert text)

| Item | Detail |
|---|---|
| Sources | 14 documents in `facts/sources.json`: NIPHM / DPPQS IPM packages (rice, tomato, chilli, groundnut), DPPQS rice blast advisory, TNAU Crop Production Guides 2020 (agriculture + horticulture), ICAR-CRRI agro-advisory (June 2026), ICAR-IIVR tomato and chilli pages, ICAR-CRIDA rainfed groundnut technologies, CIB&RC banned / restricted pesticide list |
| How facts are made | A teacher LLM (Gemma 4 26B-A4B, Apache-2.0, run locally on the VM with llama.cpp) reads each page and proposes short facts with a supporting quote. A fact is kept only if the **quote is found verbatim** in the page and **every number** in the fact is in the quote. Garbled scans give no facts with numbers; banned or crop-restricted pesticides are dropped (CIB&RC list); near-duplicates are removed. Every rejection is logged with its reason. |
| Translation | Teacher translation into hi / ta / kn in the farmer register. Hard checks: the same numbers, chemical / bio-agent / variety names unchanged, the right script; a failing item is sent back with the errors, then dropped. Soft check: back-translation similarity; low scores are flagged for review first. |
| What ships | Fact text in 4 languages, kind (first / info / action / dose), crop, target, source id, URL and page. The source quotes are **not** shipped in the app. |
| Review status | Every teacher fact is marked `review: auto`. `facts/work/review_queue.csv` lists them for an agronomist, doses first. |
| Seed | 75 facts copied exactly from the v1 advice cards (`facts/seed_facts.jsonl`). |
| Terms | NIPHM packages are marked "for internal circulation"; ICAR asks for permission before its web content is reproduced; ICAR data-use licences are non-commercial. **Get written permission (NIPHM, ICAR institutes, TNAU) before a public or commercial release.** |

## 11. Farmer questions for the fact-token model (synthetic)

| Item | Detail |
|---|---|
| Training questions | ~60,000 rows written by the teacher LLM per fact group (`facts/gen_questions.py`): 4 languages, native script, casual romanization, code-mixing, with the expected fact ids. Plus the 540 v1 training questions. |
| Held-out (teacher) | `val.jsonl`: a different prompt (phone-call openings, other personas) on the same facts. `zeroshot.jsonl`: ~10% of the new facts are held out entirely and every question touching them is only here. Questions that copy answer text or numbers are dropped. |
| **Independent test** | `factlm/data/test_independent.jsonl`: **160 questions written by hand before any teacher data existed**, by a writer who did not see the teacher prompts: 34 farmer questions × 4 languages in native script + 8 romanized each for hi / ta / kn. Labels are topic-level (crop, topic, target, expected behaviour), so the score does not depend on fact ids: 122 expect facts, 19 `<NOT_SURE>`, 8 `<ASK>`, 7 `<CONFIRM>`, 4 `<WHICH_CROP>`. If the bank has no fact for a topic, the only correct answer is `<NOT_SURE>` (KVK / KCC). |

## 12. Indian field photos (real) for the photo model (`vision2/`)

| Item | Detail |
|---|---|
| Sources | Project-AgML parquet mirrors on Hugging Face (cards checked on 12 Oct 2026): Odisha rice (Sethy et al., 5,932 photos, 4 diseases, CC-BY-4.0), UCI rice leaf diseases (120, CC-BY-4.0), two Bangladesh rice sets (773 and 1,106, CC-BY-4.0), two groundnut sets (1,720 and 3,058, CC-BY-4.0), COLD chilli (532 raw photos, CC-BY-4.0); PlantDoc for tomato and for `other_crop`. |
| Licence filter | The licence is read from each dataset card at run time; only open licences (CC-BY, CC0, Apache, MIT, ODC-BY, CDLA-permissive, PDDL) are used, and each decision is written to `report.json`. **Paddy Doctor** (Tamil Nadu, 10,407 photos) is skipped: its card states no licence and the original needs an IEEE DataPort subscription. |
| Labels | One label set (`vision2/labels.py`): `<crop>_<disease or pest>`, `<crop>_healthy` and `other_crop`. Misspelled class names in the sources ("Browon Spot", "Rice Turgro", "Shath Blight", "Leaf Scaled") are mapped too. Classes the app has no knowledge of (leaf smut, panicle diseases, nutrient deficiency) are dropped. COLD's "mites and thrips" class becomes one photo class that answers with the facts of both pests (the chilli leaf-curl "murda" complex). A black-pepper set was left out on purpose. |
| Leakage control | Augmented configs and splits are never used (COLD: the raw config only). Near-duplicates across all datasets are removed before splitting: 16×16 average hash within 12 of 256 bits, also against mirrored and rotated copies. Photos on a white background (half of the Bangladesh Dhan-Shomadhan set) are left out: they are not field photos. Dataset test / validation splits are kept; the rest is split 80/10/10 per (source, label). |
| Size | At most 3,000 training photos per label; exact counts per split and label are in the VM's `report.json`. |
| Test | Held-out test split, phone int8 weights, single view, top-1 / top-3 **within the crop**; "not sure" threshold calibrated on validation only. |

## 13. Real speech for the speech recognizer (FLEURS)

| Item | Detail |
|---|---|
| Source | Google FLEURS (CC-BY-4.0): hi_in, ta_in, kn_in, en_us; train / dev / test splits as published. |
| Candidates | Open Whisper-tiny checkpoints per language (e.g. collabora/whisper-tiny-hindi, vasista22/whisper-kannada-tiny, openai/whisper-tiny, MIT). Non-open licences are skipped; the best is picked by dev CER. |
| Fine-tune | The best open candidate per language is fine-tuned on FLEURS train in "short" mode (only the real audio frames, as the phone runs it, not a padded 30 s window) on 2–15 s crops cut at word pauses plus whole utterances; tested on FLEURS test in the same mode. |
| Phone test | 3 real FLEURS test clips + 3 teacher-voiced farmer questions per language, played into the app on the emulator. |

## 14. Teacher-voice corpus for our own voice model (synthetic, human-like)

| Item | Detail |
|---|---|
| Teacher | AI4Bharat Indic-TTS FastPitch + HiFi-GAN (MIT), female and male, hi / ta / kn / en |
| Texts | Fact texts, teacher questions (native script), v1 app sentences and FLEURS transcripts, de-duplicated (`/opt/texts/<lang>.txt`) |
| Use | The student (FastPitch-lite + Vocos-lite) learns from teacher audio only. Held-out sentences measure the student against the teacher: mel L1 and MCD-DTW, for the float model and the int8 phone weights. |

## 15. What still needs people

- An agronomist must review the teacher facts (doses first) before release.
- Native speakers must review fact translations, local disease names (`facts/target_names.json`, marked `review: auto`) and the voice.
- Real farmer recordings and field photos from a KVK pilot remain the real test for speech and photos.

