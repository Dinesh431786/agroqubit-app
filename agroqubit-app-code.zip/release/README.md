# Release builds

`krishi-doctor.apk` (38.7 MB, debug-signed test build, minSdk 21 / targetSdk 34) is built by `krishi/android/tools/job.sh`
(full rebuild) or `job_quick.sh` (rebuild + retest). It is attached to the GitHub release rather than committed here,
because the build VM produces it (see `results/RESULTS.md` for the tests it passed).

Install on a phone: allow "install unknown apps" for your file manager, open the APK.
Offline voice input needs the phone's offline speech pack for the language (Settings → Google → voice → offline speech).
