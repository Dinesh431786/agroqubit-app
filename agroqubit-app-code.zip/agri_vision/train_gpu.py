"""GPU version (Colab / AWS) for real Indian crop data, with optional teacher distillation.

Data: an ImageFolder tree  DATA/train/<crop>__<disease>/*.jpg  (and optional DATA/val/...).
      Use the '<crop>__<disease>' naming so per-crop distillation knows which classes belong together.
Teacher (optional): any timm classifier per crop, e.g. the CC-BY-4.0 ixrbhii/multicrop-disease-models
      ConvNeXt-Small checkpoints. Their file names/class orders were NOT inspected from this workspace
      (Hugging Face is blocked here) - fill TEACHERS below after listing the repo with:
          from huggingface_hub import list_repo_files; print(list_repo_files("ixrbhii/multicrop-disease-models"))
Usage:  python train_gpu.py --data /content/DATA --epochs 30 --weights mnv3.pth [--kd]
"""
import argparse, os, math, json, torch, torch.nn.functional as F, timm
from torch.utils.data import DataLoader
from torchvision import datasets, transforms as T
from model import Embedder, CosineHead

# crop -> (timm arch, checkpoint path, [class names in the teacher's output order, using the same disease names as DATA])
TEACHERS = {
    # "tomato": ("convnext_small", "/content/teachers/tomato.safetensors", ["tomato__early_blight", ...]),
}

ap = argparse.ArgumentParser()
ap.add_argument("--data", required=True); ap.add_argument("--epochs", type=int, default=30)
ap.add_argument("--weights", default="mnv3.pth"); ap.add_argument("--bs", type=int, default=64)
ap.add_argument("--kd", action="store_true"); ap.add_argument("--kd_w", type=float, default=1.0); ap.add_argument("--T", type=float, default=2.0)
a = ap.parse_args(); dev = "cuda" if torch.cuda.is_available() else "cpu"

class To255:  # model expects 0..255 floats (normalisation lives inside the model)
    def __call__(self, x): return x * 255
tf_train = T.Compose([T.RandomResizedCrop(224, scale=(0.45, 1)), T.RandomHorizontalFlip(), T.RandomVerticalFlip(),
                      T.RandomRotation(30), T.ColorJitter(.3, .3, .2, .03), T.RandomApply([T.GaussianBlur(5)], p=.2),
                      T.ToTensor(), To255()])
tf_eval = T.Compose([T.Resize(256), T.CenterCrop(224), T.ToTensor(), To255()])
tr = datasets.ImageFolder(f"{a.data}/train", tf_train); names = tr.classes
va = datasets.ImageFolder(f"{a.data}/val", tf_eval) if os.path.isdir(f"{a.data}/val") else None
dl = DataLoader(tr, a.bs, shuffle=True, num_workers=4, drop_last=True, pin_memory=True)

net = Embedder(a.weights).to(dev); head = CosineHead(len(names)).to(dev)
teachers = {}
if a.kd:
    from safetensors.torch import load_file
    for crop, (arch, path, tnames) in TEACHERS.items():
        m = timm.create_model(arch, pretrained=False, num_classes=len(tnames))
        m.load_state_dict(load_file(path) if path.endswith(".safetensors") else torch.load(path, map_location="cpu"))
        idx = torch.tensor([names.index(n) for n in tnames])  # student columns for this crop
        teachers[crop] = (m.eval().half().to(dev), idx.to(dev))
    crop_of = [n.split("__")[0] for n in names]
    TMEAN = torch.tensor([0.485, 0.456, 0.406], device=dev).view(1, 3, 1, 1) * 255
    TSTD = torch.tensor([0.229, 0.224, 0.225], device=dev).view(1, 3, 1, 1) * 255

opt = torch.optim.AdamW([{"params": net.backbone.parameters(), "lr": 4e-4},
                         {"params": list(net.proj.parameters()) + list(head.parameters()), "lr": 2e-3}], weight_decay=0.02)
steps = a.epochs * len(dl); sched = torch.optim.lr_scheduler.OneCycleLR(opt, [4e-4, 2e-3], total_steps=steps, pct_start=0.05)
scaler = torch.amp.GradScaler(enabled=dev == "cuda"); best = 0
for ep in range(a.epochs):
    net.train()
    for x, y in dl:
        x, y = x.to(dev, non_blocking=True), y.to(dev)
        with torch.autocast(dev, enabled=dev == "cuda"):
            z = net(x); loss = F.cross_entropy(head(z, y), y, label_smoothing=0.1)
            if teachers:  # per-crop KL between teacher probs and student cosine logits over that crop's diseases
                kd, n = 0, 0
                for crop, (tm, idx) in teachers.items():
                    sel = torch.tensor([crop_of[i] == crop for i in y.tolist()], device=dev)
                    if not sel.any(): continue
                    with torch.no_grad(): tl = tm(((x[sel] - TMEAN) / TSTD).half()).float()
                    sl = head(z[sel])[:, idx]
                    kd = kd + F.kl_div(F.log_softmax(sl / a.T, -1), F.softmax(tl / a.T, -1), reduction="batchmean") * a.T ** 2; n += 1
                if n: loss = loss + a.kd_w * kd / n
        opt.zero_grad(set_to_none=True); scaler.scale(loss).backward(); scaler.step(opt); scaler.update(); sched.step()
    if va:
        net.eval(); c = t = 0
        with torch.no_grad():
            for x, y in DataLoader(va, 128, num_workers=4):
                p = head(net(x.to(dev))).argmax(1).cpu(); c += (p == y).sum().item(); t += len(y)
        acc = c / t; print(f"ep {ep+1} val {acc:.4f}", flush=True)
        if acc < best: continue
        best = acc
    torch.save({"net": net.state_dict(), "head": head.state_dict(), "names": names}, "student_gpu.pt")
print("done, best val", best)
