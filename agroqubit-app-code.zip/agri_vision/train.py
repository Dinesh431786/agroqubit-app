import json, time, math, sys, numpy as np, torch, torch.nn.functional as F
from model import Embedder, CosineHead
torch.manual_seed(0); np.random.seed(0); torch.set_num_threads(int(__import__("os").environ.get("THREADS", "2")))
C = "/home/claude/data/cache"; W = "/home/claude/weights/mnv3.pth"
EPOCHS = int(sys.argv[1]) if len(sys.argv) > 1 else 12
HOLDOUT = "Tomato leaf yellow virus"   # never seen in training; added later from 10 photos

classes = json.load(open(f"{C}/classes.json")); ho = classes.index(HOLDOUT)
tr = np.load(f"{C}/train.npz"); X, y = tr["X"], tr["y"]
# stratified 10% val split, excluding the held-out class
rng = np.random.default_rng(0); val_idx = []
for c in range(len(classes)):
    if c == ho: continue
    idx = rng.permutation(np.where(y == c)[0]); val_idx += idx[: max(2, len(idx) // 10)].tolist()
val_idx = np.array(sorted(val_idx)); mask = np.ones(len(y), bool); mask[val_idx] = False; mask[y == ho] = False
train_idx = np.where(mask)[0]
known = [c for c in range(len(classes)) if c != ho]; remap = {c: i for i, c in enumerate(known)}
np.savez(f"{C}/split.npz", train_idx=train_idx, val_idx=val_idx, ho=ho, known=np.array(known))
print("train", len(train_idx), "val", len(val_idx), "classes", len(known))

def batch(idx, aug):
    x = torch.from_numpy(X[idx]).permute(0, 3, 1, 2).float()  # N,3,256,256
    if not aug: return x[:, :, 16:240, 16:240].contiguous()
    out = torch.empty(len(idx), 3, 224, 224)
    for i in range(len(idx)):
        s = int(256 * math.sqrt(np.random.uniform(0.45, 1.0))); s = max(s, 120)
        t, l = np.random.randint(0, 257 - s, 2)
        im = x[i:i+1, :, t:t+s, l:l+s]
        im = F.interpolate(im, size=224, mode="bilinear", align_corners=False)[0]
        if np.random.rand() < .5: im = im.flip(2)
        if np.random.rand() < .5: im = im.flip(1)
        k = np.random.randint(4); im = torch.rot90(im, k, (1, 2))
        im = (im - im.mean()) * np.random.uniform(.75, 1.25) + im.mean() * np.random.uniform(.75, 1.25)
        im = im * torch.tensor(np.random.uniform(.9, 1.1, 3), dtype=torch.float32).view(3, 1, 1)  # colour cast (phone cameras)
        out[i] = im.clamp(0, 255)
    return out

net = Embedder(W); head = CosineHead(len(known))
net = net.to(memory_format=torch.channels_last)
opt = torch.optim.AdamW([{"params": net.backbone.parameters(), "lr": 4e-4},
                         {"params": list(net.proj.parameters()) + list(head.parameters()), "lr": 2e-3}], weight_decay=0.02)
BS = 32; steps = EPOCHS * math.ceil(len(train_idx) / BS); step = 0
base = [g["lr"] for g in opt.param_groups]
yv = torch.tensor([remap[c] for c in y[val_idx]])

def evaluate():
    net.eval(); Z = []
    with torch.no_grad():
        for i in range(0, len(val_idx), 64): Z.append(net(batch(val_idx[i:i+64], False).to(memory_format=torch.channels_last)))
    pred = head(torch.cat(Z)).argmax(1); net.train(); return (pred == yv).float().mean().item()

best = 0; t0 = time.time()
for ep in range(EPOCHS):
    perm = np.random.permutation(train_idx); tot = 0
    for i in range(0, len(perm), BS):
        idx = perm[i:i+BS]; xb = batch(idx, True).to(memory_format=torch.channels_last)
        yb = torch.tensor([remap[c] for c in y[idx]])
        warm = min(1, (step + 1) / 30); cos = 0.5 * (1 + math.cos(math.pi * step / steps))
        for g, b in zip(opt.param_groups, base): g["lr"] = b * warm * cos
        loss = F.cross_entropy(head(net(xb), yb), yb, label_smoothing=0.1)
        opt.zero_grad(); loss.backward(); opt.step(); step += 1; tot += loss.item() * len(idx)
    acc = evaluate()
    print(f"ep {ep+1}/{EPOCHS} loss {tot/len(perm):.3f} val_acc {acc:.3f} t {time.time()-t0:.0f}s", flush=True)
    if acc >= best:
        best = acc; torch.save({"net": net.state_dict(), "head": head.state_dict(), "known": known}, "/home/claude/agri_vision/student.pt")
print("best val", best)
