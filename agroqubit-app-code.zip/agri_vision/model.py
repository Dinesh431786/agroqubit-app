"""Fingerprint student: MobileNetV3-Large -> 256-d L2-normalised embedding.
Classes are 'fingerprints' (unit vectors). Score = cosine(embedding, fingerprint).
New diseases are added by appending a fingerprint; the network is never retrained."""
import torch, torch.nn as nn, torch.nn.functional as F, timm

MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)

class Embedder(nn.Module):
    """Input: uint8-range float NCHW RGB 224x224 (0..255). Output: unit 256-d vector."""
    def __init__(self, weights=None, dim=256):
        super().__init__()
        self.backbone = timm.create_model("mobilenetv3_large_100", pretrained=False, num_classes=0)
        if weights:
            sd = torch.load(weights, map_location="cpu")
            sd = {k: v for k, v in sd.items() if not k.startswith("classifier")}
            missing, unexpected = self.backbone.load_state_dict(sd, strict=False)
            assert not unexpected, unexpected
        feat = getattr(self.backbone, "head_hidden_size", None) or self.backbone.num_features
        self.proj = nn.Linear(feat, dim)
        self.register_buffer("mean", MEAN * 255); self.register_buffer("std", STD * 255)

    def forward(self, x):
        x = (x - self.mean) / self.std
        return F.normalize(self.proj(self.backbone(x)), dim=-1)

class CosineHead(nn.Module):
    """CosFace-style head: logits = s * (cos - m on the true class). Rows become fingerprints."""
    def __init__(self, n, dim=256, s=20.0, m=0.2):
        super().__init__(); self.W = nn.Parameter(torch.randn(n, dim) * 0.01); self.s, self.m = s, m
    def forward(self, z, y=None):
        cos = z @ F.normalize(self.W, dim=-1).T
        if y is not None: cos = cos - self.m * F.one_hot(y, cos.shape[1])
        return self.s * cos
