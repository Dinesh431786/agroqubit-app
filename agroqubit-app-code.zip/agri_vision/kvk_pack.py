"""Signed fingerprint packs: how a KVK pushes a new disease to phones (Bluetooth / Nearby Share / SD card).
Pack = canonical JSON payload + Ed25519 signature. The phone accepts it only if
(a) the signer's public key is in the app's trusted list, (b) the signature matches, and
(c) model_id equals the hash of the installed vision model (fingerprints only make sense for that model)."""
import json, base64, hashlib, time, numpy as np
from nacl.signing import SigningKey, VerifyKey
from nacl.exceptions import BadSignatureError

FORMAT = "krishi-fp/1"

def model_id(onnx_path):
    return hashlib.sha256(open(onnx_path, "rb").read()).hexdigest()[:16]

def make_pack(signing_key, issuer, mid, entries):
    """entries: list of dict(id, crop, names{en,hi,ta,kn}, n_photos, vector: np.ndarray[256])"""
    payload = {"format": FORMAT, "issuer": issuer, "model_id": mid, "issued_at": int(time.time()),
               "entries": [{**{k: v for k, v in e.items() if k != "vector"},
                            "vector_f16_b64": base64.b64encode(e["vector"].astype("<f2").tobytes()).decode()} for e in entries]}
    body = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    sig = signing_key.sign(body).signature
    return json.dumps({"payload": base64.b64encode(body).decode(), "sig": sig.hex(),
                       "key_id": signing_key.verify_key.encode().hex()[:16]}).encode()

def verify_pack(blob, trusted_keys, installed_model_id):
    """Returns (ok, reason, entries). trusted_keys: {key_id: verify_key_hex}"""
    try:
        p = json.loads(blob); body = base64.b64decode(p["payload"])
        vk_hex = trusted_keys.get(p["key_id"])
        if vk_hex is None: return False, "untrusted signer", []
        VerifyKey(bytes.fromhex(vk_hex)).verify(body, bytes.fromhex(p["sig"]))
        payload = json.loads(body)
    except BadSignatureError:
        return False, "signature invalid (pack was altered)", []
    except Exception as e:
        return False, f"malformed pack: {e}", []
    if payload.get("format") != FORMAT: return False, "unknown format", []
    if payload["model_id"] != installed_model_id: return False, "pack is for a different vision model version", []
    ents = []
    for e in payload["entries"]:
        v = np.frombuffer(base64.b64decode(e["vector_f16_b64"]), dtype="<f2").astype(np.float32)
        if v.shape != (256,) or not np.isfinite(v).all(): return False, "bad vector", []
        e = dict(e); e["vector"] = v / np.linalg.norm(v); ents.append(e)
    return True, f"verified: {payload['issuer']}", ents

if __name__ == "__main__":
    A = "/home/claude/agri_vision"
    mid = model_id(f"{A}/leaf_fp16.onnx")
    kvk = SigningKey.generate(); trusted = {kvk.verify_key.encode().hex()[:16]: kvk.verify_key.encode().hex()}
    vec = np.load(f"{A}/fp_new_disease.npy")
    entry = {"id": "tomato_yellow_leaf_curl_virus", "crop": "tomato", "n_photos": 10,
             "names": {"en": "Tomato yellow leaf curl virus",
                       "hi": "टमाटर पीला पत्ती मोड़क विषाणु",
                       "ta": "தக்காளி மஞ்சள் இலை சுருள் வைரஸ்",
                       "kn": "ಟೊಮೆಟೊ ಹಳದಿ ಎಲೆ ಸುರುಳಿ ವೈರಸ್"}}
    blob = make_pack(kvk, "KVK Demo (test key)", mid, [{**entry, "vector": vec}])
    open(f"{A}/demo_pack.kfp", "wb").write(blob)
    checks = {"pack_bytes": len(blob)}
    checks["genuine"] = verify_pack(blob, trusted, mid)[:2]
    p = json.loads(blob); body = json.loads(base64.b64decode(p["payload"]))
    body["entries"][0]["names"]["en"] = "Fake disease - buy product X"
    p["payload"] = base64.b64encode(json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).decode()
    checks["tampered"] = verify_pack(json.dumps(p).encode(), trusted, mid)[:2]
    rogue = SigningKey.generate(); checks["unknown_signer"] = verify_pack(make_pack(rogue, "KVK Demo (test key)", mid, [{**entry, "vector": vec}]), trusted, mid)[:2]
    checks["wrong_model_version"] = verify_pack(blob, trusted, "0000000000000000")[:2]
    json.dump(checks, open(f"{A}/results_pack.json", "w"), indent=1, ensure_ascii=False); print(json.dumps(checks, indent=1, ensure_ascii=False))
