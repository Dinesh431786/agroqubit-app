"""Cache PlantDoc images as 256x256 uint8 arrays (center-crop of the short side)."""
import os, sys, json, numpy as np
from PIL import Image, ImageOps
from concurrent.futures import ProcessPoolExecutor

ROOT = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/data/PlantDoc-Dataset"
OUT = sys.argv[2] if len(sys.argv) > 2 else "/home/claude/data/cache"
SIZE = 256
DROP = {"Tomato two spotted spider mites leaf"}  # only 2 train / 0 test images

def load(path):
    try:
        im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
        w, h = im.size; s = min(w, h)
        im = im.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s))
        return np.asarray(im.resize((SIZE, SIZE), Image.BICUBIC), dtype=np.uint8)
    except Exception as e:
        print("skip", path, e); return None

def main():
    os.makedirs(OUT, exist_ok=True)
    classes = sorted(c for c in os.listdir(f"{ROOT}/train") if c not in DROP)
    json.dump(classes, open(f"{OUT}/classes.json", "w"), indent=1)
    for split in ["train", "test"]:
        paths, labels = [], []
        for i, c in enumerate(classes):
            d = f"{ROOT}/{split}/{c}"
            if not os.path.isdir(d): continue
            for f in sorted(os.listdir(d)):
                paths.append(f"{d}/{f}"); labels.append(i)
        with ProcessPoolExecutor(2) as ex:
            imgs = list(ex.map(load, paths, chunksize=16))
        keep = [k for k, im in enumerate(imgs) if im is not None]
        X = np.stack([imgs[k] for k in keep]); y = np.array([labels[k] for k in keep])
        np.savez(f"{OUT}/{split}.npz", X=X, y=y)
        print(split, X.shape, np.bincount(y, minlength=len(classes)).tolist())

if __name__ == "__main__":
    main()
