"""Peak RAM of a fresh process that loads the int8 model and classifies one photo."""
import resource, sys, numpy as np, onnxruntime as ort
base = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
so = ort.SessionOptions(); so.intra_op_num_threads = 1; so.enable_cpu_mem_arena = False
s = ort.InferenceSession(sys.argv[1], so, providers=["CPUExecutionProvider"])
s.run(None, {"image": (np.random.rand(1, 3, 224, 224) * 255).astype(np.float32)})
peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
print(f"python+ORT baseline {base/1024:.0f} MB, peak {peak/1024:.0f} MB, model-attributable ~{(peak-base)/1024:.0f} MB")
