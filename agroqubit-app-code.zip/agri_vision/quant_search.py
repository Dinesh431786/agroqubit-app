import json, os, numpy as np, onnx, onnxruntime as ort
from onnxruntime.quantization import quantize_static, quantize_dynamic, CalibrationDataReader, QuantFormat, QuantType, CalibrationMethod
from onnxruntime.quantization.shape_inference import quant_pre_process
A="/home/claude/agri_vision"; C="/home/claude/data/cache"
quant_pre_process(f"{A}/leaf_fp32.onnx", f"{A}/leaf_pre.onnx")
tr=np.load(f"{C}/train.npz"); sp=np.load(f"{C}/split.npz")
cal=tr["X"][np.random.default_rng(1).choice(sp["train_idx"],48,replace=False)]
class R(CalibrationDataReader):
    def __init__(s): s.it=iter(cal)
    def get_next(s):
        a=next(s.it,None); return None if a is None else {"image":a[16:240,16:240].transpose(2,0,1)[None].astype(np.float32)}
te=np.load(f"{C}/test.npz"); fps=np.load(f"{A}/fingerprints_base.npy").astype(np.float32)
names=json.load(open(f"{A}/fingerprints_base.json")); classes=json.load(open(f"{C}/classes.json"))
lab=np.array([names.index(classes[c]) if classes[c] in names else -1 for c in te["y"]]); m=lab>=0
def emb(path):
    so=ort.SessionOptions(); so.intra_op_num_threads=2; s=ort.InferenceSession(path,so,providers=["CPUExecutionProvider"])
    Z=[]
    for a in te["X"][m]:
        i=a[16:240,16:240].transpose(2,0,1)[None].astype(np.float32)
        z=s.run(None,{"image":i})[0][0]+s.run(None,{"image":i[...,::-1].copy()})[0][0]; Z.append(z/np.linalg.norm(z))
    return np.stack(Z)
Zf=emb(f"{A}/leaf_fp32.onnx")
nodes=[n for n in onnx.load(f"{A}/leaf_pre.onnx").graph.node]
convs=[n.name for n in nodes if n.op_type=="Conv"]; gemm=[n.name for n in nodes if n.op_type in("Gemm","MatMul")]
# SE-block convs operate on 1x1 pooled tensors; find them by input coming from GlobalAveragePool/ReduceMean
out2op={o:n for n in nodes for o in n.output}
se=[n.name for n in nodes if n.op_type=="Conv" and n.input[0] in out2op and out2op[n.input[0]].op_type in("GlobalAveragePool","ReduceMean")]
print("convs",len(convs),"se convs",len(se),"gemm",len(gemm))
variants={
 "M_minmax_noSE_nofirstlast":dict(method=CalibrationMethod.MinMax, ops=["Conv","Gemm","MatMul"], excl=se+[convs[0]]+gemm),


 "C_pct_noSE_nofirstlast":dict(method=CalibrationMethod.Percentile, ops=["Conv","Gemm","MatMul"], excl=se+[convs[0]]+gemm),

}
res={}
for k,v in variants.items():
    p=f"{A}/q_{k}.onnx"
    try:
        quantize_static(f"{A}/leaf_pre.onnx",p,R(),quant_format=QuantFormat.QDQ,per_channel=True,activation_type=QuantType.QUInt8,
            weight_type=QuantType.QInt8,calibrate_method=v["method"],op_types_to_quantize=v["ops"],nodes_to_exclude=v["excl"],
            extra_options={"CalibPercentile":99.99} if v["method"]==CalibrationMethod.Percentile else {})
        Z=emb(p); res[k]=dict(MB=round(os.path.getsize(p)/1e6,2),top1=round(float(((Z@fps.T).argmax(1)==lab[m]).mean()),4),cos=round(float((Z*Zf).sum(1).mean()),4))
    except Exception as e: res[k]=str(e)[:200]
    print(k,res[k],flush=True)
# weight-only fp16 storage (run as fp32 on phone after loading)
from onnxruntime.transformers.float16 import convert_float_to_float16
mod=convert_float_to_float16(onnx.load(f"{A}/leaf_fp32.onnx"),keep_io_types=True); onnx.save(mod,f"{A}/q_E_fp16.onnx")
Z=emb(f"{A}/q_E_fp16.onnx"); res["E_fp16"]=dict(MB=round(os.path.getsize(f"{A}/q_E_fp16.onnx")/1e6,2),top1=round(float(((Z@fps.T).argmax(1)==lab[m]).mean()),4),cos=round(float((Z*Zf).sum(1).mean()),4))
print("E_fp16",res["E_fp16"]); json.dump(res,open(f"{A}/results_quant_search.json","w"),indent=1)
