"""Export the embedder to ONNX, quantise to int8 (static, per-channel), verify, benchmark."""
import json, time, os, numpy as np, torch, onnxruntime as ort
from onnxruntime.quantization import quantize_static, CalibrationDataReader, QuantFormat, QuantType
from model import Embedder
A = "/home/claude/agri_vision"; C = "/home/claude/data/cache"
ck = torch.load(f"{A}/student.pt"); net = Embedder(); net.load_state_dict(ck["net"]); net.eval()
x = torch.rand(1, 3, 224, 224) * 255
torch.onnx.export(net, x, f"{A}/leaf_fp32.onnx", input_names=["image"], output_names=["embedding"],
                  opset_version=17, dynamo=False)
tr = np.load(f"{C}/train.npz"); sp = np.load(f"{C}/split.npz")
cal = tr["X"][np.random.default_rng(1).choice(sp["train_idx"], 200, replace=False)]
class R(CalibrationDataReader):
    def __init__(s): s.it = iter(cal)
    def get_next(s):
        a = next(s.it, None)
        return None if a is None else {"image": a[16:240, 16:240].transpose(2, 0, 1)[None].astype(np.float32)}
from onnxruntime.quantization.shape_inference import quant_pre_process
quant_pre_process(f"{A}/leaf_fp32.onnx", f"{A}/leaf_pre.onnx")
quantize_static(f"{A}/leaf_pre.onnx", f"{A}/leaf_int8.onnx", R(), quant_format=QuantFormat.QDQ,
                per_channel=True, activation_type=QuantType.QUInt8, weight_type=QuantType.QInt8)
os.remove(f"{A}/leaf_pre.onnx")

te = np.load(f"{C}/test.npz"); fps = np.load(f"{A}/fingerprints_base.npy").astype(np.float32)
names = json.load(open(f"{A}/fingerprints_base.json")); classes = json.load(open(f"{C}/classes.json"))
lab = np.array([names.index(classes[c]) if classes[c] in names else -1 for c in te["y"]]); m = lab >= 0
out = {}
for tag in ["fp32", "int8"]:
    so = ort.SessionOptions(); so.intra_op_num_threads = 1
    s = ort.InferenceSession(f"{A}/leaf_{tag}.onnx", so, providers=["CPUExecutionProvider"])
    Z = []
    for a in te["X"][m]:
        inp = a[16:240, 16:240].transpose(2, 0, 1)[None].astype(np.float32)
        z = s.run(None, {"image": inp})[0][0] + s.run(None, {"image": inp[..., ::-1].copy()})[0][0]
        Z.append(z / np.linalg.norm(z))
    Z = np.stack(Z); acc = float(((Z @ fps.T).argmax(1) == lab[m]).mean())
    inp = te["X"][0][16:240, 16:240].transpose(2, 0, 1)[None].astype(np.float32)
    for _ in range(5): s.run(None, {"image": inp})
    t = time.time(); [s.run(None, {"image": inp}) for _ in range(30)]
    out[tag] = dict(size_MB=round(os.path.getsize(f"{A}/leaf_{tag}.onnx") / 1e6, 2), test_top1_known=round(acc, 4),
                    ms_per_image_1thread_server=round((time.time() - t) / 30 * 1000, 1))
    out[tag + "_Z"] = Z
cos = (out["fp32_Z"] * out["int8_Z"]).sum(1); del out["fp32_Z"], out["int8_Z"]
out["int8_vs_fp32_cosine_mean"] = round(float(cos.mean()), 4)
json.dump(out, open(f"{A}/results_export.json", "w"), indent=1); print(json.dumps(out, indent=1))
