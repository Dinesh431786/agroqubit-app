"""Fingerprints = per-disease mean embeddings. Tests: (1) accuracy, (2) add an unseen disease
from K photos with zero retraining, (3) 'not sure' rejection of a disease the app doesn't know."""
import json, numpy as np, torch, torch.nn.functional as F
from model import Embedder, CosineHead
torch.set_num_threads(int(__import__("os").environ.get("THREADS", "2")))
C = "/home/claude/data/cache"; A = "/home/claude/agri_vision"
classes = json.load(open(f"{C}/classes.json")); sp = np.load(f"{C}/split.npz")
ho, known = int(sp["ho"]), sp["known"].tolist()
tr, te = np.load(f"{C}/train.npz"), np.load(f"{C}/test.npz")
ck = torch.load(f"{A}/student.pt"); net = Embedder(); net.load_state_dict(ck["net"]); net.eval()

@torch.no_grad()
def embed(X):
    out = []
    for i in range(0, len(X), 64):
        x = torch.from_numpy(X[i:i+64]).permute(0, 3, 1, 2).float()[:, :, 16:240, 16:240]
        out.append(F.normalize(net(x) + net(x.flip(3)), dim=-1))  # 2-view average (flip)
    return torch.cat(out).numpy()

Ztr, Zte = embed(tr["X"]), embed(te["X"]); ytr, yte = tr["y"], te["y"]
np.savez(f"{A}/embeddings.npz", Ztr=Ztr, Zte=Zte)
def norm(v): return v / np.linalg.norm(v, axis=-1, keepdims=True)
fp_idx = sp["train_idx"]  # fingerprints from training images only
FP = {c: norm(Ztr[fp_idx][ytr[fp_idx] == c].mean(0)) for c in known}

def topk(Z, y, fps, k):
    ids = list(fps); M = np.stack([fps[c] for c in ids]); S = Z @ M.T
    order = np.argsort(-S, 1)[:, :k]; pred = np.array(ids)[order]
    return (pred[:, 0] == y).mean(), (pred == y[:, None]).any(1).mean()

R = {}
mk = yte != ho
R["known_test_top1"], R["known_test_top3"] = topk(Zte[mk], yte[mk], FP, 3)
W = F.normalize(ck["head"]["W"], dim=-1).numpy(); FPW = {c: W[i] for i, c in enumerate(known)}
R["known_test_top1_headweights"] = topk(Zte[mk], yte[mk], FPW, 3)[0]

# (2) few-shot add of the unseen disease
ho_tr = np.where(ytr == ho)[0]; res = {}
for K in [1, 5, 10, 20]:
    a_ho, a_all, a_known = [], [], []
    for seed in range(20):
        pick = np.random.default_rng(seed).choice(ho_tr, K, replace=False)
        fps = dict(FP); fps[ho] = norm(Ztr[pick].mean(0))
        ids = list(fps); M = np.stack([fps[c] for c in ids]); pred = np.array(ids)[(Zte @ M.T).argmax(1)]
        a_ho.append((pred[yte == ho] == ho).mean()); a_all.append((pred == yte).mean()); a_known.append((pred[mk] == yte[mk]).mean())
        # also score on the remaining held-out TRAIN photos (never trained on) for a bigger sample
        rest = np.setdiff1d(ho_tr, pick); pr = np.array(ids)[(Ztr[rest] @ M.T).argmax(1)]
        a_ho[-1] = ((pred[yte == ho] == ho).sum() + (pr == ho).sum()) / ((yte == ho).sum() + len(rest))
    res[K] = dict(new_disease_recall=float(np.mean(a_ho)), all_27_top1=float(np.mean(a_all)), known_top1_after_add=float(np.mean(a_known)))
R["few_shot_add"] = res

# (3) 'not sure' gate, calibrated on val (known only). Unknown = all photos of the never-seen disease.
Mk = np.stack([FP[c] for c in known])
sv = (Ztr[sp["val_idx"]] @ Mk.T).max(1)
unk = np.concatenate([Ztr[ho_tr], Zte[yte == ho]]) @ Mk.T
gate = {}
for keep in [0.80, 0.90, 0.95]:
    t = float(np.quantile(sv, 1 - keep))
    sk = Zte[mk] @ Mk.T; acc_mask = sk.max(1) >= t
    pred = np.array(known)[sk.argmax(1)]
    gate[f"keep{int(keep*100)}"] = dict(threshold=round(t, 3),
        known_answered=float(acc_mask.mean()), accuracy_when_answered=float((pred[acc_mask] == yte[mk][acc_mask]).mean()),
        unknown_flagged_not_sure=float((unk.max(1) < t).mean()))
R["not_sure_gate"] = gate
json.dump(R, open(f"{A}/results_fingerprints.json", "w"), indent=1)
ids = known + [ho]; full = dict(FP); full[ho] = norm(Ztr[ho_tr[:10]].mean(0))
np.save(f"{A}/fingerprints_base.npy", np.stack([FP[c] for c in known]).astype(np.float16))
json.dump([classes[c] for c in known], open(f"{A}/fingerprints_base.json", "w"), indent=1)
np.save(f"{A}/fp_new_disease.npy", full[ho].astype(np.float16))
print(json.dumps(R, indent=1))
