# Part 1 — Vision: fingerprint leaf doctor (2 GB-phone ready)

Trained in a CPU-only workspace on **PlantDoc** (real field photos, CC-BY-4.0, 27 classes, 13 crops)
starting from ImageNet MobileNetV3-Large. One disease (*Tomato yellow leaf curl virus*) was **never
shown in training**, so the "add a disease from 10 photos" test is a genuine one.

## What ships to the phone

| File | Size | What it is |
|---|---|---|
| `leaf_fp16.onnx` | 9.1 MB | Photo → 256-number "fingerprint" vector (4.5 M params) |
| `fingerprints_base.npy` + `.json` | 13 KB | One fingerprint per known disease |
| `*.kfp` KVK packs | ~1.8 KB per disease | Signed new-disease fingerprints, shared phone-to-phone |

Measured here: ~65 MB of RAM for the model and about 8 ms per photo on one server CPU thread.
A ₹7k phone will be several times slower, but should still be well under a second. That needs
confirming on a real phone.

## Results (held-out PlantDoc test set; numbers are noisy because the test set is small, about 230 photos)

- **Known diseases:** top-1 is **61.3%** and top-3 is **85.7%**. PlantDoc is hard: its original paper
  reports VGG16 at 19.7% and InceptionResNetV2 at 39.9% when trained only on lab images, and fine-tuning
  on PlantDoc improved accuracy by up to 31%. Because the right disease is in the top 3 about 86% of the
  time, the yes/no question engine (Part 2) is the planned way to close the gap from top-3 to top-1.
- **New disease added from 10 photos, with no retraining:** it is recognised **42.7%** of the time
  (chance is about 4%). Accuracy on the other diseases stays exactly the same (61.2%), so adding a
  disease doesn't break existing ones. With 20 photos it rises to 48.8%; with 1 photo it is only 10.6%.
- **"Not sure" gate** (threshold 0.586): the app answers 78% of photos and is right **71%** of the
  time when it does. It flags **47%** of photos of an unknown disease as "not sure". This gate is still
  weak and is the top item to improve.
- **Quantization:** standard int8 dropped top-1 to 49%, because MobileNetV3 is sensitive to int8.
  fp16 keeps the full accuracy at 9.1 MB, so fp16 ships for now. A good int8 version needs
  quantization-aware training on a GPU.
- **Signed packs:** a genuine pack is accepted. Packs are rejected if they were altered, signed by an
  unknown key, or made for a different model version (see `results_pack.json`).

**The demo shows why Part 2 matters** (`results_demo.txt`): after the KVK pack is installed, the new
virus appears at #2, just behind *mosaic virus*. A single question such as "are the leaves curling
upward with yellow edges?" should separate the two.

## Files
`prep.py` → `train.py` → `fingerprints.py` → `export.py` → `kvk_pack.py` → `infer.py` (reference logic the Android app mirrors).
`train_gpu.py` is the Colab/AWS version for Indian crops, with optional per-crop distillation from the
42-crop ConvNeXt models (CC-BY-4.0). Their checkpoint names were not inspected, because Hugging Face is
blocked here, so fill in `TEACHERS` first.

## Next for this part
1. Retrain on Indian crop data (rice, cotton, chilli, groundnut and others) on a GPU, with teacher distillation.
2. Use quantization-aware training to get a 5 MB int8 model.
3. Improve the "not sure" gate.
4. Benchmark on a real 2 GB Android phone.
5. Get native speakers to review the Hindi, Tamil and Kannada disease names in the demo pack.

Attribution: PlantDoc (Singh et al., 2019, CC-BY-4.0); MobileNetV3 ImageNet weights from timm (Apache-2.0).
