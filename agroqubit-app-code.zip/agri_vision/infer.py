"""Reference on-phone logic (the Android app mirrors this): photo -> embedding -> cosine vs fingerprints
(+ any verified KVK packs) -> top-3 candidates or 'not sure'. Location/season prior and the question
engine plug in on top of the top-3 list (next step)."""
import json, sys, numpy as np, onnxruntime as ort
from PIL import Image, ImageOps
from kvk_pack import verify_pack, model_id
A = "/home/claude/agri_vision"; NOT_SURE = 0.586   # calibrated: answers ~78% of known photos, ~71% correct when it answers

class LeafDoctor:
    def __init__(self, model=f"{A}/leaf_fp16.onnx"):
        so = ort.SessionOptions(); so.intra_op_num_threads = 2; so.enable_cpu_mem_arena = False
        self.s = ort.InferenceSession(model, so, providers=["CPUExecutionProvider"]); self.mid = model_id(model)
        self.F = np.load(f"{A}/fingerprints_base.npy").astype(np.float32)
        self.names = json.load(open(f"{A}/fingerprints_base.json"))
    def add_pack(self, blob, trusted):
        ok, why, ents = verify_pack(blob, trusted, self.mid)
        if ok:
            for e in ents: self.F = np.vstack([self.F, e["vector"]]); self.names.append(e["names"]["en"] + " [KVK]")
        return ok, why
    def embed(self, path):
        im = ImageOps.exif_transpose(Image.open(path)).convert("RGB"); w, h = im.size; s = min(w, h)
        im = im.crop(((w-s)//2, (h-s)//2, (w-s)//2+s, (h-s)//2+s)).resize((256, 256), Image.BICUBIC)
        x = np.asarray(im, np.float32)[16:240, 16:240].transpose(2, 0, 1)[None]
        z = self.s.run(None, {"image": x})[0][0] + self.s.run(None, {"image": x[..., ::-1].copy()})[0][0]
        return z / np.linalg.norm(z)
    def diagnose(self, paths):  # 1-3 photos of the same plant: fuse by averaging embeddings
        z = np.mean([self.embed(p) for p in paths], 0); z /= np.linalg.norm(z)
        sc = self.F @ z; o = np.argsort(-sc)[:3]
        top = [(self.names[i], round(float(sc[i]), 3)) for i in o]
        return {"status": "ok" if top[0][1] >= NOT_SURE else "not_sure", "top3": top}

if __name__ == "__main__":
    import glob
    from nacl.signing import SigningKey
    from kvk_pack import make_pack
    d = LeafDoctor(); root = "/home/claude/data/PlantDoc-Dataset/test"
    yv = sorted(glob.glob(f"{root}/Tomato leaf yellow virus/*"))[:3]; sep = sorted(glob.glob(f"{root}/Tomato Septoria leaf spot/*"))[:1]
    print("before pack, yellow-virus photo:", d.diagnose(yv[:1]))
    k = SigningKey.generate()  # demo KVK key; the real app ships the KVK public keys
    ents = [{"id": "tylcv", "crop": "tomato", "n_photos": 10,
             "names": {"en": "Tomato yellow leaf curl virus", "hi": "टमाटर पीला पत्ती मोड़क विषाणु",
                       "ta": "தக்காளி மஞ்சள் இலை சுருள் வைரஸ்", "kn": "ಟೊಮೆಟೊ ಹಳದಿ ಎಲೆ ಸುರುಳಿ ವೈರಸ್"},
             "vector": np.load(f"{A}/fp_new_disease.npy")}]
    blob = make_pack(k, "KVK Demo (test key)", d.mid, ents)
    print("untrusted install attempt:", d.add_pack(blob, {}))
    print("trusted install:", d.add_pack(blob, {k.verify_key.encode().hex()[:16]: k.verify_key.encode().hex()}))
    for p in yv: print("after pack, yellow-virus photo:", d.diagnose([p]))
    print("3-photo fusion, yellow-virus:", d.diagnose(yv))
    print("known disease (Septoria):", d.diagnose(sep))
