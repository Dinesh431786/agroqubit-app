| photo | true class (PlantDoc test) | Python (phone weights) | app on emulator | app score | ms | app reply |
|---|---|---|---|---|---|---|
| p00 | Bell_pepper leaf spot | Tomato Early blight leaf | Tomato Early blight leaf | 0.853 | 183 | looks like early blight → picture question |
| p01 | Corn rust leaf | Corn rust leaf | Corn rust leaf | 0.969 | 180 | "photo check is tomato-only" → crop question |
| p02 | Potato leaf late blight | Potato leaf early blight | Potato leaf early blight | 0.805 | 147 | tomato-only note → crop question |
| p03 | Tomato Early blight leaf | Tomato leaf bacterial spot | Tomato leaf bacterial spot | 0.419 | 190 | "photo not clear" → crop question |
| p04 | Tomato Early blight leaf | Tomato Early blight leaf | **Tomato leaf late blight** | 0.761 | 183 | looks like late blight → picture question |
| p05 | Tomato Septoria leaf spot | Bell_pepper leaf spot | Bell_pepper leaf spot | 0.587 | 163 | not clear → crop question |
| p06 | Tomato Septoria leaf spot | Tomato Septoria leaf spot | Tomato Septoria leaf spot | 0.907 | 185 | looks like septoria → picture question |
| p07 | Tomato leaf (healthy) | Tomato leaf | Tomato leaf | 0.704 | 186 | **diagnosis: healthy** |
| p08 | Tomato leaf (healthy) | Tomato leaf late blight | Tomato leaf late blight | 0.616 | 159 | not clear → crop question |
| p09 | Tomato leaf bacterial spot | Tomato Septoria leaf spot | **Tomato leaf bacterial spot** | 0.635 | 182 | not clear → crop question |
| p10 | Tomato leaf bacterial spot | Tomato leaf bacterial spot | Tomato leaf bacterial spot | 0.785 | 199 | **diagnosis: bacterial leaf spot** |
| p11 | Tomato leaf late blight | Tomato leaf late blight | Tomato leaf late blight | 0.885 | 188 | **diagnosis: late blight** |
| p12 | Tomato leaf late blight | Tomato leaf late blight | Tomato leaf late blight | 0.930 | 192 | **diagnosis: late blight** |
| p13 | Tomato leaf mosaic virus | Tomato leaf | Tomato leaf | 0.751 | 209 | looks healthy → picture question |
| p14 | Tomato leaf mosaic virus | Tomato leaf mosaic virus | Tomato leaf mosaic virus | 0.618 | 200 | not clear → crop question |
| p15 | Tomato leaf yellow virus | Tomato leaf mosaic virus | Tomato leaf mosaic virus | 0.808 | 205 | looks like mosaic → picture question |
| p16 | Tomato leaf yellow virus | Tomato mold leaf | **grape leaf black rot** | 0.474 | 176 | not clear → crop question |
| p17 | Tomato mold leaf | Tomato mold leaf | Tomato mold leaf | 0.632 | 199 | not clear → crop question |
| p18 | Tomato mold leaf | Tomato mold leaf | Tomato mold leaf | 0.680 | 203 | looks like leaf mould → picture question |
| p19 | grape leaf | grape leaf | grape leaf | 0.898 | 203 | tomato-only note → crop question |

Same answer as Python: 17/20. The 3 differences (bold) are near-ties caused by different image resizing (PIL bicubic vs Android bilinear). App correct 11/20 = Python correct 11/20.
