# Build and test results (one-time CPU VM, 11 Oct 2026)

There were two runs on the same day:

- **Full build** (`job.sh`, about 70 min): retrains everything from public data and renders every voice clip.
- **Quick rebuild** (`job_quick.sh`, about 20 min): reuses the voice clips and the photo model, then rebuilds and retests the APK.

The numbers below come from the latest APK, which is the quick rebuild.

## On the emulators

| Check | Android 11, 2 GB RAM | Android 7.0 |
|---|---|---|
| Install | OK | OK (`adb install --no-streaming`) |
| Cold start | 1.34 s | 0.49 s |
| Model load | 1.53 s on the first launch after install (0.46 s in the full-build run) | 0.10 s |
| Simulated farmers, compared with the Python reference | **100/100 conversations identical**, 72% right diagnosis, 0 errors | 12/12 identical, 8/12 right |
| Time per turn | mean 1.2 ms, max 33 ms | – |
| Photo diagnosis on the phone | 20 real PlantDoc test photos: **17/20 same answer as Python**, 11/20 correct (Python also 11/20), **147–209 ms per photo** | 6 photos: 5/6 same answer, 150–162 ms |
| Full spoken answers (closed-world voice) | hi 6 clips in 18.5 s, ta 6 in 24.9 s, kn 6 in 26.3 s, en 5 in 14.4 s; 0 errors | hi 6 in 17.5 s, en 5 in 13.5 s; 0 errors (Opus plays on Android 7) |
| Voice clips in the APK | 1,224 of 1,224 (2 voices × 612 sentences), 0 missing | same |
| Memory (PSS) | 88 MB after 20 photos; 133 MB after 100 conversations | 56 MB |
| Crashes | 0 | 0 |
| Microphone | Opens the system voice-typing screen. The emulator has no offline speech pack, so it asked for network. | – |
| Camera button | Opens the camera app with full-resolution output | – |

## Models and parity

| Part | Result |
|---|---|
| Text understanding (AL / DL) | single-meaning top-1 0.900 / 0.869 |
| Free chat (270 held-out questions) | 76.3% verified answer, 20% safe fallback, 3.3% wrong, **0 wrong doses** |
| Java vs Python | probabilities max \|diff\| 9.9e-7; 300/300 conversations (2,094 turns) identical; 4,819 voice clips played, 0 missing |
| Photo model (PlantDoc test set, phone int8 weights, single view) | known diseases top-1 60–62%, top-3 86%; tomato top-1 43–45%, top-3 74–78%; cosine vs fp32 0.997; **4.83 MB** |
| "Not sure" gate for photos | answers 79% of known photos and is right 69% of the time when it answers |
| Voice packs | 153 sentences × 4 languages × 2 voices; 11.5–16.9 min of speech per language; **12.9 MB** |

## APK size: 38.7 MB

| Part | Size |
|---|---|
| Text encoders, AL + DL (int8) | 14.3 MB |
| Free-chat intent model (int8) | 6.7 MB |
| Voice, female + male (1,224 Opus clips) | 12.9 MB |
| Photo model (int8 + fp16) | 4.8 MB |
| Knowledge base, advice, questions, picture tiles, code | about 0.5 MB |

Files: `emu_android11.json`, `emu_android7.json`, `photo_tests_android11.md`, `vision_check.json`, `voice_render_summary.json`, `java_parity.txt`, `progress_*.txt`.
