# Krishi Doctor (AgroQubit): offline crop doctor for 2 GB phones

Krishi Doctor is a one-screen chat app. A farmer can **type, speak or send a photo** in **Hindi, Tamil, Kannada or English**. Every answer is shown on screen and **spoken in a human voice**.

The app runs fully offline: no internet and no cloud. It never generates free text: every sentence it says is a verified fact from Government of India / state university sources (NIPHM / DPPQS, TNAU, ICAR institutes), with its source. When it is not sure, it sends the farmer to the KVK or the Kisan Call Centre, 1800-180-1551.

> **Status**
> - **Version 1** (tested APK): Bayesian diagnosis of 25 diseases of rice, tomato, chilli and groundnut, closed-world human voice, tomato photo model. Tested on 2 GB Android 11 and Android 7 emulators (results below).
> - **Version 2** (this code): LLM-style chat over a verified fact bank (fact-token model), our own voice model, our own offline speech recognizer and an Indian field-photo model for all four crops. All code is written and parity-tested here (Java == Python). Training and the accuracy numbers come from the training run (`krishi/android/tools/job_train.sh`: two CPU VMs, or one GPU VM), then the emulator run (`job_emu.sh`).
> - Field pilot, native-speaker review and agronomist review are the next steps (see *Honest limits*).

---

## What is new (details and sources in [RESEARCH.md](RESEARCH.md))

| Idea | What it gives |
|---|---|
| **Fact-token model** (v2). A small transformer whose output tokens are verified fact ids plus `<ASK>`, `<CONFIRM>`, `<WHICH_CROP>`, `<NOT_SURE>`. | Answers any farmer question like a chat model, combining facts, asking back or refusing, but it **cannot say an unverified sentence**. 13 MB int8, ~11 ms per question on one desktop core. |
| **Three locks on doses** (v2). Table rule + model gate + a deterministic local-name guard. | A chemical dose only after the farmer confirms the disease, and never when the question names another disease. |
| **Build-time teacher, phone-time students** (v2). Gemma 4 26B, Indic-TTS and Whisper run only on the build VM. | The phone gets small students and checked tables; every teacher fact must quote its source verbatim. |
| **Closed-world voice + our own voice model** (v1 + v2). Every known sentence is pre-rendered in a human voice; anything new is spoken by our 13 M-parameter voice model distilled from it. | Human voice for every answer, 0 ms for known sentences, still a voice for facts added later. |
| **Our own offline speech recognizer** (v2). Whisper-tiny fine-tuned in short mode, restricted vocabulary, pure Java. | Voice input on phones without Android's on-device recognizer. 5 s of speech in 1.6–2.2 s on one desktop core instead of 17 s. |
| **One belief for every input** (v1). Text, voice, taps and photos update one Bayesian belief; the next question is chosen by information gain. | Few questions per diagnosis, every step explainable. |
| **Photo model with no ML runtime** (v1, retrained in v2 on Indian field photos of all four crops). MobileNetV3 fingerprints in about 250 lines of Java. | 4.7 MB, same accuracy as fp32, loaded only when a photo arrives. Pest photos lead straight to that pest's facts. |

## Architecture (version 2)

```
 text ─────────────────────────────┐
 voice ─► phone recogniser (Android 12+) or our Whisper-tiny (Java) ─► text
                                   ▼
            fact-token model (Java): question + [crop, confirmed disease]
                 ├─ facts  ──► verified sentences in the farmer's language (+ source)
                 ├─ <ASK>  ──► Bayesian diagnosis: questions by information gain ◄── taps, photo prior
                 ├─ <CONFIRM> ► "Is it <disease>?"  (doses only after yes)
                 ├─ <WHICH_CROP> ► "Which crop?"
                 └─ <NOT_SURE> ► KVK / Kisan Call Centre 1800-180-1551
 photo ─► MobileNetV3 fingerprints (Java, int8) ─► crop + disease / pest / healthy / other crop
                                   ▼
        answer = clip ids ─► human-voice clip, or our own voice model (Java) for sentences without a clip
```

## Results

**Version 1 APK** (emulators, details in [results/RESULTS.md](results/RESULTS.md)):

| | Android 11, 2 GB RAM | Android 7 |
|---|---|---|
| APK | 38.7 MB, no ML runtime | same APK |
| Cold start / model load | 1.3 s / 0.5–1.5 s | 0.5 s / 0.1 s |
| Chat turn | 1.2 ms on average | – |
| Photo diagnosis on the phone | **150–210 ms per photo**; 17/20 same answer as the Python model | 150–162 ms |
| Spoken answers | every reply spoken in full (4 languages), 0 playback errors | 0 errors |
| Simulated farmers, 25 diseases × 4 languages | 100/100 identical to the Python reference, **72% right diagnosis** | 12/12 identical |
| Memory (PSS) | 88–133 MB | 56 MB |
| Crashes | 0 | 0 |

**Version 2, checked in this workspace** (CPU, no GPU):

| Check | Result |
|---|---|
| Fact-token model, Java vs PyTorch (52 hard questions × 3 models) | identical answers 52/52; max logit difference 5e-6 |
| Chat in Java vs Python (simulated conversations) | 120/120 identical (seed facts); 80/80 with a rehearsal bank of new pests and facts; every spoken sentence has a clip |
| Own voice model, Java vs PyTorch | mel difference 1.7e-6; real-time factor 0.34 on one desktop core |
| Whisper-tiny, Java vs transformers | greedy tokens 11/11 and transcriptions 9/9 identical |
| Photo turn, Java vs Python | 6/6 same label |
| Fact pipeline tests (mock teacher) | 15/15 unit, 61/61 end-to-end checks |
| Independent test, 160 hand-written questions | seed-only model 42.5% (the 75 seed facts cover 8 of 122 fact questions); **0 wrong doses** |

**Version 2, from the training and emulator runs:** fact-model accuracy on the 160 independent questions, per-crop photo accuracy, speech recognizer CER on real speakers, voice quality vs the teacher, and on-phone speed and memory. They are added to `results/` when the run finishes.

## Repository layout

| Path | What |
|---|---|
| `krishi/android/src` | Java core: Chat, FactLM, Doctor (Bayesian engine), Brain, TextModel, Vision, Speak (voice model), Whisper + Listen (speech), Nn/Krw (shared kernels and weights), Krishi (loader) |
| `krishi/android/app` | One-screen chat app (MainActivity, PhotoProvider, manifest) |
| `krishi/android/tools` | `job_train.sh` (training on CPU or GPU VMs), `job_gpu.sh` (the same on one GPU VM), `job_emu.sh` (APK + emulator VM), `build_apk.sh` (no Gradle), `emu_test.py`, exporters |
| `krishi/android/test` | Java vs Python parity tests: chat, fact model, voice, Whisper, photos, kernels |
| `krishi/facts` | verified fact bank pipeline: fetch, extract (quote checks), translate, merge, local names, lexicon, questions |
| `krishi/factlm` | fact-token model: training, export, evaluation, independent test |
| `krishi/voice` | closed-world voice (`closed_world.py`, `verbalize.py`, `render_segments.py`) and our own voice model (`student/`) |
| `krishi/speech/whisper` | Whisper-tiny selection, short-mode fine-tuning, export |
| `krishi/vision2` | Indian field-photo data, training and export |
| `krishi/brain`, `krishi/freechat`, `krishi/text` | Python reference models and training |
| `agri_vision`, `agri_reason/v2` | v1 photo model training, knowledge base (25 diseases, symptom table, sources) |
| `results/` | emulator, parity and model results |
| `release/` | how to get and install the test APK |

## Build everything from scratch

1. **Training** with `krishi/android/tools/job_train.sh`. It builds the fact bank with the teacher LLM, trains the fact-token model, the photo model, our voice model and the speech recognizers, renders the voice clips, and uploads the app assets. Two ways:
   - **CPU only, two VMs at the same time:** `ROLE=main CPU=1` on a c8i.8xlarge (teacher LLM with llama.cpp, fact-token model, photo model, voice clips; about 20–24 h, resumes from S3 after a spot interruption) and `ROLE=voice CPU=1` on a c8i.2xlarge (speech recognizer and our voice model; about 12 h).
   - **One GPU VM** (g6.xlarge, NVIDIA L4, about 14–16 h): `job_gpu.sh`, the same job with `ROLE=all CPU=0`.
2. **CPU VM with nested virtualization** (c8i.2xlarge, about 2 h): `krishi/android/tools/job_emu.sh` runs the Java/Python parity tests on the trained models, builds the APK (all languages, and one per language) with aapt2 / javac / d8 / apksigner, and tests it on 2 GB Android 11 and Android 7 emulators.

Every VM shuts itself down at the end and has a hard time cap.

## Honest limits

- **Facts need review.** Teacher facts pass verbatim-quote and number checks, but an agronomist must review them (doses first) before release. Translations and local names need native speakers.
- **Source terms.** NIPHM packages are marked for internal circulation and ICAR asks for permission to reproduce its content. Get written permission before a public or commercial release (DATASETS.md section 10).
- **Voice.** Clips use AI4Bharat Indic-TTS with our colloquial rewrites; our own voice model is distilled from it. Native speakers still need to review pronunciation and tone.
- **Speech input** is tested on read speech (FLEURS) and teacher voices, not yet on farmers in fields.
- **Own voice model on CPU.** A CPU-only run trains our voice model for far fewer steps than a GPU run, so it sounds worse. It is only the fallback for sentences without a human clip; every known sentence is a human-voice clip.
- **Photos** come from public datasets; a KVK field pilot is the real test.
- **v1 end-to-end numbers are simulated** from the same symptom table the engine uses, so they are optimistic.

## Licences of third-party parts

- Gemma 4 (teacher, build time only): Apache-2.0.
- AI4Bharat Indic-TTS checkpoints: MIT. OpenAI Whisper: MIT. Open Whisper-tiny fine-tunes: licence checked per checkpoint.
- Google FLEURS: CC-BY-4.0. PlantDoc photos: CC-BY-4.0 (Singh et al., 2019). AgML field-photo mirrors: licence read from each dataset card, open licences only.
- MobileNetV3 ImageNet weights: timm, Apache-2.0.
- Advice content: Government of India and state sources (NIPHM / DPPQS, TNAU, ICAR institutes), cited per fact.
